from urllib.parse import quote, urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from routing import Plugin

from resources.lib.core.addon_runtime import addon_installed as _addon_installed_impl
from resources.lib.core.addon_runtime import (
    torrent_player_route as _torrent_player_route_impl,
)
from resources.lib.core.debrid_auth import (
    alldebrid_pin_authorize as _alldebrid_pin_authorize_impl,
)
from resources.lib.core.debrid_provider_config import (
    migrate_legacy_debrid_settings as _migrate_legacy_debrid_settings,
)
from resources.lib.core.external_scrapers import (
    external_scraper_candidates as _external_scraper_candidates_impl,
)
from resources.lib.core.metadata_cache import clean_title as _clean_title_impl
from resources.lib.core.metadata_cache import (
    clear_omdb_cache_file as _clear_omdb_cache_file_impl,
    omdb_empty_metadata as _omdb_empty_metadata_impl,
)
from resources.lib.core.metadata_cache import omdb_search_art as _omdb_search_art_impl
from resources.lib.core.metadata_runtime import (
    omdb_search_art_bridge as _omdb_search_art_bridge,
)
from resources.lib.core.metadata_runtime import (
    tmdb_id_details_bridge as _tmdb_id_details_bridge,
)
from resources.lib.core.metadata_runtime import (
    tmdb_search_art_by_id_bridge as _tmdb_search_art_by_id_bridge,
)
from resources.lib.core.metadata_settings import (
    external_scrapers_timeout as _external_scrapers_timeout_impl,
)
from resources.lib.core.metadata_settings import (
    metadata_fallback_fanart as _metadata_fallback_fanart_impl,
)
from resources.lib.core.metadata_settings import (
    metadata_priority as _metadata_priority_impl,
)
from resources.lib.core.metadata_settings import (
    metadata_timeout as _metadata_timeout_impl,
)
from resources.lib.core.metadata_settings import (
    trakt_results_limit as _trakt_results_limit_impl,
)
from resources.lib.core.metadata_settings import (
    trakt_title_with_year as _trakt_title_with_year_impl,
)
from resources.lib.core.metadata_tmdb import tmdb_id_details as _tmdb_id_details_impl
from resources.lib.core.metadata_tmdb import (
    tmdb_search_art_by_id as _tmdb_search_art_by_id_impl,
)
from resources.lib.core.language_prefs import tmdb_language_param as _tmdb_language_param
from resources.lib.core.network import json_get as _json_get_impl
from resources.lib.core.network import json_post as _json_post_impl
from resources.lib.core.omdb_tmdb_settings import omdb_api_key as _omdb_api_key_impl
from resources.lib.core.omdb_tmdb_settings import omdb_enabled as _omdb_enabled_impl
from resources.lib.core.omdb_tmdb_settings import (
    omdb_external_ratings_enabled as _omdb_external_ratings_enabled_impl,
)
from resources.lib.core.omdb_tmdb_settings import tmdb_api_key as _tmdb_api_key_impl
from resources.lib.core.omdb_tmdb_settings import tmdb_enabled as _tmdb_enabled_impl
from resources.lib.core.provider_context import (
    get_enabled_providers as _get_enabled_providers_impl,
)
from resources.lib.core.provider_context import (
    get_stremio_provider as _get_stremio_provider_impl,
)
from resources.lib.core.provider_context import (
    get_trakt_search_provider as _get_trakt_search_provider_impl,
)
from resources.lib.core.request_runtime import (
    play_result_id_from_request_bridge as _play_result_id_from_request_bridge,
)
from resources.lib.core.request_runtime import (
    query_arg_first_str_bridge as _query_arg_first_str_bridge,
)

# Imports extensos (rutas → impl → bridges); orden estable para diffs.
from resources.lib.core.route_args import (
    play_result_id_from_request as _route_play_result_id_from_request,
)
from resources.lib.core.route_args import (
    query_arg_first_str as _route_query_arg_first_str,
)
from resources.lib.core.runtime_context import (
    build_runtime_context as _build_runtime_context,
)
from resources.lib.core.runtime_misc import (
    external_scraper_candidates_bridge as _external_scraper_candidates_bridge,
)
from resources.lib.core.runtime_misc import (
    omdb_external_ratings_label2_extra as _omdb_external_ratings_label2_extra_impl,
)
from resources.lib.core.runtime_misc import (
    resolve_trakt_episode_stream_bridge as _resolve_trakt_episode_stream_bridge,
)
from resources.lib.core.runtime_misc import (
    resolve_trakt_result_bridge as _resolve_trakt_result_bridge,
)
from resources.lib.core.scraper_runtime import (
    load_scraper_module as _load_scraper_module_impl,
)
from resources.lib.core.search_history import (
    search_history_add as _search_history_add,
)
from resources.lib.core.search_history import (
    search_history_last as _search_history_last,
)
from resources.lib.core.search_history import (
    search_history_load as _search_history_load,
)
from resources.lib.core.search_history import (
    search_history_save as _search_history_save,
)
from resources.lib.core.search_history import (
    search_history_token_read as _search_history_token_read,
)
from resources.lib.core.settings_helpers import (
    get_bool_setting as _get_bool_setting_impl,
)
from resources.lib.core.settings_helpers import get_int_setting as _get_int_setting_impl
from resources.lib.core.settings_helpers import get_setting as _get_setting_impl
from resources.lib.core.settings_helpers import set_setting as _set_setting_impl
from resources.lib.core.source_context import (
    build_source_context as _build_source_context,
)
from resources.lib.core.source_runtime import (
    language_bucket_for_item_bridge as _language_bucket_for_item_bridge,
)
from resources.lib.core.source_runtime import (
    normalize_language_label_bridge as _normalize_language_label_bridge,
)
from resources.lib.core.source_runtime import (
    pick_stream_dialog_bridge as _pick_stream_dialog_bridge,
)
from resources.lib.core.source_runtime import (
    pick_stream_url_silent_bridge as _pick_stream_url_silent_bridge,
)
from resources.lib.core.stremio_config import (
    get_stremio_toggle_names as _get_stremio_toggle_names_impl,
)
from resources.lib.core.stremio_config import (
    stremio_addons_config as _stremio_addons_config_impl,
)
from resources.lib.core.tv_tokens import tv_catalog_token_dict as _tv_catalog_token_dict
from resources.lib.core.tv_tokens import tv_catalog_token_read as _tv_catalog_token_read
from resources.lib.core.web_link_scrapers import (
    web_link_provider_candidates as _web_link_provider_candidates_impl,
)
from resources.lib.routes.actor_routes_bundle import (
    run_actor_listing_route as _run_actor_listing_route,
)
from resources.lib.routes.actor_routes_bundle import (
    run_actor_person_route as _run_actor_person_route,
)
from resources.lib.routes.browse_year_genre_routes import (
    run_browse_tmdb_genre_list as _run_browse_tmdb_genre_list,
)
from resources.lib.routes.browse_year_genre_routes import (
    run_browse_tmdb_genres_menu as _run_browse_tmdb_genres_menu,
)
from resources.lib.routes.browse_year_genre_routes import (
    run_browse_tmdb_platform_list as _run_browse_tmdb_platform_list,
)
from resources.lib.routes.browse_year_genre_routes import (
    run_browse_tmdb_platforms_menu as _run_browse_tmdb_platforms_menu,
)
from resources.lib.routes.browse_year_genre_routes import (
    run_browse_tmdb_year_list as _run_browse_tmdb_year_list,
)
from resources.lib.routes.browse_year_genre_routes import (
    run_browse_tmdb_years_menu as _run_browse_tmdb_years_menu,
)
from resources.lib.routes.browse_year_genre_routes import (
    run_browse_trakt_genre_list as _run_browse_trakt_genre_list,
)
from resources.lib.routes.browse_year_genre_routes import (
    run_browse_trakt_genres_menu as _run_browse_trakt_genres_menu,
)
from resources.lib.routes.browse_year_genre_routes import (
    run_browse_trakt_year_list as _run_browse_trakt_year_list,
)
from resources.lib.routes.browse_year_genre_routes import (
    run_browse_trakt_years_menu as _run_browse_trakt_years_menu,
)
from resources.lib.providers.stremio_catalog import (
    clear_stremio_manifest_session_cache as _clear_stremio_manifest_session_impl,
)
from resources.lib.routes.kraken_tools_routes import (
    noop_end_directory as _kraken_tools_noop_end,
    run_kraken_maintenance_confirm_and_run as _run_kraken_maintenance_confirm,
)
from resources.lib.routes.kraken_tools_routes import (
    run_kraken_maintenance_menu as _run_kraken_maintenance_menu,
)
from resources.lib.routes.kraken_tools_routes import (
    run_kraken_tools_hub as _run_kraken_tools_hub,
)
from resources.lib.routes.kraken_tools_routes import (
    run_kraken_tools_show_changelog as _run_kraken_tools_changelog,
)
from resources.lib.routes.kraken_tools_routes import (
    run_kraken_tools_tail_kodi_log as _run_kraken_tools_logtail,
)
from resources.lib.routes.kraken_tools_routes import (
    run_kraken_views_menu as _run_kraken_views_menu,
)
from resources.lib.routes.kraken_tools_routes import (
    run_kraken_views_pick_profile as _run_kraken_views_pick,
)
from resources.lib.routes.kraken_tools_routes import (
    run_kraken_kodi_library_action as _run_kraken_kodi_library_action,
)
from resources.lib.routes.kraken_tools_routes import (
    run_kraken_open_kodi_addon_settings as _run_kraken_open_kodi_addon_settings,
)
from resources.lib.stremio.logo_assets import clear_cached_logos as _clear_cached_logos_impl
from resources.lib.routes.catalog_routes_bundle import run_root_route as _run_root_route
from resources.lib.routes.catalog_routes_bundle import (
    run_tv_browse_channel_route as _run_tv_browse_channel_route,
)
from resources.lib.routes.catalog_routes_bundle import (
    run_tv_browse_route as _run_tv_browse_route,
)
from resources.lib.routes.catalog_routes_bundle import (
    run_tv_browse_search_route as _run_tv_browse_search_route,
)
from resources.lib.routes.catalog_routes_bundle import (
    run_tv_pais_categorias_route as _run_tv_pais_categorias_route,
)
from resources.lib.routes.debrid_routes import (
    run_debrid_provider_connect as _run_debrid_provider_connect,
)
from resources.lib.routes.debrid_routes import (
    run_debrid_provider_disconnect as _run_debrid_provider_disconnect,
)
from resources.lib.routes.debrid_routes import (
    run_debrid_provider_show_info as _run_debrid_provider_show_info,
)
from resources.lib.routes.debrid_routes import (
    run_debrid_provider_test as _run_debrid_provider_test,
)
from resources.lib.routes.download_routes import (
    run_download_episode as _run_download_episode,
)
from resources.lib.routes.download_routes import (
    run_download_movie as _run_download_movie,
)
from resources.lib.routes.download_routes import (
    run_download_season as _run_download_season,
)
from resources.lib.routes.download_routes import run_download_show as _run_download_show
from resources.lib.routes.download_routes import (
    run_downloads_active as _run_downloads_active,
)
from resources.lib.routes.download_routes import run_downloads_hub as _run_downloads_hub
from resources.lib.routes.download_routes import (
    run_downloads_list as _run_downloads_list,
)
from resources.lib.routes.kraken_mobile_web_routes import (
    run_kraken_mobile_web_start as _run_kraken_mobile_web_start,
)
from resources.lib.routes.kraken_mobile_web_routes import (
    run_kraken_mobile_web_stop as _run_kraken_mobile_web_stop,
)
from resources.lib.routes.navigation_routes import (
    run_accounts_status_route as _run_accounts_status_route,
)
from resources.lib.routes.navigation_routes import run_noop as _run_noop
from resources.lib.routes.navigation_routes import (
    run_providers_check_route as _run_providers_check_route,
)
from resources.lib.routes.navigation_routes import (
    run_providers_view_route as _run_providers_view_route,
)
from resources.lib.routes.navigation_routes import (
    run_settings_route as _run_settings_route,
)
from resources.lib.routes.navigation_routes import (
    run_stremio_open_all_configs_route as _run_stremio_open_all_configs_route,
)
from resources.lib.routes.navigation_routes import (
    run_stremio_open_config_route as _run_stremio_open_config_route,
)
from resources.lib.routes.play_routes import run_play as _run_play
from resources.lib.routes.playback_routes_bundle import (
    run_play_episode_route as _run_play_episode_route,
)
from resources.lib.routes.playback_routes_bundle import (
    run_play_route as _run_play_route,
)
from resources.lib.routes.playback_routes_bundle import (
    run_show_episodes_route as _run_show_episodes_route,
)
from resources.lib.routes.playback_routes_bundle import (
    run_show_seasons_route as _run_show_seasons_route,
)
from resources.lib.routes.prefetch_routes import (
    run_trakt_prefetch_next as _run_trakt_prefetch_next,
)
from resources.lib.routes.provider_routes import (
    run_lite_link_providers_list as _run_lite_link_providers_list,
)
from resources.lib.routes.provider_routes import (
    run_lite_urls_reset as _run_lite_urls_reset,
)
from resources.lib.routes.provider_routes import (
    run_providers_check as _run_providers_check,
)
from resources.lib.routes.provider_routes import (
    run_providers_view as _run_providers_view,
)
from resources.lib.routes.root_routes import run_anime_menu as _run_anime_menu
from resources.lib.routes.root_routes import run_movies_menu as _run_movies_menu
from resources.lib.routes.root_routes import run_root as _run_root
from resources.lib.routes.root_routes import run_series_menu as _run_series_menu
from resources.lib.routes.search_history_routes import (
    run_search_history as _run_search_history,
)
from resources.lib.routes.search_history_routes import (
    run_search_history_clear as _run_search_history_clear,
)
from resources.lib.routes.search_history_routes import (
    run_search_history_delete as _run_search_history_delete,
)
from resources.lib.routes.search_history_routes import (
    run_search_history_run as _run_search_history_run,
)
from resources.lib.routes.search_routes import (
    run_actor_listing_entry as _run_actor_listing_entry,
)
from resources.lib.routes.search_routes import (
    run_actor_person_entry as _run_actor_person_entry,
)
from resources.lib.routes.search_routes import run_search_folder as _run_search_folder
from resources.lib.routes.search_routes import run_simple_search as _run_simple_search
from resources.lib.routes.search_routes_bundle import (
    run_search_folder_route as _run_search_folder_route,
)
from resources.lib.routes.search_routes_bundle import (
    run_search_history_clear_route as _run_search_history_clear_route,
)
from resources.lib.routes.search_routes_bundle import (
    run_search_history_delete_route as _run_search_history_delete_route,
)
from resources.lib.routes.search_routes_bundle import (
    run_search_history_route as _run_search_history_route,
)
from resources.lib.routes.search_routes_bundle import (
    run_search_history_run_route as _run_search_history_run_route,
)
from resources.lib.routes.search_routes_bundle import (
    run_simple_search_route as _run_simple_search_route,
)
from resources.lib.routes.settings_routes import run_settings as _run_settings_menu
from resources.lib.routes.source_repick_routes import (
    run_source_repick as _run_source_repick,
)
from resources.lib.routes.sources_stremio_routes import (
    run_sources_stremio_hub as _run_sources_stremio_hub,
)
from resources.lib.routes.status_routes import (
    run_accounts_status as _run_accounts_status,
)
from resources.lib.routes.status_routes import (
    run_stremio_open_all_configs as _run_stremio_open_all_configs,
)
from resources.lib.routes.stremio_autostart import (
    SETTING_FIRST_RUN_DONE as _SETTING_FIRST_RUN_DONE,
)
from resources.lib.routes.stremio_autostart import (
    apply_stremio_autostart_defaults as _apply_stremio_autostart_defaults,
)
from resources.lib.routes.stremio_autostart import (
    ensure_stremio_ready_for_search as _ensure_stremio_ready_for_search,
)
from resources.lib.routes.stremio_check_routes import (
    run_stremio_manifest_check as _run_stremio_manifest_check,
)
from resources.lib.routes.stremio_routes import (
    run_stremio_open_config as _run_stremio_open_config,
)
from resources.lib.routes.trakt_auth_routes import (
    run_trakt_authorize as _run_trakt_authorize,
)
from resources.lib.routes.trakt_auth_routes import run_trakt_logout as _run_trakt_logout
from resources.lib.routes.trakt_discover_routes import (
    run_trakt_discover_movie_list as _run_trakt_discover_movie_list,
)
from resources.lib.routes.trakt_discover_routes import (
    run_trakt_discover_show_list as _run_trakt_discover_show_list,
)
from resources.lib.routes.trakt_progress_routes import (
    run_movies_in_progress as _run_movies_in_progress,
)
from resources.lib.routes.trakt_progress_routes import (
    run_movies_random_recent as _run_movies_random_recent,
)
from resources.lib.routes.trakt_progress_routes import (
    run_movies_related_recent as _run_movies_related_recent,
)
from resources.lib.routes.trakt_progress_routes import (
    run_series_in_progress as _run_series_in_progress,
)
from resources.lib.routes.trakt_progress_routes import (
    run_series_in_progress_choice as _run_series_in_progress_choice,
)
from resources.lib.routes.trakt_progress_routes import (
    run_series_random_recent as _run_series_random_recent,
)
from resources.lib.routes.trakt_progress_routes import (
    run_series_related_recent as _run_series_related_recent,
)
from resources.lib.routes.trakt_routes_bundle import (
    run_trakt_authorize_route as _run_trakt_authorize_route,
)
from resources.lib.routes.trakt_routes_bundle import (
    run_trakt_logout_route as _run_trakt_logout_route,
)
from resources.lib.routes.trakt_routes_bundle import (
    run_trakt_movies_in_progress_route as _run_trakt_movies_in_progress_route,
)
from resources.lib.routes.trakt_routes_bundle import (
    run_trakt_movies_random_recent_route as _run_trakt_movies_random_recent_route,
)
from resources.lib.routes.trakt_routes_bundle import (
    run_trakt_movies_related_recent_route as _run_trakt_movies_related_recent_route,
)
from resources.lib.routes.trakt_routes_bundle import (
    run_trakt_prefetch_next_route as _run_trakt_prefetch_next_route,
)
from resources.lib.routes.trakt_routes_bundle import (
    run_trakt_series_in_progress_route as _run_trakt_series_in_progress_route,
)
from resources.lib.routes.trakt_routes_bundle import (
    run_trakt_series_random_recent_route as _run_trakt_series_random_recent_route,
)
from resources.lib.routes.trakt_routes_bundle import (
    run_trakt_series_related_recent_route as _run_trakt_series_related_recent_route,
)
from resources.lib.routes.trakt_show_routes import run_play_episode as _run_play_episode
from resources.lib.routes.trakt_show_routes import (
    run_show_episodes as _run_show_episodes,
)
from resources.lib.routes.trakt_show_routes import run_show_seasons as _run_show_seasons
from resources.lib.routes.tv_routes import run_tv_browse as _run_tv_browse
from resources.lib.routes.tv_routes import (
    run_tv_browse_channel as _run_tv_browse_channel,
)
from resources.lib.routes.tv_routes import run_tv_browse_search as _run_tv_browse_search
from resources.lib.routes.tv_routes import (
    run_tv_pais_categorias as _run_tv_pais_categorias,
)
from resources.lib.sources.next_episode import (
    trakt_next_episode_pair as _trakt_next_episode_pair_impl,
)
from resources.lib.sources.resolver_progress import RESOLVER_PROGRESS_PHASE
from resources.lib.sources.resolver_progress import (
    quality_counts_colored as _quality_counts_colored_impl,
)
from resources.lib.sources.resolver_progress import (
    resolver_progress_detail as _resolver_progress_detail_impl,
)
from resources.lib.sources.search_cache import (
    cache_search_results as _cache_search_results_impl,
)
from resources.lib.sources.search_cache import (
    is_playable_stream_url as _is_playable_stream_url_impl,
)
from resources.lib.sources.source_language import (
    finalize_stream_language as _finalize_stream_language_impl,
)
from resources.lib.sources.source_language import (
    language_bucket_for_item as _language_bucket_for_item_impl,
)
from resources.lib.sources.source_language import language_flag as _language_flag_impl
from resources.lib.sources.source_language import (
    language_section_title as _language_section_title_impl,
)
from resources.lib.sources.source_language import (
    normalize_language_label as _normalize_language_label_impl,
)
from resources.lib.sources.source_language import (
    source_sort_key_with_language as _source_sort_key_with_language_impl,
)
from resources.lib.sources.source_picker import (
    candidates_deduped_for_picker as _candidates_deduped_for_picker_impl,
)
from resources.lib.sources.source_picker import (
    pick_stream_url_silent as _pick_stream_url_silent_impl,
)
from resources.lib.sources.source_presenter import (
    pretty_source_line as _pretty_source_line_impl,
)
from resources.lib.sources.source_presenter import source_label as _source_label_impl
from resources.lib.sources.source_ranking import compact_origin as _compact_origin_impl
from resources.lib.sources.source_ranking import (
    normalize_quality as _normalize_quality_impl,
)
from resources.lib.sources.source_ranking import quality_rank as _quality_rank_impl
from resources.lib.sources.source_ranking import (
    sources_order_priority as _sources_order_priority_impl,
)
from resources.lib.sources.source_selector import (
    autoplay_url_by_language_priority as _autoplay_url_by_language_priority_impl,
)
from resources.lib.sources.source_selector import (
    source_selector_style as _source_selector_style_impl,
)
from resources.lib.trakt.actor_runtime import (
    run_actor_credits_search as _run_actor_credits_search,
)
from resources.lib.trakt.actor_runtime import (
    run_actor_people_listing_and_open as _run_actor_people_listing_and_open,
)
from resources.lib.trakt.actor_search import (
    search_movies_shows_by_actor_credits as _search_actor_credits_impl,
)
from resources.lib.trakt.actor_search import (
    search_movies_shows_by_actor_people_listing as _search_actor_people_listing_impl,
)
from resources.lib.trakt.fallback_search import (
    search_fallback_media as _search_fallback_media_impl,
)
from resources.lib.trakt.resolver import (
    resolve_trakt_episode_stream as _resolve_trakt_episode_stream_impl,
)
from resources.lib.trakt.resolver import (
    resolve_trakt_result as _resolve_trakt_result_impl,
)
from resources.lib.trakt.search_bridge import (
    search_trakt_media_bridge as _search_trakt_media_bridge,
)
from resources.lib.trakt.search_flow import (
    search_trakt_media as _search_trakt_media_impl,
)
from resources.lib.trakt.search_listing_token import (
    decode_search_listing_token as _decode_search_listing_token,
)
from resources.lib.trakt.search_listing import (
    add_trakt_search_listing_to_directory as _add_trakt_search_listing_to_directory_impl,
)
from resources.lib.trakt.search_listing import (
    enrich_trakt_result_items_with_metadata as _enrich_trakt_result_items_with_metadata_impl,
)
from resources.lib.trakt.trakt_context import (
    parse_trakt_compound_id as _parse_trakt_compound_id_impl,
)
from resources.lib.trakt.trakt_context import (
    source_order_rank as _source_order_rank_impl,
)
from resources.lib.trakt.trakt_context import (
    stremio_source_is_tv_only as _stremio_source_is_tv_only_impl,
)
from resources.lib.trakt.trakt_context import (
    trakt_progress_translator as _trakt_progress_translator_impl,
)
from resources.lib.trakt.trakt_http import trakt_authed_get as _trakt_authed_get_impl
from resources.lib.trakt.trakt_http import (
    trakt_authed_get_with_refresh as _trakt_authed_get_with_refresh_impl,
)
from resources.lib.trakt.trakt_http import trakt_get as _trakt_get_impl
from resources.lib.trakt.trakt_http import trakt_is_ready as _trakt_is_ready_impl
from resources.lib.trakt.trakt_http import trakt_post as _trakt_post_impl
from resources.lib.trakt.trakt_http import trakt_public_get as _trakt_public_get_impl
from resources.lib.trakt.trakt_meta import (
    format_trakt_vote_count as _format_trakt_vote_count,
)
from resources.lib.trakt.trakt_meta import (
    trakt_float_or_none as _trakt_float_or_none,
)
from resources.lib.trakt.trakt_meta import (
    trakt_list_label1_with_year_rating as _trakt_list_label1_with_year_rating,
)
from resources.lib.trakt.trakt_meta import (
    trakt_parse_year as _trakt_parse_year,
)
from resources.lib.trakt.trakt_meta import (
    trakt_rating_label2_extra as _trakt_rating_label2_extra,
)
from resources.lib.trakt.trakt_meta import (
    trakt_title_with_year_rating_plain as _trakt_title_with_year_rating_plain,
)
from resources.lib.trakt.trakt_progress_format import (
    progress_percent_text as _progress_percent_text,
)
from resources.lib.trakt.trakt_progress_format import safe_votes_str as _safe_votes_str
from resources.lib.trakt.trakt_progress_helpers import (
    trakt_listitem_set_info_and_videotag as _trakt_listitem_set_info_and_videotag,
)
from resources.lib.trakt.trakt_progress_helpers import (
    trakt_year_from_movie_dict as _trakt_year_from_movie_dict,
)
from resources.lib.ui.source_dialog import (
    pick_stream_dialog as _pick_stream_dialog_impl,
)
from resources.lib.ui.listing_skin_hooks import install as _install_listing_skin_hooks
from resources.lib.ui.ui_helpers import (
    apply_directory_style as _apply_directory_style_impl,
    default_list_art as _default_list_art_impl,
    kraken_progress as _kraken_progress_impl,
    _t,
)


def _kraken_ui_dialog_classes():
    cached = getattr(_kraken_ui_dialog_classes, "_cache", None)
    if cached is None:
        from resources.lib.ui.ui_dialogs import KrakenQrDialog as _Qr
        from resources.lib.ui.ui_dialogs import KrakenSourcesDialog as _Sources

        cached = {
            "qr": _Qr,
            "sources": _Sources,
        }
        _kraken_ui_dialog_classes._cache = cached
    return cached


plugin = Plugin()
ADDON = xbmcaddon.Addon()
_install_listing_skin_hooks(lambda k: _get_setting_impl(ADDON, k))
TRAKT_CLIENT_ID = "1038ef327e86e7f6d39d80d2eb5479bff66dd8394e813c5e0e387af0f84d89fb"
TRAKT_CLIENT_SECRET = "8d27a92e1d17334dae4a0590083a4f26401cb8f721f477a79fd3f218f8534fd1"
PEERFLIX_WEB_URL = "https://config.peerflix.mov/"
DEFAULT_STREMIO_TVVOO_MANIFEST = "https://tvvoo.hayd.uk/manifest.json"
_STREMIO_OPEN_ALL_PEERFLIX = "__kraken_peerflix_web__"
OMDB_CACHE_TTL_SECONDS = 7 * 24 * 60 * 60
OMDB_CACHE_MAX_ITEMS = 500
TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p/w500"
TMDB_BACKDROP_BASE = "https://image.tmdb.org/t/p/w780"
CONTENT_PANEL_TEXTURE = (
    "special://home/addons/plugin.video.kraken/resources/art/ContentPanel.png"
)
_SEARCH_RESULT_CACHE = {}


def _kraken_addon_icon():
    try:
        return ADDON.getAddonIcon() or ""
    except Exception:
        return ""


def _kraken_clear_ram_search():
    try:
        _SEARCH_RESULT_CACHE.clear()
    except Exception:
        pass


_runtime_ctx = _build_runtime_context(
    addon=ADDON,
    trakt_client_id=TRAKT_CLIENT_ID,
    trakt_client_secret=TRAKT_CLIENT_SECRET,
    stremio_open_all_peerflix=_STREMIO_OPEN_ALL_PEERFLIX,
    get_bool_setting_impl=_get_bool_setting_impl,
    get_setting_impl=_get_setting_impl,
    get_int_setting_impl=_get_int_setting_impl,
    set_setting_impl=_set_setting_impl,
    get_enabled_providers_impl=_get_enabled_providers_impl,
    get_trakt_search_provider_impl=_get_trakt_search_provider_impl,
    get_stremio_provider_impl=_get_stremio_provider_impl,
    get_stremio_toggle_names_impl=_get_stremio_toggle_names_impl,
    stremio_addons_config_impl=_stremio_addons_config_impl,
    metadata_timeout_impl=_metadata_timeout_impl,
    metadata_priority_impl=_metadata_priority_impl,
    trakt_results_limit_impl=_trakt_results_limit_impl,
    trakt_title_with_year_impl=_trakt_title_with_year_impl,
    metadata_fallback_fanart_impl=_metadata_fallback_fanart_impl,
    external_scrapers_timeout_impl=_external_scrapers_timeout_impl,
    addon_installed_impl=_addon_installed_impl,
    torrent_player_route_impl=_torrent_player_route_impl,
    json_get_impl=_json_get_impl,
    json_post_impl=_json_post_impl,
    trakt_post_impl=_trakt_post_impl,
    trakt_get_impl=_trakt_get_impl,
    trakt_public_get_impl=_trakt_public_get_impl,
    trakt_is_ready_impl=_trakt_is_ready_impl,
    trakt_authed_get_impl=_trakt_authed_get_impl,
    trakt_authed_get_with_refresh_impl=_trakt_authed_get_with_refresh_impl,
    trakt_progress_translator_impl=_trakt_progress_translator_impl,
    omdb_enabled_impl=_omdb_enabled_impl,
    omdb_external_ratings_enabled_impl=_omdb_external_ratings_enabled_impl,
    tmdb_enabled_impl=_tmdb_enabled_impl,
    tmdb_api_key_impl=_tmdb_api_key_impl,
    omdb_api_key_impl=_omdb_api_key_impl,
)
_get_bool_setting = _runtime_ctx["get_bool_setting"]
_get_setting = _runtime_ctx["get_setting"]
_get_int_setting = _runtime_ctx["get_int_setting"]
_get_enabled_providers_raw = _runtime_ctx["get_enabled_providers"]
_get_trakt_search_provider = _runtime_ctx["get_trakt_search_provider"]
_get_stremio_provider = _runtime_ctx["get_stremio_provider"]
_get_stremio_toggle_names = _runtime_ctx["get_stremio_toggle_names"]
_stremio_addons_config = _runtime_ctx["stremio_addons_config"]
_metadata_timeout = _runtime_ctx["metadata_timeout"]
_metadata_priority = _runtime_ctx["metadata_priority"]
_trakt_results_limit = _runtime_ctx["trakt_results_limit"]
_trakt_title_with_year = _runtime_ctx["trakt_title_with_year"]
_metadata_fallback_fanart = _runtime_ctx["metadata_fallback_fanart"]
_external_scrapers_timeout = _runtime_ctx["external_scrapers_timeout"]
_addon_installed = _runtime_ctx["addon_installed"]
_torrent_player_route = _runtime_ctx["torrent_player_route"]
_finalize_playback_stream_url = _runtime_ctx["finalize_playback_stream_url"]
_set_setting = _runtime_ctx["set_setting"]
_trakt_post = _runtime_ctx["trakt_post"]
_trakt_get = _runtime_ctx["trakt_get"]
_trakt_public_get = _runtime_ctx["trakt_public_get"]
_trakt_is_ready = _runtime_ctx["trakt_is_ready"]
_trakt_authed_get = _runtime_ctx["trakt_authed_get"]
_trakt_progress_translator = _runtime_ctx["trakt_progress_translator"]
_omdb_enabled = _runtime_ctx["omdb_enabled"]
_omdb_external_ratings_enabled = _runtime_ctx["omdb_external_ratings_enabled"]
_tmdb_enabled = _runtime_ctx["tmdb_enabled"]
_tmdb_api_key = _runtime_ctx["tmdb_api_key"]
_omdb_api_key = _runtime_ctx["omdb_api_key"]


def _ensure_stremio_ready_silent():
    try:
        _ensure_stremio_ready_for_search(_get_bool_setting, _get_setting, _set_setting)
    except Exception as ex:
        try:
            xbmc.log(f"[Kraken] Stremio autostart check error: {ex}", xbmc.LOGWARNING)
        except Exception:
            pass


def _get_enabled_providers():
    _ensure_stremio_ready_silent()
    return _get_enabled_providers_raw()


def _search_fallback_media(query, media_filter):
    return _search_fallback_media_impl(
        query=query,
        media_filter=media_filter,
        tmdb_enabled=_tmdb_enabled,
        tmdb_api_key=_tmdb_api_key,
        json_get=_json_get,
        metadata_timeout=_metadata_timeout,
        tmdb_image_base=TMDB_IMAGE_BASE,
        tmdb_backdrop_base=TMDB_BACKDROP_BASE,
        omdb_enabled=_omdb_enabled,
        omdb_search_art=_omdb_search_art,
    )


def _privacy_scrub_accounts_once():
    if (_get_setting("kraken_privacy_scrub_done") or "").strip().lower() == "true":
        return
    # No borrar cuentas automaticamente: solo marcamos el flag de migracion.
    # En algunas instalaciones este scrub podia ejecutarse repetidamente y
    # provocar perdida de sesion en Trakt/Debrid.
    _set_setting("kraken_privacy_scrub_done", "true")


def _ensure_trakt_first_run_pin():
    if not _get_bool_setting("trakt_enabled"):
        _set_setting("trakt_first_pin_prompted", "false")
        return
    if (_get_setting("trakt_access_token") or "").strip():
        return
    if (_get_setting("trakt_first_pin_prompted") or "").strip().lower() == "true":
        return
    _set_setting("trakt_first_pin_prompted", "true")
    _run_trakt_authorize_route(
        run_trakt_authorize=_run_trakt_authorize,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
        set_setting=_set_setting,
        ensure_stremio_ready_for_search=_ensure_stremio_ready_for_search,
        trakt_client_id=TRAKT_CLIENT_ID,
        trakt_client_secret=TRAKT_CLIENT_SECRET,
        trakt_post=_trakt_post,
        trakt_get=_trakt_get,
        addon_path=ADDON.getAddonInfo("path"),
        qr_dialog_cls=_kraken_ui_dialog_classes()["qr"],
        auto_start=True,
    )


_privacy_scrub_accounts_once()
_ensure_stremio_ready_silent()


_tmdb_id_details = lambda tmdb_id, media_type="movie": _tmdb_id_details_bridge(
    tmdb_id=tmdb_id,
    media_type=media_type,
    tmdb_id_details_impl=_tmdb_id_details_impl,
    tmdb_enabled=_tmdb_enabled,
    tmdb_api_key=_tmdb_api_key,
    json_get=_json_get,
    metadata_timeout=_metadata_timeout,
    tmdb_image_base=TMDB_IMAGE_BASE,
    tmdb_backdrop_base=TMDB_BACKDROP_BASE,
    trakt_parse_year=_trakt_parse_year,
    trakt_float_or_none=_trakt_float_or_none,
)


_tmdb_search_art_by_id = lambda tmdb_id, media_type="movie": (
    _tmdb_search_art_by_id_bridge(
        tmdb_id=tmdb_id,
        media_type=media_type,
        tmdb_search_art_by_id_impl=_tmdb_search_art_by_id_impl,
        tmdb_id_details=_tmdb_id_details,
    )
)
_omdb_empty_metadata = lambda: _omdb_empty_metadata_impl()


_omdb_search_art = lambda title, year=None, media_type="movie", imdb_id="": (
    _omdb_search_art_bridge(
        addon=ADDON,
        title=title,
        year=year,
        media_type=media_type,
        imdb_id=imdb_id,
        omdb_search_art_impl=_omdb_search_art_impl,
        omdb_enabled=_omdb_enabled,
        omdb_api_key=_omdb_api_key,
        json_get=_json_get,
        metadata_timeout=_metadata_timeout,
        ttl_seconds=OMDB_CACHE_TTL_SECONDS,
        max_items=OMDB_CACHE_MAX_ITEMS,
    )
)


_clean_title = lambda value: _clean_title_impl(value)
_is_playable_stream_url = lambda url: _is_playable_stream_url_impl(url)
_source_label = lambda stream_url, source_name: _source_label_impl(
    stream_url, source_name
)
_pretty_source_line = lambda item: _pretty_source_line_impl(
    item,
    compact_origin_fn=_compact_origin,
    source_selector_style_fn=_source_selector_style,
)
_candidates_deduped_for_picker = lambda candidates: _candidates_deduped_for_picker_impl(
    candidates
)


def _pick_stream_url_silent(candidates, playback_kind=None, rotation=None):
    return _pick_stream_url_silent_bridge(
        candidates=candidates,
        playback_kind=playback_kind,
        pick_stream_url_silent_impl=_pick_stream_url_silent_impl,
        source_sort_key_with_language_fn=_source_sort_key_with_language,
        get_bool_setting_fn=_get_bool_setting,
        get_setting_fn=_get_setting,
        autoplay_url_by_language_priority_fn=_autoplay_url_by_language_priority,
        rotation=rotation,
    )


_trakt_next_episode_pair = lambda show_id, season_num, ep_num: (
    _trakt_next_episode_pair_impl(show_id, season_num, ep_num, _trakt_public_get)
)


def _pick_stream_dialog(title, candidates, playback_kind=None, rotation=None):
    dlg = _kraken_ui_dialog_classes()
    return _pick_stream_dialog_bridge(
        title=title,
        candidates=candidates,
        playback_kind=playback_kind,
        rotation=rotation,
        pick_stream_dialog_impl=_pick_stream_dialog_impl,
        candidates_deduped_for_picker=_candidates_deduped_for_picker,
        source_sort_key_with_language=_source_sort_key_with_language,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
        autoplay_url_by_language_priority=_autoplay_url_by_language_priority,
        language_bucket_for_item=_language_bucket_for_item,
        language_section_title=_language_section_title,
        compact_origin=_compact_origin,
        normalize_language_label=_normalize_language_label,
        language_flag=_language_flag,
        pretty_source_line=_pretty_source_line,
        quality_counts_colored=_quality_counts_colored,
        kraken_sources_dialog_cls=dlg["sources"],
        addon_path=ADDON.getAddonInfo("path"),
    )


_default_list_art = lambda: _default_list_art_impl(
    ADDON, CONTENT_PANEL_TEXTURE, _get_setting
)
_apply_directory_style = lambda media_filter: _apply_directory_style_impl(
    plugin.handle, media_filter, ADDON, _get_setting
)
_kraken_progress = lambda dialog, percent, phase, detail="": _kraken_progress_impl(
    dialog, percent, phase, detail
)
_resolver_progress_detail = lambda status_line, base_list, partial_list, started_at: (
    _resolver_progress_detail_impl(status_line, base_list, partial_list, started_at)
)
_source_ctx = _build_source_context(
    normalize_quality_impl=_normalize_quality_impl,
    quality_counts_colored_impl=_quality_counts_colored_impl,
    quality_rank_impl=_quality_rank_impl,
    compact_origin_impl=_compact_origin_impl,
    language_flag_impl=_language_flag_impl,
    normalize_language_label_bridge=_normalize_language_label_bridge,
    normalize_language_label_impl=_normalize_language_label_impl,
    language_bucket_for_item_bridge=_language_bucket_for_item_bridge,
    language_bucket_for_item_impl=_language_bucket_for_item_impl,
    language_section_title_impl=_language_section_title_impl,
    source_sort_key_with_language_impl=_source_sort_key_with_language_impl,
    autoplay_url_by_language_priority_impl=_autoplay_url_by_language_priority_impl,
    source_selector_style_impl=_source_selector_style_impl,
    sources_order_priority_impl=_sources_order_priority_impl,
    source_order_rank_impl=_source_order_rank_impl,
    parse_trakt_compound_id_impl=_parse_trakt_compound_id_impl,
    get_setting=_get_setting,
)
_normalize_quality = _source_ctx["normalize_quality"]
_quality_counts_colored = _source_ctx["quality_counts_colored"]
_quality_rank = _source_ctx["quality_rank"]
_compact_origin = _source_ctx["compact_origin"]
_language_flag = _source_ctx["language_flag"]
_normalize_language_label = _source_ctx["normalize_language_label"]
_language_bucket_for_item = _source_ctx["language_bucket_for_item"]
_language_section_title = _source_ctx["language_section_title"]
_source_sort_key_with_language = _source_ctx["source_sort_key_with_language"]
_autoplay_url_by_language_priority = _source_ctx["autoplay_url_by_language_priority"]
_source_selector_style = _source_ctx["source_selector_style"]
_sources_order_priority = _source_ctx["sources_order_priority"]
_source_order_rank = _source_ctx["source_order_rank"]
_parse_trakt_compound_id = _source_ctx["parse_trakt_compound_id"]


def _omdb_external_ratings_label2_extra(rotten, metacritic, imdb_omdb):
    return _omdb_external_ratings_label2_extra_impl(
        rotten=rotten,
        metacritic=metacritic,
        imdb_omdb=imdb_omdb,
        omdb_external_ratings_enabled=_omdb_external_ratings_enabled,
    )


_cache_search_results = lambda results: _cache_search_results_impl(
    _SEARCH_RESULT_CACHE, results
)
_stremio_source_is_tv_only = lambda source_name: _stremio_source_is_tv_only_impl(
    source_name
)


def _resolve_trakt_result(
    result_id, collect_sources=False, progress_cb=None, progress_started_at=None
):
    return _resolve_trakt_result_bridge(
        result_id=result_id,
        collect_sources=collect_sources,
        progress_cb=progress_cb,
        progress_started_at=progress_started_at,
        resolve_trakt_result_impl=_resolve_trakt_result_impl,
        search_result_cache=_SEARCH_RESULT_CACHE,
        trakt_public_get=_trakt_public_get,
        get_enabled_providers=_get_enabled_providers,
        clean_title=_clean_title,
        resolver_progress_phase=RESOLVER_PROGRESS_PHASE,
        resolver_progress_detail=_resolver_progress_detail,
        stremio_source_is_tv_only=_stremio_source_is_tv_only,
        is_playable_stream_url=_is_playable_stream_url,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
        external_scraper_candidates=_external_scraper_candidates,
        web_link_provider_candidates=_web_link_provider_candidates,
        source_label=_source_label,
    )


def _resolve_trakt_episode_stream(
    show_trakt_id,
    season,
    episode,
    collect_sources=False,
    progress_cb=None,
    progress_started_at=None,
    context_label="",
):
    return _resolve_trakt_episode_stream_bridge(
        show_trakt_id=show_trakt_id,
        season=season,
        episode=episode,
        collect_sources=collect_sources,
        progress_cb=progress_cb,
        progress_started_at=progress_started_at,
        context_label=context_label,
        resolve_trakt_episode_stream_impl=_resolve_trakt_episode_stream_impl,
        trakt_public_get=_trakt_public_get,
        get_enabled_providers=_get_enabled_providers,
        resolver_progress_phase=RESOLVER_PROGRESS_PHASE,
        resolver_progress_detail=_resolver_progress_detail,
        stremio_source_is_tv_only=_stremio_source_is_tv_only,
        is_playable_stream_url=_is_playable_stream_url,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
        external_scraper_candidates=_external_scraper_candidates,
        web_link_provider_candidates=_web_link_provider_candidates,
    )


_json_get = lambda url, headers=None, timeout=15: _json_get_impl(
    url, headers=headers, timeout=timeout
)
_json_post = lambda url, payload=None, headers=None, timeout=15: _json_post_impl(
    url, payload=payload, headers=headers, timeout=timeout
)
_load_scraper_module = lambda package_name, addon_id: _load_scraper_module_impl(
    package_name, addon_id
)


def _debrid_resolve_torrent_for_download(stream_url):
    from resources.lib.core.debrid_stream_resolve import (
        maybe_resolve_torrent_via_debrid,
    )

    return maybe_resolve_torrent_via_debrid(
        stream_url,
        _get_bool_setting,
        _get_setting,
        _json_get,
        _json_post,
    )


def _external_scraper_candidates(
    title,
    year,
    imdb_id,
    media_type="movie",
    season=None,
    episode=None,
    tvshowtitle=None,
    preferred_engine="",
    progress_cb=None,
):
    return _external_scraper_candidates_bridge(
        title=title,
        year=year,
        imdb_id=imdb_id,
        media_type=media_type,
        season=season,
        episode=episode,
        tvshowtitle=tvshowtitle,
        preferred_engine=preferred_engine,
        progress_cb=progress_cb,
        external_scraper_candidates_impl=_external_scraper_candidates_impl,
        external_scrapers_timeout=_external_scrapers_timeout,
        get_bool_setting=_get_bool_setting,
        addon_installed=_addon_installed,
        load_scraper_module=_load_scraper_module,
        is_playable_stream_url=_is_playable_stream_url,
        normalize_language_label=_normalize_language_label,
    )


def _web_link_provider_candidates(
    *,
    title,
    year,
    media_type,
    season=None,
    episode=None,
    get_bool_setting,
    get_setting,
    is_playable_stream_url,
):
    return _web_link_provider_candidates_impl(
        title=title,
        year=year,
        media_type=media_type,
        season=season,
        episode=episode,
        get_bool_setting=get_bool_setting,
        get_setting=get_setting,
        is_playable_stream_url=is_playable_stream_url,
    )


def _alldebrid_pin_authorize():
    return _alldebrid_pin_authorize_impl(
        json_get=_json_get,
        set_setting=_set_setting,
        token_setting_id="debrid_ad_token",
        info_setting_id="debrid_ad_info",
        addon_path=ADDON.getAddonInfo("path"),
        qr_dialog_cls=_kraken_ui_dialog_classes()["qr"],
    )


def _ensure_debrid_legacy_migrated():
    _migrate_legacy_debrid_settings(_get_setting, _set_setting, _get_bool_setting)


@plugin.route("/")
def root():
    _ensure_debrid_legacy_migrated()
    if (_get_setting(_SETTING_FIRST_RUN_DONE) or "").strip().lower() != "true":
        _apply_stremio_autostart_defaults(_get_bool_setting, _get_setting, _set_setting)
    _ensure_stremio_ready_for_search(_get_bool_setting, _get_setting, _set_setting)
    _ensure_trakt_first_run_pin()
    _run_root_route(
        run_root=_run_root,
        plugin_handle=plugin.handle,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
        default_list_art=_default_list_art,
        url_for_search_folder=lambda: plugin.url_for(search_folder),
        url_for_menu_movies=lambda: plugin.url_for(menu_movies),
        url_for_menu_series=lambda: plugin.url_for(menu_series),
        url_for_menu_anime=lambda: plugin.url_for(menu_anime),
        url_for_tv_browse=lambda: plugin.url_for(tv_browse),
        url_for_trakt_series_in_progress=lambda: plugin.url_for(
            trakt_series_in_progress
        ),
        url_for_trakt_movies_in_progress=lambda: plugin.url_for(
            trakt_movies_in_progress
        ),
        url_for_trakt_anime_in_progress=lambda: plugin.url_for(trakt_anime_in_progress),
        url_for_downloads=lambda: plugin.url_for(downloads_hub),
        url_for_quick_movie_trending=lambda: plugin.url_for(
            discover_movies, list_id="trending"
        ),
        url_for_quick_series_trending=lambda: plugin.url_for(
            discover_series, list_id="trending"
        ),
        url_for_quick_anime_trending=lambda: plugin.url_for(
            discover_anime, list_id="trending"
        ),
        url_for_settings=lambda: plugin.url_for(settings),
    )


@plugin.route("/menu/peliculas")
def menu_movies():
    _run_movies_menu(
        plugin_handle=plugin.handle,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
        default_list_art=_default_list_art,
        url_for_discover_movies=lambda lid: plugin.url_for(
            discover_movies, list_id=lid
        ),
        url_for_movies_by_actor=lambda: plugin.url_for(search_movies_by_actor),
        url_for_browse_trakt_years=lambda: plugin.url_for(
            browse_trakt_anios, scope="peliculas"
        ),
        url_for_browse_trakt_genres=lambda: plugin.url_for(
            browse_trakt_generos, scope="peliculas"
        ),
        url_for_browse_tmdb_years=lambda: plugin.url_for(
            browse_tmdb_anios, scope="peliculas"
        ),
        url_for_browse_tmdb_genres=lambda: plugin.url_for(
            browse_tmdb_generos, scope="peliculas"
        ),
        url_for_browse_tmdb_platforms=lambda: plugin.url_for(
            browse_tmdb_plataformas, scope="peliculas"
        ),
        url_for_search_movies=lambda: plugin.url_for(search_movies),
        url_for_trakt_movies_in_progress=lambda: plugin.url_for(
            trakt_movies_in_progress
        ),
        url_for_trakt_movies_related_recent=lambda: plugin.url_for(
            trakt_movies_related_recent
        ),
        url_for_trakt_movies_random_recent=lambda: plugin.url_for(
            trakt_movies_random_recent
        ),
    )


@plugin.route("/menu/series")
def menu_series():
    _run_series_menu(
        plugin_handle=plugin.handle,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
        default_list_art=_default_list_art,
        url_for_discover_series=lambda lid: plugin.url_for(
            discover_series, list_id=lid
        ),
        url_for_series_by_actor=lambda: plugin.url_for(search_series_by_actor),
        url_for_browse_trakt_years=lambda: plugin.url_for(
            browse_trakt_anios, scope="series"
        ),
        url_for_browse_trakt_genres=lambda: plugin.url_for(
            browse_trakt_generos, scope="series"
        ),
        url_for_browse_tmdb_years=lambda: plugin.url_for(
            browse_tmdb_anios, scope="series"
        ),
        url_for_browse_tmdb_genres=lambda: plugin.url_for(
            browse_tmdb_generos, scope="series"
        ),
        url_for_browse_tmdb_platforms=lambda: plugin.url_for(
            browse_tmdb_plataformas, scope="series"
        ),
        url_for_search_series=lambda: plugin.url_for(search_series),
        url_for_trakt_series_in_progress=lambda: plugin.url_for(
            trakt_series_in_progress
        ),
        url_for_trakt_series_related_recent=lambda: plugin.url_for(
            trakt_series_related_recent
        ),
        url_for_trakt_series_random_recent=lambda: plugin.url_for(
            trakt_series_random_recent
        ),
    )


@plugin.route("/menu/anime")
def menu_anime():
    _run_anime_menu(
        plugin_handle=plugin.handle,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
        default_list_art=_default_list_art,
        url_for_search_anime=lambda: plugin.url_for(search_anime),
        url_for_discover_anime=lambda lid: plugin.url_for(discover_anime, list_id=lid),
        url_for_anime_by_actor=lambda: plugin.url_for(search_series_by_actor),
        url_for_browse_trakt_years=lambda: plugin.url_for(
            browse_trakt_anios, scope="anime"
        ),
        url_for_browse_trakt_genres=lambda: plugin.url_for(
            browse_trakt_generos, scope="anime"
        ),
        url_for_browse_tmdb_years=lambda: plugin.url_for(
            browse_tmdb_anios, scope="anime"
        ),
        url_for_browse_tmdb_genres=lambda: plugin.url_for(
            browse_tmdb_generos, scope="anime"
        ),
        url_for_browse_tmdb_platforms=lambda: plugin.url_for(
            browse_tmdb_plataformas, scope="anime"
        ),
        url_for_trakt_anime_in_progress=lambda: plugin.url_for(trakt_anime_in_progress),
        url_for_trakt_anime_related_recent=lambda: plugin.url_for(
            trakt_anime_related_recent
        ),
        url_for_trakt_anime_random_recent=lambda: plugin.url_for(
            trakt_anime_random_recent
        ),
    )


def _url_for_play_result(result_id):
    return "{}?{}".format(
        plugin.url_for(play),
        urlencode({"result_id": str(result_id or "")}),
    )


@plugin.route("/discover/peliculas/<list_id>")
def discover_movies(list_id):
    _run_trakt_discover_movie_list(
        plugin_handle=plugin.handle,
        list_id=list_id,
        trakt_public_get=_trakt_public_get,
        default_list_art=_default_list_art,
        tmdb_id_details=_tmdb_id_details,
        trakt_parse_year=_trakt_parse_year,
        trakt_float_or_none=_trakt_float_or_none,
        trakt_progress_translator=_trakt_progress_translator,
        trakt_list_label1_with_year_rating=_trakt_list_label1_with_year_rating,
        trakt_listitem_set_info_and_videotag=_trakt_listitem_set_info_and_videotag,
        url_for_play=lambda rid: _url_for_play_result(rid),
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/discover/series/<list_id>")
def discover_series(list_id):
    _run_trakt_discover_show_list(
        plugin_handle=plugin.handle,
        list_id=list_id,
        genres=None,
        trakt_public_get=_trakt_public_get,
        default_list_art=_default_list_art,
        tmdb_id_details=_tmdb_id_details,
        trakt_parse_year=_trakt_parse_year,
        trakt_float_or_none=_trakt_float_or_none,
        trakt_progress_translator=_trakt_progress_translator,
        trakt_list_label1_with_year_rating=_trakt_list_label1_with_year_rating,
        trakt_listitem_set_info_and_videotag=_trakt_listitem_set_info_and_videotag,
        url_for_show_seasons=lambda show_id: plugin.url_for(
            show_seasons, show_trakt_id=str(show_id)
        ),
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/discover/anime/<list_id>")
def discover_anime(list_id):
    _run_trakt_discover_show_list(
        plugin_handle=plugin.handle,
        list_id=list_id,
        genres="anime",
        trakt_public_get=_trakt_public_get,
        default_list_art=_default_list_art,
        tmdb_id_details=_tmdb_id_details,
        trakt_parse_year=_trakt_parse_year,
        trakt_float_or_none=_trakt_float_or_none,
        trakt_progress_translator=_trakt_progress_translator,
        trakt_list_label1_with_year_rating=_trakt_list_label1_with_year_rating,
        trakt_listitem_set_info_and_videotag=_trakt_listitem_set_info_and_videotag,
        url_for_show_seasons=lambda show_id: plugin.url_for(
            show_seasons, show_trakt_id=str(show_id)
        ),
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/browse/<scope>/trakt-anios")
def browse_trakt_anios(scope):
    _run_browse_trakt_years_menu(
        plugin_handle=plugin.handle,
        scope=scope,
        default_list_art=_default_list_art,
        url_for_year=lambda y: plugin.url_for(
            browse_trakt_anio, scope=scope, year=str(y)
        ),
    )


@plugin.route("/browse/<scope>/trakt-anio/<year>")
def browse_trakt_anio(scope, year):
    _run_browse_trakt_year_list(
        plugin_handle=plugin.handle,
        scope=scope,
        year_raw=year,
        trakt_public_get=_trakt_public_get,
        default_list_art=_default_list_art,
        tmdb_id_details=_tmdb_id_details,
        trakt_parse_year=_trakt_parse_year,
        trakt_float_or_none=_trakt_float_or_none,
        trakt_progress_translator=_trakt_progress_translator,
        trakt_list_label1_with_year_rating=_trakt_list_label1_with_year_rating,
        trakt_listitem_set_info_and_videotag=_trakt_listitem_set_info_and_videotag,
        url_for_play=lambda rid: _url_for_play_result(rid),
        url_for_show_seasons=lambda show_id: plugin.url_for(
            show_seasons, show_trakt_id=str(show_id)
        ),
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/browse/<scope>/trakt-generos")
def browse_trakt_generos(scope):
    _run_browse_trakt_genres_menu(
        plugin_handle=plugin.handle,
        scope=scope,
        default_list_art=_default_list_art,
        url_for_genre=lambda slug: plugin.url_for(
            browse_trakt_genero, scope=scope, slug=slug
        ),
    )


@plugin.route("/browse/<scope>/trakt-genero/<slug>")
def browse_trakt_genero(scope, slug):
    _run_browse_trakt_genre_list(
        plugin_handle=plugin.handle,
        scope=scope,
        slug_raw=slug,
        trakt_public_get=_trakt_public_get,
        default_list_art=_default_list_art,
        tmdb_id_details=_tmdb_id_details,
        trakt_parse_year=_trakt_parse_year,
        trakt_float_or_none=_trakt_float_or_none,
        trakt_progress_translator=_trakt_progress_translator,
        trakt_list_label1_with_year_rating=_trakt_list_label1_with_year_rating,
        trakt_listitem_set_info_and_videotag=_trakt_listitem_set_info_and_videotag,
        url_for_play=lambda rid: _url_for_play_result(rid),
        url_for_show_seasons=lambda show_id: plugin.url_for(
            show_seasons, show_trakt_id=str(show_id)
        ),
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/browse/<scope>/tmdb-anios")
def browse_tmdb_anios(scope):
    _run_browse_tmdb_years_menu(
        plugin_handle=plugin.handle,
        scope=scope,
        default_list_art=_default_list_art,
        url_for_year=lambda y: plugin.url_for(
            browse_tmdb_anio, scope=scope, year=str(y)
        ),
    )


@plugin.route("/browse/<scope>/tmdb-anio/<year>")
def browse_tmdb_anio(scope, year):
    _run_browse_tmdb_year_list(
        plugin_handle=plugin.handle,
        scope=scope,
        year_raw=year,
        tmdb_enabled=_tmdb_enabled,
        tmdb_api_key=_tmdb_api_key,
        json_get=_json_get,
        metadata_timeout=_metadata_timeout,
        trakt_public_get=_trakt_public_get,
        default_list_art=_default_list_art,
        tmdb_id_details=_tmdb_id_details,
        trakt_list_label1_with_year_rating=_trakt_list_label1_with_year_rating,
        trakt_listitem_set_info_and_videotag=_trakt_listitem_set_info_and_videotag,
        url_for_play=lambda rid: _url_for_play_result(rid),
        url_for_show_seasons=lambda show_id: plugin.url_for(
            show_seasons, show_trakt_id=str(show_id)
        ),
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/browse/<scope>/tmdb-generos")
def browse_tmdb_generos(scope):
    _run_browse_tmdb_genres_menu(
        plugin_handle=plugin.handle,
        scope=scope,
        default_list_art=_default_list_art,
        url_for_genre=lambda gid: plugin.url_for(
            browse_tmdb_genero, scope=scope, gid=str(gid)
        ),
    )


@plugin.route("/browse/<scope>/tmdb-plataformas")
def browse_tmdb_plataformas(scope):
    _run_browse_tmdb_platforms_menu(
        plugin_handle=plugin.handle,
        scope=scope,
        default_list_art=_default_list_art,
        url_for_platform=lambda pid: plugin.url_for(
            browse_tmdb_plataforma, scope=scope, provider_id=str(pid)
        ),
    )


@plugin.route("/browse/<scope>/tmdb-plataforma/<provider_id>")
def browse_tmdb_plataforma(scope, provider_id):
    _run_browse_tmdb_platform_list(
        plugin_handle=plugin.handle,
        scope=scope,
        provider_id_raw=provider_id,
        tmdb_enabled=_tmdb_enabled,
        tmdb_api_key=_tmdb_api_key,
        json_get=_json_get,
        metadata_timeout=_metadata_timeout,
        trakt_public_get=_trakt_public_get,
        default_list_art=_default_list_art,
        tmdb_id_details=_tmdb_id_details,
        trakt_list_label1_with_year_rating=_trakt_list_label1_with_year_rating,
        trakt_listitem_set_info_and_videotag=_trakt_listitem_set_info_and_videotag,
        url_for_play=lambda rid: _url_for_play_result(rid),
        url_for_show_seasons=lambda show_id: plugin.url_for(
            show_seasons, show_trakt_id=str(show_id)
        ),
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/browse/<scope>/tmdb-genero/<gid>")
def browse_tmdb_genero(scope, gid):
    _run_browse_tmdb_genre_list(
        plugin_handle=plugin.handle,
        scope=scope,
        gid_raw=gid,
        tmdb_enabled=_tmdb_enabled,
        tmdb_api_key=_tmdb_api_key,
        json_get=_json_get,
        metadata_timeout=_metadata_timeout,
        trakt_public_get=_trakt_public_get,
        default_list_art=_default_list_art,
        tmdb_id_details=_tmdb_id_details,
        trakt_list_label1_with_year_rating=_trakt_list_label1_with_year_rating,
        trakt_listitem_set_info_and_videotag=_trakt_listitem_set_info_and_videotag,
        url_for_play=lambda rid: _url_for_play_result(rid),
        url_for_show_seasons=lambda show_id: plugin.url_for(
            show_seasons, show_trakt_id=str(show_id)
        ),
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/tv/pais/<token>")
@plugin.route("/tv/pais")
def tv_pais_categorias(token=None):
    _run_tv_pais_categorias_route(
        run_tv_pais_categorias=_run_tv_pais_categorias,
        plugin_handle=plugin.handle,
        token=token,
        get_stremio_provider=_get_stremio_provider,
        query_arg_first_str=_query_arg_first_str,
        tv_catalog_token_read=_tv_catalog_token_read,
        default_list_art=_default_list_art,
        tv_catalog_token_dict=_tv_catalog_token_dict,
        url_for_tv_browse_channel=lambda t2: plugin.url_for(
            tv_browse_channel, token=t2
        ),
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/tv")
def tv_browse():
    try:
        tvvoo_url = (_get_setting("stremio_tvvoo_url") or "").strip()
    except Exception:
        tvvoo_url = ""
    if not tvvoo_url:
        tvvoo_url = DEFAULT_STREMIO_TVVOO_MANIFEST
    _run_tv_browse_route(
        run_tv_browse=_run_tv_browse,
        plugin_handle=plugin.handle,
        get_bool_setting=_get_bool_setting,
        get_stremio_provider=_get_stremio_provider,
        tvvoo_url=tvvoo_url,
        default_list_art=_default_list_art,
        tv_catalog_token_dict=_tv_catalog_token_dict,
        url_for_tv_browse_search=lambda: plugin.url_for(tv_browse_search),
        url_for_tv_pais_categorias=lambda tok: plugin.url_for(
            tv_pais_categorias, token=tok
        ),
        url_for_tv_browse_channel=lambda tok: plugin.url_for(
            tv_browse_channel, token=tok
        ),
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/tv/buscar")
def tv_browse_search():
    _run_tv_browse_search_route(
        run_tv_browse_search=_run_tv_browse_search,
        plugin_handle=plugin.handle,
        get_stremio_provider=_get_stremio_provider,
        default_list_art=_default_list_art,
        url_for_play=lambda rid: _url_for_play_result(rid),
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/tv/c/<token>")
@plugin.route("/tv/c")
def tv_browse_channel(token=None):
    _run_tv_browse_channel_route(
        run_tv_browse_channel=_run_tv_browse_channel,
        plugin_handle=plugin.handle,
        token=token,
        get_stremio_provider=_get_stremio_provider,
        query_arg_first_str=_query_arg_first_str,
        tv_catalog_token_read=_tv_catalog_token_read,
        default_list_art=_default_list_art,
        url_for_play=lambda rid: _url_for_play_result(rid),
        url_for_noop=lambda: plugin.url_for(noop),
    )


def _enrich_trakt_result_items_with_metadata(results, dialog):
    _enrich_trakt_result_items_with_metadata_impl(
        results=results,
        dialog=dialog,
        tmdb_enabled=_tmdb_enabled,
        omdb_enabled=_omdb_enabled,
        kraken_progress=_kraken_progress,
        metadata_priority=_metadata_priority,
        omdb_search_art=_omdb_search_art,
        tmdb_search_art_by_id=_tmdb_search_art_by_id,
        omdb_empty_metadata=_omdb_empty_metadata,
        omdb_external_ratings_enabled=_omdb_external_ratings_enabled,
        metadata_fallback_fanart=_metadata_fallback_fanart,
    )


def _add_trakt_search_listing_to_directory(
    results, media_filter, empty_message="Sin resultados"
):
    _add_trakt_search_listing_to_directory_impl(
        results=results,
        media_filter=media_filter,
        plugin_handle=plugin.handle,
        empty_message=empty_message,
        cache_search_results=_cache_search_results,
        default_list_art=_default_list_art,
        trakt_parse_year=_trakt_parse_year,
        trakt_float_or_none=_trakt_float_or_none,
        trakt_list_label1_with_year_rating=_trakt_list_label1_with_year_rating,
        trakt_rating_label2_extra=_trakt_rating_label2_extra,
        omdb_external_ratings_label2_extra=_omdb_external_ratings_label2_extra,
        format_trakt_vote_count=_format_trakt_vote_count,
        omdb_external_ratings_enabled=_omdb_external_ratings_enabled,
        trakt_listitem_set_info_and_videotag=_trakt_listitem_set_info_and_videotag,
        parse_trakt_compound_id=_parse_trakt_compound_id,
        apply_directory_style=_apply_directory_style,
        url_for_show_seasons=lambda trakt_id: plugin.url_for(
            show_seasons, show_trakt_id=trakt_id
        ),
        url_for_play=lambda rid: _url_for_play_result(rid),
        trakt_public_get=_trakt_public_get,
        url_for_noop=lambda: plugin.url_for(noop),
        json_get=_json_get,
        tmdb_api_key=_tmdb_api_key,
        metadata_timeout=_metadata_timeout,
        tmdb_enabled=_tmdb_enabled,
    )


def _search_trakt_media(media_filter, forced_query=None):
    _search_trakt_media_bridge(
        media_filter=media_filter,
        forced_query=forced_query,
        search_trakt_media_impl=_search_trakt_media_impl,
        plugin_handle=plugin.handle,
        search_history_last=_search_history_last,
        search_history_add=_search_history_add,
        kraken_progress=_kraken_progress,
        get_trakt_search_provider=_get_trakt_search_provider,
        trakt_results_limit=_trakt_results_limit,
        tmdb_enabled=_tmdb_enabled,
        omdb_enabled=_omdb_enabled,
        enrich_trakt_result_items_with_metadata=_enrich_trakt_result_items_with_metadata,
        add_trakt_search_listing_to_directory=_add_trakt_search_listing_to_directory,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
        fallback_search=_search_fallback_media,
    )


@plugin.route("/busqueda")
def search_folder():
    _ensure_trakt_first_run_pin()
    _run_search_folder_route(
        run_search_folder=_run_search_folder,
        plugin_handle=plugin.handle,
        default_list_art=_default_list_art,
        url_for_search_all=lambda: plugin.url_for(search),
        url_for_search_movies=lambda: plugin.url_for(search_movies),
        url_for_search_series=lambda: plugin.url_for(search_series),
        url_for_search_anime=lambda: plugin.url_for(search_anime),
        url_for_search_movies_by_actor=lambda: plugin.url_for(search_movies_by_actor),
        url_for_search_series_by_actor=lambda: plugin.url_for(search_series_by_actor),
        url_for_search_history=lambda: plugin.url_for(search_history),
    )


@plugin.route("/busqueda/historial")
def search_history():
    _run_search_history_route(
        run_search_history=_run_search_history,
        plugin_handle=plugin.handle,
        default_list_art=_default_list_art,
        search_history_load=_search_history_load,
        url_for_search_history_clear=lambda: plugin.url_for(search_history_clear),
        url_for_search_history_delete=lambda token: plugin.url_for(
            search_history_delete, token=token
        ),
        url_for_search_history_run=lambda token: plugin.url_for(
            search_history_run, token=token
        ),
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/busqueda/historial/run/<token>")
def search_history_run(token):
    _run_search_history_run_route(
        run_search_history_run=_run_search_history_run,
        token=token,
        search_history_token_read=_search_history_token_read,
        run_actor_listing=_search_movies_shows_by_actor_people_listing,
        run_search_trakt_media=_search_trakt_media,
        plugin_handle=plugin.handle,
    )


@plugin.route("/busqueda/historial/delete/<token>")
def search_history_delete(token):
    _run_search_history_delete_route(
        run_search_history_delete=_run_search_history_delete,
        token=token,
        search_history_token_read=_search_history_token_read,
        search_history_load=_search_history_load,
        search_history_save=_search_history_save,
        plugin_handle=plugin.handle,
    )


@plugin.route("/busqueda/historial/clear")
def search_history_clear():
    _run_search_history_clear_route(
        run_search_history_clear=_run_search_history_clear,
        search_history_save=_search_history_save,
        plugin_handle=plugin.handle,
    )


_search_movies_shows_by_actor_people_listing = lambda kind="movie", forced_query=None: (
    _run_actor_people_listing_and_open(
        kind=kind,
        forced_query=forced_query,
        search_actor_people_listing_impl=_search_actor_people_listing_impl,
        plugin_handle=plugin.handle,
        search_history_last=_search_history_last,
        search_history_add=_search_history_add,
        get_trakt_search_provider=_get_trakt_search_provider,
        default_list_art=_default_list_art,
        url_for_movie_person=lambda person_id: plugin.url_for(
            search_movies_by_person_id, person_id=person_id
        ),
        url_for_show_person=lambda person_id: plugin.url_for(
            search_series_by_person_id, person_id=person_id
        ),
        search_actor_credits=_search_movies_shows_by_actor_credits,
    )
)


@plugin.route("/buscar/actor-pelicula")
def search_movies_by_actor():
    _run_actor_listing_route(
        run_actor_listing_entry=_run_actor_listing_entry,
        mode="movie",
        actor_listing_fn=_search_movies_shows_by_actor_people_listing,
    )


@plugin.route("/buscar/actor-pelicula/persona/<person_id>")
def search_movies_by_person_id(person_id):
    _run_actor_person_route(
        run_actor_person_entry=_run_actor_person_entry,
        person_id=person_id,
        mode="movie",
        actor_credits_fn=_search_movies_shows_by_actor_credits,
        plugin_handle=plugin.handle,
    )


@plugin.route("/buscar/actor-serie")
def search_series_by_actor():
    _run_actor_listing_route(
        run_actor_listing_entry=_run_actor_listing_entry,
        mode="show",
        actor_listing_fn=_search_movies_shows_by_actor_people_listing,
    )


@plugin.route("/buscar/actor-serie/persona/<person_id>")
def search_series_by_person_id(person_id):
    _run_actor_person_route(
        run_actor_person_entry=_run_actor_person_entry,
        person_id=person_id,
        mode="show",
        actor_credits_fn=_search_movies_shows_by_actor_credits,
        plugin_handle=plugin.handle,
    )


_search_movies_shows_by_actor_credits = lambda kind, person_id: (
    _run_actor_credits_search(
        kind=kind,
        person_id=person_id,
        search_actor_credits_impl=_search_actor_credits_impl,
        get_trakt_search_provider=_get_trakt_search_provider,
        kraken_progress=_kraken_progress,
        trakt_results_limit=_trakt_results_limit,
        tmdb_enabled=_tmdb_enabled,
        omdb_enabled=_omdb_enabled,
        enrich_trakt_result_items_with_metadata=_enrich_trakt_result_items_with_metadata,
        add_trakt_search_listing_to_directory=_add_trakt_search_listing_to_directory,
        trakt_parse_year=_trakt_parse_year,
    )
)


@plugin.route("/buscar/le/<blob>")
def search_listing_le(blob):
    decoded = _decode_search_listing_token(blob)
    if not decoded:
        xbmcplugin.endOfDirectory(plugin.handle, succeeded=True)
        return
    mf, fq = decoded
    _search_trakt_media(mf, forced_query=fq)


@plugin.route("/buscar")
def search():
    _run_simple_search_route(
        run_simple_search=_run_simple_search,
        mode="all",
        search_trakt_media=_search_trakt_media,
        plugin_handle=plugin.handle,
        search_history_last=_search_history_last,
    )


@plugin.route("/buscar/peliculas")
def search_movies():
    _run_simple_search_route(
        run_simple_search=_run_simple_search,
        mode="movie",
        search_trakt_media=_search_trakt_media,
        plugin_handle=plugin.handle,
        search_history_last=_search_history_last,
    )


@plugin.route("/buscar/series")
def search_series():
    _run_simple_search_route(
        run_simple_search=_run_simple_search,
        mode="show",
        search_trakt_media=_search_trakt_media,
        plugin_handle=plugin.handle,
        search_history_last=_search_history_last,
    )


@plugin.route("/buscar/anime")
def search_anime():
    _run_simple_search_route(
        run_simple_search=_run_simple_search,
        mode="show",
        search_trakt_media=_search_trakt_media,
        plugin_handle=plugin.handle,
        search_history_last=_search_history_last,
    )


_play_result_id_from_request = lambda result_id_path: (
    _play_result_id_from_request_bridge(
        result_id_path=result_id_path,
        route_play_result_id_from_request=_route_play_result_id_from_request,
        plugin_args=getattr(plugin, "args", None) or {},
    )
)
_query_arg_first_str = lambda *candidates: _query_arg_first_str_bridge(
    route_query_arg_first_str=_route_query_arg_first_str,
    plugin_args=getattr(plugin, "args", None) or {},
    candidates=candidates,
)


def _resolve_fallback_source_candidates(
    title, year, media_type, *, progress_cb=None, progress_started_at=None
):
    media_type = "series" if str(media_type or "").lower() in ("show", "series", "tv") else "movie"
    title = str(title or "").strip()
    if not title:
        return []

    out = []
    seen_stream_origin = set()
    import time as _time_fb

    _fb_started_at = (
        progress_started_at
        if progress_started_at is not None
        else _time_fb.time()
    )

    def _fb_emit(percent, status_line):
        if progress_cb:
            progress_cb(
                max(4, min(92, int(percent))),
                RESOLVER_PROGRESS_PHASE,
                _resolver_progress_detail(
                    status_line, out, None, _fb_started_at
                ),
            )

    def add_stream(src, origin):
        stream = str((src or {}).get("url") or "").strip()
        origin_s = str(origin or "").strip()
        key = (stream.lower(), origin_s.lower())
        if not stream or key in seen_stream_origin or not _is_playable_stream_url(stream):
            return
        seen_stream_origin.add(key)
        out.append(
            {
                "url": stream,
                "label": str((src or {}).get("label") or "Fuente").strip(),
                "title": str((src or {}).get("title") or "").strip(),
                "quality": str((src or {}).get("quality") or "Auto").strip(),
                "language": _finalize_stream_language_impl(src, stream),
                "origin": origin_s,
            }
        )

    def fallback_imdb_id():
        if not _tmdb_enabled() or not _tmdb_api_key():
            return ""
        try:
            search_kind = "movie" if media_type == "movie" else "tv"
            date_key = "release_date" if media_type == "movie" else "first_air_date"
            url = (
                "https://api.themoviedb.org/3/search/{}"
                "?api_key={}&query={}&language={}&include_adult=false"
            ).format(
                search_kind,
                quote(str(_tmdb_api_key()), safe=""),
                quote(title, safe=""),
                quote(str(_tmdb_language_param()), safe=""),
            )
            if year:
                url += "&year={}".format(int(year))
            payload = _json_get(url, timeout=_metadata_timeout()) or {}
            rows = payload.get("results") or []
        except Exception:
            rows = []
        tmdb_id = ""
        for row in rows:
            if not isinstance(row, dict):
                continue
            rd = str(row.get(date_key) or "")
            row_year = int(rd[:4]) if len(rd) >= 4 and rd[:4].isdigit() else None
            if year and row_year and int(year) != int(row_year):
                continue
            tmdb_id = str(row.get("id") or "").strip()
            if tmdb_id:
                break
        if not tmdb_id:
            return ""
        try:
            ext_kind = "movie" if media_type == "movie" else "tv"
            ext = _json_get(
                "https://api.themoviedb.org/3/{}/{}/external_ids?api_key={}".format(
                    ext_kind, quote(tmdb_id, safe=""), quote(str(_tmdb_api_key()), safe="")
                ),
                timeout=_metadata_timeout(),
            ) or {}
            imdb = str(ext.get("imdb_id") or "").strip()
            return imdb if imdb.startswith("tt") else ""
        except Exception:
            return ""

    _fb_emit(
        10,
        _t(
            "Resolviendo título de respaldo",
            "Resolving fallback title",
            "Résolution titre de secours",
            "Titolo fallback in risoluzione",
            "Fallback-Titel wird aufgelöst",
        ),
    )
    imdb_id = fallback_imdb_id()
    _fb_emit(
        28,
        _t(
            "IMDb desde TMDb: {}",
            "IMDb from TMDb: {}",
            "IMDb via TMDb : {}",
            "IMDa da TMDb: {}",
            "IMDb von TMDb: {}",
        ).format(
            imdb_id
            or _t("(ninguno)", "(none)", "(aucun)", "(nessuno)", "(keiner)")
        ),
    )

    for provider in _get_enabled_providers():
        pname = str(getattr(provider, "name", "") or "")
        if "stremio" not in pname.lower():
            continue
        _fb_emit(
            36,
            _t(
                "Stremio {} — recolectando",
                "Stremio {} — collecting",
                "Stremio {} — collecte",
                "Stremio {} — raccolta",
                "Stremio {} — sammeln",
            ).format(pname),
        )
        if imdb_id:
            for source_name, _source_url in getattr(provider, "_catalog_sources", []) or []:
                if _stremio_source_is_tv_only(source_name) and media_type in (
                    "movie",
                    "series",
                ):
                    continue
                direct_id = f"stremio::{source_name}::{media_type}::{imdb_id}"
                try:
                    streams = (
                        provider.resolve_all(direct_id)
                        if hasattr(provider, "resolve_all")
                        else []
                    )
                except Exception:
                    streams = []
                for src in streams or []:
                    add_stream(src, f"Stremio {source_name}")
            if out:
                break
        terms = [title]
        if title and title.rsplit(" ", 1)[-1].isdigit() and len(title.rsplit(" ", 1)[-1]) == 4:
            terms.append(title.rsplit(" ", 1)[0].strip())
        if year:
            terms.append(f"{title} {year}")
        seen_ids = set()
        for ti, term in enumerate(terms):
            _fb_emit(
                min(74, 44 + ti * 10),
                _t(
                    "Búsqueda: {}",
                    "Search: {}",
                    "Recherche : {}",
                    "Ricerca: {}",
                    "Suche: {}",
                ).format(str(term)),
            )
            try:
                candidates = provider.search(term, allowed_types=(media_type,))
            except TypeError:
                try:
                    candidates = provider.search(term)
                except Exception:
                    candidates = []
            except Exception:
                candidates = []
            for cand in candidates or []:
                cid = str((cand or {}).get("id") or "").strip()
                if not cid or cid in seen_ids:
                    continue
                seen_ids.add(cid)
                parts = cid.split("::")
                source_name = parts[1] if len(parts) >= 2 else pname
                if _stremio_source_is_tv_only(source_name) and media_type in (
                    "movie",
                    "series",
                ):
                    continue
                try:
                    streams = (
                        provider.resolve_all(cid)
                        if hasattr(provider, "resolve_all")
                        else []
                    )
                except Exception:
                    streams = []
                if not streams:
                    try:
                        raw = provider.resolve(cid)
                    except Exception:
                        raw = None
                    if raw:
                        streams = [raw] if isinstance(raw, dict) else [{"url": raw}]
                for src in streams or []:
                    add_stream(src, f"Stremio {source_name}")
        if out:
            break

    _fb_emit(
        82,
        _t(
            "Scrapers externos",
            "External scrapers",
            "Scrapers externes",
            "Scraper esterni",
            "Externe Scraper",
        ),
    )
    ext = _external_scraper_candidates(
        title=title,
        year=year,
        imdb_id="",
        media_type=media_type,
    )
    for src in ext or []:
        add_stream(src, str((src or {}).get("origin") or "Scraper externo").strip())
    return out


@plugin.route("/play/<result_id>")
@plugin.route("/play")
def play(result_id=None):
    _run_play_route(
        run_play=_run_play,
        plugin_handle=plugin.handle,
        result_id_path=result_id,
        play_result_id_from_request=_play_result_id_from_request,
        kraken_progress=_kraken_progress,
        resolver_progress_phase=RESOLVER_PROGRESS_PHASE,
        resolver_progress_detail=_resolver_progress_detail,
        resolve_trakt_result=_resolve_trakt_result,
        pick_stream_dialog=_pick_stream_dialog,
        finalize_playback_stream_url=_finalize_playback_stream_url,
        get_enabled_providers=_get_enabled_providers,
        is_playable_stream_url=_is_playable_stream_url,
        resolve_fallback_candidates=_resolve_fallback_source_candidates,
        trakt_public_get=_trakt_public_get,
        get_setting=_get_setting,
        set_setting=_set_setting,
        get_bool_setting=_get_bool_setting,
    )


@plugin.route("/descargas")
def downloads_hub():
    _run_downloads_hub(
        plugin_handle=plugin.handle,
        default_list_art=_default_list_art,
        url_for_downloads_category=lambda slug: plugin.url_for(
            downloads_list, kind_slug=slug
        ),
        url_for_downloads_active=lambda: plugin.url_for(downloads_en_curso),
    )


@plugin.route("/descargas/en-curso")
def downloads_en_curso():
    _run_downloads_active(
        plugin_handle=plugin.handle,
        default_list_art=_default_list_art,
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/descargas/<kind_slug>")
def downloads_list(kind_slug):
    _run_downloads_list(
        plugin_handle=plugin.handle,
        default_list_art=_default_list_art,
        kind_slug=kind_slug,
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/download/<result_id>")
def download_movie(result_id):
    _run_download_movie(
        result_id=result_id,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
        set_setting=_set_setting,
        resolve_trakt_result=_resolve_trakt_result,
        pick_stream_dialog=_pick_stream_dialog,
        torrent_player_route=_torrent_player_route,
        resolve_fallback_candidates=_resolve_fallback_source_candidates,
        trakt_public_get=_trakt_public_get,
        debrid_resolve_torrent_for_download=_debrid_resolve_torrent_for_download,
    )


@plugin.route(
    "/download/series/<show_trakt_id>/season/<season_number>/episode/<episode_number>"
)
def download_episode(show_trakt_id, season_number, episode_number):
    _run_download_episode(
        show_trakt_id=show_trakt_id,
        season_number=season_number,
        episode_number=episode_number,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
        set_setting=_set_setting,
        resolve_trakt_episode_stream=_resolve_trakt_episode_stream,
        pick_stream_dialog=_pick_stream_dialog,
        torrent_player_route=_torrent_player_route,
        trakt_public_get=_trakt_public_get,
        debrid_resolve_torrent_for_download=_debrid_resolve_torrent_for_download,
    )


@plugin.route("/download/series/<show_trakt_id>/season/<season_number>")
def download_season(show_trakt_id, season_number):
    _run_download_season(
        show_trakt_id=show_trakt_id,
        season_number=season_number,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
        set_setting=_set_setting,
        resolve_trakt_episode_stream=_resolve_trakt_episode_stream,
        pick_stream_url_silent=_pick_stream_url_silent,
        torrent_player_route=_torrent_player_route,
        trakt_public_get=_trakt_public_get,
        debrid_resolve_torrent_for_download=_debrid_resolve_torrent_for_download,
    )


@plugin.route("/download/series/<show_trakt_id>/complete")
def download_show_complete(show_trakt_id):
    _run_download_show(
        show_trakt_id=show_trakt_id,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
        set_setting=_set_setting,
        resolve_trakt_episode_stream=_resolve_trakt_episode_stream,
        pick_stream_url_silent=_pick_stream_url_silent,
        torrent_player_route=_torrent_player_route,
        trakt_public_get=_trakt_public_get,
        debrid_resolve_torrent_for_download=_debrid_resolve_torrent_for_download,
    )


@plugin.route("/trakt/show/<show_trakt_id>/seasons")
def show_seasons(show_trakt_id):
    _run_show_seasons_route(
        run_show_seasons=_run_show_seasons,
        plugin_handle=plugin.handle,
        show_trakt_id=show_trakt_id,
        trakt_public_get=_trakt_public_get,
        default_list_art=_default_list_art,
        url_for_show_episodes=lambda sid, sn: plugin.url_for(
            show_episodes, show_trakt_id=sid, season_number=sn
        ),
        json_get=_json_get,
        tmdb_api_key=_tmdb_api_key,
        metadata_timeout=_metadata_timeout,
        tmdb_enabled=_tmdb_enabled,
        tmdb_image_base=TMDB_IMAGE_BASE,
    )


@plugin.route("/trakt/show/<show_trakt_id>/season/<season_number>/episodes")
def show_episodes(show_trakt_id, season_number):
    _run_show_episodes_route(
        run_show_episodes=_run_show_episodes,
        plugin_handle=plugin.handle,
        show_trakt_id=show_trakt_id,
        season_number=season_number,
        trakt_public_get=_trakt_public_get,
        default_list_art=_default_list_art,
        url_for_play_episode=lambda sid, sn, en: plugin.url_for(
            play_episode, show_trakt_id=sid, season_number=sn, episode_number=en
        ),
        json_get=_json_get,
        tmdb_api_key=_tmdb_api_key,
        metadata_timeout=_metadata_timeout,
        tmdb_enabled=_tmdb_enabled,
        tmdb_image_base=TMDB_IMAGE_BASE,
    )


@plugin.route(
    "/trakt/show/<show_trakt_id>/season/<season_number>/episode/<episode_number>/play"
)
def play_episode(show_trakt_id, season_number, episode_number):
    _run_play_episode_route(
        run_play_episode=_run_play_episode,
        plugin_handle=plugin.handle,
        show_trakt_id=show_trakt_id,
        season_number=season_number,
        episode_number=episode_number,
        kraken_progress=_kraken_progress,
        resolver_progress_phase=RESOLVER_PROGRESS_PHASE,
        resolver_progress_detail=_resolver_progress_detail,
        resolve_trakt_episode_stream=_resolve_trakt_episode_stream,
        pick_stream_dialog=_pick_stream_dialog,
        finalize_playback_stream_url=_finalize_playback_stream_url,
        trakt_public_get=_trakt_public_get,
        get_setting=_get_setting,
        set_setting=_set_setting,
        get_bool_setting=_get_bool_setting,
    )


@plugin.route("/trakt/in-progress-choice/<show_trakt_id>/<season>/<episode>")
def trakt_in_progress_choice(show_trakt_id, season, episode):
    _run_series_in_progress_choice(
        plugin_handle=plugin.handle,
        show_trakt_id=show_trakt_id,
        season_str=str(season),
        episode_str=str(episode),
        url_for_play_episode=lambda sid, sn, en: plugin.url_for(
            play_episode,
            show_trakt_id=str(sid),
            season_number=str(sn),
            episode_number=str(en),
        ),
        url_for_show_seasons=lambda sid: plugin.url_for(
            show_seasons, show_trakt_id=str(sid)
        ),
        default_list_art=_default_list_art,
    )


@plugin.route("/proveedores")
def providers_view():
    _run_providers_view_route(
        run_providers_view=_run_providers_view,
        plugin_handle=plugin.handle,
        get_enabled_providers=_get_enabled_providers,
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/proveedores/check")
def providers_check():
    _run_providers_check_route(
        run_providers_check=_run_providers_check,
        plugin_handle=plugin.handle,
        get_enabled_providers=_get_enabled_providers,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
        set_setting=_set_setting,
        addon_installed=_addon_installed,
        load_scraper_module=_load_scraper_module,
        json_get=_json_get,
    )


@plugin.route("/proveedores/lite/links/list")
def providers_lite_links_list():
    _run_lite_link_providers_list(
        plugin_handle=plugin.handle,
        get_bool_setting=_get_bool_setting,
    )


@plugin.route("/proveedores/lite/urls/reset")
def providers_lite_urls_reset():
    _run_lite_urls_reset(
        plugin_handle=plugin.handle,
        set_setting=_set_setting,
    )


@plugin.route("/ajustes")
def settings():
    from resources.lib.ui.settings_pin import allow_open_settings_kodi

    if not allow_open_settings_kodi(get_setting=_get_setting):
        return
    _run_settings_route(
        run_settings=_run_settings_menu,
        plugin_handle=plugin.handle,
        addon=ADDON,
        default_list_art=_default_list_art,
        url_for_views_menu=lambda: plugin.url_for(kraken_tools_views),
        url_for_maintenance_menu=lambda: plugin.url_for(kraken_tools_maintenance),
        url_for_open_kodi_addon_settings=lambda: plugin.url_for(
            kraken_open_kodi_addon_settings
        ),
    )


@plugin.route("/stremio/open/<addon_key>")
def stremio_open_config(addon_key):
    _run_stremio_open_config_route(
        run_stremio_open_config=_run_stremio_open_config,
        addon_key=addon_key,
        peerflix_web_url=PEERFLIX_WEB_URL,
        get_setting=_get_setting,
        addon_path=ADDON.getAddonInfo("path"),
        qr_dialog_cls=_kraken_ui_dialog_classes()["qr"],
    )


@plugin.route("/stremio/open_all")
def stremio_open_all_configs():
    _run_stremio_open_all_configs_route(
        run_stremio_open_all_configs=_run_stremio_open_all_configs,
        stremio_addons_config=_stremio_addons_config,
        stremio_open_all_peerflix=_STREMIO_OPEN_ALL_PEERFLIX,
        peerflix_web_url=PEERFLIX_WEB_URL,
        get_setting=_get_setting,
        addon_path=ADDON.getAddonInfo("path"),
        qr_dialog_cls=_kraken_ui_dialog_classes()["qr"],
    )


@plugin.route("/stremio/clear_cache")
def stremio_clear_cache():
    from resources.lib.providers.stremio_catalog import (
        clear_stremio_manifest_session_cache,
    )

    clear_stremio_manifest_session_cache()


@plugin.route("/stremio/check_manifest")
def stremio_check_manifest():
    _run_stremio_manifest_check(addon=ADDON)


@plugin.route("/kraken/mobile_web")
def kraken_mobile_web():
    _run_kraken_mobile_web_start(
        addon=ADDON,
        addon_path=ADDON.getAddonInfo("path"),
        qr_dialog_cls=_kraken_ui_dialog_classes()["qr"],
    )


@plugin.route("/kraken/mobile_web/stop")
def kraken_mobile_web_stop():
    _run_kraken_mobile_web_stop()


@plugin.route("/trakt/authorize")
def trakt_authorize():
    _run_trakt_authorize_route(
        run_trakt_authorize=_run_trakt_authorize,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
        set_setting=_set_setting,
        ensure_stremio_ready_for_search=_ensure_stremio_ready_for_search,
        trakt_client_id=TRAKT_CLIENT_ID,
        trakt_client_secret=TRAKT_CLIENT_SECRET,
        trakt_post=_trakt_post,
        trakt_get=_trakt_get,
        addon_path=ADDON.getAddonInfo("path"),
        qr_dialog_cls=_kraken_ui_dialog_classes()["qr"],
        auto_start=False,
    )


@plugin.route("/trakt/series-en-seguimiento")
def trakt_series_in_progress():
    _run_trakt_series_in_progress_route(
        run_series_in_progress=_run_series_in_progress,
        plugin_handle=plugin.handle,
        get_bool_setting=_get_bool_setting,
        trakt_is_ready=_trakt_is_ready,
        trakt_authed_get=_trakt_authed_get,
        trakt_progress_translator=_trakt_progress_translator,
        default_list_art=_default_list_art,
        trakt_parse_year=_trakt_parse_year,
        trakt_float_or_none=_trakt_float_or_none,
        tmdb_id_details=_tmdb_id_details,
        progress_percent_text=_progress_percent_text,
        trakt_list_label1_with_year_rating=_trakt_list_label1_with_year_rating,
        trakt_title_with_year_rating_plain=_trakt_title_with_year_rating_plain,
        url_for_in_progress_pick=lambda show_id, season, number: plugin.url_for(
            trakt_in_progress_choice,
            show_trakt_id=str(show_id),
            season=str(int(season)),
            episode=str(int(number)),
        ),
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/trakt/peliculas-sin-finalizar")
def trakt_movies_in_progress():
    _run_trakt_movies_in_progress_route(
        run_movies_in_progress=_run_movies_in_progress,
        plugin_handle=plugin.handle,
        get_bool_setting=_get_bool_setting,
        trakt_is_ready=_trakt_is_ready,
        trakt_authed_get=_trakt_authed_get,
        trakt_progress_translator=_trakt_progress_translator,
        default_list_art=_default_list_art,
        trakt_year_from_movie_dict=_trakt_year_from_movie_dict,
        trakt_float_or_none=_trakt_float_or_none,
        tmdb_id_details=_tmdb_id_details,
        progress_percent_text=_progress_percent_text,
        trakt_list_label1_with_year_rating=_trakt_list_label1_with_year_rating,
        trakt_title_with_year_rating_plain=_trakt_title_with_year_rating_plain,
        safe_votes_str=_safe_votes_str,
        trakt_listitem_set_info_and_videotag=_trakt_listitem_set_info_and_videotag,
        url_for_play=lambda trakt_id: _url_for_play_result(f"trakt::movie::{trakt_id}"),
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/trakt/peliculas-relacionadas-recientes")
def trakt_movies_related_recent():
    _run_trakt_movies_related_recent_route(
        run_movies_related_recent=_run_movies_related_recent,
        plugin_handle=plugin.handle,
        get_bool_setting=_get_bool_setting,
        trakt_is_ready=_trakt_is_ready,
        trakt_authed_get=_trakt_authed_get,
        trakt_progress_translator=_trakt_progress_translator,
        default_list_art=_default_list_art,
        trakt_parse_year=_trakt_parse_year,
        trakt_float_or_none=_trakt_float_or_none,
        tmdb_id_details=_tmdb_id_details,
        trakt_list_label1_with_year_rating=_trakt_list_label1_with_year_rating,
        url_for_play=lambda trakt_id: _url_for_play_result(f"trakt::movie::{trakt_id}"),
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/trakt/series-relacionadas-recientes")
def trakt_series_related_recent():
    _run_trakt_series_related_recent_route(
        run_series_related_recent=_run_series_related_recent,
        plugin_handle=plugin.handle,
        get_bool_setting=_get_bool_setting,
        trakt_is_ready=_trakt_is_ready,
        trakt_authed_get=_trakt_authed_get,
        trakt_progress_translator=_trakt_progress_translator,
        default_list_art=_default_list_art,
        trakt_parse_year=_trakt_parse_year,
        trakt_float_or_none=_trakt_float_or_none,
        tmdb_id_details=_tmdb_id_details,
        trakt_list_label1_with_year_rating=_trakt_list_label1_with_year_rating,
        url_for_show_seasons=lambda show_id: plugin.url_for(
            show_seasons, show_trakt_id=str(show_id)
        ),
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/trakt/anime-en-seguimiento")
def trakt_anime_in_progress():
    _run_trakt_series_in_progress_route(
        run_series_in_progress=_run_series_in_progress,
        plugin_handle=plugin.handle,
        get_bool_setting=_get_bool_setting,
        trakt_is_ready=_trakt_is_ready,
        trakt_authed_get=_trakt_authed_get,
        trakt_progress_translator=_trakt_progress_translator,
        default_list_art=_default_list_art,
        trakt_parse_year=_trakt_parse_year,
        trakt_float_or_none=_trakt_float_or_none,
        tmdb_id_details=_tmdb_id_details,
        progress_percent_text=_progress_percent_text,
        trakt_list_label1_with_year_rating=_trakt_list_label1_with_year_rating,
        trakt_title_with_year_rating_plain=_trakt_title_with_year_rating_plain,
        url_for_in_progress_pick=lambda show_id, season, number: plugin.url_for(
            trakt_in_progress_choice,
            show_trakt_id=str(show_id),
            season=str(int(season)),
            episode=str(int(number)),
        ),
        url_for_noop=lambda: plugin.url_for(noop),
        anime_only=True,
        category_title=_t(
            "Kraken - Trakt - Anime en seguimiento",
            "Kraken - Trakt - Anime in progress",
            "Kraken - Trakt - Anime en cours",
            "Kraken - Trakt - Anime in corso",
            "Kraken - Trakt - Anime in Bearbeitung",
        ),
        empty_label=_t(
            "No hay anime en seguimiento",
            "No anime in progress",
            "Aucun anime en cours",
            "Nessun anime in corso",
            "Kein Anime in Bearbeitung",
        ),
    )


@plugin.route("/trakt/anime-relacionados-recientes")
def trakt_anime_related_recent():
    _run_trakt_series_related_recent_route(
        run_series_related_recent=_run_series_related_recent,
        plugin_handle=plugin.handle,
        get_bool_setting=_get_bool_setting,
        trakt_is_ready=_trakt_is_ready,
        trakt_authed_get=_trakt_authed_get,
        trakt_progress_translator=_trakt_progress_translator,
        default_list_art=_default_list_art,
        trakt_parse_year=_trakt_parse_year,
        trakt_float_or_none=_trakt_float_or_none,
        tmdb_id_details=_tmdb_id_details,
        trakt_list_label1_with_year_rating=_trakt_list_label1_with_year_rating,
        url_for_show_seasons=lambda show_id: plugin.url_for(
            show_seasons, show_trakt_id=str(show_id)
        ),
        url_for_noop=lambda: plugin.url_for(noop),
        anime_only=True,
        category_title=_t(
            "Kraken - Trakt - Anime relacionados",
            "Kraken - Trakt - Related anime",
            "Kraken - Trakt - Anime connexes",
            "Kraken - Trakt - Anime correlati",
            "Kraken - Trakt - Aehnliches Anime",
        ),
        empty_label=_t(
            "Sin recomendaciones relacionadas de anime",
            "No related anime recommendations",
            "Aucune recommandation d'anime connexe",
            "Nessun consiglio di anime correlati",
            "Keine aehnlichen Anime-Empfehlungen",
        ),
    )


@plugin.route("/trakt/anime-aleatorio-reciente")
def trakt_anime_random_recent():
    _run_trakt_series_random_recent_route(
        run_series_random_recent=_run_series_random_recent,
        plugin_handle=plugin.handle,
        get_bool_setting=_get_bool_setting,
        trakt_is_ready=_trakt_is_ready,
        trakt_authed_get=_trakt_authed_get,
        trakt_progress_translator=_trakt_progress_translator,
        default_list_art=_default_list_art,
        trakt_parse_year=_trakt_parse_year,
        trakt_float_or_none=_trakt_float_or_none,
        tmdb_id_details=_tmdb_id_details,
        url_for_show_seasons=lambda show_id: plugin.url_for(
            show_seasons, show_trakt_id=str(show_id)
        ),
        url_for_noop=lambda: plugin.url_for(noop),
        anime_only=True,
        empty_label=_t(
            "Sin anime aleatorio disponible",
            "No random anime available",
            "Aucun anime aleatoire disponible",
            "Nessun anime casuale disponibile",
            "Kein Zufalls-Anime verfügbar",
        ),
        item_label=_t(
            "Abrir anime aleatorio",
            "Open random anime",
            "Ouvrir un anime aleatoire",
            "Apri anime casuale",
            "Zufalls-Anime öffnen",
        ),
    )


@plugin.route("/trakt/pelicula-aleatoria-reciente")
def trakt_movies_random_recent():
    _run_trakt_movies_random_recent_route(
        run_movies_random_recent=_run_movies_random_recent,
        plugin_handle=plugin.handle,
        get_bool_setting=_get_bool_setting,
        trakt_is_ready=_trakt_is_ready,
        trakt_authed_get=_trakt_authed_get,
        trakt_progress_translator=_trakt_progress_translator,
        default_list_art=_default_list_art,
        trakt_parse_year=_trakt_parse_year,
        trakt_float_or_none=_trakt_float_or_none,
        tmdb_id_details=_tmdb_id_details,
        url_for_play=lambda trakt_id: _url_for_play_result(f"trakt::movie::{trakt_id}"),
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/trakt/serie-aleatoria-reciente")
def trakt_series_random_recent():
    _run_trakt_series_random_recent_route(
        run_series_random_recent=_run_series_random_recent,
        plugin_handle=plugin.handle,
        get_bool_setting=_get_bool_setting,
        trakt_is_ready=_trakt_is_ready,
        trakt_authed_get=_trakt_authed_get,
        trakt_progress_translator=_trakt_progress_translator,
        default_list_art=_default_list_art,
        trakt_parse_year=_trakt_parse_year,
        trakt_float_or_none=_trakt_float_or_none,
        tmdb_id_details=_tmdb_id_details,
        url_for_show_seasons=lambda show_id: plugin.url_for(
            show_seasons, show_trakt_id=str(show_id)
        ),
        url_for_noop=lambda: plugin.url_for(noop),
    )


@plugin.route("/trakt/logout")
def trakt_logout():
    _run_trakt_logout_route(
        run_trakt_logout=_run_trakt_logout, set_setting=_set_setting
    )


@plugin.route("/debrid/<slug>/connect")
def debrid_provider_connect(slug):
    _ensure_debrid_legacy_migrated()
    _run_debrid_provider_connect(
        slug=slug,
        get_bool_setting=_get_bool_setting,
        set_setting=_set_setting,
        alldebrid_pin_authorize=_alldebrid_pin_authorize,
    )


@plugin.route("/debrid/<slug>/disconnect")
def debrid_provider_disconnect(slug):
    _ensure_debrid_legacy_migrated()
    _run_debrid_provider_disconnect(slug=slug, set_setting=_set_setting)


@plugin.route("/debrid/<slug>/test")
def debrid_provider_test(slug):
    _ensure_debrid_legacy_migrated()
    _run_debrid_provider_test(
        slug=slug,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
        set_setting=_set_setting,
        json_get=_json_get,
    )


@plugin.route("/debrid/<slug>/info")
def debrid_provider_info(slug):
    _ensure_debrid_legacy_migrated()
    _run_debrid_provider_show_info(
        slug=slug,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
    )


@plugin.route("/debrid/service/clear_cache")
def debrid_service_clear_cache():
    """Vacia caches en memoria relacionadas con búsqueda (no toca tokens Debrid)."""
    try:
        _SEARCH_RESULT_CACHE.clear()
    except Exception:
        pass

    xbmcgui.Dialog().notification(
        "Kraken",
        _t(
            "Caché de búsqueda vaciada.",
            "Search cache cleared.",
            "Cache de recherche vidé.",
            "Cache di ricerca svuotata.",
            "Such-Cache geleert.",
        ),
        xbmcgui.NOTIFICATION_INFO,
        4500,
    )


@plugin.route("/kraken/tools")
def kraken_tools():
    _run_kraken_tools_hub(
        plugin_handle=plugin.handle,
        addon=ADDON,
        url_for_views_menu=lambda: plugin.url_for(kraken_tools_views),
        url_for_open_kodi_addon_settings=lambda: plugin.url_for(
            kraken_open_kodi_addon_settings
        ),
        url_for_maintenance_menu=lambda: plugin.url_for(kraken_tools_maintenance),
        url_for_show_changelog=lambda: plugin.url_for(kraken_tools_changelog),
        url_for_tail_log=lambda: plugin.url_for(kraken_tools_log_tail),
        default_list_art=_default_list_art,
    )


@plugin.route("/kraken/open_kodi_addon_settings")
def kraken_open_kodi_addon_settings():
    _run_kraken_open_kodi_addon_settings(
        addon_id=ADDON.getAddonInfo("id"),
        addon=ADDON,
        icon_path_fn=_kraken_addon_icon,
    )
    _kraken_tools_noop_end(plugin.handle)


@plugin.route("/kraken/tools/views")
def kraken_tools_views():
    _run_kraken_views_menu(
        plugin_handle=plugin.handle,
        addon=ADDON,
        url_for_pick_profile_fn=lambda slug: plugin.url_for(
            kraken_tools_views_profile,
            slug=str(slug),
        ),
        default_list_art=_default_list_art,
    )


@plugin.route("/kraken/tools/views/<slug>")
def kraken_tools_views_profile(slug):
    _run_kraken_views_pick(
        profile_slug=str(slug or "").strip(),
        addon=ADDON,
        get_setting=_get_setting,
        set_setting=_set_setting,
        icon_path_fn=_kraken_addon_icon,
    )
    _kraken_tools_noop_end(plugin.handle)


@plugin.route("/kraken/tools/maintenance")
def kraken_tools_maintenance():
    _run_kraken_maintenance_menu(
        plugin_handle=plugin.handle,
        addon=ADDON,
        profile_path_translate="special://masterprofile",
        url_library_clean=lambda: plugin.url_for(
            kraken_tools_maintenance_library_clean
        ),
        url_library_scan=lambda: plugin.url_for(kraken_tools_maintenance_library_scan),
        url_clear_omdb=lambda: plugin.url_for(kraken_tools_maintenance_run, slug="omdb"),
        url_clear_ram=lambda: plugin.url_for(kraken_tools_maintenance_run, slug="ram"),
        url_clear_stremio=lambda: plugin.url_for(
            kraken_tools_maintenance_run, slug="stremio"
        ),
        url_clear_logos=lambda: plugin.url_for(kraken_tools_maintenance_run, slug="logos"),
        url_clear_all=lambda: plugin.url_for(kraken_tools_maintenance_run, slug="all"),
        default_list_art=_default_list_art,
    )


@plugin.route("/kraken/tools/maintenance/run/library_clean")
def kraken_tools_maintenance_library_clean():
    _run_kraken_kodi_library_action(
        action="clean", addon=ADDON, icon_path_fn=_kraken_addon_icon
    )
    _kraken_tools_noop_end(plugin.handle)


@plugin.route("/kraken/tools/maintenance/run/library_scan")
def kraken_tools_maintenance_library_scan():
    _run_kraken_kodi_library_action(
        action="scan", addon=ADDON, icon_path_fn=_kraken_addon_icon
    )
    _kraken_tools_noop_end(plugin.handle)


@plugin.route("/kraken/tools/maintenance/run/<slug>")
def kraken_tools_maintenance_run(slug):
    _run_kraken_maintenance_confirm(
        action=str(slug or "").strip(),
        addon=ADDON,
        omdb_clear_fn=_clear_omdb_cache_file_impl,
        logos_clear_fn=_clear_cached_logos_impl,
        stremio_clear_fn=_clear_stremio_manifest_session_impl,
        ram_clear_fn=_kraken_clear_ram_search,
        icon_path_fn=_kraken_addon_icon,
    )
    _kraken_tools_noop_end(plugin.handle)


@plugin.route("/kraken/tools/changelog")
def kraken_tools_changelog():
    _run_kraken_tools_changelog(addon=ADDON, icon_path_fn=_kraken_addon_icon)
    _kraken_tools_noop_end(plugin.handle)


@plugin.route("/kraken/tools/logtail")
def kraken_tools_log_tail():
    _run_kraken_tools_logtail(addon=ADDON, icon_path_fn=_kraken_addon_icon)
    _kraken_tools_noop_end(plugin.handle)


@plugin.route("/cuentas")
def accounts_status():
    _run_accounts_status_route(
        run_accounts_status=_run_accounts_status,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
        get_stremio_toggle_names=_get_stremio_toggle_names,
        tmdb_enabled=_tmdb_enabled,
        omdb_enabled=_omdb_enabled,
        addon_path=ADDON.getAddonInfo("path"),
        qr_dialog_cls=_kraken_ui_dialog_classes()["qr"],
    )


@plugin.route("/noop")
def noop():
    _run_noop()


@plugin.route("/sources/repick")
def sources_repick():
    _run_source_repick(
        pick_stream_dialog=_pick_stream_dialog,
        finalize_playback_stream_url=_finalize_playback_stream_url,
    )


@plugin.route("/sources/stremio")
def sources_stremio_hub():
    _run_sources_stremio_hub(
        addon=ADDON,
        get_bool_setting=_get_bool_setting,
        get_setting=_get_setting,
        set_setting=_set_setting,
        plugin_url_open_all=plugin.url_for(stremio_open_all_configs),
        plugin_url_settings_stremio=plugin.url_for(kraken_open_kodi_addon_settings),
        addon_path=ADDON.getAddonInfo("path"),
        qr_dialog_cls=_kraken_ui_dialog_classes()["qr"],
    )


@plugin.route("/trakt/prefetch_next/<show_id>/<season_num>/<ep_num>")
def trakt_prefetch_next(show_id, season_num, ep_num):
    _run_trakt_prefetch_next_route(
        run_trakt_prefetch_next=_run_trakt_prefetch_next,
        show_id=show_id,
        season_num=season_num,
        ep_num=ep_num,
        get_bool_setting=_get_bool_setting,
        trakt_next_episode_pair=_trakt_next_episode_pair,
        kraken_progress=_kraken_progress,
        resolve_trakt_episode_stream=_resolve_trakt_episode_stream,
        pick_stream_url_silent=_pick_stream_url_silent,
        finalize_playback_stream_url=_finalize_playback_stream_url,
        trakt_public_get=_trakt_public_get,
    )


if __name__ == "__main__":
    plugin.run()
