import time
from urllib.error import URLError

import xbmc
import xbmcgui

from resources.lib.core.kraken_qr_ui import (
    device_activation_qr_url,
    open_kraken_qr_modal,
    write_qr_png_to_special_temp,
)
from resources.lib.ui.ui_helpers import _t


def run_trakt_authorize(
    *,
    get_bool_setting,
    get_setting=None,
    set_setting,
    ensure_stremio_ready_for_search=None,
    trakt_client_id,
    trakt_client_secret,
    trakt_post,
    trakt_get,
    addon_path=None,
    qr_dialog_cls=None,
    auto_start=False,
):
    if not get_bool_setting("trakt_enabled"):
        set_setting("trakt_enabled", "true")
        xbmcgui.Dialog().notification(
            "Kraken - Trakt",
            _t(
                "Trakt activado automaticamente",
                "Trakt enabled automatically",
                "Trakt active automatiquement",
                "Trakt attivato automaticamente",
                "Trakt automatisch aktiviert",
            ),
            xbmcgui.NOTIFICATION_INFO,
        )

    client_id = trakt_client_id
    client_secret = trakt_client_secret
    if not client_id or not client_secret:
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t(
                "No hay configuración interna de Trakt disponible.",
                "No internal Trakt configuration is available.",
                "Aucune configuration interne Trakt disponible.",
                "Nessuna configurazione interna Trakt disponibile.",
                "Keine interne Trakt-Konfiguration verfügbar.",
            ),
        )
        return

    try:
        device = trakt_post(
            "https://api.trakt.tv/oauth/device/code",
            {"client_id": client_id},
        )
    except (URLError, ValueError):
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t(
                "No se pudo iniciar la autorizacion con Trakt.",
                "Could not start Trakt authorization.",
                "Impossible de demarrer l'autorisation Trakt.",
                "Impossibile avviare l'autorizzazione Trakt.",
                "Trakt-Autorisierung konnte nicht gestartet werden.",
            ),
        )
        return

    user_code = device.get("user_code", "")
    device_code = device.get("device_code", "")
    interval = int(device.get("interval", 5))
    expires_in = int(device.get("expires_in", 600))
    if not user_code or not device_code:
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t(
                "Respuesta invalida de Trakt.",
                "Invalid response from Trakt.",
                "Reponse Trakt invalide.",
                "Risposta Trakt non valida.",
                "Ungültige Trakt-Antwort.",
            ),
        )
        return

    verify_page = (
        device.get("verification_url") or "https://trakt.tv/activate"
    ).strip()
    activate_complete = (
        device.get("verification_uri_complete") or ""
    ).strip().split("#", 1)[0]
    activate_url = activate_complete or device_activation_qr_url(
        verify_page, user_code
    ) or verify_page
    token_holder: dict = {}

    def try_fetch_tokens():
        if token_holder.get("_tokens"):
            return True
        try:
            td = trakt_post(
                "https://api.trakt.tv/oauth/device/token",
                {
                    "code": device_code,
                    "client_id": client_id,
                    "client_secret": client_secret,
                },
            )
        except (URLError, ValueError):
            return False
        if td and td.get("access_token"):
            token_holder["_tokens"] = td
            return True
        return False

    deadline = time.time() + expires_in
    poll_kw = dict(
        poll_interval_sec=float(max(1, interval)),
        poll_deadline_epoch=deadline,
        poll_fn=try_fetch_tokens,
    )

    if auto_start:
        xbmcgui.Dialog().notification(
            "Kraken - Trakt",
            _t(
                "Escanea el QR en el telefono; la ventana se cerrara cuando Trakt autorice.",
                "Scan QR on phone; window closes once Trakt authorizes.",
                "Scannez le QR sur le téléphone ; la fenêtre se ferme après autorisation.",
                "Scansiona il QR sul telefono; si chiude quando Trakt autorizza.",
                "QR auf dem Telefon scannen; Fenster schließt sich nach Freigabe.",
            ),
            xbmcgui.NOTIFICATION_INFO,
            4000,
        )

    showed_qr = False
    if qr_dialog_cls and addon_path:
        qr_path = write_qr_png_to_special_temp(
            "kraken_trakt_activate_qr.png", activate_url, scale=6, border=4
        )
        if qr_path:
            showed_qr = True
            open_kraken_qr_modal(
                qr_dialog_cls,
                addon_path,
                dialog_title=f"Kraken - Trakt (PIN: {user_code})",
                body_text=_t(
                    f"{verify_page}  Codigo: {user_code}",
                    f"{verify_page}  Code: {user_code}",
                    f"{verify_page}  Code : {user_code}",
                    f"{verify_page}  Codice: {user_code}",
                    f"{verify_page}  Code: {user_code}",
                ),
                qr_special_path=qr_path,
                **poll_kw,
            )
        else:
            xbmcgui.Dialog().ok(
                "Kraken - Trakt",
                _t(
                    f"Abre {verify_page} con el PIN {user_code}.\n\n(No se pudo crear el PNG del QR.)",
                    f"Open {verify_page} with PIN {user_code}.\n\n(Could not generate QR PNG.)",
                    f"Ouvre {verify_page} avec le PIN {user_code}.\n\n(Generation PNG du QR impossible.)",
                    f"Apri {verify_page} con il PIN {user_code}.\n\n(Impossibile generare il PNG QR.)",
                    f"Öffne {verify_page} mit PIN {user_code}.\n\n(QR-PNG konnte nicht erstellt werden.)",
                ),
            )

    if not showed_qr:
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t(
                f"Abre {verify_page}\nCodigo: {user_code}\n\nPulsa OK cuando lo hayas activado.",
                f"Open {verify_page}\nCode: {user_code}\n\nPress OK when you have activated it.",
                f"Ouvre {verify_page}\nCode : {user_code}\n\nAppuie sur OK apres activation.",
                f"Apri {verify_page}\nCodice: {user_code}\n\nPremi OK dopo aver attivato.",
                f"Öffne {verify_page}\nCode: {user_code}\n\nOK drücken, wenn aktiviert.",
            ),
        )

    token_data = token_holder.get("_tokens")
    while (not token_data or not token_data.get("access_token")) and time.time() < deadline:
        if try_fetch_tokens():
            token_data = token_holder.get("_tokens")
            break
        xbmc.sleep(interval * 1000)

    if not token_data or not token_data.get("access_token"):
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t(
                "Autorizacion no completada o expirada.",
                "Authorization not completed or expired.",
                "Autorisation non terminee ou expiree.",
                "Autorizzazione non completata o scaduta.",
                "Autorisierung nicht abgeschlossen oder abgelaufen.",
            ),
        )
        return

    set_setting("trakt_access_token", token_data.get("access_token", ""))
    set_setting("trakt_refresh_token", token_data.get("refresh_token", ""))
    set_setting("trakt_enabled", "true")
    try:
        created_at = int(token_data.get("created_at") or int(time.time()))
    except (TypeError, ValueError):
        created_at = int(time.time())
    try:
        expires_in = int(token_data.get("expires_in") or 0)
    except (TypeError, ValueError):
        expires_in = 0
    set_setting("trakt_token_expires", str(created_at + max(0, expires_in)))
    # Tras conectar Trakt, dejar Stremio listo para buscar sin pasar por el menú principal.
    try:
        if ensure_stremio_ready_for_search and get_setting:
            ensure_stremio_ready_for_search(get_bool_setting, get_setting, set_setting)
    except Exception:
        pass
    username = ""
    try:
        user_data = trakt_get(
            "https://api.trakt.tv/users/settings",
            client_id,
            token_data.get("access_token", ""),
        )
        username = (user_data.get("user", {}) or {}).get("username", "")
    except Exception:
        username = ""
    set_setting(
        "trakt_account_info",
        _t("Conectada: {}", "Connected: {}", "Connecte : {}", "Connesso: {}", "Verbunden: {}").format(username or "OK"),
    )
    xbmcgui.Dialog().notification(
        "Kraken - Trakt",
        _t(
            "Trakt conectado: {}",
            "Trakt connected: {}",
            "Trakt connecte : {}",
            "Trakt connesso: {}",
            "Trakt verbunden: {}",
        ).format(username if username else "OK"),
        xbmcgui.NOTIFICATION_INFO,
        6500,
    )


def run_trakt_logout(*, set_setting):
    set_setting("trakt_access_token", "")
    set_setting("trakt_refresh_token", "")
    set_setting("trakt_token_expires", "")
    set_setting(
        "trakt_account_info",
        _t("No conectada", "Not connected", "Non connectee", "Non connessa", "Nicht verbunden"),
    )
    xbmcgui.Dialog().ok(
        "Kraken - Trakt",
        _t("Sesion cerrada.", "Logged out.", "Session fermee.", "Sessione chiusa.", "Sitzung beendet."),
    )
