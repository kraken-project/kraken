import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import quote, urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib.core.playback_listitem import configure_listitem_stream_properties
from resources.lib.core.playback_source_stash import stash_source_candidates
from resources.lib.core.settings_helpers import get_setting as _addon_get_setting
from resources.lib.ui.context_menu import (
    add_episode_download_context,
    add_season_download_context,
)
from resources.lib.routes.play_routes import _is_unrouted_torrent_url
from resources.lib.ui.video_info import apply_video_info
from resources.lib.routes.i18n_routes import make_mapped_t

_TRAKT_SHOW_PHRASE_MAP = {
    ("Episode {}", "Episode {}"): ("Épisode {}", "Episodio {}", "Episode {}"),
}


_t = make_mapped_t(_TRAKT_SHOW_PHRASE_MAP)


def _trakt_effective_translations_code():
    """Idioma para traducciones Trakt, alineado con ajuste interno/Kodi."""
    try:
        addon = xbmcaddon.Addon()
        raw = str(_addon_get_setting(addon, "trakt_plot_language") or "").strip()
    except Exception:
        raw = ""
    low = raw.lower()
    for code in ("es", "en", "fr", "it", "pt", "de"):
        if low == code or low == f"{code} ":
            return code
    if (low and "auto" in low) or (not raw) or raw == "Auto (Kodi)":
        try:
            rpc = xbmc.executeJSONRPC(
                '{"jsonrpc":"2.0","id":0,"method":"Settings.GetSettingValue",'
                '"params":{"setting":"locale.language"}}'
            )
            payload = json.loads(rpc) if rpc else {}
            val = str(payload.get("result", {}).get("value") or "").lower().strip()
        except Exception:
            val = ""
        if val.startswith("resource.language.spanish") or val.startswith("es"):
            return "es"
        if val.startswith("resource.language.english") or val.startswith("en"):
            return "en"
        return "es"
    if len(raw) == 2 and raw.isalpha():
        return raw.lower()
    return "es"


def _trakt_listing_translation_lang():
    """
    Idioma al navegar temporadas y capítulos (título de serie, temporada y capítulo).
    Respeta `trakt_plot_language` si el usuario fija un código; con Auto o vacío
    se usa español para títulos y sinopsis (flujo esperado: ver lista antes de
    reproducir y buscar fuentes al elegir capítulo).
    """
    try:
        addon = xbmcaddon.Addon()
        raw = str(_addon_get_setting(addon, "trakt_plot_language") or "").strip()
    except Exception:
        raw = ""
    low = (raw or "").lower()
    if low in ("es", "en", "fr", "it", "pt", "de"):
        return low
    if (not raw) or ("auto" in low) or (raw == "Auto (Kodi)"):
        return "es"
    if len(raw) == 2 and raw.isalpha():
        return raw.lower()
    return "es"


def _trakt_translation_title_overview(
    trakt_public_get, *, show_id, season_num=None, episode_num=None, language="es"
):
    if not show_id or not language:
        return ""
    try:
        if season_num is None:
            url = f"https://api.trakt.tv/shows/{quote(show_id)}/translations/{language}"
        elif episode_num is None:
            url = f"https://api.trakt.tv/shows/{quote(show_id)}/seasons/{int(season_num)}/translations/{language}"
        else:
            url = f"https://api.trakt.tv/shows/{quote(show_id)}/seasons/{int(season_num)}/episodes/{int(episode_num)}/translations/{language}"
        rows = trakt_public_get(url)
        if isinstance(rows, list) and rows:
            row0 = rows[0] or {}
            return (
                str(row0.get("title") or "").strip(),
                str(row0.get("overview") or "").strip(),
            )
    except Exception:
        return "", ""
    return "", ""


def _prefetch_season_translations_map(
    trakt_public_get, *, show_id, season_nums, language, max_workers=8
):
    """Varias rutas translations de temporadas en paralelo."""
    uniq = sorted({int(sn) for sn in (season_nums or []) if sn is not None})
    out = {}

    def one(sn_int):
        t_tr, p_tr = _trakt_translation_title_overview(
            trakt_public_get, show_id=show_id, season_num=sn_int, language=language
        )
        return sn_int, (t_tr or "", p_tr or "")

    if not uniq or not show_id:
        return out
    workers = min(max(1, int(max_workers)), len(uniq))
    try:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futures = [ex.submit(one, sn_i) for sn_i in uniq]
            for fut in as_completed(futures):
                try:
                    sn_int, tup = fut.result()
                    out[sn_int] = tup
                except Exception:
                    pass
    except Exception:
        for sn_i in uniq:
            try:
                sn_int, tup = one(sn_i)
                out[sn_int] = tup
            except Exception:
                pass
    for sn_i in uniq:
        out.setdefault(sn_i, ("", ""))
    return out


def _prefetch_episode_translations_map(
    trakt_public_get,
    *,
    show_id,
    season_num,
    episode_nums,
    language,
    max_workers=12,
):
    """Traducciones de episodios en paralelo (evita latencia serial al abrir una temporada)."""
    uniq = sorted(
        {int(en) for en in (episode_nums or []) if en is not None and int(en) >= 1}
    )
    out = {}

    def one(en_int):
        t_tr, p_tr = _trakt_translation_title_overview(
            trakt_public_get,
            show_id=show_id,
            season_num=season_num,
            episode_num=en_int,
            language=language,
        )
        return en_int, {
            "title": str(t_tr or "").strip(),
            "plot": str(p_tr or "").strip(),
        }

    if not uniq or not show_id:
        return out
    workers = min(max(1, int(max_workers)), len(uniq))
    try:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futures = [ex.submit(one, en_i) for en_i in uniq]
            for fut in as_completed(futures):
                try:
                    en_int, blob = fut.result()
                    out[en_int] = blob
                except Exception:
                    pass
    except Exception:
        for en_i in uniq:
            try:
                en_int, blob = one(en_i)
                out[en_int] = blob
            except Exception:
                pass
    for en_i in uniq:
        out.setdefault(en_i, {"title": "", "plot": ""})
    return out


def _tmdb_numeric_show_id_from_trakt(show_data):
    ids = (show_data or {}).get("ids") or {}
    raw = ids.get("tmdb")
    if raw is None:
        return None
    try:
        return int(str(raw).strip())
    except (TypeError, ValueError):
        return None


def _tmdb_get_season_detail(
    json_get, tmdb_api_key_fn, metadata_timeout_fn, tmdb_tv_id, season_num_int
):
    if not callable(json_get) or not callable(tmdb_api_key_fn):
        return {}
    api = str(tmdb_api_key_fn() or "").strip()
    if not api or not tmdb_tv_id:
        return {}
    try:
        sid = int(tmdb_tv_id)
        sn = int(season_num_int)
    except (TypeError, ValueError):
        return {}
    to = 15
    if callable(metadata_timeout_fn):
        try:
            to = max(5, int(metadata_timeout_fn()))
        except (TypeError, ValueError):
            pass
    tr_lang = _trakt_effective_translations_code()
    tmdb_lang = "en-US" if tr_lang == "en" else "es-ES"
    params = urlencode({"api_key": api, "language": tmdb_lang})
    url = "https://api.themoviedb.org/3/tv/{}/season/{}?{}".format(sid, sn, params)
    try:
        doc = json_get(url, timeout=to)
    except Exception:
        return {}
    return doc if isinstance(doc, dict) else {}


def _tmdb_url_from_path(tmdb_image_base, path_fragment):
    base = (tmdb_image_base or "https://image.tmdb.org/t/p/w500").rstrip("/")
    frag = str(path_fragment or "").strip()
    if not frag:
        return ""
    return "{}{}".format(base, frag)


def _prefetch_tmdb_season_poster_urls(
    json_get,
    tmdb_api_key_fn,
    metadata_timeout_fn,
    tmdb_image_base,
    tmdb_enabled_fn,
    show_data,
    season_nums,
):
    """
    Carátulas de temporada (TMDb poster_path por temporada).
    """
    if not callable(tmdb_enabled_fn) or not tmdb_enabled_fn():
        return {}
    tid = _tmdb_numeric_show_id_from_trakt(show_data)
    if not tid or not season_nums:
        return {}
    out = {}

    def one(sn):
        doc = _tmdb_get_season_detail(
            json_get, tmdb_api_key_fn, metadata_timeout_fn, tid, sn
        )
        pp = str((doc or {}).get("poster_path") or "").strip()
        url = _tmdb_url_from_path(tmdb_image_base, pp)
        return int(sn), url

    uniq = sorted({int(x) for x in season_nums if x is not None and int(x) >= 0})
    if not uniq:
        return {}
    workers = min(8, len(uniq))
    try:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = [ex.submit(one, sn) for sn in uniq]
            for fut in as_completed(futs):
                try:
                    sn_i, u = fut.result()
                    if u:
                        out[sn_i] = u
                except Exception:
                    pass
    except Exception:
        for sn in uniq:
            try:
                sn_i, u = one(sn)
                if u:
                    out[sn_i] = u
            except Exception:
                pass
    return out


def _tmdb_season_episode_thumbnails(
    json_get,
    tmdb_api_key_fn,
    metadata_timeout_fn,
    tmdb_image_base,
    tmdb_enabled_fn,
    show_data,
    season_num_int,
):
    """
    Miniatura por capítulo (still_path) + poster de temporada como respaldo.
    Returns: (season_poster_url, dict[episode_num] -> thumb_url)
    """
    if not callable(tmdb_enabled_fn) or not tmdb_enabled_fn():
        return "", {}
    tid = _tmdb_numeric_show_id_from_trakt(show_data)
    if not tid:
        return "", {}
    doc = _tmdb_get_season_detail(
        json_get, tmdb_api_key_fn, metadata_timeout_fn, tid, season_num_int
    )
    if not doc:
        return "", {}
    pp = str(doc.get("poster_path") or "").strip()
    season_poster = _tmdb_url_from_path(tmdb_image_base, pp)
    thumbs = {}
    for ep in doc.get("episodes") or []:
        if not isinstance(ep, dict):
            continue
        try:
            en = int(ep.get("episode_number") or 0)
        except (TypeError, ValueError):
            continue
        if en < 1:
            continue
        st = str(ep.get("still_path") or "").strip()
        u = _tmdb_url_from_path(tmdb_image_base, st)
        if u:
            thumbs[en] = u
    return season_poster, thumbs


def run_show_seasons(
    *,
    plugin_handle,
    show_trakt_id,
    trakt_public_get,
    default_list_art,
    url_for_show_episodes,
    json_get=None,
    tmdb_api_key=None,
    metadata_timeout=None,
    tmdb_enabled=None,
    tmdb_image_base=None,
):
    show_id = (show_trakt_id or "").strip()
    if not show_id:
        xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)
        return
    try:
        show_data = trakt_public_get(
            f"https://api.trakt.tv/shows/{quote(show_id)}?extended=full"
        )
        seasons = trakt_public_get(
            f"https://api.trakt.tv/shows/{quote(show_id)}/seasons?extended=full"
        )
    except Exception:
        xbmcgui.Dialog().notification(
            "Kraken",
            _t(
                "No se pudo cargar temporadas",
                "Could not load seasons",
                "Impossible de charger les saisons",
                "Impossibile caricare le stagioni",
                "Staffeln konnten nicht geladen werden",
            ),
            xbmcgui.NOTIFICATION_WARNING,
        )
        xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)
        return

    show_title = str((show_data or {}).get("title") or _t("Serie", "TV Show", "Serie", "Serie TV", "Serie")).strip()
    show_plot = str((show_data or {}).get("overview") or "").strip()
    lang = _trakt_listing_translation_lang()
    show_title_tr, show_plot_tr = _trakt_translation_title_overview(
        trakt_public_get, show_id=show_id, language=lang
    )
    if show_title_tr:
        show_title = show_title_tr
    show_plot_localized = show_plot_tr or show_plot
    xbmcplugin.setPluginCategory(
        plugin_handle,
        _t(
            f"{show_title} - Temporadas",
            f"{show_title} - Seasons",
            f"{show_title} - Saisons",
            f"{show_title} - Stagioni",
            f"{show_title} - Staffeln",
        ),
    )
    xbmcplugin.setContent(plugin_handle, "seasons")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_UNSORTED)

    season_nums = []
    for season in seasons or []:
        number = season.get("number")
        if number is None or int(number) < 0:
            continue
        season_nums.append(int(number))
    season_tr_map = _prefetch_season_translations_map(
        trakt_public_get,
        show_id=show_id,
        season_nums=season_nums,
        language=lang,
    )

    season_poster_map = _prefetch_tmdb_season_poster_urls(
        json_get,
        tmdb_api_key,
        metadata_timeout,
        tmdb_image_base,
        tmdb_enabled,
        show_data,
        season_nums,
    )

    directory = []
    base_art = default_list_art()
    for season in seasons or []:
        number = season.get("number")
        if number is None or int(number) < 0:
            continue
        label = f"Temporada {number}"
        li = xbmcgui.ListItem(label=label)
        _season_title_tr, season_plot_tr = season_tr_map.get(int(number), ("", ""))
        season_plot = season_plot_tr or show_plot_localized
        apply_video_info(
            li,
            {
                "title": label,
                "tvshowtitle": show_title,
                "plot": season_plot,
                "season": int(number),
            },
        )
        art = dict(base_art)
        poster_url = str(season_poster_map.get(int(number)) or "").strip()
        if poster_url:
            art["thumb"] = poster_url
            art["poster"] = poster_url
            art["icon"] = poster_url
        li.setArt(art)
        add_season_download_context(li, show_id, int(number))
        directory.append((url_for_show_episodes(show_id, str(int(number))), li, True))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)


def run_show_episodes(
    *,
    plugin_handle,
    show_trakt_id,
    season_number,
    trakt_public_get,
    default_list_art,
    url_for_play_episode,
    json_get=None,
    tmdb_api_key=None,
    metadata_timeout=None,
    tmdb_enabled=None,
    tmdb_image_base=None,
):
    show_id = (show_trakt_id or "").strip()
    try:
        season_num = int(str(season_number or "0"))
    except Exception:
        season_num = 0
    if not show_id or season_num < 0:
        xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)
        return

    try:
        show_data = trakt_public_get(
            f"https://api.trakt.tv/shows/{quote(show_id)}?extended=full"
        )
        episodes = trakt_public_get(
            f"https://api.trakt.tv/shows/{quote(show_id)}/seasons/{season_num}/episodes?extended=full"
        )
    except Exception:
        xbmcgui.Dialog().notification(
            "Kraken",
            _t(
                "No se pudo cargar episodios",
                "Could not load episodes",
                "Impossible de charger les episodes",
                "Impossibile caricare gli episodi",
                "Episoden konnten nicht geladen werden",
            ),
            xbmcgui.NOTIFICATION_WARNING,
        )
        xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)
        return

    show_title = str((show_data or {}).get("title") or _t("Serie", "TV Show", "Serie", "Serie TV", "Serie")).strip()
    lang = _trakt_listing_translation_lang()
    show_title_tr, _show_plot_tr = _trakt_translation_title_overview(
        trakt_public_get, show_id=show_id, language=lang
    )
    if show_title_tr:
        show_title = show_title_tr

    episode_nums_pref = []
    for ep in episodes or []:
        ep_n = ep.get("number")
        if ep_n is None or int(ep_n) < 1:
            continue
        episode_nums_pref.append(int(ep_n))

    directory = []

    ep_plot_cache = _prefetch_episode_translations_map(
        trakt_public_get,
        show_id=show_id,
        season_num=season_num,
        episode_nums=episode_nums_pref,
        language=lang,
    )

    season_poster_tmdb, episode_thumb_map = _tmdb_season_episode_thumbnails(
        json_get,
        tmdb_api_key,
        metadata_timeout,
        tmdb_image_base,
        tmdb_enabled,
        show_data,
        season_num,
    )

    xbmcplugin.setPluginCategory(
        plugin_handle,
        _t(
            f"{show_title} - T{season_num}",
            f"{show_title} - S{season_num}",
            f"{show_title} - S{season_num}",
            f"{show_title} - S{season_num}",
            f"{show_title} - S{season_num}",
        ),
    )
    xbmcplugin.setContent(plugin_handle, "episodes")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_EPISODE)

    base_art = default_list_art()
    for ep in episodes or []:
        ep_num = ep.get("number")
        if ep_num is None or int(ep_num) < 1:
            continue
        ep_title = str(
            ep.get("title")
            or _t(
                f"Episodio {ep_num}",
                f"Episode {ep_num}",
                f"Épisode {ep_num}",
                f"Episodio {ep_num}",
                f"Episode {ep_num}",
            )
        ).strip()
        label = f"{season_num:02d}x{int(ep_num):02d} - {ep_title}"
        li = xbmcgui.ListItem(label=label)
        ep_plot = str(ep.get("overview") or "").strip()
        ep_key = int(ep_num)
        tr_row = ep_plot_cache.get(ep_key) or {}
        if tr_row.get("title"):
            ep_title = tr_row.get("title")
            label = f"{season_num:02d}x{int(ep_num):02d} - {ep_title}"
            li.setLabel(label)
        if tr_row.get("plot"):
            ep_plot = tr_row.get("plot")
        apply_video_info(
            li,
            {
                "title": ep_title,
                "tvshowtitle": show_title,
                "plot": ep_plot,
                "season": season_num,
                "episode": int(ep_num),
                "mediatype": "episode",
            },
        )
        art = dict(base_art)
        thumb_u = str(episode_thumb_map.get(int(ep_num)) or "").strip()
        if thumb_u:
            art["thumb"] = thumb_u
            art["icon"] = thumb_u
            art["poster"] = thumb_u
        elif season_poster_tmdb:
            art["thumb"] = season_poster_tmdb
            art["icon"] = season_poster_tmdb
            art["poster"] = season_poster_tmdb
        li.setArt(art)
        li.setProperty("IsPlayable", "true")
        add_episode_download_context(li, show_id, season_num, int(ep_num))
        directory.append(
            (
                url_for_play_episode(show_id, str(season_num), str(int(ep_num))),
                li,
                False,
            )
        )
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)


def run_play_episode(
    *,
    plugin_handle,
    show_trakt_id,
    season_number,
    episode_number,
    kraken_progress,
    resolver_progress_phase,
    resolver_progress_detail,
    resolve_trakt_episode_stream,
    pick_stream_dialog,
    finalize_playback_stream_url,
    trakt_public_get,
    get_setting=None,
    set_setting=None,
    get_bool_setting=None,
):
    show_id = (show_trakt_id or "").strip()
    try:
        season_num = int(str(season_number or "0"))
        episode_num = int(str(episode_number or "0"))
    except Exception:
        season_num = 0
        episode_num = 0
    if not show_id or season_num < 0 or episode_num < 1:
        xbmcplugin.setResolvedUrl(plugin_handle, False, xbmcgui.ListItem())
        return

    dialog = xbmcgui.DialogProgress()
    dialog.create(
        _t(
            "Kraken - Resolver",
            "Kraken - Resolver",
            "Kraken - Resolution",
            "Kraken - Risolutore",
            "Kraken - Aufloesung",
        ),
        _t(
            "Resolviendo fuentes",
            "Resolving sources",
            "Resolution des sources",
            "Risoluzione delle fonti",
            "Quellen werden aufgeloest",
        ),
    )
    started_at = time.time()
    ep_ctx = f"{season_num:02d}x{episode_num:02d}"

    def _progress_cb(percent, phase, detail):
        kraken_progress(dialog, percent, phase, detail)

    try:
        kraken_progress(
            dialog,
            5,
            resolver_progress_phase,
            resolver_progress_detail(f"{ep_ctx} · inicio", [], None, started_at),
        )
        candidates = (
            resolve_trakt_episode_stream(
                show_id,
                season_num,
                episode_num,
                collect_sources=True,
                progress_cb=_progress_cb,
                progress_started_at=started_at,
                context_label=ep_ctx,
            )
            or []
        )
        xbmc.log(
            f"[Kraken] {_t('Candidatas episodio', 'Episode candidates', 'Candidates épisode', 'Candidati episodio', 'Episodenkandidaten')}: {len(candidates)}",
            xbmc.LOGINFO,
        )
        kraken_progress(
            dialog,
            100,
            resolver_progress_phase,
            resolver_progress_detail(f"{ep_ctx} · listo", candidates, None, started_at),
        )
    finally:
        dialog.close()
    stash_source_candidates(
        candidates,
        _t("Serie", "TV Show", "Série", "Serie TV", "Serie")
        + f" {season_num:02d}x{episode_num:02d}",
    )
    try:
        w = xbmcgui.Window(10000)
        w.setProperty("Kraken.LastPlaybackKind", "episode")
        w.setProperty("Kraken.PlaybackSeason", str(season_num))
        w.setProperty("Kraken.PlaybackEpisode", str(episode_num))
    except Exception:
        pass
    rot_ep = None
    if get_setting and set_setting and get_bool_setting:
        rot_ep = {
            "content_key": f"e:{show_id}:{season_num}:{episode_num}",
            "get_setting": get_setting,
            "set_setting": set_setting,
            "get_bool_setting": get_bool_setting,
        }
    stream_url = pick_stream_dialog(
        _t(
            "Kraken - Selecciona fuente",
            "Kraken - Select source",
            "Kraken - Selectionner une source",
            "Kraken - Seleziona fonte",
            "Kraken - Quelle wählen",
        ),
        candidates,
        playback_kind="episode",
        rotation=rot_ep,
    )

    if stream_url is None:
        xbmcplugin.setResolvedUrl(plugin_handle, False, xbmcgui.ListItem())
        return

    if stream_url:
        stream_url = finalize_playback_stream_url(
            stream_url,
            {"season": season_num, "episode": episode_num},
        )
        if _is_unrouted_torrent_url(stream_url):
            xbmcgui.Dialog().ok(
                "Kraken",
                _t(
                    "La fuente es torrent/magnet y no hay enlace HTTP reproducible ni cliente torrent disponible.\n\n"
                    "Configura el cliente torrent o Debrid en Kraken y elige otra fuente en el listado si hace falta.",
                    "The source is torrent/magnet and there is no playable HTTP link or torrent client available.\n\n"
                    "Set up your torrent client or Debrid in Kraken, or pick another source from the list.",
                    "La source est torrent/magnet : pas de lien HTTP lisible ni de client torrent disponible.\n\n"
                    "Configure le client torrent ou Debrid dans Kraken, puis choisis une autre source si besoin.",
                    "La fonte è torrent/magnet e non c'è link HTTP né client torrent disponibile.\n\n"
                    "Configura client torrent o Debrid in Kraken o scegli un'altra fonte dall'elenco.",
                    "Es handelt sich um Torrent/Magnet ohne abspielbaren HTTP-Link oder Torrent-Client.\n\n"
                    "Torrent-Client oder Debrid in Kraken einrichten oder eine andere Quelle wählen.",
                ),
            )
            xbmcplugin.setResolvedUrl(plugin_handle, False, xbmcgui.ListItem())
            return
        try:
            w = xbmcgui.Window(10000)
            w.setProperty("Kraken.PendingPlaybackStart", "1")
            w.setProperty("Kraken.PendingPlaybackTs", str(time.time()))
        except Exception:
            pass
        duration_sec = 0
        try:
            one = trakt_public_get(
                f"https://api.trakt.tv/shows/{quote(show_id)}/seasons/{season_num}/episodes/{episode_num}?extended=full"
            )
            if isinstance(one, dict):
                r = one.get("runtime")
                if r is not None:
                    rm = int(r)
                    if rm > 0:
                        duration_sec = rm * 60
        except Exception:
            duration_sec = 0
        li = xbmcgui.ListItem(path=stream_url)
        try:
            li.setContentLookup(False)
        except Exception:
            pass
        configure_listitem_stream_properties(li, stream_url)
        try:
            w = xbmcgui.Window(10000)
            w.setProperty("Kraken.LastPlaybackAttemptUrl", str(stream_url))
            w.clearProperty("Kraken.FallbackTriedUrls")
            w.clearProperty("Kraken.FallbackAutoAttempts")
        except Exception:
            pass
        if duration_sec > 0:
            apply_video_info(li, {"duration": duration_sec})
        try:
            w = xbmcgui.Window(10000)
            w.setProperty(
                "Kraken.Playing",
                json.dumps(
                    {
                        "kind": "episode",
                        "show_id": show_id,
                        "season": season_num,
                        "episode": episode_num,
                    }
                ),
            )
            w.clearProperty("Kraken.TraktSynced")
            w.clearProperty("Kraken.TraktCollectionSent")
            for p in (
                "Kraken.30sDialogShown",
                "Kraken.30sUserCancelled",
                "Kraken.PrefetchStreamUrl",
                "Kraken.PrefetchMeta",
                "Kraken.EofSoon",
                "Kraken.LastProgressPct",
                "Kraken.PrefetchInProgress",
                "Kraken.TraktScrobbleLast.start",
                "Kraken.TraktScrobbleLast.pause",
                "Kraken.TraktScrobbleLast.stop",
            ):
                w.clearProperty(p)
        except Exception:
            pass
        xbmcplugin.setResolvedUrl(plugin_handle, True, li)
        return

    xbmcgui.Dialog().ok(
        "Kraken",
        _t(
            "No se encontro stream para este episodio.\n\n"
            "- Revisa que el addon Stremio tenga links por episodio.\n"
            "- Si devuelve magnet/.torrent, configura Kraken - Torrent.",
            "No stream was found for this episode.\n\n"
            "- Check that the Stremio addon has per-episode links.\n"
            "- If it returns magnet/.torrent, configure Kraken - Torrent.",
        ),
    )
    xbmcplugin.setResolvedUrl(plugin_handle, False, xbmcgui.ListItem())
