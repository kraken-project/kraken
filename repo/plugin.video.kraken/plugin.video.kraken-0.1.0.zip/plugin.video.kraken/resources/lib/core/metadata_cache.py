import json
import os
import time
from urllib.parse import urlencode


def clean_title(value):
    text = str(value or "").strip().lower()
    for ch in ("(", ")", "[", "]", ":", ".", ",", "-", "_"):
        text = text.replace(ch, " ")
    return " ".join(text.split())


def addon_data_dir(addon):
    profile = addon.getAddonInfo("profile")
    path = profile
    if profile.startswith("special://"):
        try:
            import xbmcvfs

            path = xbmcvfs.translatePath(profile)
        except Exception:
            path = profile
    if path and not os.path.isdir(path):
        try:
            os.makedirs(path, exist_ok=True)
        except Exception:
            return ""
    return path or ""


def omdb_cache_path(addon):
    base = addon_data_dir(addon)
    if not base:
        return ""
    return os.path.join(base, "omdb_cache.json")


def clear_omdb_cache_file(addon):
    path = omdb_cache_path(addon)
    if not path or not os.path.isfile(path):
        return False
    try:
        os.remove(path)
        return True
    except OSError:
        pass
    try:
        import xbmcvfs

        xbmcvfs.delete(path)
        return True
    except Exception:
        return False


def omdb_cache_load(addon):
    path = omdb_cache_path(addon)
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, encoding="utf-8") as fh:
            payload = json.load(fh)
        if isinstance(payload, dict):
            return payload
    except Exception:
        return {}
    return {}


def omdb_cache_save(addon, cache):
    path = omdb_cache_path(addon)
    if not path:
        return
    try:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(cache, fh, ensure_ascii=True)
    except Exception:
        return


def omdb_cache_key(title, year, media_type, imdb_id=""):
    imdb = str(imdb_id or "").strip().lower()
    if imdb:
        return f"imdb|{imdb}"
    return "{}|{}|{}".format(
        clean_title(title), str(year or ""), (media_type or "movie")
    )


def omdb_empty_metadata():
    return {
        "poster": "",
        "fanart": "",
        "omdb_rotten": None,
        "omdb_metacritic": None,
        "omdb_imdb": None,
    }


def omdb_parse_external_ratings(payload):
    out = {
        "omdb_rotten": None,
        "omdb_metacritic": None,
        "omdb_imdb": None,
    }
    if (
        not payload
        or not isinstance(payload, dict)
        or payload.get("Response") != "True"
    ):
        return out
    im = str(payload.get("imdbRating") or "").strip()
    if im and im.upper() != "N/A":
        out["omdb_imdb"] = im
    metas = str(payload.get("Metascore") or "").strip()
    if metas and metas.upper() != "N/A":
        out["omdb_metacritic"] = f"{metas}/100"
    for row in payload.get("Ratings") or []:
        if not isinstance(row, dict):
            continue
        src = str(row.get("Source") or "")
        val = str(row.get("Value") or "").strip()
        if not val or val.upper() == "N/A":
            continue
        s_low = src.lower()
        if "rotten" in s_low and "tomato" in s_low:
            out["omdb_rotten"] = val
        elif "metacritic" in s_low:
            out["omdb_metacritic"] = val
        elif "internet movie database" in s_low and not out.get("omdb_imdb"):
            omdb_im = val.replace("/10", "").strip() if val else None
            if omdb_im:
                out["omdb_imdb"] = omdb_im
    return out


def omdb_cache_get(addon, title, year, media_type, ttl_seconds, imdb_id=""):
    key = omdb_cache_key(title, year, media_type, imdb_id=imdb_id)
    cache = omdb_cache_load(addon)
    node = cache.get(key) if isinstance(cache, dict) else None
    if not isinstance(node, dict):
        return None
    saved_at = int(node.get("saved_at") or 0)
    if saved_at <= 0 or (time.time() - saved_at) > ttl_seconds:
        return None
    art = node.get("art") or {}
    if not isinstance(art, dict):
        return None
    out = {
        "poster": str(art.get("poster") or ""),
        "fanart": str(art.get("fanart") or ""),
        "omdb_rotten": None,
        "omdb_metacritic": None,
        "omdb_imdb": None,
    }
    sc = node.get("scores")
    if isinstance(sc, dict):
        if sc.get("rotten"):
            out["omdb_rotten"] = str(sc.get("rotten") or "")
        if sc.get("metacritic"):
            out["omdb_metacritic"] = str(sc.get("metacritic") or "")
        if sc.get("imdb"):
            out["omdb_imdb"] = str(sc.get("imdb") or "")
    return out


def omdb_cache_set(
    addon,
    title,
    year,
    media_type,
    art,
    ttl_seconds,
    max_items,
    imdb_id="",
    extra_scores=None,
):
    key = omdb_cache_key(title, year, media_type, imdb_id=imdb_id)
    cache = omdb_cache_load(addon)
    if not isinstance(cache, dict):
        cache = {}
    scores = {}
    if isinstance(extra_scores, dict):
        if extra_scores.get("omdb_rotten"):
            scores["rotten"] = str(extra_scores.get("omdb_rotten") or "")
        if extra_scores.get("omdb_metacritic"):
            scores["metacritic"] = str(extra_scores.get("omdb_metacritic") or "")
        if extra_scores.get("omdb_imdb"):
            scores["imdb"] = str(extra_scores.get("omdb_imdb") or "")
    cache[key] = {
        "saved_at": int(time.time()),
        "art": {"poster": art.get("poster", ""), "fanart": art.get("fanart", "")},
        "scores": scores,
    }

    now = int(time.time())
    valid_items = []
    for k, v in cache.items():
        if not isinstance(v, dict):
            continue
        saved_at = int(v.get("saved_at") or 0)
        if saved_at <= 0 or (now - saved_at) > ttl_seconds:
            continue
        valid_items.append((k, v, saved_at))
    valid_items.sort(key=lambda row: row[2], reverse=True)
    trimmed = {}
    for k, v, _saved_at in valid_items[:max_items]:
        trimmed[k] = v
    omdb_cache_save(addon, trimmed)


def omdb_search_art(
    *,
    addon,
    title,
    year=None,
    media_type="movie",
    imdb_id="",
    omdb_enabled,
    omdb_api_key,
    json_get,
    metadata_timeout,
    ttl_seconds,
    max_items,
):
    if not omdb_enabled():
        return omdb_empty_metadata()
    api_key = omdb_api_key()
    clean = (title or "").strip()
    if not clean:
        return omdb_empty_metadata()
    cached = omdb_cache_get(
        addon, clean, year, media_type, ttl_seconds, imdb_id=imdb_id
    )
    if cached is not None:
        return cached

    omdb_type = "series" if media_type == "series" else "movie"
    payload = {}
    imdb = str(imdb_id or "").strip()
    if imdb.startswith("tt"):
        url = "https://www.omdbapi.com/?{}".format(
            urlencode({"apikey": api_key, "i": imdb, "type": omdb_type})
        )
        try:
            payload = json_get(url, timeout=metadata_timeout())
        except Exception:
            payload = {}

    if not payload or payload.get("Response") != "True":
        params = {"apikey": api_key, "t": clean, "type": omdb_type}
        if year:
            params["y"] = str(year)
        url = f"https://www.omdbapi.com/?{urlencode(params)}"
        try:
            payload = json_get(url, timeout=metadata_timeout())
        except Exception:
            return omdb_empty_metadata()

    if not payload or payload.get("Response") != "True":
        return omdb_empty_metadata()

    scores = omdb_parse_external_ratings(payload)
    poster = str(payload.get("Poster") or "").strip()
    has_poster = bool(poster and poster.upper() != "N/A")
    imdb_final = (imdb or str(payload.get("imdbID") or "")).strip()
    art = {"poster": poster if has_poster else "", "fanart": ""}
    omdb_cache_set(
        addon,
        clean,
        year,
        media_type,
        art,
        ttl_seconds,
        max_items,
        imdb_id=imdb_final,
        extra_scores=scores,
    )
    out = omdb_empty_metadata()
    out.update(art)
    out.update(
        {k: scores.get(k) for k in ("omdb_rotten", "omdb_metacritic", "omdb_imdb")}
    )
    return out
