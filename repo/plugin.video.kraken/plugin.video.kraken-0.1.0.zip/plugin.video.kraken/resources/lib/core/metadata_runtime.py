def tmdb_id_details_bridge(
    *,
    tmdb_id,
    media_type,
    tmdb_id_details_impl,
    tmdb_enabled,
    tmdb_api_key,
    json_get,
    metadata_timeout,
    tmdb_image_base,
    tmdb_backdrop_base,
    trakt_parse_year,
    trakt_float_or_none,
):
    return tmdb_id_details_impl(
        tmdb_id,
        media_type,
        tmdb_enabled=tmdb_enabled,
        tmdb_api_key=tmdb_api_key,
        json_get=json_get,
        metadata_timeout=metadata_timeout,
        tmdb_image_base=tmdb_image_base,
        tmdb_backdrop_base=tmdb_backdrop_base,
        trakt_parse_year=trakt_parse_year,
        trakt_float_or_none=trakt_float_or_none,
    )


def tmdb_search_art_by_id_bridge(
    *, tmdb_id, media_type, tmdb_search_art_by_id_impl, tmdb_id_details
):
    return tmdb_search_art_by_id_impl(tmdb_id, media_type, tmdb_id_details)


def omdb_search_art_bridge(
    *,
    addon,
    title,
    year,
    media_type,
    imdb_id,
    omdb_search_art_impl,
    omdb_enabled,
    omdb_api_key,
    json_get,
    metadata_timeout,
    ttl_seconds,
    max_items,
):
    return omdb_search_art_impl(
        addon=addon,
        title=title,
        year=year,
        media_type=media_type,
        imdb_id=imdb_id,
        omdb_enabled=omdb_enabled,
        omdb_api_key=omdb_api_key,
        json_get=json_get,
        metadata_timeout=metadata_timeout,
        ttl_seconds=ttl_seconds,
        max_items=max_items,
    )
