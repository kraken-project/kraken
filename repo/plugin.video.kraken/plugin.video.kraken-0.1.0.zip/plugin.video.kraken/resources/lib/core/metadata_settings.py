def metadata_timeout(get_int_setting):
    return max(3, min(20, get_int_setting("metadata_timeout", 10)))


def metadata_priority(get_setting):
    value = (get_setting("metadata_priority") or "TMDB first").strip().lower()
    if "omdb" in value:
        return "omdb_first"
    return "tmdb_first"


def trakt_results_limit(get_int_setting):
    return max(5, min(100, get_int_setting("trakt_results_limit", 20)))


def trakt_title_with_year(get_bool_setting):
    return get_bool_setting("trakt_title_with_year")


def metadata_fallback_fanart(get_bool_setting):
    return get_bool_setting("metadata_fallback_fanart")


def external_scrapers_timeout(get_int_setting):
    return max(3, min(20, get_int_setting("external_scrapers_timeout", 8)))
