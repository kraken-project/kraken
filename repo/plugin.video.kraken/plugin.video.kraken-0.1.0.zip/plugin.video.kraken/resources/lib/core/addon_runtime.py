from urllib.parse import quote

import xbmc
import xbmcgui
import xbmcaddon
import os

from resources.lib.core.debrid_stream_resolve import DEBRID_PLAYBACK_SECOND_PASS_SEC
from resources.lib.ui.ui_helpers import _t


def _setting_is_true(get_setting, key):
    return str(get_setting(key) or "").strip().lower() == "true"


def _torrent_debrid_first_enabled(get_setting):
    """Por defecto activo: magnet/torrent pasan antes por AllDebrid si está listo."""
    try:
        raw = str(get_setting("torrent_debrid_first") or "").strip().lower()
    except Exception:
        return True
    if raw == "false":
        return False
    return True


def _debrid_ready(get_setting):
    ad_ready = _setting_is_true(get_setting, "debrid_ad_enabled") and bool(
        (get_setting("debrid_ad_token") or "").strip()
    )
    return ad_ready


def addon_installed(addon_id):
    try:
        return xbmc.getCondVisibility(f"System.HasAddon({addon_id})") == 1
    except Exception:
        return False


def _elementum_runtime_ready():
    """Comprueba que el cliente torrent instalado (plugin.video.elementum) tenga ficheros necesarios."""
    try:
        addon_path = xbmcaddon.Addon("plugin.video.elementum").getAddonInfo("path")
    except Exception:
        return False
    base = str(addon_path or "").strip()
    if not base:
        return False
    required = os.path.join(
        base, "resources", "site-packages", "platform_detect", "platform.py"
    )
    return os.path.exists(required)


def _delegate_torrent_to_installed_client(raw, magnet, torrent_http, addon_installed_fn):
    """Fallback cuando Debrid no entrega HTTPS (magnet vivo): orden Elementum → Torrest → Jacktorr."""
    if addon_installed_fn("plugin.video.elementum") and _elementum_runtime_ready():
        return f"plugin://plugin.video.elementum/play?uri={quote(raw)}"
    if addon_installed_fn("plugin.video.torrest"):
        if magnet:
            return f"plugin://plugin.video.torrest/play_magnet?magnet={quote(raw)}"
        return f"plugin://plugin.video.torrest/play_url?url={quote(raw)}"
    if addon_installed_fn("plugin.video.jacktorr"):
        if magnet:
            return f"plugin://plugin.video.jacktorr/play_magnet?magnet={quote(raw)}"
        return f"plugin://plugin.video.jacktorr/play_url?url={quote(raw)}"
    return ""


def torrent_player_route(stream_url, get_setting, addon_installed_fn):
    """Convierte magnet/torrent a URL plugin del reproductor elegido."""
    if not stream_url:
        return stream_url
    raw = stream_url.strip()
    choice = (get_setting("torrent_player") or "Direct (Kodi)").strip()

    magnet = raw.startswith("magnet:")
    torrent_http = raw.lower().endswith(".torrent") or ".torrent?" in raw.lower()

    if not magnet and not torrent_http:
        return raw

    lowc = choice.lower()
    if (
        lowc.startswith("direct")
        or lowc.startswith("directo")
        or lowc.startswith("direkt")
        or lowc.startswith("diretto")
    ):
        delegated = _delegate_torrent_to_installed_client(
            raw, magnet, torrent_http, addon_installed_fn
        )
        if delegated.startswith("plugin://"):
            try:
                xbmc.log(
                    "[Kraken] Playback: modo Direct + magnet tras Debrid -> cliente torrent (fallback)",
                    xbmc.LOGINFO,
                )
            except Exception:
                pass
            return delegated
        xbmcgui.Dialog().notification(
            "Kraken",
            _t(
                "Debrid no entrego enlace a tiempo o fallo. Instala Elementum/Torrest/Jacktorr para reproducir el magnet.",
                "Debrid did not return a link in time or failed. Install Elementum/Torrest/Jacktorr to play the magnet.",
                "Debrid n'a pas renvoye de lien a temps. Installez Elementum/Torrest/Jacktorr pour lire le magnet.",
                "Debrid non ha fornito link in tempo. Installa Elementum/Torrest/Jacktorr per il magnet.",
                "Debrid lieferte rechtzeitig keinen Link. Elementum/Torrest/Jacktorr fur Magnet installieren.",
            ),
            xbmcgui.NOTIFICATION_WARNING,
            7800,
        )
        return raw

    if choice.startswith("Elementum"):
        if not addon_installed_fn("plugin.video.elementum"):
            xbmcgui.Dialog().notification(
                "Kraken",
                _t(
                    "Instala el complemento torrent configurado como destino (Ajustes - Torrent)",
                    "Install the torrent add-on configured in Kraken Torrent settings.",
                    "Installez l'addon torrent défini dans Reglages - Torrent Kraken.",
                    "Installa l'addon torrent impostato in Impostazioni - Torrent Kraken.",
                    "Installieren Sie das in Kraken Torrent-Einstellungen gewahlte Torrent-Addon.",
                ),
                xbmcgui.NOTIFICATION_WARNING,
                4500,
            )
            return raw
        if not _elementum_runtime_ready():
            xbmcgui.Dialog().notification(
                "Kraken",
                _t(
                    "El cliente torrent instalado parece incompleto. Reinstálalo o elige otro en Ajustes - Torrent / Debrid.",
                    "Installed torrent client looks incomplete. Reinstall it or pick another option in Kraken Torrent / Debrid.",
                    "Le client torrent installe semble incomplet. Reinstallez-le ou choisissez autre chose dans Torrent / Debrid Kraken.",
                    "Il client torrent installato risulta incompleto. Reinstallalo o usa altro da Torrent / Debrid Kraken.",
                    "Torrent-Client wirkt unvollstandig. Neu installieren oder in Kraken Torrent/Debrid wechseln.",
                ),
                xbmcgui.NOTIFICATION_WARNING,
                6500,
            )
            return raw
        return f"plugin://plugin.video.elementum/play?uri={quote(raw)}"

    if choice.startswith("Torrest"):
        if not addon_installed_fn("plugin.video.torrest"):
            xbmcgui.Dialog().notification(
                "Kraken",
                _t(
                    "Instala el complemento torrent elegido como destino (Ajustes - Torrent)",
                    "Install the torrent add-on configured in Kraken Torrent settings.",
                    "Installez l'addon torrent des Reglages - Torrent Kraken.",
                    "Installa l'addon torrent scelto in Impostazioni - Torrent Kraken.",
                    "Torrent-Addon aus Kraken Torrent-Einstellungen installieren.",
                ),
                xbmcgui.NOTIFICATION_WARNING,
                4500,
            )
            return raw
        if magnet:
            return f"plugin://plugin.video.torrest/play_magnet?magnet={quote(raw)}"
        return f"plugin://plugin.video.torrest/play_url?url={quote(raw)}"

    if choice.startswith("Jacktorr"):
        if not addon_installed_fn("plugin.video.jacktorr"):
            xbmcgui.Dialog().notification(
                "Kraken",
                _t(
                    "Instala el complemento torrent elegido como destino (Ajustes - Torrent)",
                    "Install the torrent add-on configured in Kraken Torrent settings.",
                    "Installez l'addon torrent des Reglages - Torrent Kraken.",
                    "Installa l'addon torrent scelto in Impostazioni - Torrent Kraken.",
                    "Torrent-Addon aus Kraken Torrent-Einstellungen installieren.",
                ),
                xbmcgui.NOTIFICATION_WARNING,
                4500,
            )
            return raw
        if magnet:
            return f"plugin://plugin.video.jacktorr/play_magnet?magnet={quote(raw)}"
        return f"plugin://plugin.video.jacktorr/play_url?url={quote(raw)}"

    return raw


def _url_is_magnet_or_torrent_http(url):
    raw = str(url or "").strip()
    if not raw:
        return False
    low = raw.lower()
    if raw.startswith("magnet:"):
        return True
    return low.endswith(".torrent") or ".torrent?" in low


def playback_hints_from_window():
    """Toma temporada/episodio si la reproduccion actual es capitulo Kraken."""
    try:
        w = xbmcgui.Window(10000)
        if (w.getProperty("Kraken.LastPlaybackKind") or "").strip().lower() != "episode":
            return None
        s = (w.getProperty("Kraken.PlaybackSeason") or "").strip()
        e = (w.getProperty("Kraken.PlaybackEpisode") or "").strip()
        if not s or not e:
            return None
        title = (w.getProperty("Kraken.PlaybackEpisodeTitle") or "").strip()
        out = {"season": int(s), "episode": int(e)}
        if title:
            out["ep_title"] = title
        return out
    except Exception:
        return None


def finalize_playback_stream_url(
    stream_url,
    get_setting,
    addon_installed_fn,
    debrid_torrent_resolve=None,
    playback_context=None,
):
    """
    Magnet / .torrent HTTP:

    Con AllDebrid configurado y opción ``torrent_debrid_first`` activa (valor por defecto),
    se intenta Debrid rápido y, si sigue magnet/torrent, un segundo intento más largo
    antes de Plugin de cliente torrent — asi llega HTTPS al modo Direct (Kodi).

    Si ``torrent_debrid_first`` es false: primero el cliente configurado y, si la URL sigue siendo torrent,
    segunda pasada vía AllDebrid (evitar cliente donde sea posible).

    Para packs de serie AllDebrid puede exigir contexto temporada/episodio: desde ``playback_context`` o desde
    propiedades de ventana (Kraken.PlaybackSeason/Episode) cuando ``LastPlaybackKind`` es episodio.
    """
    if not stream_url:
        return stream_url
    raw_in = str(stream_url).strip()
    resolver = debrid_torrent_resolve
    torrent_like = _url_is_magnet_or_torrent_http(raw_in)
    debrid_long_already_tried = False

    playback_effective = (
        playback_context
        if playback_context is not None
        else playback_hints_from_window()
    )

    def _call_resolve(url_arg, magnet_quick=False, magnet_max_wait_seconds=None):
        if not callable(resolver):
            return None
        pb = playback_effective
        try:
            return resolver(
                url_arg,
                magnet_quick=magnet_quick,
                magnet_max_wait_seconds=magnet_max_wait_seconds,
                playback=pb,
            )
        except TypeError:
            try:
                return resolver(url_arg, magnet_quick=magnet_quick, magnet_max_wait_seconds=magnet_max_wait_seconds)
            except TypeError:
                try:
                    return resolver(url_arg, magnet_quick=magnet_quick)
                except TypeError:
                    return resolver(url_arg)
    if (
        torrent_like
        and _torrent_debrid_first_enabled(get_setting)
        and _debrid_ready(get_setting)
        and callable(resolver)
    ):
        working = raw_in
        try:
            after_early = _call_resolve(working, magnet_quick=True) or working
        except Exception:
            after_early = working
        early = str(after_early).strip()
        if early != raw_in and not _url_is_magnet_or_torrent_http(early):
            try:
                xbmc.log(
                    "[Kraken] Playback: Debrid primero → enlace reproducible",
                    xbmc.LOGINFO,
                )
            except Exception:
                pass
            return torrent_player_route(early, get_setting, addon_installed_fn)
        working = early
        if _url_is_magnet_or_torrent_http(working):
            try:
                xbmc.log(
                    "[Kraken] Playback: Debrid segunda pasada antes de cliente torrent "
                    "(max {}s)".format(int(DEBRID_PLAYBACK_SECOND_PASS_SEC)),
                    xbmc.LOGINFO,
                )
            except Exception:
                pass
            try:
                after_long = (
                    _call_resolve(
                        working,
                        magnet_max_wait_seconds=DEBRID_PLAYBACK_SECOND_PASS_SEC,
                    )
                    or working
                )
            except Exception:
                after_long = working
            after_long = str(after_long).strip()
            debrid_long_already_tried = True
            if after_long != working and not _url_is_magnet_or_torrent_http(after_long):
                try:
                    xbmc.log(
                        "[Kraken] Playback: Debrid (largo) → HTTP reproducible Kodi",
                        xbmc.LOGINFO,
                    )
                except Exception:
                    pass
                return torrent_player_route(
                    after_long, get_setting, addon_installed_fn
                )
            working = after_long
        raw_work = working
    else:
        raw_work = raw_in

    delegated = torrent_player_route(raw_work, get_setting, addon_installed_fn)
    if delegated.startswith("plugin://"):
        try:
            xbmc.log("[Kraken] Playback: torrent -> delegated client", xbmc.LOGINFO)
        except Exception:
            pass
        return delegated

    if (
        _url_is_magnet_or_torrent_http(delegated)
        and callable(resolver)
        and not debrid_long_already_tried
    ):
        try:
            xbmc.log(
                "[Kraken] Playback: Debrid segunda pasada (max {}s, evita bloqueo del plugin)".format(
                    int(DEBRID_PLAYBACK_SECOND_PASS_SEC)
                ),
                xbmc.LOGINFO,
            )
        except Exception:
            pass
        try:
            after_debrid = (
                _call_resolve(
                    delegated,
                    magnet_max_wait_seconds=DEBRID_PLAYBACK_SECOND_PASS_SEC,
                )
                or delegated
            )
        except Exception:
            after_debrid = delegated
        if after_debrid != delegated:
            try:
                xbmc.log(
                    "[Kraken] Playback: torrent resuelto a HTTP via Debrid (sin cliente)",
                    xbmc.LOGINFO,
                )
            except Exception:
                pass
        return torrent_player_route(
            str(after_debrid).strip(), get_setting, addon_installed_fn
        )

    return delegated
