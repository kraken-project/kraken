import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import quote

import xbmc

from resources.lib.sources.source_language import finalize_stream_language
from resources.lib.sources.source_ranking import (
    sort_stremio_stream_rows_for_play,
    sources_order_priority,
)
from resources.lib.trakt.trakt_context import filter_peerflix_magnets_when_alldebrid


def _strip_trailing_year(text):
    raw = str(text or "").strip()
    if not raw:
        return ""
    parts = raw.rsplit(" ", 1)
    if len(parts) == 2 and len(parts[1]) == 4 and parts[1].isdigit():
        return parts[0].strip()
    return raw


def _unique_terms(terms):
    out = []
    seen = set()
    for term in terms or []:
        t = str(term or "").strip()
        if not t:
            continue
        k = t.casefold()
        if k in seen:
            continue
        seen.add(k)
        out.append(t)
    return out


def _movie_show_search_terms(*, title, default_title, year, imdb_id):
    terms = []
    if imdb_id and imdb_id.startswith("tt"):
        terms.append(imdb_id)
    terms.append(title)
    terms.append(default_title)
    if year:
        terms.append(f"{title} {year}")
        if default_title:
            terms.append(f"{default_title} {year}")
    terms.append(_strip_trailing_year(title))
    terms.append(_strip_trailing_year(default_title))
    return _unique_terms(terms)


def _resolver_external_scrapers_first(get_setting):
    return sources_order_priority(get_setting) == "external_first"


def _stremio_origin_label_from_candidate_id(cid):
    parts = str(cid or "").strip().split("::")
    if len(parts) >= 2 and parts[0] == "stremio" and parts[1]:
        return f"Stremio {parts[1]}"
    return "Stremio"


def _stremio_search_terms_parallel(provider, terms):
    """Varias consultas catalog search en paralelo (título, año, variante, imdb tt…)."""
    safe = [str(t).strip() for t in (terms or []) if str(t or "").strip()]
    if not safe:
        return []
    if len(safe) == 1:
        try:
            return list(provider.search(safe[0]) or [])
        except Exception:
            return []

    mw = max(2, min(16, len(safe)))
    merged = []

    def fetch_one(term):
        try:
            return list(provider.search(term) or [])
        except Exception:
            return []

    try:
        with ThreadPoolExecutor(max_workers=mw) as ex:
            futs = [ex.submit(fetch_one, t) for t in safe]
            for fut in as_completed(futs):
                try:
                    merged.extend(fut.result())
                except Exception:
                    pass
    except Exception:
        for t in safe:
            merged.extend(fetch_one(t))
    return merged


def resolve_trakt_result(
    result_id,
    *,
    collect_sources=False,
    progress_cb=None,
    progress_started_at=None,
    search_result_cache,
    trakt_public_get,
    get_enabled_providers,
    clean_title,
    resolver_progress_phase,
    resolver_progress_detail,
    stremio_source_is_tv_only,
    is_playable_stream_url,
    get_bool_setting,
    get_setting,
    external_scraper_candidates,
    web_link_provider_candidates,
    source_label,
):
    rid = (result_id or "").strip()
    if not rid.startswith("trakt::"):
        return None
    parts = rid.split("::")
    trakt_type_hint = "movie"
    trakt_id = ""
    if len(parts) >= 3:
        trakt_type_hint = "series" if parts[1] in ("show", "series", "tv") else "movie"
        trakt_id = parts[2].strip()
    elif len(parts) == 2:
        trakt_id = parts[1].strip()
    if not trakt_id:
        return None

    trakt_type = trakt_type_hint
    media = {}
    cached = search_result_cache.get(rid) or {}
    if cached:
        res_title = (
            cached.get("trakt_default_title") or cached.get("title") or ""
        ).strip()
        media = {
            "title": res_title,
            "year": cached.get("year"),
            "ids": {"imdb": cached.get("imdb_id", "")},
        }
        if cached.get("media_type") in ("movie", "series"):
            trakt_type = cached.get("media_type")
    else:
        try:
            if trakt_type_hint == "series":
                media = trakt_public_get(
                    f"https://api.trakt.tv/shows/{quote(trakt_id)}?extended=full"
                )
            else:
                media = trakt_public_get(
                    f"https://api.trakt.tv/movies/{quote(trakt_id)}?extended=full"
                )
        except Exception:
            media = {}

    if not isinstance(media, dict) or not media.get("title"):
        try:
            payload = trakt_public_get(
                f"https://api.trakt.tv/search/trakt/{quote(trakt_id)}?type=movie,show&limit=1"
            )
        except Exception:
            return None
        if not payload:
            return None
        item = payload[0] if isinstance(payload, list) else {}
        media = item.get("movie") or item.get("show") or {}
        if item.get("type") == "show":
            trakt_type = "series"

    title = str(media.get("title") or "").strip()
    if not title:
        return None
    year = media.get("year")
    imdb_id = str((media.get("ids") or {}).get("imdb") or "").strip()

    providers = get_enabled_providers()
    title_clean = clean_title(title)
    gathered = []
    stremio_gathered = []
    ext_first = _resolver_external_scrapers_first(get_setting)
    scraper_candidates = []
    web_candidates = []
    # Con "Scrapers primero", la búsqueda externa debe correr antes de Stremio también
    # cuando se reúne la lista (diálogo de fuentes), no solo en autoplay sin diálogo.
    scrapers_after_stremio = not ext_first
    t0 = time.time() if progress_started_at is None else progress_started_at

    def _report(percent, origin, partial=None):
        if not callable(progress_cb):
            return
        pl = partial
        if collect_sources:
            if pl is None:
                pl = []
                if ext_first:
                    pl.extend(scraper_candidates or [])
                    pl.extend(web_candidates or [])
                pl.extend(stremio_gathered)
                if not ext_first:
                    pl.extend(scraper_candidates or [])
                    pl.extend(web_candidates or [])
            else:
                pl = list(stremio_gathered) + list(pl)
        progress_cb(
            percent,
            resolver_progress_phase,
            resolver_progress_detail(origin, gathered, pl, t0),
        )

    if ext_first:
        _report(8, "Scrapers externos (prioridad)...", None)
        scraper_candidates = external_scraper_candidates(
            title,
            year,
            imdb_id,
            media_type=trakt_type,
            preferred_engine="",
            progress_cb=lambda engine, prov, partial: (
                _report(12, f"{engine} - {prov}", partial)
                if callable(progress_cb)
                else None
            ),
        )
        # Desactivado en el scrapeo general: algunos proveedores web pueden
        # bloquear Kodi al final del proceso por timeouts/HTML remotos.
        web_candidates = []
        if not collect_sources:
            for entry in scraper_candidates or []:
                u = str((entry or {}).get("url") or "").strip()
                if u and is_playable_stream_url(u):
                    return u
            for entry in web_candidates or []:
                u = str((entry or {}).get("url") or "").strip()
                if u and is_playable_stream_url(u):
                    return u
            scraper_candidates = []
            web_candidates = []

    stremio_candidates = [p for p in providers if "stremio" in (p.name or "").lower()]
    total_providers = max(1, len(stremio_candidates))
    for provider_idx, provider in enumerate(stremio_candidates, start=1):
        provider_name = str(getattr(provider, "name", "") or "Stremio")
        _report(
            min(95, 10 + int((provider_idx - 1) * 70 / total_providers)),
            f"Stremio - {provider_name}",
        )
        if imdb_id and imdb_id.startswith("tt"):
            source_pairs = getattr(provider, "_catalog_sources", []) or []
            seed_sources = [
                (n, u)
                for (n, u) in source_pairs
                if not stremio_source_is_tv_only(n)
            ]
            if seed_sources:
                seed_name = seed_sources[0][0]
                _report(
                    min(95, 15 + int((provider_idx - 1) * 70 / total_providers)),
                    f"Stremio - {provider_name} (fuentes IMDB)",
                )
                direct_id = f"stremio::{seed_name}::{trakt_type}::{imdb_id}"
                try:
                    all_streams = (
                        provider.resolve_all(direct_id)
                        if hasattr(provider, "resolve_all")
                        else []
                    )
                except Exception:
                    all_streams = []
                all_streams = sort_stremio_stream_rows_for_play(
                    all_streams or [], get_setting
                )
                if all_streams:
                    for src in all_streams:
                        stream = str(src.get("url") or "").strip()
                        if stream and is_playable_stream_url(stream):
                            cat_name = str(
                                (src or {}).get("_stremio_catalog_name") or ""
                            ).strip()
                            entry = {
                                "url": stream,
                                "label": str(src.get("label") or "Fuente").strip(),
                                "title": str(src.get("title") or "").strip(),
                                "quality": str(src.get("quality") or "Auto").strip(),
                                "language": finalize_stream_language(src, stream),
                                "origin": (
                                    f"Stremio {cat_name}"
                                    if cat_name
                                    else f"Stremio {seed_name}"
                                ),
                            }
                            if collect_sources:
                                stremio_gathered.append(entry)
                                _report(
                                    min(
                                        95,
                                        20 + int(provider_idx * 70 / total_providers),
                                    ),
                                    "Stremio - {}/{} (nueva fuente)".format(
                                        provider_name,
                                        cat_name or seed_name or "fuente",
                                    ),
                                )
                            else:
                                return stream

        search_terms = _movie_show_search_terms(
            title=title,
            default_title=cached.get("trakt_default_title") if isinstance(cached, dict) else "",
            year=year,
            imdb_id=imdb_id,
        )
        seen_ids = set()
        ranked = []

        merged_candidates = _stremio_search_terms_parallel(provider, search_terms)

        for candidate in merged_candidates or []:
            c_id = str(candidate.get("id") or "")
            if not c_id or c_id in seen_ids:
                continue
            seen_ids.add(c_id)
            c_title = str(candidate.get("title") or "").strip()
            c_year = candidate.get("year")
            c_type = "movie"
            p = c_id.split("::")
            if len(p) >= 4 and p[0] == "stremio":
                c_type = p[2]

            score = 0
            if imdb_id and imdb_id in c_id:
                score += 4
            if clean_title(c_title) == title_clean:
                score += 2
            elif title_clean and title_clean in clean_title(c_title):
                score += 1
            if year and c_year and str(year) == str(c_year):
                score += 2
            if c_type == trakt_type:
                score += 1
            ranked.append((score, candidate))

        ranked.sort(key=lambda row: row[0], reverse=True)
        for score, candidate in ranked:
            if score <= 0:
                continue
            cid = candidate.get("id", "")
            streams = []
            if hasattr(provider, "resolve_all"):
                streams = provider.resolve_all(cid)
            streams = sort_stremio_stream_rows_for_play(streams or [], get_setting)
            if not streams:
                raw = provider.resolve(cid)
                if raw:
                    if isinstance(raw, dict):
                        u0 = str(raw.get("url") or "").strip()
                        h0 = raw.get("http_headers")
                        row0 = {"url": u0, "label": "Fuente"}
                        if isinstance(h0, dict) and h0:
                            row0["http_headers"] = h0
                        streams = [row0]
                    else:
                        streams = [{"url": str(raw).strip(), "label": "Fuente"}]
            for src in streams:
                stream = str(src.get("url") or "").strip()
                if stream and is_playable_stream_url(stream):
                    cat = str((src or {}).get("_stremio_catalog_name") or "").strip()
                    entry = {
                        "url": stream,
                        "label": str(src.get("label") or "Fuente").strip(),
                        "title": str(src.get("title") or "").strip(),
                        "quality": str(src.get("quality") or "Auto").strip(),
                        "language": finalize_stream_language(src, stream),
                        "origin": (
                            f"Stremio {cat}"
                            if cat
                            else _stremio_origin_label_from_candidate_id(cid)
                        ),
                    }
                    hh = src.get("http_headers")
                    if isinstance(hh, dict) and hh:
                        entry["http_headers"] = hh
                    if collect_sources:
                        stremio_gathered.append(entry)
                        _report(
                            min(95, 25 + int(provider_idx * 70 / total_providers)),
                            f"Stremio - {provider_name} (nueva fuente)",
                        )
                    else:
                        return stream

    if scrapers_after_stremio and not stremio_gathered:
        _report(94, "Scrapers externos activados (Burst, Coco, Gears, Viper)...", None)
        scraper_candidates = external_scraper_candidates(
            title,
            year,
            imdb_id,
            media_type=trakt_type,
            preferred_engine="",
            progress_cb=lambda engine, prov, partial: (
                _report(96, f"{engine} - {prov}", partial)
                if callable(progress_cb)
                else None
            ),
        )
        # Desactivado en el scrapeo general: algunos proveedores web pueden
        # bloquear Kodi al final del proceso por timeouts/HTML remotos.
        web_candidates = []
    extra_candidates = []
    if collect_sources:
        if ext_first:
            extra_candidates.extend(scraper_candidates or [])
            extra_candidates.extend(web_candidates or [])
            extra_candidates.extend(stremio_gathered)
        else:
            extra_candidates.extend(stremio_gathered)
            extra_candidates.extend(scraper_candidates or [])
            extra_candidates.extend(web_candidates or [])
    elif not ext_first:
        for entry in scraper_candidates or []:
            u = str((entry or {}).get("url") or "").strip()
            if u and is_playable_stream_url(u):
                return u
        for entry in web_candidates or []:
            u = str((entry or {}).get("url") or "").strip()
            if u and is_playable_stream_url(u):
                return u

    for entry in extra_candidates:
        if collect_sources:
            gathered.append(entry)
        else:
            return entry.get("url")

    # En modo "lista de fuentes" (diálogo), evitar una segunda pasada completa
    # por todos los providers si ya terminó el scrapeo principal.
    # Esa pasada extra puede bloquear Kodi al final en algunos entornos.
    if collect_sources:
        return filter_peerflix_magnets_when_alldebrid(
            gathered, get_bool_setting, get_setting
        )

    for provider in providers:
        if "trakt" in (provider.name or "").lower():
            continue
        try:
            candidates = provider.search(title)
        except Exception:
            continue
        for candidate in candidates or []:
            raw_s = provider.resolve(candidate.get("id", ""))
            if isinstance(raw_s, dict):
                stream = str(raw_s.get("url") or "").strip()
                h_s = raw_s.get("http_headers")
            else:
                stream = str(raw_s or "").strip() if raw_s else ""
                h_s = None
            if stream and is_playable_stream_url(stream):
                entry = {"url": stream, "label": source_label(stream, provider.name)}
                if isinstance(h_s, dict) and h_s:
                    entry["http_headers"] = h_s
                if collect_sources:
                    gathered.append(entry)
                    _report(
                        99,
                        "Otro proveedor - {}".format(
                            str(provider.name or "fuente").strip()
                        ),
                        None,
                    )
                else:
                    return stream
    xbmc.log(
        "[Kraken] Sin stream para Trakt '{}' ({}) imdb={}".format(
            title, trakt_type, imdb_id or "-"
        ),
        xbmc.LOGWARNING,
    )
    return None


def resolve_trakt_episode_stream(
    show_trakt_id,
    season,
    episode,
    *,
    collect_sources=False,
    progress_cb=None,
    progress_started_at=None,
    context_label="",
    trakt_public_get,
    get_enabled_providers,
    resolver_progress_phase,
    resolver_progress_detail,
    stremio_source_is_tv_only,
    is_playable_stream_url,
    get_bool_setting,
    get_setting,
    external_scraper_candidates,
    web_link_provider_candidates,
):
    show_id = str(show_trakt_id or "").strip()
    season_num = int(season)
    episode_num = int(episode)
    if not show_id or season_num < 0 or episode_num < 1:
        return None

    try:
        show_data = trakt_public_get(
            f"https://api.trakt.tv/shows/{quote(show_id)}?extended=full"
        )
    except Exception:
        return None
    if not isinstance(show_data, dict):
        return None
    show_title = str(show_data.get("title") or "").strip()
    if not show_title:
        return None
    imdb_id = str((show_data.get("ids") or {}).get("imdb") or "").strip()

    providers = get_enabled_providers()
    gathered = []
    stremio_gathered = []
    ext_first = _resolver_external_scrapers_first(get_setting)
    scraper_candidates = []
    web_candidates = []
    scrapers_after_stremio = not ext_first
    t0 = time.time() if progress_started_at is None else progress_started_at
    ep_prefix = (
        (str(context_label).strip() + " · ") if str(context_label or "").strip() else ""
    )

    def _report(percent, origin, partial=None):
        if not callable(progress_cb):
            return
        pl = partial
        if collect_sources:
            if pl is None:
                pl = []
                if ext_first:
                    pl.extend(scraper_candidates or [])
                    pl.extend(web_candidates or [])
                pl.extend(stremio_gathered)
                if not ext_first:
                    pl.extend(scraper_candidates or [])
                    pl.extend(web_candidates or [])
            else:
                pl = list(stremio_gathered) + list(pl)
        progress_cb(
            percent,
            resolver_progress_phase,
            resolver_progress_detail(ep_prefix + origin, gathered, pl, t0),
        )

    if ext_first:
        _report(8, "Scrapers externos (prioridad)...", None)
        scraper_candidates = external_scraper_candidates(
            show_title,
            show_data.get("year"),
            imdb_id,
            media_type="series",
            season=season_num,
            episode=episode_num,
            tvshowtitle=show_title,
            preferred_engine="",
            progress_cb=lambda engine, prov, partial: (
                _report(12, f"{engine} - {prov}", partial)
                if callable(progress_cb)
                else None
            ),
        )
        # Desactivado en el scrapeo general: algunos proveedores web pueden
        # bloquear Kodi al final del proceso por timeouts/HTML remotos.
        web_candidates = []
        if not collect_sources:
            for entry in scraper_candidates or []:
                u = str((entry or {}).get("url") or "").strip()
                if u and is_playable_stream_url(u):
                    return u
            for entry in web_candidates or []:
                u = str((entry or {}).get("url") or "").strip()
                if u and is_playable_stream_url(u):
                    return u
            scraper_candidates = []
            web_candidates = []

    stremio_candidates = [p for p in providers if "stremio" in (p.name or "").lower()]
    total_providers = max(1, len(stremio_candidates))
    for provider_idx, provider in enumerate(stremio_candidates, start=1):
        provider_name = str(getattr(provider, "name", "") or "Stremio")
        _report(
            min(95, 15 + int((provider_idx - 1) * 70 / total_providers)),
            f"Stremio - {provider_name}",
        )
        source_pairs = getattr(provider, "_catalog_sources", []) or []
        if imdb_id and imdb_id.startswith("tt"):
            seed_sources = [
                (n, u)
                for (n, u) in source_pairs
                if not stremio_source_is_tv_only(n)
            ]
            if seed_sources:
                seed_name = seed_sources[0][0]
                episode_meta_id = f"{imdb_id}:{season_num}:{episode_num}"
                direct_id = f"stremio::{seed_name}::series::{episode_meta_id}"
                _report(
                    min(95, 20 + int((provider_idx - 1) * 70 / total_providers)),
                    f"Stremio - {provider_name} (fuentes IMDB)",
                )
                try:
                    streams = (
                        provider.resolve_all(direct_id)
                        if hasattr(provider, "resolve_all")
                        else []
                    )
                except Exception:
                    streams = []
                streams = sort_stremio_stream_rows_for_play(streams or [], get_setting)
                for src in streams:
                    stream = str(src.get("url") or "").strip()
                    if stream and is_playable_stream_url(stream):
                        cat_name = str(
                            (src or {}).get("_stremio_catalog_name") or ""
                        ).strip()
                        entry = {
                            "url": stream,
                            "label": str(src.get("label") or "Fuente").strip(),
                            "title": str(src.get("title") or "").strip(),
                            "quality": str(src.get("quality") or "Auto").strip(),
                            "language": finalize_stream_language(src, stream),
                            "origin": (
                                f"Stremio {cat_name}"
                                if cat_name
                                else f"Stremio {seed_name}"
                            ),
                        }
                        if collect_sources:
                            stremio_gathered.append(entry)
                            _report(
                                min(95, 25 + int(provider_idx * 70 / total_providers)),
                                "Stremio - {}/{} (nueva fuente)".format(
                                    provider_name,
                                    cat_name or seed_name or "fuente",
                                ),
                            )
                        else:
                            return stream

        show_terms = _movie_show_search_terms(
            title=show_title,
            default_title="",
            year=show_data.get("year"),
            imdb_id=imdb_id,
        )
        candidates = _stremio_search_terms_parallel(provider, show_terms)
        seen_candidate_ids = set()
        deduped_candidates = []
        for candidate in candidates or []:
            cid = str((candidate or {}).get("id") or "").strip()
            if not cid or cid in seen_candidate_ids:
                continue
            seen_candidate_ids.add(cid)
            deduped_candidates.append(candidate)
        candidates = deduped_candidates
        for candidate in candidates or []:
            cid = str(candidate.get("id") or "")
            if "::series::" not in cid:
                continue
            parts = cid.split("::")
            if len(parts) < 4:
                continue
            source_name = parts[1]
            base_meta_id = "::".join(parts[3:])
            episode_meta_id = f"{base_meta_id}:{season_num}:{episode_num}"
            episode_id = f"stremio::{source_name}::series::{episode_meta_id}"
            try:
                streams = (
                    provider.resolve_all(episode_id)
                    if hasattr(provider, "resolve_all")
                    else []
                )
            except Exception:
                streams = []
            streams = sort_stremio_stream_rows_for_play(streams or [], get_setting)
            for src in streams:
                stream = str(src.get("url") or "").strip()
                if stream and is_playable_stream_url(stream):
                    cat_name = str(
                        (src or {}).get("_stremio_catalog_name") or ""
                    ).strip()
                    entry = {
                        "url": stream,
                        "label": str(src.get("label") or "Fuente").strip(),
                        "title": str(src.get("title") or "").strip(),
                        "quality": str(src.get("quality") or "Auto").strip(),
                        "language": finalize_stream_language(src, stream),
                        "origin": (
                            f"Stremio {cat_name}"
                            if cat_name
                            else f"Stremio {source_name}"
                        ),
                    }
                    if collect_sources:
                        stremio_gathered.append(entry)
                        _report(
                            min(95, 30 + int(provider_idx * 70 / total_providers)),
                            f"Stremio - {provider_name} (nueva fuente)",
                        )
                    else:
                        return stream
    if scrapers_after_stremio and not stremio_gathered:
        _report(94, "Scrapers externos activados (Burst, Coco, Gears, Viper)...", None)
        scraper_candidates = external_scraper_candidates(
            show_title,
            show_data.get("year"),
            imdb_id,
            media_type="series",
            season=season_num,
            episode=episode_num,
            tvshowtitle=show_title,
            preferred_engine="",
            progress_cb=lambda engine, prov, partial: (
                _report(96, f"{engine} - {prov}", partial)
                if callable(progress_cb)
                else None
            ),
        )
        # Desactivado en el scrapeo general: algunos proveedores web pueden
        # bloquear Kodi al final del proceso por timeouts/HTML remotos.
        web_candidates = []
    extra_candidates = []
    if collect_sources:
        if ext_first:
            extra_candidates.extend(scraper_candidates or [])
            extra_candidates.extend(web_candidates or [])
            extra_candidates.extend(stremio_gathered)
        else:
            extra_candidates.extend(stremio_gathered)
            extra_candidates.extend(scraper_candidates or [])
            extra_candidates.extend(web_candidates or [])
    elif not ext_first:
        for entry in scraper_candidates or []:
            u = str((entry or {}).get("url") or "").strip()
            if u and is_playable_stream_url(u):
                return u
        for entry in web_candidates or []:
            u = str((entry or {}).get("url") or "").strip()
            if u and is_playable_stream_url(u):
                return u

    for entry in extra_candidates:
        if collect_sources:
            gathered.append(entry)
        else:
            return entry.get("url")
    if collect_sources:
        return filter_peerflix_magnets_when_alldebrid(
            gathered, get_bool_setting, get_setting
        )
    return None
