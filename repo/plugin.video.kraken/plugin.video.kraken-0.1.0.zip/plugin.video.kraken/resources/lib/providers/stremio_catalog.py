import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.error import URLError
from urllib.parse import quote, unquote
from urllib.request import Request, urlopen

import xbmc

from resources.lib.core.settings_helpers import get_bool_setting as _addon_bool_setting
from resources.lib.core.stremio_alldebrid_url import augment_stremio_catalog_url
from resources.lib.core.stremio_transport import normalize_stremio_addon_url
from resources.lib.sources.source_language import (
    _text_hints_english,
    castellano_hint_in_text,
    extra_text_from_stream_url,
    latino_hint_in_text,
)
from resources.lib.sources.stremio_sources_config import (
    SETTING_PER_ADDON_TOGGLE,
    SETTING_USE_MANIFEST_CATALOG_FILTER,
    STREMIO_CATALOG_NAMED_ADDONS,
    default_manifest_url_for_prefix,
    http_timeout_seconds_from_addon,
    parse_manifest_catalog_filter_map,
    skip_stremio_source_for_vod,
    stremio_catalog_triple_allowed,
)
from resources.lib.stremio.domain import parse_named_custom

from .base import BaseProvider

# Un solo almacén por proceso Kodi: todas las instancias del proveedor comparten la misma caché
# de manifest.json (Fase E / mantenimiento tipo Jacktook clear_stremio_cache).
_SHARED_MANIFEST_DOC_CACHE = {}

# Banderas regionales en nombres de magnet (ej. Peerflix pone España en dn= tras % decoding).
_FLAG_ES = "\U0001f1ea\U0001f1f8"
_FLAG_MX = "\U0001f1f2\U0001f1fd"
_FLAG_AR = "\U0001f1e6\U0001f1f7"
_FLAG_CO = "\U0001f1e8\U0001f1f4"
_FLAG_VE = "\U0001f1fb\U0001f1ea"


def _stremio_magnet_dn_text(magnet_url):
    u = str(magnet_url or "").strip()
    if not u.startswith("magnet:"):
        return ""
    try:
        q = u.split("?", 1)[1]
    except IndexError:
        return ""
    for part in q.split("&"):
        if part.startswith("dn="):
            return unquote(part[3:].replace("+", " "))
    return ""


def _stremio_language_from_regional_flag(s):
    if not s:
        return None
    if _FLAG_ES in s:
        return "Castellano"
    if any(f in s for f in (_FLAG_MX, _FLAG_AR, _FLAG_CO, _FLAG_VE)):
        return "Latino"
    return None


def clear_stremio_manifest_session_cache():
    """Vacía la caché en memoria de documentos manifest.json descargados."""
    try:
        _SHARED_MANIFEST_DOC_CACHE.clear()
    except Exception:
        pass


class StremioCatalogProvider(BaseProvider):
    name = "Stremio"
    description = "Catalogos JSON (complementos con URL) cuando Stremio esta activado en Proveedores."

    def __init__(self, addon):
        self._addon = addon
        self._manifest_doc_cache = _SHARED_MANIFEST_DOC_CACHE
        self._catalog_sources = self._load_catalog_sources(addon)

    @staticmethod
    def _safe_setting_text(addon, setting_id):
        """
        Lee settings tipo texto de forma tolerante:
        evita TypeError cuando el setting no existe o no es string.
        """
        sid = str(setting_id or "").strip()
        if not sid:
            return ""
        try:
            return (addon.getSettingString(sid) or "").strip()
        except Exception:
            try:
                return (addon.getSetting(sid) or "").strip()
            except Exception:
                return ""

    def _load_catalog_sources(self, addon):
        sources = []

        def _prep(u):
            raw = augment_stremio_catalog_url(normalize_stremio_addon_url(u), addon)
            low = raw.lower()
            if (
                "aiostreams.elfhosted.com/manifest.json" in low
                and "aiostreams.elfhosted.com/stremio/manifest.json" not in low
            ):
                return raw.replace(
                    "aiostreams.elfhosted.com/manifest.json",
                    "aiostreams.elfhosted.com/stremio/manifest.json",
                )
            return raw

        state_json = self._safe_setting_text(addon, "stremio_addons_state")
        loaded_from_state = False
        if state_json:
            try:
                state = json.loads(state_json)
            except Exception:
                state = {}
            known_state = state.get("known") if isinstance(state, dict) else {}
            custom_state = state.get("custom") if isinstance(state, dict) else []
            if isinstance(known_state, dict):
                for name, setting_prefix in self._named_source_settings():
                    row = (
                        known_state.get(setting_prefix)
                        if isinstance(known_state, dict)
                        else None
                    )
                    if not isinstance(row, dict):
                        continue
                    if not bool(row.get("enabled", True)):
                        continue
                    url = str(row.get("url") or "").strip()
                    if not url:
                        url = self._safe_setting_text(
                            addon, f"{setting_prefix}_url"
                        ).strip()
                    if not url:
                        url = default_manifest_url_for_prefix(setting_prefix)
                    if not url:
                        continue
                    sources.append((name, _prep(url)))
                    loaded_from_state = True
            if isinstance(custom_state, list):
                for row in custom_state:
                    if not isinstance(row, dict):
                        continue
                    if not bool(row.get("enabled", True)):
                        continue
                    cname = str(row.get("name") or "Stremio").strip() or "Stremio"
                    curl = str(row.get("url") or "").strip()
                    if curl:
                        sources.append((cname, _prep(curl)))
                        loaded_from_state = True

        # Fallback transicional: solo si todavía no hay estado nuevo.
        if not loaded_from_state:
            use_named_toggle = _addon_bool_setting(addon, SETTING_PER_ADDON_TOGGLE)
            for name, setting_prefix in self._named_source_settings():
                url = self._safe_setting_text(addon, f"{setting_prefix}_url")
                if not url:
                    url = default_manifest_url_for_prefix(setting_prefix)
                if not url:
                    continue
                if use_named_toggle and not _addon_bool_setting(
                    addon, f"{setting_prefix}_enabled"
                ):
                    continue
                sources.append((name, _prep(url)))
            # Compatibilidad: incluir también catálogos custom guardados en stremio_catalog_named
            # cuando todavía no existe stremio_addons_state persistido.
            try:
                rows = parse_named_custom(
                    self._safe_setting_text(addon, "stremio_catalog_named")
                )
            except Exception:
                rows = []
            for row in rows:
                if not isinstance(row, dict):
                    continue
                cname = str(row.get("name") or "Stremio").strip() or "Stremio"
                curl = str(row.get("manifest_url") or row.get("url") or "").strip()
                if curl:
                    sources.append((cname, _prep(curl)))

        # Completar addons nombrados que faltan en el JSON de estado (tras añadir uno nuevo, p. ej. Tvvoo).
        names_have = {(n or "").strip() for n, _ in sources}
        use_named_toggle2 = _addon_bool_setting(addon, SETTING_PER_ADDON_TOGGLE)
        for name, setting_prefix in self._named_source_settings():
            if (name or "").strip() in names_have:
                continue
            url = self._safe_setting_text(addon, f"{setting_prefix}_url")
            if not url:
                url = default_manifest_url_for_prefix(setting_prefix)
            if not url:
                continue
            if use_named_toggle2 and not _addon_bool_setting(
                addon, f"{setting_prefix}_enabled"
            ):
                continue
            sources.append((name, _prep(url)))
            names_have.add((name or "").strip())

        # Evita duplicados manteniendo orden
        unique_sources = []
        seen_urls = set()
        for source_name, url in sources:
            if url in seen_urls:
                continue
            seen_urls.add(url)
            unique_sources.append((source_name, url))
        return unique_sources

    def _named_source_settings(self):
        return STREMIO_CATALOG_NAMED_ADDONS

    def _catalog_search_http_url(self, catalog_base, query):
        """Construye la URL HTTP de búsqueda según protocolo Stremio addon."""
        raw = (catalog_base or "").strip()
        q = quote((query or "").strip(), safe="")
        if not raw or not q:
            return ""
        base = raw.rstrip("/")
        lower = base.lower()
        # Protocolo estandar Stremio: GET .../catalog/{tipo}/{id}/search={consulta}.json
        # https://stremio.github.io/stremio-addon-guide/step7
        if "/catalog/" in lower:
            return f"{base}/search={q}.json"
        # URLs antiguas o APIs que aceptan search como parametro de consulta
        sep = "&" if "?" in base else "?"
        return f"{base}{sep}search={q}"

    @staticmethod
    def transport_base_from_catalog_url(raw_url):
        """Raiz transport del complemento (sin /manifest ni /catalog); usable sin instancia (ping)."""
        raw = (raw_url or "").strip()
        if not raw:
            return ""
        base = raw.split("?", 1)[0].rstrip("/")
        lower = base.lower()
        # Tolerancia tipo Jacktook: muchos usuarios pegan URL web de setup/config en vez de manifest/catalog.
        # Si detectamos endpoints de configuracion, recortamos a la raiz del addon.
        for marker in ("/configure", "/settings", "/setup"):
            idx = lower.find(marker)
            if idx > 0:
                return base[:idx].rstrip("/")
        if lower.endswith("/config"):
            return base[: -len("/config")].rstrip("/")
        if lower.endswith("/manifest.json"):
            return base[: -len("/manifest.json")]
        idx = lower.find("/catalog/")
        if idx > 0:
            return base[:idx].rstrip("/")
        return base

    @classmethod
    def manifest_url_from_catalog_entry(cls, catalog_url):
        """GET manifest.json para una URL de catalogo ya preparada (AllDebrid, etc.)."""
        t = cls.transport_base_from_catalog_url(catalog_url)
        return f"{t}/manifest.json" if t else ""

    def _source_transport_url(self, raw_url):
        """Normaliza URL de complemento a la raiz transport (sin /manifest ni /catalog)."""
        return self.transport_base_from_catalog_url(raw_url)

    def _manifest_catalog_search_urls(self, source_name, source_url, query):
        """Descubre catalogos buscables desde manifest.json y construye URLs."""
        transport = self._source_transport_url(source_url)
        if not transport:
            return []
        manifest_url = f"{transport}/manifest.json"
        try:
            payload = self._load_manifest_payload(manifest_url)
        except (URLError, ValueError) as err:
            xbmc.log(
                f"[Kraken][Stremio:{source_name}] Manifest no disponible {manifest_url}: {err}",
                xbmc.LOGDEBUG,
            )
            return []

        catalogs = payload.get("catalogs") or []
        q = quote((query or "").strip(), safe="")
        if not q:
            return []

        use_mf = _addon_bool_setting(self._addon, SETTING_USE_MANIFEST_CATALOG_FILTER)
        fmap = parse_manifest_catalog_filter_map(self._addon) if use_mf else None

        urls = []
        for catalog in catalogs:
            if not isinstance(catalog, dict):
                continue
            meta_type = str(catalog.get("type") or "").strip().lower()
            catalog_id = str(catalog.get("id") or "").strip()
            if not meta_type or not catalog_id:
                continue

            # Muchos addons no anuncian `search` en manifest.extra/extraSupported,
            # pero sí responden a /catalog/.../search=...json.
            # Probamos de forma optimista y, si falla, se descarta en el fetch.

            if not stremio_catalog_triple_allowed(
                self._addon, source_name, meta_type, catalog_id, fmap
            ):
                continue

            urls.append(
                (
                    source_name,
                    f"{transport}/catalog/{meta_type}/{catalog_id}/search={q}.json",
                )
            )
        return urls

    def search(
        self, query, allowed_types=None, include_sources=None, exclude_sources=None
    ):
        source_urls = self._build_query_url(query.strip())
        if not source_urls:
            return []

        # Por defecto, el scrapeo general de Kraken (pelis/series) NO debe mezclar TV en directo.
        want_types = {
            str(x).strip().lower()
            for x in (allowed_types or ("movie", "series"))
            if str(x).strip()
        }
        include_src = {
            str(x).strip().lower() for x in (include_sources or ()) if str(x).strip()
        }
        exclude_src = {
            str(x).strip().lower() for x in (exclude_sources or ()) if str(x).strip()
        }
        if (
            not include_src
            and not exclude_src
            and want_types
            and ("tv" not in want_types and "channel" not in want_types)
        ):
            exclude_src.add("tvvoo")

        filtered = []
        for source_name, url in source_urls:
            src = str(source_name or "").strip().lower()
            if include_src and src not in include_src:
                continue
            if src in exclude_src:
                continue
            filtered.append((source_name, url))

        def _fetch_catalog_payload(item):
            source_name, url = item
            try:
                req = Request(url, headers={"User-Agent": "Kraken-Stremio/1.0"})
                with urlopen(req, timeout=self._stremio_http_timeout()) as response:
                    payload = json.loads(response.read().decode("utf-8"))
            except (URLError, ValueError) as err:
                xbmc.log(
                    f"[Kraken][Stremio:{source_name}] {err}",
                    xbmc.LOGDEBUG,
                )
                payload = {}
            return source_name, payload

        if self._parallel_workers(len(filtered)) <= 1:
            payload_rows = [_fetch_catalog_payload(it) for it in filtered]
        else:
            payload_rows = []
            with ThreadPoolExecutor(
                max_workers=self._parallel_workers(len(filtered))
            ) as ex:
                futures = [ex.submit(_fetch_catalog_payload, it) for it in filtered]
                for fut in as_completed(futures):
                    try:
                        payload_rows.append(fut.result())
                    except Exception:
                        continue

        results = []
        seen = set()
        for source_name, payload in payload_rows:
            metas = payload.get("metas", [])
            for meta in metas:
                item_id = str(meta.get("id", "")).strip()
                title = meta.get("name", "Sin titulo")
                if not item_id:
                    continue

                src_slug = str(source_name or "").strip().lower()
                key = "{}::{}".format(src_slug, item_id)
                if key in seen:
                    continue
                seen.add(key)

                meta_type = str(meta.get("type") or "movie").strip().lower()
                if meta_type in ("show",):
                    meta_type = "series"
                if meta_type not in ("movie", "series", "tv", "channel"):
                    meta_type = "movie"
                if want_types and meta_type not in want_types:
                    continue
                release_info = str(meta.get("releaseInfo") or "").strip()
                year = None
                if len(release_info) >= 4 and release_info[:4].isdigit():
                    year = int(release_info[:4])
                elif str(meta.get("year") or "").isdigit():
                    year = int(str(meta.get("year")))
                poster = (
                    str(meta.get("poster") or "").strip()
                    or str(meta.get("posterShape") or "").strip()
                    or str(meta.get("thumbnail") or "").strip()
                    or str(meta.get("logo") or "").strip()
                )

                results.append(
                    {
                        "id": f"stremio::{source_name}::{meta_type}::{item_id}",
                        "title": title,
                        "year": year,
                        "plot": meta.get("description", ""),
                        "poster": poster,
                        "provider": f"{self.name}: {source_name}",
                    }
                )
        return results

    def _addon_transport_url(self, catalog_base_url):
        """Raiz del addon Stremio (transport), todo lo que va antes de /catalog/."""
        return self._source_transport_url(catalog_base_url)

    def list_catalogs_for_types(self, source_name, types_filter):
        """
        A partir del manifiesto, listas de catalogo Stremio (p. ej. type=tv|channel) para un prefijo dado.
        types_filter: iterable estricto, ej. ('tv', 'channel').
        """
        want = {str(x).lower().strip() for x in (types_filter or ()) if x}
        if not want:
            return []
        use_mf = _addon_bool_setting(self._addon, SETTING_USE_MANIFEST_CATALOG_FILTER)
        fmap = parse_manifest_catalog_filter_map(self._addon) if use_mf else None
        out = []
        for name, base_url in self._catalog_sources:
            if (name or "").strip() != (source_name or "").strip():
                continue
            transport = self._source_transport_url(base_url)
            if not transport:
                continue
            murl = f"{transport}/manifest.json"
            try:
                man = self._load_manifest_payload(murl)
            except (URLError, ValueError) as e:
                xbmc.log(
                    f"[Kraken][Stremio:{source_name}] Manifest {murl}: {e}",
                    xbmc.LOGINFO,
                )
                continue
            for c in man.get("catalogs") or []:
                if not isinstance(c, dict):
                    continue
                mt = str(c.get("type") or "").strip().lower()
                if mt not in want:
                    continue
                cid = str(c.get("id") or "").strip()
                if not cid:
                    continue
                # vavoo_search_* / "🔎 Pais" solo funciona con search=, no con catalogo plano
                if "vavoo_search" in cid.lower():
                    continue
                cname = str(c.get("name") or c.get("label") or c.get("title") or cid)
                nstart = cname.lstrip()[:1]
                if nstart in ("\U0001f50d", "\U0001f50d", "\u2318"):
                    continue
                genre_opts = []
                for ex in c.get("extra") or []:
                    if not isinstance(ex, dict):
                        continue
                    if str(ex.get("name") or "").strip().lower() != "genre":
                        continue
                    opts = ex.get("options")
                    if isinstance(opts, (list, tuple)) and opts:
                        genre_opts = [
                            str(x) for x in opts if (x is not None and str(x).strip())
                        ]
                if not stremio_catalog_triple_allowed(
                    self._addon, source_name, mt, cid, fmap
                ):
                    continue
                out.append(
                    {
                        "type": mt,
                        "id": cid,
                        "name": cname,
                        "genres": genre_opts,
                    }
                )
        return out

    def list_manifest_catalog_entries_for_picker(self, source_name):
        """Entradas catalogs[] del manifest para multicheck (complementos nombrados)."""
        out = []
        for name, base_url in self._catalog_sources:
            if (name or "").strip() != (source_name or "").strip():
                continue
            transport = self._source_transport_url(base_url)
            if not transport:
                continue
            murl = f"{transport}/manifest.json"
            try:
                man = self._load_manifest_payload(murl)
            except (URLError, ValueError) as e:
                xbmc.log(
                    f"[Kraken][Stremio:{source_name}] Manifest (picker) {murl}: {e}",
                    xbmc.LOGINFO,
                )
                continue
            for c in man.get("catalogs") or []:
                if not isinstance(c, dict):
                    continue
                mt = str(c.get("type") or "").strip().lower()
                cid = str(c.get("id") or "").strip()
                if not mt or not cid:
                    continue
                if "vavoo_search" in cid.lower():
                    continue
                cname = str(c.get("name") or c.get("label") or c.get("title") or cid)
                nstart = cname.lstrip()[:1]
                if nstart in ("\U0001f50d", "\U0001f50d", "\u2318"):
                    continue
                out.append({"type": mt, "id": cid, "name": cname})
        return out

    def list_genre_options(self, source_name, meta_type, catalog_id):
        """
        Nombres de 'genre' (extra) del manifiesto para un catalogo concreto, o [].
        """
        cid0 = (catalog_id or "").strip()
        m0 = (meta_type or "tv").strip().lower()
        for name, base_url in self._catalog_sources:
            if (name or "").strip() != (source_name or "").strip():
                continue
            transport = self._source_transport_url(base_url)
            if not transport:
                continue
            murl = f"{transport}/manifest.json"
            try:
                man = self._load_manifest_payload(murl)
            except (URLError, ValueError) as e:
                xbmc.log(
                    f"[Kraken][Stremio:{source_name}] Manifest (genres) {murl}: {e}",
                    xbmc.LOGINFO,
                )
                continue
            for c in man.get("catalogs") or []:
                if not isinstance(c, dict):
                    continue
                if str(c.get("id") or "").strip() != cid0:
                    continue
                if str(c.get("type") or "").strip().lower() != m0:
                    continue
                for ex in c.get("extra") or []:
                    if not isinstance(ex, dict):
                        continue
                    if str(ex.get("name") or "").strip().lower() != "genre":
                        continue
                    opts = ex.get("options")
                    if isinstance(opts, (list, tuple)) and opts:
                        return [
                            str(x) for x in opts if (x is not None and str(x).strip())
                        ]
                return []
        return []

    def fetch_catalog_browse(self, source_name, meta_type, catalog_id, genre=None):
        """
        Carga canales/entradas de un catálogo (sin búsqueda). Varios formatos de URL (addons distintos).
        Tvvoo / similares: a veces hace falta extra genre= (p. ej. /catalog/tv/.../genre=Tutti.json).
        """
        g = (genre or "").strip() if genre else ""
        for name, base_url in self._catalog_sources:
            if (name or "").strip() != (source_name or "").strip():
                continue
            transport = self._source_transport_url(base_url)
            if not transport:
                continue
            m = (meta_type or "tv").strip().lower()
            rel = (catalog_id or "").strip()
            if not rel:
                continue
            from urllib.parse import quote as uquote

            relq = uquote(rel, safe="!$&'()*+,;=:@-._~")
            gseg = uquote("genre=" + (g or "Tutti"), safe="!$&'()*+,;=:@-._~")
            try_urls = []
            # Si hay temática, probar ANTES la ruta filtrada por genre para evitar
            # caer en la lista completa del país.
            if g:
                try_urls.append(f"{transport}/catalog/{m}/{relq}/{gseg}.json")
            try_urls.append(f"{transport}/catalog/{m}/{relq}.json")
            if not g or g in (
                "Tutti",
                "tutti",
                "TUTTI",
                "Todas",
                "todas",
                "All",
                "all",
            ):
                try_urls.append(f"{transport}/catalog/{m}/{relq}/genre=Tutti.json")
            if relq != rel:
                try_urls.append(f"{transport}/catalog/{m}/{rel}.json")
            if (not g or g in ("Tutti", "TUTTI", "Todas", "all")) and relq != rel:
                try_urls.append(f"{transport}/catalog/{m}/{rel}/genre=Tutti.json")
            try_urls.append(f"{transport}/catalog/{m}/{relq}/catalog.json")
            if g and g not in (
                "Tutti",
                "TUTTI",
                "tutti",
                "Todas",
                "todas",
                "All",
                "all",
            ):
                try_urls.append(
                    "{}/catalog/{}/{}/{}".format(
                        transport,
                        m,
                        relq,
                        uquote("genre=" + g, safe="!$&'()*+,;=:@-._~"),
                    )
                    + ".json"
                )
            seen = set()
            for u in try_urls:
                if not u or u in seen:
                    continue
                seen.add(u)
                try:
                    payload = self._fetch_json(u)
                except (URLError, ValueError):
                    continue
                metas = payload.get("metas")
                if isinstance(metas, list) and metas:
                    return metas
        return []

    def search_tvvoo_only(self, query):
        q = (query or "").strip()
        if not q or not self._catalog_sources:
            return []
        acc = self.search(
            q,
            allowed_types=("tv", "channel"),
            include_sources=("tvvoo",),
            exclude_sources=(),
        )

        def _is_tvvoo_id(item):
            s = str((item or {}).get("id") or "").lower()
            return s.startswith("stremio::tvvoo::")

        return [x for x in (acc or []) if _is_tvvoo_id(x)]

    @staticmethod
    def stremio_result_id_from_meta(source_name, meta):
        """ID interno stremio::<fuente>::<tipo>::<id> a partir de un bloque meta del addon."""
        m = (meta or {}) if isinstance(meta, dict) else {}
        mid = str(m.get("id") or "").strip()
        if not mid:
            return ""
        for _ in range(5):
            u = unquote(mid)
            if u == mid:
                break
            mid = u
        t = str(m.get("type") or "movie").strip().lower()
        if t in ("show",):
            t = "series"
        if t not in ("movie", "series", "tv", "channel"):
            t = "movie"
        return "stremio::{}::{}::{}".format((source_name or "Stremio").strip(), t, mid)

    @staticmethod
    def _stremio_meta_id_to_stream_path_segment(meta_id):
        """
        Tvvoo/manifestos suelen poner en meta.id cadenas ya con %20, %7C, etc.
        Volver a quote() el mismo string escapa el '%' -> %2520 y /stream/ falla.
        Aqui desescapamos hasta dejar caracteres reales, luego un unico quote para la URL.
        """
        s = (meta_id or "").strip()
        if not s:
            return ""
        for _ in range(10):
            t = unquote(s)
            if t == s:
                break
            s = t
        return quote(s, safe="")

    def _parse_stremio_result_id(self, result_id):
        """stremio::<fuente>::<tipo>::<meta_id> o formato antiguo sin tipo."""
        parts = result_id.split("::")
        if len(parts) < 3 or parts[0] != "stremio":
            return None, None, None
        source_name = parts[1]
        if len(parts) >= 4:
            meta_type = parts[2]
            meta_id = "::".join(parts[3:])
            return source_name, meta_type, meta_id
        meta_id = parts[2]
        return source_name, "movie", meta_id

    def _stremio_http_timeout(self):
        return http_timeout_seconds_from_addon(self._addon)

    @staticmethod
    def _parallel_workers(count):
        try:
            n = int(count or 0)
        except Exception:
            n = 0
        if n <= 1:
            return 1
        # Más peticiones concurrentes cuando hay muchos catálogos / addons (~mismo coste de red acumulado, menos tiempo de muro).
        return max(2, min(24, n))

    def _collect_search_urls_one_source(self, source_name, catalog_url, query_stripped):
        """URLs de catalog search para una sola entrada (uso en paralelo desde _build_query_url)."""
        from_manifest = self._manifest_catalog_search_urls(
            source_name, catalog_url, query_stripped
        )
        if from_manifest:
            return list(from_manifest)
        url = self._catalog_search_http_url(catalog_url, query_stripped)
        if url:
            return [(source_name, url)]
        return []

    def _build_query_url(self, query):
        if not self._catalog_sources:
            return []
        query_stripped = (query or "").strip()
        if not query_stripped:
            return []
        pairs = list(self._catalog_sources)
        out = []

        def extend_result(chunk):
            if chunk:
                out.extend(chunk)

        if len(pairs) <= 1:
            for p in pairs:
                extend_result(self._collect_search_urls_one_source(p[0], p[1], query_stripped))
            return out

        workers = max(2, min(24, len(pairs)))
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futures = [
                ex.submit(self._collect_search_urls_one_source, sn, cu, query_stripped)
                for sn, cu in pairs
            ]
            for fut in as_completed(futures):
                try:
                    extend_result(fut.result())
                except Exception:
                    continue
        return out

    def _load_manifest_payload(self, manifest_url):
        """Cache breve de manifest.json por sesion (menos peticiones al mismo transport)."""
        key = manifest_url
        if key in self._manifest_doc_cache:
            return self._manifest_doc_cache[key]
        data = self._fetch_json(key)
        if len(self._manifest_doc_cache) >= 48:
            self._manifest_doc_cache.clear()
        self._manifest_doc_cache[key] = data
        return data

    def _fetch_json(self, url):
        req = Request(url, headers={"User-Agent": "Kraken-Stremio/1.0"})
        with urlopen(req, timeout=self._stremio_http_timeout()) as response:
            return json.loads(response.read().decode("utf-8"))

    @staticmethod
    def _stream_http_headers_dict(stream):
        """Cabeceras HTTP opcionales del protocolo Stremio (`streams[].headers`)."""
        if not isinstance(stream, dict):
            return None
        h = stream.get("headers")
        if not isinstance(h, dict) or not h:
            return None
        out = {}
        for k, v in h.items():
            if v is None:
                continue
            ks = str(k).strip()
            if ks:
                out[ks] = str(v)
        return out or None

    def _first_playable_stream_result(self, payload):
        """URL reproducible del JSON /stream/…, o dict {url, http_headers} si el addon las envía."""
        candidates = self._playable_stream_candidates(payload)
        if not candidates:
            return None
        c = candidates[0]
        url = str(c.get("url") or "").strip()
        if not url:
            return None
        h = c.get("http_headers")
        if isinstance(h, dict) and h:
            return {"url": url, "http_headers": h}
        return url

    def _playable_stream_candidates(self, payload):
        """Devuelve lista de streams reproducibles con etiquetas para selector."""
        streams = payload.get("streams") or []
        candidates = []
        seen = set()
        for stream in streams:
            if not isinstance(stream, dict):
                continue
            label = str(
                stream.get("name")
                or stream.get("title")
                or stream.get("description")
                or "Fuente"
            ).strip()
            quality = self._detect_quality(stream)
            language = self._detect_language(stream)
            title = str(stream.get("title") or stream.get("name") or "").strip()
            hdr = self._stream_http_headers_dict(stream)
            raw_text = " ".join(
                [
                    str(stream.get("name") or ""),
                    str(stream.get("title") or ""),
                    str(stream.get("description") or ""),
                    str(stream.get("behaviorHints") or ""),
                    str(stream.get("tag") or ""),
                ]
            ).strip()
            url = stream.get("url")
            if isinstance(url, str) and url.strip():
                u = url.strip()
                if u.startswith(("http://", "https://")):
                    if self._is_allowed_stream_http_url(u) and u not in seen:
                        seen.add(u)
                        row = {
                            "url": u,
                            "label": label,
                            "title": title,
                            "quality": quality,
                            "language": language,
                            "_raw_text": raw_text,
                        }
                        if hdr:
                            row["http_headers"] = hdr
                        candidates.append(row)
                elif u.startswith("magnet:"):
                    if u not in seen:
                        seen.add(u)
                        row = {
                            "url": u,
                            "label": label,
                            "title": title,
                            "quality": quality,
                            "language": language,
                            "_raw_text": raw_text,
                        }
                        if hdr:
                            row["http_headers"] = hdr
                        candidates.append(row)
            mag_alt = stream.get("magnetUrl") or stream.get("magnet")
            if isinstance(mag_alt, str) and mag_alt.strip().startswith("magnet:"):
                u = mag_alt.strip()
                if u not in seen:
                    seen.add(u)
                    candidates.append(
                        {
                            "url": u,
                            "label": label,
                            "title": title,
                            "quality": quality,
                            "language": language,
                            "_raw_text": raw_text,
                        }
                    )
            ext = stream.get("externalUrl")
            if isinstance(ext, str) and ext.startswith(("http://", "https://")):
                ext_clean = ext.strip()
                if (
                    self._is_allowed_stream_http_url(ext_clean)
                    and ext_clean not in seen
                ):
                    seen.add(ext_clean)
                    row = {
                        "url": ext_clean,
                        "label": label,
                        "title": title,
                        "quality": quality,
                        "language": language,
                        "_raw_text": raw_text,
                    }
                    if hdr:
                        row["http_headers"] = hdr
                    candidates.append(row)

            srcs = stream.get("sources")
            if isinstance(srcs, list):
                for raw in srcs:
                    if not isinstance(raw, str):
                        continue
                    su = raw.strip()
                    if not su.startswith(("http://", "https://")):
                        continue
                    if self._is_allowed_stream_http_url(su) and su not in seen:
                        seen.add(su)
                        row = {
                            "url": su,
                            "label": label,
                            "title": title,
                            "quality": quality,
                            "language": language,
                            "_raw_text": raw_text,
                        }
                        if hdr:
                            row["http_headers"] = hdr
                        candidates.append(row)

            ih = stream.get("infoHash") or stream.get("infohash")
            if isinstance(ih, str):
                ih_clean = ih.strip().lower()
                if len(ih_clean) >= 32:
                    disp = stream.get("name") or stream.get("title") or ""
                    magnet = "magnet:?xt=urn:btih:{}&dn={}".format(
                        ih_clean,
                        quote(str(disp), safe=""),
                    )
                    if magnet not in seen:
                        seen.add(magnet)
                        candidates.append(
                            {
                                "url": magnet,
                                "label": label,
                                "title": title,
                                "quality": quality,
                                "language": language,
                                "_raw_text": raw_text,
                            }
                        )
        # Algunos addons (p.ej. Peerflix) publican filas de estado
        # ("downloading/descargando") que abren una pantalla informativa.
        # Se excluyen para no romper la reproducción automática.
        ready = [c for c in candidates if not self._looks_stream_pending(c)]
        return ready

    @staticmethod
    def _looks_stream_pending(candidate):
        text = " ".join(
            [
                str((candidate or {}).get("label") or ""),
                str((candidate or {}).get("title") or ""),
                str((candidate or {}).get("url") or ""),
                str((candidate or {}).get("_raw_text") or ""),
            ]
        ).lower()
        pending_tokens = (
            "downloading",
            "download in progress",
            "downloaded in debrid",
            "being downloaded in debrid",
            "buffering",
            "preparing",
            "processing",
            "caching",
            "queued",
            "descargando",
            "siendo descargado en debrid",
            "preparando",
            "procesando",
            "en cola",
            "vuelve mas tarde",
            "vuelve más tarde",
        )
        return any(tok in text for tok in pending_tokens)

    @staticmethod
    def _looks_non_media_landing_url(url):
        low = str(url or "").strip().lower()
        if not low:
            return True
        blocked_parts = (
            "/configure",
            "/config",
            "/settings",
            "/setup",
            "/manifest.json",
        )
        if any(part in low for part in blocked_parts):
            return True
        blocked_ext = (".css", ".js", ".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg")
        if any(low.endswith(ext) for ext in blocked_ext):
            return True
        # AIOStreams / addons mal configurados a veces devuelven la URL del repo (HTML), no un stream.
        # Ej. https://github.com/Viren070/AIOStreams -> FFmpeg "error probing input format"
        if "github.com/" in low and "raw.githubusercontent.com" not in low:
            if re.match(r"^https?://(www\.)?github\.com/[^/]+/[^/]+/?$", low):
                return True
        return False

    def _is_allowed_stream_http_url(self, stream_url):
        """
        Evita enlaces de setup/config y, para URLs tipo /playback/, detecta redirecciones
        silenciosas a /configure antes de pasarlas al reproductor.
        """
        u = str(stream_url or "").strip()
        if not u.startswith(("http://", "https://")):
            return False
        if self._looks_non_media_landing_url(u):
            return False

        low = u.lower()
        must_probe = ("/playback/" in low) or any(
            x in low for x in (".m3u8", ".mpd", "/hls/")
        )
        if not must_probe:
            return True

        try:
            req = Request(
                u,
                headers={
                    "User-Agent": "Kraken-Stremio/1.0",
                    "Range": "bytes=0-0",
                },
            )
            with urlopen(req, timeout=min(8, self._stremio_http_timeout())) as resp:
                final_url = str(resp.geturl() or u).strip().lower()
                ctype = str(resp.headers.get("Content-Type") or "").strip().lower()
        except Exception:
            # La sonda corta suele fallar con CDN/IPTV en vivo (timeout, TLS lento, geo).
            # Descartar aquí deja "Respuesta sin URL" y el canal no reproduce aunque Kodi sí abriría el HLS.
            if must_probe:
                xbmc.log(
                    f"[Kraken][Stremio] Sonda falló; se mantiene URL para intento de reproducción: {u}",
                    xbmc.LOGINFO,
                )
                return True
            return True

        if self._looks_non_media_landing_url(final_url):
            xbmc.log(
                f"[Kraken][Stremio] Stream descartado por redireccion a setup/config: {u} -> {final_url}",
                xbmc.LOGWARNING,
            )
            return False
        if "text/html" in ctype and not any(
            x in final_url for x in (".m3u8", ".mpd", ".mp4", ".mkv", ".avi")
        ):
            xbmc.log(
                f"[Kraken][Stremio] Stream descartado por contenido HTML no reproducible: {final_url}",
                xbmc.LOGWARNING,
            )
            return False
        return True

    def _detect_quality(self, stream):
        text = " ".join(
            [
                str(stream.get("name") or ""),
                str(stream.get("title") or ""),
                str(stream.get("description") or ""),
            ]
        ).lower()
        if "2160" in text or "4k" in text:
            return "4K"
        if "1080" in text:
            return "1080p"
        if "720" in text:
            return "720p"
        if "480" in text:
            return "480p"
        m = re.search(r"\b(\d{3,4}p)\b", text)
        if m:
            return m.group(1).upper()
        return "Auto"

    def _detect_language(self, stream):
        bits = [
            str(stream.get("name") or ""),
            str(stream.get("title") or ""),
            str(stream.get("description") or ""),
            str(stream.get("tag") or ""),
        ]
        hints = stream.get("behaviorHints")
        if isinstance(hints, dict):
            bits.append(json.dumps(hints, ensure_ascii=False))
        elif hints is not None:
            bits.append(str(hints))
        for key in (
            "lang",
            "language",
            "audioLang",
            "audio_lang",
            "audioLanguage",
            "locale",
        ):
            v = stream.get(key)
            if isinstance(v, str) and v.strip():
                bits.append(v)
        dns_seen = set()
        for magnet_field in (
            stream.get("url"),
            stream.get("magnetUrl"),
            stream.get("magnet"),
        ):
            if not isinstance(magnet_field, str):
                continue
            mu = magnet_field.strip()
            if not mu.startswith("magnet:"):
                continue
            dn = _stremio_magnet_dn_text(mu)
            if dn and dn not in dns_seen:
                dns_seen.add(dn)
                bits.append(dn)
        for ufield in (stream.get("url"), stream.get("externalUrl")):
            if not isinstance(ufield, str):
                continue
            uu = ufield.strip()
            if uu.startswith(("http://", "https://")):
                ex = extra_text_from_stream_url(uu)
                if ex:
                    bits.append(ex)
        banner = " ".join(bits).strip()
        flagged = _stremio_language_from_regional_flag(banner)
        if flagged:
            return flagged
        text = banner.lower()
        if latino_hint_in_text(text):
            return "Latino"
        if castellano_hint_in_text(text):
            return "Castellano"
        if any(
            token in text
            for token in (
                "dual",
                "multi",
                "multi-audio",
                "multiaudio",
                "dub+sub",
            )
        ):
            return "Multi"
        if any(token in text for token in ("sub", "subtit", "subs", "vose")):
            return "Sub"
        if _text_hints_english(text):
            return "English"
        return "N/D"

    def resolve(self, result_id):
        source_name, meta_type, meta_id = self._parse_stremio_result_id(result_id or "")
        if not source_name or not meta_id:
            return None

        meta_type = (meta_type or "movie").strip().lower()
        if meta_type in ("show",):
            meta_type = "series"
        if meta_type not in ("movie", "series", "tv", "channel"):
            meta_type = "movie"

        sources = self._load_catalog_sources(self._addon)
        # Addons de catálogo puro: no exponen /stream/ utilizable.
        catalog_only = {"imdbcatalogs", "torrentcatalogs"}
        preferred = []
        others = []
        for name, url in sources:
            nlow = str(name or "").strip().lower()
            if nlow in catalog_only:
                continue
            if name == source_name:
                preferred.append((name, url))
            else:
                others.append((name, url))
        ordered_sources = preferred + others
        if not ordered_sources:
            xbmc.log(
                "[Kraken][Stremio] Sin fuentes configuradas para resolver.",
                xbmc.LOGWARNING,
            )
            return None

        safe_id = self._stremio_meta_id_to_stream_path_segment(meta_id)
        if not safe_id:
            return None
        mraw = (meta_id or "").strip()
        alt = quote(mraw, safe="")

        for cand_name, catalog_base in ordered_sources:
            if skip_stremio_source_for_vod(meta_type, cand_name):
                continue
            transport = self._addon_transport_url(catalog_base)
            if not transport:
                continue
            try_urls = [f"{transport}/stream/{meta_type}/{safe_id}.json"]
            if alt and alt != safe_id:
                try_urls.append(f"{transport}/stream/{meta_type}/{alt}.json")
            payload = None
            last_err = None
            stream_http = try_urls[0]
            for u in try_urls:
                try:
                    payload = self._fetch_json(u)
                    stream_http = u
                    break
                except (URLError, ValueError) as err:
                    last_err = err
            if payload is None:
                xbmc.log(
                    f"[Kraken][Stremio] {cand_name}/stream falló en {try_urls}: {last_err}",
                    xbmc.LOGINFO,
                )
                continue
            playable = self._first_playable_stream_result(payload)
            if playable:
                return playable
            xbmc.log(
                f"[Kraken][Stremio] {cand_name} sin URL http/magnet en {stream_http}",
                xbmc.LOGINFO,
            )
        return None

    def resolve_all(self, result_id):
        source_name, meta_type, meta_id = self._parse_stremio_result_id(result_id or "")
        if not source_name or not meta_id:
            return []
        meta_type = (meta_type or "movie").strip().lower()
        if meta_type in ("show",):
            meta_type = "series"
        if meta_type not in ("movie", "series", "tv", "channel"):
            meta_type = "movie"
        sources = self._load_catalog_sources(self._addon)
        catalog_only = {"imdbcatalogs", "torrentcatalogs"}
        preferred = []
        others = []
        for name, url in sources:
            nlow = str(name or "").strip().lower()
            if nlow in catalog_only:
                continue
            if name == source_name:
                preferred.append((name, url))
            else:
                others.append((name, url))
        ordered_sources = preferred + others
        if not ordered_sources:
            return []
        safe_id = self._stremio_meta_id_to_stream_path_segment(meta_id)
        if not safe_id:
            return []
        mraw = (meta_id or "").strip()
        alt = quote(mraw, safe="")
        work = []
        for _cand_name, catalog_base in ordered_sources:
            if skip_stremio_source_for_vod(meta_type, _cand_name):
                continue
            transport = self._addon_transport_url(catalog_base)
            if not transport:
                continue
            try_urls = [f"{transport}/stream/{meta_type}/{safe_id}.json"]
            if alt and alt != safe_id:
                try_urls.append(f"{transport}/stream/{meta_type}/{alt}.json")
            work.append((_cand_name, try_urls))

        def _resolve_one_source(item):
            cand_name, try_urls = item
            payload = None
            for u in try_urls:
                try:
                    payload = self._fetch_json(u)
                    break
                except (URLError, ValueError):
                    continue
            if not payload:
                return cand_name, []
            return cand_name, self._playable_stream_candidates(payload)

        if self._parallel_workers(len(work)) <= 1:
            resolved_rows = [_resolve_one_source(it) for it in work]
        else:
            resolved_rows = []
            with ThreadPoolExecutor(
                max_workers=self._parallel_workers(len(work))
            ) as ex:
                futures = [ex.submit(_resolve_one_source, it) for it in work]
                for fut in as_completed(futures):
                    try:
                        resolved_rows.append(fut.result())
                    except Exception:
                        continue

        all_candidates = []
        # Mismo magnet/enlace puede venir de varios addons; antes se descartaba y solo
        # quedaba el primero (suele ser Torrentio), ocultando el resto de proveedores.
        seen_pair = set()
        for _cand_name, rows in resolved_rows:
            cat_key = str(_cand_name or "").strip().lower()
            for row in rows:
                u = str((row or {}).get("url") or "").strip()
                if not u:
                    continue
                dedup = (u.lower(), cat_key)
                if dedup in seen_pair:
                    continue
                seen_pair.add(dedup)
                tagged = dict(row)
                tagged["_stremio_catalog_name"] = _cand_name
                all_candidates.append(tagged)
        return all_candidates
