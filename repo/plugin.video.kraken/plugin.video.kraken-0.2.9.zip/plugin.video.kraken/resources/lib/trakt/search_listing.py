import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

import xbmcgui
import xbmcplugin

from resources.lib.ui.context_menu import (
    add_movie_download_context,
    add_show_download_context,
)
from resources.lib.trakt.trakt_phrases import _t

# OMDB usa cache fichero lectura-modifica-escritura; serialize entre hilos para evitar condiciones de carrera.
_ENRICH_OMDB_LOCK = threading.Lock()


def _search_results_banner_row(media_filter, default_list_art, url_for_noop):
    """
    Primera fila con fanart/wallpaper del addon para anclar visualmente el listado
    de búsqueda (mejor foco al navegar resultados).
    """
    if not callable(url_for_noop):
        return None
    mf = str(media_filter or "all").strip().lower()
    if mf == "movie":
        label = _t(
            "[B][COLOR FF88CCFF]Películas[/COLOR][/B]  ·  resultados",
            "[B][COLOR FF88CCFF]Movies[/COLOR][/B]  ·  results",
        )
        plain_title = _t(
            "Películas — resultados de búsqueda",
            "Movies — search results",
        )
    elif mf == "show":
        label = _t(
            "[B][COLOR FF88CCFF]Series[/COLOR][/B]  ·  resultados",
            "[B][COLOR FF88CCFF]TV shows[/COLOR][/B]  ·  results",
        )
        plain_title = _t(
            "Series — resultados de búsqueda",
            "TV shows — search results",
        )
    else:
        label = _t(
            "[B][COLOR FF88CCFF]Resultados[/COLOR][/B]  ·  búsqueda",
            "[B][COLOR FF88CCFF]Results[/COLOR][/B]  ·  search",
        )
        plain_title = _t(
            "Resultados — búsqueda Kraken",
            "Results — Kraken search",
        )
    li = xbmcgui.ListItem(label=label)
    li.setProperty("IsPlayable", "false")
    try:
        li.setContentLookup(False)
    except Exception:
        pass
    art = default_list_art() if callable(default_list_art) else {}
    banner = ""
    if isinstance(art, dict):
        banner = str(
            (art.get("fanart") or art.get("thumb") or art.get("icon") or "").strip()
        )
    if banner:
        li.setArt(
            {
                "thumb": banner,
                "fanart": banner,
                "banner": banner,
                "landscape": banner,
                "poster": banner,
            }
        )
    try:
        li.setInfo("video", {"title": plain_title})
    except Exception:
        pass
    return (url_for_noop(), li, False)


def _parse_trakt_search_show_row(row):
    if str(row.get("type") or "").strip().lower() != "show":
        return ""
    s = row.get("show") or {}
    trakt_id = (s.get("ids") or {}).get("trakt")
    if trakt_id is None:
        return ""
    return str(trakt_id).strip()


def _trakt_show_id_from_tmdb_trakt_api(trakt_public_get, tmdb_numeric_id):
    """API pública Trakt: tmdb id → trakt id de serie (no hace falta cuenta vinculada)."""
    if not callable(trakt_public_get) or not tmdb_numeric_id:
        return ""
    try:
        tid = int(tmdb_numeric_id)
    except (TypeError, ValueError):
        return ""
    if tid <= 0:
        return ""
    try:
        url = f"https://api.trakt.tv/search/tmdb/{tid}?type=show"
        payload = trakt_public_get(url)
    except Exception:
        return ""
    if not isinstance(payload, list):
        return ""
    for row in payload:
        sid = _parse_trakt_search_show_row(row)
        if sid:
            return sid
    return ""


def _resolve_trakt_show_id_for_fallback_row(
    *,
    trakt_public_get,
    json_get,
    tmdb_api_key_fn,
    metadata_timeout_fn,
    tmdb_enabled_fn,
    tmdb_numeric_id,
):
    """
    Resolución rápida: Trakt por TMDb.
    Evita fallback IMDb para acelerar el listado de búsqueda.
    """
    return _trakt_show_id_from_tmdb_trakt_api(trakt_public_get, tmdb_numeric_id)


def _prefetch_fallback_show_trakt_ids(
    trakt_public_get,
    results,
    *,
    json_get=None,
    tmdb_api_key_fn=None,
    metadata_timeout_fn=None,
    tmdb_enabled_fn=None,
):
    tmdb_ids = []
    for r in results or []:
        rid = str((r or {}).get("id") or "")
        if not rid.startswith("fallback::show::"):
            continue
        raw = (r or {}).get("tmdb_id")
        if raw is None:
            continue
        try:
            tmdb_ids.append(int(raw))
        except (TypeError, ValueError):
            pass
    uniq = sorted({x for x in tmdb_ids if x > 0})
    if not uniq or not callable(trakt_public_get):
        return {}
    out = {}

    def one(tid):
        trid = _resolve_trakt_show_id_for_fallback_row(
            trakt_public_get=trakt_public_get,
            json_get=json_get,
            tmdb_api_key_fn=tmdb_api_key_fn,
            metadata_timeout_fn=metadata_timeout_fn,
            tmdb_enabled_fn=tmdb_enabled_fn,
            tmdb_numeric_id=tid,
        )
        return tid, trid

    try:
        workers = min(8, len(uniq))
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futures = [ex.submit(one, tid) for tid in uniq]
            for fut in as_completed(futures):
                try:
                    tid, trid = fut.result()
                    if trid:
                        out[tid] = trid
                except Exception:
                    pass
    except Exception:
        for tid in uniq:
            try:
                _, trid = one(tid)
                if trid:
                    out[tid] = trid
            except Exception:
                pass
    return out


def _is_trakt_search_show_result(result_id):
    rid = str(result_id or "")
    return rid.startswith("trakt::show::") or rid.startswith("fallback::show::")


def _folder_trakt_id_for_search_show(
    result,
    *,
    parse_trakt_compound_id,
    prefetch_map,
    trakt_public_get,
    json_get=None,
    tmdb_api_key_fn=None,
    metadata_timeout_fn=None,
    tmdb_enabled_fn=None,
):
    result_id = str((result or {}).get("id") or "")
    if result_id.startswith("trakt::show::"):
        _mt, tid = parse_trakt_compound_id(result_id)
        return str(tid or "").strip()
    if result_id.startswith("fallback::show::"):
        raw = (result or {}).get("tmdb_id")
        try:
            k = int(raw)
        except (TypeError, ValueError):
            return ""
        sid = str((prefetch_map or {}).get(k) or "").strip()
        if sid:
            return sid
        return _resolve_trakt_show_id_for_fallback_row(
            trakt_public_get=trakt_public_get,
            json_get=json_get,
            tmdb_api_key_fn=tmdb_api_key_fn,
            metadata_timeout_fn=metadata_timeout_fn,
            tmdb_enabled_fn=tmdb_enabled_fn,
            tmdb_numeric_id=raw,
        )
    return ""


def _compute_single_item_art_and_ratings(
    item,
    *,
    tmdb_on,
    omdb_on,
    meta_priority_omdb_first,
    omdb_search_art_fn,
    tmdb_search_art_by_id_fn,
    fanart_tv_search_art_fn,
    omdb_empty_metadata_fn,
    omdb_extra_ratings_on,
):
    """Solo trabajo de red/metadata; debe poder ejecutarse en un hilo (OMDB vía función serializada)."""
    result_id = str(item.get("id") or "")
    media_type = "series" if result_id.startswith("trakt::show::") else "movie"
    out = {}

    art = {"poster": "", "fanart": ""}

    def _omdb_locked(*oa, **okw):
        with _ENRICH_OMDB_LOCK:
            return omdb_search_art_fn(*oa, **okw)

    # Si TMDb esta activado en el addon, no cargar OMDb (solo TMDb por id).
    if tmdb_on:
        if item.get("tmdb_id"):
            tmdb_media = tmdb_search_art_by_id_fn(
                item.get("tmdb_id"), media_type=media_type
            )
            art = {
                "poster": str((tmdb_media or {}).get("poster") or ""),
                "fanart": str((tmdb_media or {}).get("fanart") or ""),
            }
            if callable(fanart_tv_search_art_fn):
                fanart_media = fanart_tv_search_art_fn(
                    media_type=media_type,
                    tmdb_id=item.get("tmdb_id", ""),
                    tvdb_id=item.get("tvdb_id", ""),
                    imdb_id=item.get("imdb_id", ""),
                )
                if not art.get("poster") and fanart_media.get("poster"):
                    art["poster"] = fanart_media.get("poster")
                if not art.get("fanart") and fanart_media.get("fanart"):
                    art["fanart"] = fanart_media.get("fanart")
        if not item.get("poster") and art.get("poster"):
            out["poster"] = art["poster"]
        if not item.get("fanart") and art.get("fanart"):
            out["fanart"] = art["fanart"]
        return out

    omdb_data = omdb_empty_metadata_fn()

    # OMDb/IMDb empata mejor con título original (normalmente EN) que con el título traducido.
    omdb_lookup_title = str(
        item.get("trakt_default_title") or item.get("title") or ""
    ).strip()

    if meta_priority_omdb_first:
        if omdb_on:
            omdb_data = _omdb_locked(
                omdb_lookup_title,
                item.get("year"),
                media_type,
                imdb_id=item.get("imdb_id", ""),
            )
            art = {
                "poster": omdb_data.get("poster", ""),
                "fanart": omdb_data.get("fanart", ""),
            }
    else:
        if not art.get("poster") and omdb_on:
            omdb_data = _omdb_locked(
                omdb_lookup_title,
                item.get("year"),
                media_type,
                imdb_id=item.get("imdb_id", ""),
            )
            art = {
                "poster": omdb_data.get("poster", ""),
                "fanart": omdb_data.get("fanart", ""),
            }

    ratings = {}
    for key in ("omdb_rotten", "omdb_metacritic", "omdb_imdb"):
        value = omdb_data.get(key) if omdb_data else None
        if value:
            ratings[key] = value

    if (
        omdb_on
        and omdb_extra_ratings_on
        and (str(item.get("imdb_id") or "")).startswith("tt")
    ):
        if not any(
            (
                ratings.get("omdb_rotten"),
                ratings.get("omdb_metacritic"),
                ratings.get("omdb_imdb"),
            )
        ):
            fill = _omdb_locked(
                omdb_lookup_title,
                item.get("year"),
                media_type,
                imdb_id=item.get("imdb_id", ""),
            )
            for key in ("omdb_rotten", "omdb_metacritic", "omdb_imdb"):
                if fill.get(key) and not ratings.get(key):
                    ratings[key] = fill.get(key)

    if not item.get("poster") and art.get("poster"):
        out["poster"] = art["poster"]
    if not item.get("fanart") and art.get("fanart"):
        out["fanart"] = art["fanart"]
    out.update(ratings)
    return out


def enrich_trakt_result_items_with_metadata(
    *,
    results,
    dialog,
    tmdb_enabled,
    omdb_enabled,
    kraken_progress,
    metadata_priority,
    omdb_search_art,
    tmdb_search_art_by_id,
    omdb_empty_metadata,
    omdb_external_ratings_enabled,
    metadata_fallback_fanart,
    fanart_tv_search_art=None,
):
    if not results or (not tmdb_enabled() and not omdb_enabled()):
        return

    todo = [
        (i, r)
        for i, r in enumerate(results)
        if not (r.get("poster") and r.get("fanart"))
    ]
    if not todo:
        return

    tmdb_on = bool(tmdb_enabled())
    omdb_on = bool(omdb_enabled())
    meta_pri = metadata_priority()
    ratings_on = bool(omdb_external_ratings_enabled())

    kraken_progress(
        dialog,
        46,
        "Enriqueciendo metadatos",
        f"{len(todo)} elementos (paralelo)",
    )

    max_workers = min(12, max(1, len(todo)))

    def _job(pair):
        _idx, it = pair
        try:
            return _idx, _compute_single_item_art_and_ratings(
                it,
                tmdb_on=tmdb_on,
                omdb_on=omdb_on,
                meta_priority_omdb_first=(meta_pri == "omdb_first"),
                omdb_search_art_fn=omdb_search_art,
                tmdb_search_art_by_id_fn=tmdb_search_art_by_id,
                fanart_tv_search_art_fn=fanart_tv_search_art,
                omdb_empty_metadata_fn=omdb_empty_metadata,
                omdb_extra_ratings_on=ratings_on,
            )
        except Exception:
            return _idx, {}

    done = 0
    total = len(todo)
    try:
        with ThreadPoolExecutor(max_workers=max_workers) as ex:
            futures = [ex.submit(_job, pr) for pr in todo]
            for fut in as_completed(futures):
                try:
                    idx, delta = fut.result()
                except Exception:
                    continue
                item = results[idx]
                if not isinstance(delta, dict):
                    continue
                for key in (
                    "poster",
                    "fanart",
                    "omdb_rotten",
                    "omdb_metacritic",
                    "omdb_imdb",
                ):
                    if delta.get(key) and not item.get(key):
                        item[key] = delta[key]
                if (
                    metadata_fallback_fanart()
                    and not item.get("fanart")
                    and item.get("poster")
                ):
                    item["fanart"] = item.get("poster")
                done += 1
                if done == 1 or done == total or done % max(1, total // 5) == 0:
                    kraken_progress(
                        dialog,
                        min(94, 48 + int((42 * done) / total)),
                        "Enriqueciendo metadatos",
                        f"{done} / {total}",
                    )
    except Exception:
        for idx, _todo_item in todo:
            try:
                delta = _compute_single_item_art_and_ratings(
                    results[idx],
                    tmdb_on=tmdb_on,
                    omdb_on=omdb_on,
                    meta_priority_omdb_first=(meta_pri == "omdb_first"),
                    omdb_search_art_fn=omdb_search_art,
                    tmdb_search_art_by_id_fn=tmdb_search_art_by_id,
                    fanart_tv_search_art_fn=fanart_tv_search_art,
                    omdb_empty_metadata_fn=omdb_empty_metadata,
                    omdb_extra_ratings_on=ratings_on,
                )
            except Exception:
                continue
            item = results[idx]
            if not isinstance(delta, dict):
                continue
            for key in (
                "poster",
                "fanart",
                "omdb_rotten",
                "omdb_metacritic",
                "omdb_imdb",
            ):
                if delta.get(key) and not item.get(key):
                    item[key] = delta[key]
            if (
                metadata_fallback_fanart()
                and not item.get("fanart")
                and item.get("poster")
            ):
                item["fanart"] = item.get("poster")


def add_trakt_search_listing_to_directory(
    *,
    results,
    media_filter,
    plugin_handle,
    empty_message,
    cache_search_results,
    default_list_art,
    trakt_parse_year,
    trakt_float_or_none,
    trakt_list_label1_with_year_rating,
    trakt_rating_label2_extra,
    omdb_external_ratings_label2_extra,
    format_trakt_vote_count,
    omdb_external_ratings_enabled,
    trakt_listitem_set_info_and_videotag,
    parse_trakt_compound_id,
    apply_directory_style,
    url_for_show_seasons,
    url_for_play,
    trakt_public_get=None,
    url_for_noop=None,
    json_get=None,
    tmdb_api_key=None,
    metadata_timeout=None,
    tmdb_enabled=None,
):
    if not results:
        xbmcgui.Dialog().notification(
            "Kraken", empty_message, xbmcgui.NOTIFICATION_INFO
        )
        xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)
        return
    cache_search_results(results)
    base_art = default_list_art()
    prefetch_shows = _prefetch_fallback_show_trakt_ids(
        trakt_public_get,
        results,
        json_get=json_get,
        tmdb_api_key_fn=tmdb_api_key,
        metadata_timeout_fn=metadata_timeout,
        tmdb_enabled_fn=tmdb_enabled,
    )
    prepared = []
    for idx, result in enumerate(results, start=1):
        title = (result.get("title") or "Sin titulo").strip()
        year, has_year = trakt_parse_year(result.get("year"))
        result_id = str(result.get("id", ""))
        is_show = _is_trakt_search_show_result(result_id)
        media_tag = (
            _t("SERIE", "TV SHOW") if is_show else _t("PELÍCULA", "MOVIE")
        )
        rating = result.get("rating")
        votes = result.get("votes")
        rating_display = trakt_float_or_none(rating)
        if rating_display is not None and rating_display <= 0.0:
            rating_display = None
        base_display_title = trakt_list_label1_with_year_rating(
            title, has_year, year, rating_display
        )
        if str(media_filter or "all").strip().lower() == "all":
            type_color = "FF88CCFF" if is_show else "FFFFB347"
            base_display_title = "[COLOR {}][{}][/COLOR] {}".format(
                type_color,
                media_tag,
                base_display_title,
            )
        # Prefijo ordinal para ubicar mejor el foco en listados largos.
        display_title = "[COLOR FFE6B800]{:02d}.[/COLOR] {}".format(
            idx, base_display_title
        )
        subline = "[COLOR orange]{}[/COLOR]{}{}".format(
            media_tag,
            trakt_rating_label2_extra(rating, votes),
            omdb_external_ratings_label2_extra(
                result.get("omdb_rotten"),
                result.get("omdb_metacritic"),
                result.get("omdb_imdb"),
            ),
        )
        li = xbmcgui.ListItem(label=display_title, label2=subline)
        li.setProperty("VideoListItem.SeasonLabel", subline)
        li.setProperty("VideoListItem.EpisodeName", title)
        tagline_plain = media_tag
        if rating_display is not None and rating_display > 0.0:
            tagline_plain = f"{media_tag}  {rating_display:.1f}/10 (Trakt)"
            vote_count = format_trakt_vote_count(votes) if votes else ""
            if vote_count:
                tagline_plain += f"  {vote_count} v."
        if omdb_external_ratings_enabled():
            omdb_bits = []
            if result.get("omdb_rotten"):
                omdb_bits.append("RT {}".format(result.get("omdb_rotten")))
            if result.get("omdb_metacritic"):
                omdb_bits.append("MC {}".format(result.get("omdb_metacritic")))
            if result.get("omdb_imdb"):
                omdb_bits.append("IMDb {}".format(result.get("omdb_imdb")))
            if omdb_bits:
                tagline_plain = "{}  |  {}".format(tagline_plain, "  ".join(omdb_bits))
        if has_year and year is not None:
            tagline_plain = f"{tagline_plain}  {year}"
        info = {
            "title": display_title,
            "year": int(year) if has_year else 0,
            "plot": result.get("plot", ""),
            "plotoutline": result.get("plot", ""),
            "tagline": tagline_plain,
            "mediatype": "tvshow" if is_show else "movie",
        }
        if is_show:
            info["tvshowtitle"] = display_title
        if rating_display is not None and rating_display > 0.0:
            info["rating"] = rating_display
        if votes is not None and votes != "":
            try:
                vote_int = int(votes)
                if vote_int > 0:
                    info["votes"] = str(vote_int)
            except (TypeError, ValueError):
                pass
        trakt_listitem_set_info_and_videotag(
            li,
            display_title,
            str(result.get("plot", "")),
            is_show,
            has_year,
            year,
            rating,
            votes,
            info,
        )
        poster = (result.get("poster") or "").strip()
        fanart = (result.get("fanart") or "").strip()
        art = dict(base_art)
        if poster:
            art.update({"poster": poster, "thumb": poster, "icon": poster})
        if fanart:
            art.update({"fanart": fanart, "landscape": fanart, "banner": fanart})
        elif poster:
            art.update({"fanart": poster, "landscape": poster})
        li.setArt(art)
        if is_show:
            trakt_sid = _folder_trakt_id_for_search_show(
                result,
                parse_trakt_compound_id=parse_trakt_compound_id,
                prefetch_map=prefetch_shows,
                trakt_public_get=trakt_public_get,
                json_get=json_get,
                tmdb_api_key_fn=tmdb_api_key,
                metadata_timeout_fn=metadata_timeout,
                tmdb_enabled_fn=tmdb_enabled,
            )
            action = "folder"
            if trakt_sid:
                url = url_for_show_seasons(trakt_sid)
                li.setProperty("IsPlayable", "false")
                add_show_download_context(li, trakt_sid)
            elif url_for_noop:
                url = url_for_noop()
                li.setProperty("IsPlayable", "false")
                extra = (
                    "\n\n[COLOR gray]"
                    + _t(
                        "No hay enlace Trakt para abrir temporadas; autoriza Trakt en Ajustes o busca con Trakt activo.",
                        "No Trakt link to open seasons; authorize Trakt in Settings or search with Trakt enabled.",
                    )
                    + "[/COLOR]"
                )
                info["plot"] = str(info.get("plot") or "") + extra
                info["plotoutline"] = str(info.get("plotoutline") or "") + extra
                li.setInfo("video", info)
            else:
                url = url_for_play(result["id"])
                li.setProperty("IsPlayable", "true")
        else:
            action = "play"
            url = url_for_play(result["id"])
            li.setProperty("IsPlayable", "true")
            add_movie_download_context(li, result_id)

        try:
            li.setSortTitle((title or "").strip() or "?")
            li.setLabel(display_title)
            li.setLabel2(subline)
        except Exception:
            pass

        prepared.append(
            {
                "list_item": li,
                "action": action,
                "url": url,
                "poster": poster,
                "fanart": fanart,
                "plot": str(result.get("plot", "")),
            }
        )
    apply_directory_style(media_filter)
    directory = []
    banner = _search_results_banner_row(
        media_filter, default_list_art, url_for_noop
    )
    if banner and prepared:
        directory.append(banner)
    for item in prepared:
        is_folder = item.get("action") == "folder"
        directory.append((item.get("url"), item.get("list_item"), is_folder))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)
