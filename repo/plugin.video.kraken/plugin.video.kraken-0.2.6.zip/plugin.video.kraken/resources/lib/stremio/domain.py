import json
from urllib.parse import urljoin, urlsplit, urlunsplit
from urllib.request import Request, urlopen

KNOWN_ADDONS = (
    ("Comet", "stremio_comet"),
    ("MediaFusion", "stremio_mediafusion"),
    ("Jackettio", "stremio_jackettio"),
    ("KnightCrawler", "stremio_knightcrawler"),
    ("Annatar", "stremio_annatar"),
    ("Preeflix", "stremio_preeflix"),
    ("Torrentio", "stremio_torrentio"),
)


def normalize_transport_url(raw):
    u = (raw or "").strip()
    if not u:
        return ""
    low = u.lower()
    if low.startswith("stremio://"):
        u = "https://" + u[len("stremio://") :]
    elif low.startswith("strem://"):
        u = "https://" + u[len("strem://") :].lstrip("/")
    parts = urlsplit(u)
    scheme = (parts.scheme or "https").lower()
    if scheme not in ("http", "https"):
        scheme = "https"
    netloc = (parts.netloc or "").lower()
    path = (parts.path or "").rstrip("/")
    if path.endswith("/manifest.json"):
        path = path[: -len("/manifest.json")]
    return urlunsplit((scheme, netloc, path, parts.query or "", ""))


def normalize_manifest_url(raw):
    base = normalize_transport_url(raw)
    if not base:
        return ""
    low = base.lower()
    if "/catalog/" in low:
        return base
    if base.endswith("/manifest.json"):
        return base
    return base.rstrip("/") + "/manifest.json"


def addon_instance_key(addon_id, transport_url):
    aid = str(addon_id or "").strip()
    turl = normalize_transport_url(transport_url)
    if aid and turl:
        return f"{aid}|{turl}"
    return aid or turl


def login_stremio(email, password, timeout=15):
    em = str(email or "").strip()
    pw = str(password or "").strip()
    if not em or not pw:
        return False, "Debes completar usuario/email y contraseña.", "", {}
    payload = json.dumps({"email": em, "password": pw}).encode("utf-8")
    req = Request(
        "https://api.strem.io/api/login",
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "Kraken/2.0-Stremio",
        },
        method="POST",
    )
    try:
        with urlopen(req, timeout=int(timeout)) as resp:  # nosec B310
            data = json.loads(resp.read().decode("utf-8", errors="replace") or "{}")
    except Exception as ex:
        return False, f"No se pudo validar Stremio: {ex}", "", {}
    auth_key = ""
    user_obj = {}
    if isinstance(data, dict):
        auth_key = str(
            data.get("authKey")
            or (
                (data.get("result") or {}).get("authKey")
                if isinstance(data.get("result"), dict)
                else ""
            )
            or ""
        ).strip()
        if isinstance(data.get("result"), dict):
            user_obj = data.get("result")
    if auth_key:
        return True, "", auth_key, user_obj
    err = ""
    if isinstance(data, dict):
        err = str(data.get("error") or data.get("message") or "").strip()
    return False, (err or "Credenciales no válidas o respuesta inesperada."), "", {}


def fetch_remote_addons(auth_key, timeout=20):
    auth = str(auth_key or "").strip()
    if not auth:
        return False, "Sin authKey de Stremio.", []
    payload = json.dumps({"authKey": auth, "update": True, "addFromURL": []}).encode(
        "utf-8"
    )
    req = Request(
        "https://api.strem.io/api/addonCollectionGet",
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "Kraken/2.0-Stremio",
        },
        method="POST",
    )
    try:
        with urlopen(req, timeout=int(timeout)) as resp:  # nosec B310
            data = json.loads(resp.read().decode("utf-8", errors="replace") or "{}")
    except Exception as ex:
        return False, f"No se pudo descargar addons: {ex}", []
    result = data.get("result") if isinstance(data, dict) else {}
    addons = result.get("addons") if isinstance(result, dict) else None
    if not isinstance(addons, list):
        return False, "La cuenta no devolvió lista de addons.", []
    return True, "", addons


def classify_addon_descriptor(descriptor):
    transport = str((descriptor or {}).get("transportUrl") or "").strip()
    manifest = (descriptor or {}).get("manifest") or {}
    addon_id = str(manifest.get("id") or "").strip()
    addon_name = str(manifest.get("name") or addon_id or "Stremio Custom").strip()
    normalized_manifest = normalize_manifest_url(transport)
    host = ""
    try:
        host = (urlsplit(normalized_manifest).hostname or "").lower()
    except Exception:
        host = ""
    mapping = (
        ("stremio_torrentio", ("torrentio",)),
        ("stremio_preeflix", ("peerflix", "preeflix")),
        ("stremio_comet", ("comet",)),
        ("stremio_mediafusion", ("mediafusion",)),
        ("stremio_aiostreams", ("aiostreams",)),
        ("stremio_jackettio", ("jackettio", "stremio-jackett")),
        ("stremio_knightcrawler", ("knightcrawler",)),
        ("stremio_annatar", ("annatar",)),
    )
    known_prefix = ""
    for prefix, tokens in mapping:
        if any(token in host for token in tokens):
            known_prefix = prefix
            break
    if not known_prefix:
        full = normalized_manifest.lower()
        if "torrentio" in full:
            known_prefix = "stremio_torrentio"
        elif "peerflix" in full or "preeflix" in full:
            known_prefix = "stremio_preeflix"
        elif "jackettio" in full or "stremio-jackett" in full:
            known_prefix = "stremio_jackettio"
        elif "knightcrawler" in full:
            known_prefix = "stremio_knightcrawler"
        elif "annatar" in full:
            known_prefix = "stremio_annatar"
    return {
        "id": addon_id,
        "name": addon_name,
        "manifest_url": normalized_manifest,
        "transport_url": normalize_transport_url(transport),
        "known_prefix": known_prefix,
        "icon": str(manifest.get("icon") or "").strip(),
        "instance_key": addon_instance_key(addon_id, transport),
    }


def merge_remote_with_locals(remote_descriptors):
    known = {}
    custom = []
    seen_custom = set()
    for descriptor in remote_descriptors or []:
        info = classify_addon_descriptor(descriptor)
        if not info.get("manifest_url"):
            continue
        if info.get("known_prefix"):
            known[info["known_prefix"]] = info
            continue
        low_u = info["manifest_url"].lower()
        if low_u in seen_custom:
            continue
        seen_custom.add(low_u)
        custom.append(info)
    return known, custom


def parse_named_custom(raw_named):
    out = []
    raw = str(raw_named or "").strip()
    if not raw:
        return out
    for chunk in raw.split(";"):
        piece = chunk.strip()
        if not piece:
            continue
        if "|" in piece:
            name, url = piece.split("|", 1)
            name = str(name or "").strip() or "Stremio"
            url = normalize_manifest_url(url)
        else:
            name = "Stremio"
            url = normalize_manifest_url(piece)
        if not url:
            continue
        out.append({"name": name, "manifest_url": url})
    return out


def serialize_named_custom(rows):
    chunks = []
    seen = set()
    for row in rows or []:
        name = str((row or {}).get("name") or "Stremio").strip() or "Stremio"
        url = normalize_manifest_url(
            (row or {}).get("manifest_url") or (row or {}).get("url")
        )
        if not url:
            continue
        low = url.lower()
        if low in seen:
            continue
        seen.add(low)
        chunks.append(f"{name}|{url}")
    return ";".join(chunks)


def resolve_manifest_icon(manifest_url, declared_icon):
    icon = str(declared_icon or "").strip()
    if not icon:
        return ""
    if icon.startswith(("http://", "https://")):
        return icon
    base = str(manifest_url or "").rsplit("/", 1)[0].rstrip("/") + "/"
    return urljoin(base, icon)


def apply_remote_addons_to_settings(
    *, remote_addons, get_setting, set_setting, known_addons=KNOWN_ADDONS
):
    known, custom = merge_remote_with_locals(remote_addons or [])
    applied_known = 0
    set_setting("provider_stremio_catalog", True)
    set_setting("stremio_use_per_addon_toggle", True)
    for _name, prefix in known_addons:
        if prefix not in known:
            continue
        set_setting(f"{prefix}_enabled", True)
        set_setting(f"{prefix}_url", known[prefix]["manifest_url"])
        applied_known += 1
    existing = parse_named_custom(get_setting("stremio_catalog_named"))
    rows = [{"name": x["name"], "manifest_url": x["manifest_url"]} for x in existing]
    seen = {str(x.get("manifest_url") or "").lower() for x in rows}
    before = len(rows)
    for item in custom:
        low = str(item.get("manifest_url") or "").lower()
        if not low or low in seen:
            continue
        seen.add(low)
        rows.append(
            {
                "name": item.get("name") or "Stremio Custom",
                "manifest_url": item["manifest_url"],
            }
        )
    set_setting("stremio_catalog_named", serialize_named_custom(rows))
    applied_custom = max(0, len(rows) - before)
    return applied_known, applied_custom
