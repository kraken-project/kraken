import hashlib
import os
from urllib.request import Request, urlopen

import xbmcvfs


def default_logo():
    return "DefaultAddon.png"


def _cache_dir():
    root = xbmcvfs.translatePath("special://temp/kraken_stremio_icons")
    try:
        if not os.path.isdir(root):
            os.makedirs(root)
    except Exception:
        return ""
    return root


def _ext_for_url(url):
    low = str(url or "").lower()
    if ".jpg" in low or ".jpeg" in low:
        return ".jpg"
    if ".webp" in low:
        return ".webp"
    return ".png"


def cache_remote_logo(url, timeout=15):
    src = str(url or "").strip()
    if not src or src.lower().endswith(".svg"):
        return default_logo()
    root = _cache_dir()
    if not root:
        return default_logo()
    key = hashlib.md5(src.lower().encode("utf-8")).hexdigest()  # nosec B324
    local = os.path.join(root, key + _ext_for_url(src))
    if os.path.isfile(local):
        return local.replace("\\", "/")
    try:
        req = Request(src, headers={"User-Agent": "Kraken-Stremio-Logo/2.0"})
        with urlopen(req, timeout=max(5, int(timeout or 15))) as resp:  # nosec B310
            blob = resp.read()
        if not blob:
            return default_logo()
        with open(local, "wb") as fh:
            fh.write(blob)
        return local.replace("\\", "/")
    except Exception:
        return default_logo()


def clear_cached_logos():
    root = _cache_dir()
    if not root or not os.path.isdir(root):
        return 0
    removed = 0
    try:
        for name in os.listdir(root):
            path = os.path.join(root, name)
            if not os.path.isfile(path):
                continue
            try:
                os.remove(path)
                removed += 1
            except Exception:
                continue
    except Exception:
        return removed
    return removed
