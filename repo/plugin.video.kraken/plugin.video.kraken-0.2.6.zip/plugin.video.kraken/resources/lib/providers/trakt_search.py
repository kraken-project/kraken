import json
import math
import re
from urllib.error import URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

from .base import BaseProvider

TRAKT_CLIENT_ID = "1038ef327e86e7f6d39d80d2eb5479bff66dd8394e813c5e0e387af0f84d89fb"


class TraktSearchProvider(BaseProvider):
    name = "Trakt"
    description = "Búsqueda pública en Trakt."

    def __init__(self, addon):
        self._addon = addon
        self._client_id = TRAKT_CLIENT_ID

    def _request(self, url):
        headers = {
            "Content-Type": "application/json",
            "trakt-api-key": self._client_id,
            "trakt-api-version": "2",
            "User-Agent": "Kraken Kodi Addon/0.1",
        }
        req = Request(url, headers=headers)
        try:
            with urlopen(req, timeout=10) as response:
                return json.loads(response.read().decode("utf-8"))
        except (URLError, TimeoutError, OSError, ValueError) as ex:
            # Evita romper el flujo de búsqueda cuando Trakt tarda o falla red/TLS.
            raise URLError(ex) from ex

    def _get_setting_text(self, setting_id):
        try:
            return self._addon.getSettingString(setting_id) or ""
        except Exception:
            return self._addon.getSetting(setting_id) or ""

    def _trakt_effective_translations_code(self):
        """Codigo ISO 639-1 (es, en,.) para /translations/ de Trakt. Auto = idioma de la interfaz de Kodi."""
        v = (self._get_setting_text("trakt_plot_language") or "").strip()
        vl = v.lower()
        alias = {
            "english": "en",
            "ingles": "en",
            "inglés": "en",
            "spanish": "es",
            "espanol": "es",
            "español": "es",
            "castellano": "es",
            "en_gb": "en",
            "en-us": "en",
            "es_es": "es",
            "es-es": "es",
        }
        if vl in alias:
            return alias[vl]
        for code in ("es", "en", "fr", "it", "pt", "de"):
            if vl == code or vl == code + " ":
                return code
        if (vl and "auto" in vl) or (not v) or v == "Auto (Kodi)":
            return self._kodi_locale_to_trakt_lang()
        if len(v) == 2 and v.isalpha():
            return v.lower()
        return "es"

    @staticmethod
    def _kodi_locale_to_trakt_lang():
        """Alinea titulo/sinopsis con caratula TMDB (es-ES): codigo 2 letras, fallback es."""
        out = "es"
        try:
            import xbmc
        except Exception:
            return out
        try:
            r = xbmc.executeJSONRPC(
                '{"jsonrpc":"2.0","id":0,"method":"Settings.GetSettingValue",'
                '"params":{"setting":"locale.language"}}'
            )
            p = json.loads(r) if r else {}
            val = str(p.get("result", {}).get("value") or "").lower().strip()
        except (
            ValueError,
            TypeError,
            AttributeError,
            OSError,
            KeyError,
            json.JSONDecodeError,
        ):
            val = ""
        if not val:
            return out
        if "language." in val and "resource" in val:
            part = val.split("language.", 1)[-1]
            c0 = (part.split("_", 1)[0] or "").lower()
            if re.match(r"^[a-z]{2}$", c0) and c0 not in ("on", "id"):
                return c0
        m2 = re.search(
            r"resource\.[a-z_]*[.]?language[._-]([a-z]{2})(?=[._-]|[.]|$)",
            val,
            re.IGNORECASE,
        )
        if m2:
            return m2.group(1).lower()
        m3 = re.match(r"^([a-z]{2})[_-].*", val, re.IGNORECASE)
        if m3 and m3.group(1) not in ("on", "id", "re"):
            return m3.group(1).lower()
        return out

    def _translation_title_and_overview(self, item_type, trakt_id, language):
        """
        Título y sinopsis en el idioma pedido (misma ficha de Trakt que 'extended',
        p. ej. título comercial en castellano si la API lo tiene).
        """
        it = str(item_type or "movie").strip().lower()
        if not trakt_id or not language or it not in ("movie", "show"):
            return "", ""
        endpoint = "movies" if it == "movie" else "shows"
        url = f"https://api.trakt.tv/{endpoint}/{trakt_id}/translations/{language}"
        try:
            payload = self._request(url)
        except (URLError, ValueError):
            return "", ""
        if not isinstance(payload, list) or not payload:
            return "", ""
        first = payload[0] or {}
        tit = str(first.get("title") or "").strip()
        ov = str(first.get("overview") or "").strip()
        return tit, ov

    @staticmethod
    def _normalize_year(media):
        """Año: entero/float/string JSON; o primeros 4 digitos de fechas Trakt."""
        y = media.get("year")
        if y is not None and y != "":
            try:
                f = float(str(y).strip().replace(",", "."))
            except (TypeError, ValueError):
                f = None
            if f is not None and 1800.0 < f < 3000.0:
                return int(f)
        for key in ("first_aired", "released", "airs"):
            raw = media.get(key)
            if not raw:
                continue
            s = str(raw)[:4]
            if s.isdigit() and 1800 < int(s) < 3000:
                return int(s)
        return None

    @staticmethod
    def _normalize_search_query_parts(raw):
        """
        Deja sólo texto para consulta y, opcionalmente, año al final («Silo 2023»).
        Devuelve (titulo_sin_año_opcional, year_int_o_None).
        """
        q = str(raw or "").strip()
        if not q:
            return "", None
        tail = re.search(r"\s+(18\d{2}|19\d{2}|20\d{2})\s*$", q, flags=re.I)
        if tail:
            yint = int(tail.group(1))
            shorter = q[: tail.start()].strip()
            if len(shorter) >= 2:
                if 1850 <= yint <= 2100:
                    return shorter, yint
                return shorter, None
        return q.strip(), None

    @staticmethod
    def _normalize_search_query(raw):
        t, _y = TraktSearchProvider._normalize_search_query_parts(raw)
        return t

    @staticmethod
    def _trakt_url(path):
        return "https://api.trakt.tv/{}".format(path.lstrip("/"))

    @staticmethod
    def _https_media_url(maybe):
        u = (maybe or "").strip()
        if not u:
            return ""
        if u.startswith("http://") or u.startswith("https://"):
            return u
        return "https://{}".format(u.lstrip("/"))

    @staticmethod
    def _iter_person_media_credits(credits_obj, key):
        """credits: cast[] y crew{} con listas; cada entrada puede tener 'movie' o 'show'."""
        if not credits_obj or not isinstance(credits_obj, dict):
            return
        key = (key or "movie").lower()
        field = "movie" if key == "movie" else "show"
        for entry in credits_obj.get("cast") or []:
            if isinstance(entry, dict) and entry.get(field):
                yield entry.get(field)
        crew = credits_obj.get("crew")
        if isinstance(crew, dict):
            for group in crew.values():
                if not isinstance(group, list):
                    continue
                for entry in group:
                    if isinstance(entry, dict) and entry.get(field):
                        yield entry.get(field)
        elif isinstance(crew, list):
            for entry in crew:
                if isinstance(entry, dict) and entry.get(field):
                    yield entry.get(field)

    def _result_from_media(self, item_type, media, language):
        item_type = str(item_type or "movie").strip().lower()
        if item_type not in ("movie", "show"):
            item_type = "movie"
        if not media or not isinstance(media, dict):
            return None
        trakt_id = (media.get("ids") or {}).get("trakt")
        base_title = str(media.get("title") or "").strip()
        if not trakt_id or not base_title:
            return None
        year = self._normalize_year(media)
        rating = media.get("rating")
        votes = media.get("votes")
        ratings_sub = media.get("ratings")
        if isinstance(ratings_sub, dict):
            if rating is None and ratings_sub.get("rating") is not None:
                rating = ratings_sub.get("rating")
            if votes is None and ratings_sub.get("votes") is not None:
                votes = ratings_sub.get("votes")
        try:
            rating = float(rating) if rating is not None else None
        except (TypeError, ValueError):
            rating = None
        try:
            votes = int(votes) if votes is not None else None
        except (TypeError, ValueError):
            votes = None
        overview = str(media.get("overview") or "").strip()
        t_trans, o_trans = ("", "")
        if language:
            t_trans, o_trans = self._translation_title_and_overview(
                item_type, trakt_id, language
            )
        display_title = (t_trans or base_title).strip() or base_title
        if o_trans:
            overview = o_trans
        if not overview:
            overview = (
                "No overview available."
                if str(language or "").strip().lower() == "en"
                else "Sin sinopsis disponible."
            )
        return {
            "id": f"trakt::{item_type}::{trakt_id}",
            "title": display_title,
            "trakt_default_title": base_title,
            "year": year,
            "rating": rating,
            "votes": votes,
            "plot": overview,
            "imdb_id": str((media.get("ids", {}) or {}).get("imdb") or "").strip(),
            "tmdb_id": (media.get("ids", {}) or {}).get("tmdb"),
            "tvdb_id": (media.get("ids", {}) or {}).get("tvdb"),
            "provider": self.name,
        }

    def search(self, query, media_kind=None, api_limit=20):
        """media_kind None = peliculas+series; 'movie' / 'show' = endpoint. api_limit = total objetivo (paginas)."""
        canon, _year_tail = self._normalize_search_query_parts(str(query or "").strip())
        if not self._client_id or not canon:
            return []
        mk = str(media_kind or "").strip().lower()
        aggregate = max(5, min(100, int(api_limit or 20)))
        # Trakt: limit alto por página; pedimos páginas hasta llegar al acumulado deseado.
        page_lim = min(50, aggregate)
        max_pages = min(
            20,
            max(3, math.ceil(float(aggregate) / float(page_lim)) + 2),
        )
        seen_trakt_ids = set()
        collected = []
        language = self._trakt_effective_translations_code()
        base_q = quote(canon)
        page = 1
        while len(collected) < aggregate and page <= max_pages:
            if mk == "movie":
                url = (
                    f"https://api.trakt.tv/search/movie?query={base_q}"
                    f"&limit={page_lim}&page={page}&extended=full"
                )
            elif mk == "show":
                url = (
                    f"https://api.trakt.tv/search/show?query={base_q}"
                    f"&limit={page_lim}&page={page}&extended=full"
                )
            else:
                url = (
                    "https://api.trakt.tv/search/movie,show?"
                    f"query={base_q}&limit={page_lim}&page={page}&extended=full"
                )
            try:
                payload = self._request(url)
            except (URLError, ValueError):
                break
            if not payload:
                break
            batch = 0
            for item in payload:
                item_type = str(item.get("type") or "").strip().lower()
                media = item.get("movie") or item.get("show") or {}
                ids = media.get("ids") or {} if isinstance(media, dict) else {}
                tid = ids.get("trakt")
                if tid is None:
                    continue
                sid = str(tid).strip()
                if not sid:
                    continue
                if sid in seen_trakt_ids:
                    continue
                r = self._result_from_media(item_type or "movie", media, language)
                if not r:
                    continue
                seen_trakt_ids.add(sid)
                collected.append(r)
                batch += 1
                if len(collected) >= aggregate:
                    break
            if batch == 0:
                break
            page += 1
        return collected[:aggregate]

    def search_people(self, query, limit=20):
        if not self._client_id or not query.strip():
            return []
        n = max(1, min(30, int(limit) if limit else 20))
        url = (
            f"https://api.trakt.tv/search/person?query={quote(query.strip())}&limit={n}"
        )
        try:
            payload = self._request(url)
        except (URLError, ValueError):
            return []
        out = []
        language = self._trakt_effective_translations_code()
        for row in payload or []:
            p = (row or {}).get("person") or {}
            pid = (p.get("ids") or {}).get("trakt")
            name = (p.get("name") or "").strip()
            if not pid or not name:
                continue
            headshot = ""
            imgs = p.get("images") or {}
            hs = imgs.get("headshot")
            if isinstance(hs, list) and hs:
                headshot = self._https_media_url(hs[0])
            elif isinstance(hs, str):
                headshot = self._https_media_url(hs)
            fanart = ""
            fa = imgs.get("fanart")
            if isinstance(fa, list) and fa:
                fanart = self._https_media_url(fa[0])
            elif isinstance(fa, str):
                fanart = self._https_media_url(fa)
            bio = str(p.get("biography") or "").strip() or (
                "No biography available on Trakt."
                if language == "en"
                else "Sin biografia en Trakt."
            )
            out.append(
                {
                    "person_id": int(pid),
                    "name": name,
                    "plot": bio,
                    "headshot": headshot,
                    "fanart": fanart,
                }
            )
        return out

    def _person_credits(self, trakt_person_id, kind="movie"):
        if not self._client_id or not trakt_person_id:
            return {}
        k = (kind or "movie").lower()
        path = "people/{}/{}?extended=full".format(
            int(trakt_person_id), "movies" if k == "movie" else "shows"
        )
        try:
            return self._request(self._trakt_url(path))
        except (URLError, ValueError, TypeError):
            return {}

    def person_movies(self, trakt_person_id):
        return self._person_media_from_credits(
            self._person_credits(trakt_person_id, "movie"), "movie"
        )

    def person_shows(self, trakt_person_id):
        return self._person_media_from_credits(
            self._person_credits(trakt_person_id, "show"), "show"
        )

    def _person_media_from_credits(self, cred, kind="movie"):
        by_id = {}
        kind = (kind or "movie").lower()
        item_t = "movie" if kind == "movie" else "show"
        language = self._trakt_effective_translations_code()
        for media in self._iter_person_media_credits(cred, kind):
            r = self._result_from_media(item_t, media, language)
            if not r:
                continue
            key = str(r.get("id") or "")
            if key and key not in by_id:
                by_id[key] = r
        return list(by_id.values())

    def resolve(self, result_id):
        # Trakt no es host de video; solo catalogo/seguimiento.
        return None
