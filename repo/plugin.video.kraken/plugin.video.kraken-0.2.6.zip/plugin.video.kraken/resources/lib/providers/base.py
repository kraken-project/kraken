class BaseProvider:
    name = "Base"
    description = "Proveedor base"

    def search(self, query):
        raise NotImplementedError

    def resolve(self, result_id):
        raise NotImplementedError
