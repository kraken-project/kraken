"""Registro de proveedores de catálogo / búsqueda expuestos a Kraken."""

from .stremio_catalog import StremioCatalogProvider
from .trakt_search import TraktSearchProvider


def _get_bool_setting(addon, setting_id):
    try:
        return addon.getSettingBool(setting_id)
    except Exception:
        return (addon.getSetting(setting_id) or "").lower() == "true"


def get_enabled_providers(addon):
    """Stremio: solo si el interruptor global está activo. Trakt búsqueda: siempre si la cuenta Trakt está activada."""
    providers = []

    if _get_bool_setting(addon, "provider_stremio_catalog"):
        providers.append(StremioCatalogProvider(addon))

    if _get_bool_setting(addon, "trakt_enabled"):
        providers.append(TraktSearchProvider(addon))

    return providers
