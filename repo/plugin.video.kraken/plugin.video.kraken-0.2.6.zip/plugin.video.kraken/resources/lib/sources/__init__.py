"""Capa de fuentes (orden, idioma, selector). Config Stremio: `stremio_sources_config`."""
