from urllib.parse import quote


def trakt_next_episode_pair(show_id, season_num, ep_num, trakt_public_get):
    """Devuelve (next_season, next_ep) o (None, None) si no hay siguiente."""
    if (
        not show_id
        or ep_num is None
        or int(ep_num) < 1
        or season_num is None
        or int(season_num) < 0
    ):
        return None, None
    sid = str(show_id).strip()
    s_num = int(season_num)
    e_num = int(ep_num)
    try:
        ep_list = trakt_public_get(
            f"https://api.trakt.tv/shows/{quote(sid)}/seasons/{s_num}/episodes?extended=full"
        )
    except Exception:
        return None, None
    numbers = []
    for e in ep_list or []:
        n = e.get("number")
        if n is None or int(n) < 1:
            continue
        numbers.append(int(n))
    numbers = sorted(set(numbers))
    try:
        idx = numbers.index(e_num)
    except ValueError:
        return None, None
    if idx + 1 < len(numbers):
        return s_num, numbers[idx + 1]
    try:
        s_list = trakt_public_get(f"https://api.trakt.tv/shows/{quote(sid)}/seasons")
    except Exception:
        return None, None
    s_numbers = []
    for s in s_list or []:
        sn = s.get("number")
        if sn is not None and int(sn) >= 0:
            s_numbers.append(int(sn))
    s_numbers = sorted(set(s_numbers))
    try:
        si = s_numbers.index(s_num)
    except ValueError:
        return None, None
    if si + 1 >= len(s_numbers):
        return None, None
    next_s = s_numbers[si + 1]
    if int(next_s) < 0:
        return None, None
    try:
        ep_list2 = trakt_public_get(
            f"https://api.trakt.tv/shows/{quote(sid)}/seasons/{int(next_s)}/episodes?extended=full"
        )
    except Exception:
        return None, None
    for e in ep_list2 or []:
        n = e.get("number")
        if n is not None and int(n) >= 1:
            return int(next_s), int(n)
    return None, None
