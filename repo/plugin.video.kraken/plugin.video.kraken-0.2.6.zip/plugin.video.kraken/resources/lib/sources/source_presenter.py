from urllib.parse import urlparse


def source_label(stream_url, source_name):
    low = str(stream_url or "").lower()
    if low.startswith("magnet:"):
        kind = "MAGNET"
    elif low.endswith(".torrent") or ".torrent?" in low:
        kind = "TORRENT"
    else:
        kind = "HTTP"
    host = ""
    try:
        host = urlparse(stream_url).netloc
    except Exception:
        host = ""
    host = host or "origen"
    return f"[{source_name}] {kind} - {host}"


def pretty_source_line(item, *, compact_origin_fn, source_selector_style_fn):
    label = str(item.get("label") or "Fuente").strip()
    title = str(item.get("title") or "").strip()
    quality = str(item.get("quality") or "Auto").strip()
    language = str(item.get("language") or "N/D").strip()
    origin = str(item.get("origin") or "").strip()
    low = str(item.get("url") or "").lower()
    raw_text = " ".join(
        str(item.get(k) or "")
        for k in ("label", "title", "origin", "url", "_raw_text", "raw_text")
    ).lower()
    link_type = (
        "MAGNET"
        if low.startswith("magnet:")
        else ("TORRENT" if ".torrent" in low else "HTTP")
    )

    origin_clean = compact_origin_fn(origin)
    top = f"[COLOR FF00BFFF][{origin_clean}][/COLOR] [COLOR FFFFFFFF]{label}[/COLOR]"
    if title and title.lower() not in top.lower():
        short_title = title if len(title) <= 34 else f"{title[:31]}..."
        top = f"{top} - {short_title}"
    quality_badges = {
        "4k": "[COLOR FFFFCC00][B]4K[/B][/COLOR]",
        "1080p": "[COLOR FF00D1FF][B]1080p[/B][/COLOR]",
        "720p": "[COLOR FF66FF66][B]720p[/B][/COLOR]",
        "sd": "[COLOR FFC8C8C8][B]SD[/B][/COLOR]",
    }
    q_key = quality.strip().lower()
    q_tag = quality_badges.get(q_key, f"[COLOR FFAAAAAA]{quality}[/COLOR]")
    extra_tags = []
    if any(x in raw_text for x in ("dolby vision", "dovi", " dv ", ".dv.", "[dv]")):
        extra_tags.append("[COLOR FFB46CFF][B]DV[/B][/COLOR]")
    elif "hdr" in raw_text or "hlg" in raw_text:
        extra_tags.append("[COLOR FFFF9900][B]HDR[/B][/COLOR]")
    if any(x in raw_text for x in ("h.265", "h265", "x265", "hevc")):
        extra_tags.append("[COLOR FF8BD6FF][B]H.265[/B][/COLOR]")
    elif any(x in raw_text for x in ("h.264", "h264", "x264", "avc")):
        extra_tags.append("[COLOR FF8BD6FF][B]H.264[/B][/COLOR]")
    elif "av1" in raw_text:
        extra_tags.append("[COLOR FF8BD6FF][B]AV1[/B][/COLOR]")
    lang_tag = f"[COLOR FFFFF36B]{language}[/COLOR]"
    type_tag = f"[COLOR FFFF7A7A]{link_type}[/COLOR]"
    badge_tail = " ".join([q_tag] + extra_tags + [lang_tag, type_tag])
    if source_selector_style_fn() == "detailed":
        title_line = title if len(title) <= 46 else f"{title[:43]}..."
        if title_line:
            return f"{top}\n[COLOR lightgray]{title_line}[/COLOR] | {badge_tail}"
        return f"{top}\n{badge_tail}"
    return f"{top}  |  {badge_tail}"
