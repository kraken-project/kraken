"""Rotación de servidor/fuente entre reproducciones del mismo título (evita repetir el mismo addon si hay alternativas)."""
from __future__ import annotations

import json
from urllib.parse import urlparse

_ROTATION_ENABLED_ID = "kraken_rotate_sources_enabled"
_ROTATION_STORE_ID = "kraken_source_rotation_fp"
_MAX_KEYS = 400


def source_fingerprint(item: dict) -> str:
    """Identifica «servidor» por addon Stremio/origen o host HTTPS."""
    origin = str((item or {}).get("origin") or "").strip().lower()
    if origin:
        return origin[:240]
    url = str((item or {}).get("url") or "").strip()
    if url.startswith(("plugin://", "magnet:")):
        return url[:240].lower()
    try:
        netloc = urlparse(url).netloc.lower()
        if netloc:
            return netloc[:240]
    except Exception:
        pass
    return url[:120].lower() if url else ""


def _load_map(get_setting_fn):
    raw = ""
    try:
        raw = str(get_setting_fn(_ROTATION_STORE_ID) or "").strip()
    except Exception:
        raw = ""
    if not raw:
        return {}
    try:
        d = json.loads(raw)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save_map(set_setting_fn, data: dict):
    try:
        if len(data) > _MAX_KEYS:
            keys = list(data.keys())
            data = {k: data[k] for k in keys[-_MAX_KEYS:]}
        set_setting_fn(_ROTATION_STORE_ID, json.dumps(data, separators=(",", ":")))
    except Exception:
        pass


def last_fingerprint_for(get_setting_fn, content_key: str) -> str:
    if not content_key:
        return ""
    m = _load_map(get_setting_fn)
    return str(m.get(content_key) or "").strip()


def remember_pick(set_setting_fn, get_setting_fn, content_key: str, picked: dict):
    if not content_key or not picked:
        return
    fp = source_fingerprint(picked)
    if not fp:
        return
    m = _load_map(get_setting_fn)
    m[str(content_key)] = fp
    _save_map(set_setting_fn, m)


def rotate_candidates_order(clean_list: list, last_fp: str) -> list:
    """Coloca primero las fuentes cuyo fingerprint difiere del último usado."""
    if not clean_list or not last_fp:
        return list(clean_list)
    prefer: list = []
    rest: list = []
    for it in clean_list:
        fp = source_fingerprint(it)
        if fp and fp != last_fp:
            prefer.append(it)
        else:
            rest.append(it)
    if not prefer:
        return list(clean_list)
    return prefer + rest


def rotation_enabled(get_bool_setting_fn) -> bool:
    try:
        return bool(get_bool_setting_fn(_ROTATION_ENABLED_ID))
    except Exception:
        return True


def rotation_content_key_from_play_rid(rid: str) -> str:
    rid = str(rid or "").strip()
    if rid.startswith("trakt::"):
        parts = [x.strip() for x in rid.split("::") if x.strip()]
        if len(parts) >= 3:
            kind = parts[1].lower()
            tid = parts[2]
            if kind in ("movie", "movies"):
                return f"m:{tid}"
            if kind in ("show", "series", "tv"):
                return f"s:{tid}"
    if rid.startswith("fallback::movie::"):
        seg = rid.split("::", 3)
        if len(seg) >= 4:
            return f"fb:m:{seg[2]}:{seg[3]}"
    if rid.startswith("fallback::show::"):
        seg = rid.split("::", 3)
        if len(seg) >= 4:
            return f"fb:s:{seg[2]}:{seg[3]}"
    return ""
