def cache_search_results(cache_dict, results):
    for item in results or []:
        rid = str(item.get("id") or "").strip()
        if not rid:
            continue
        cache_dict[rid] = {
            "title": str(item.get("title") or "").strip(),
            "trakt_default_title": str(
                item.get("trakt_default_title") or item.get("title") or ""
            ).strip(),
            "year": item.get("year"),
            "imdb_id": str(item.get("imdb_id") or "").strip(),
            "tmdb_id": item.get("tmdb_id"),
            "media_type": "series" if rid.startswith("trakt::show::") else "movie",
            "rating": item.get("rating"),
            "votes": item.get("votes"),
        }


def is_playable_stream_url(url):
    raw = str(url or "").strip()
    if not raw:
        return False
    low = raw.lower()
    if raw.startswith("magnet:"):
        return True
    if low.endswith(".torrent") or ".torrent?" in low:
        return True
    if not low.startswith(("http://", "https://", "plugin://")):
        return False
    blocked_parts = (
        "/configure",
        "/config",
        "/settings",
        "/setup",
        "/manifest.json",
    )
    if any(part in low for part in blocked_parts):
        return False
    return True
