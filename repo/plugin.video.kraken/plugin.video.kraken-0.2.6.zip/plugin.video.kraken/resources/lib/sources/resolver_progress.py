import time

RESOLVER_PROGRESS_PHASE = "[B][COLOR deepskyblue]Resolviendo fuentes[/COLOR][/B]"


def normalize_quality(value):
    text = str(value or "").strip().lower()
    if "4k" in text or "2160" in text:
        return "4K"
    if "1080" in text:
        return "1080p"
    if "720" in text:
        return "720p"
    if "480" in text or "sd" in text:
        return "SD"
    return "Auto"


def quality_counts_colored(candidates):
    counts = {"4K": 0, "1080p": 0, "720p": 0, "SD": 0, "Auto": 0}
    for item in candidates or []:
        key = normalize_quality((item or {}).get("quality"))
        counts[key] = counts.get(key, 0) + 1
    return (
        "[B][COLOR gold]4K[/COLOR][/B]:{}  "
        "[B][COLOR deepskyblue]1080[/COLOR][/B]:{}  "
        "[B][COLOR lightgreen]720[/COLOR][/B]:{}  "
        "[B][COLOR silver]SD[/COLOR][/B]:{}  "
        "[COLOR gray]AUTO[/COLOR]:{}"
    ).format(
        counts.get("4K", 0),
        counts.get("1080p", 0),
        counts.get("720p", 0),
        counts.get("SD", 0),
        counts.get("Auto", 0),
    )


def resolver_progress_detail(status_line, base_list, partial_list, started_at):
    """Misma estructura siempre: Origen + totales + calidades (con color) + tiempo."""
    combined = list(base_list or [])
    if partial_list is not None:
        combined = combined + list(partial_list)
    n = len(combined)
    counts = quality_counts_colored(combined)
    origin_line = f"[COLOR orange]Origen[/COLOR]: [B]{status_line}[/B]"
    sources_line = f"[COLOR white]Fuentes[/COLOR]: [B]{n}[/B] | {counts}"
    if started_at is not None:
        return f"{origin_line}\n{sources_line} | [COLOR gray]Tiempo: {time.time() - started_at:.1f}s[/COLOR]"
    return f"{origin_line}\n{sources_line}"
