def autoplay_url_by_language_priority(
    clean, primary_bid, secondary_bid, language_bucket_for_item_fn
):
    """
    Elige la primera URL con idioma principal; si no, con secundario.
    El orden de candidatos ya viene priorizado.
    """
    if not clean:
        return ""
    for item in clean:
        _order, bid = language_bucket_for_item_fn(item)
        if primary_bid is not None and bid == primary_bid:
            u = str((item or {}).get("url") or "").strip()
            if u:
                return u
    for item in clean:
        _order, bid = language_bucket_for_item_fn(item)
        if secondary_bid is not None and bid == secondary_bid:
            u = str((item or {}).get("url") or "").strip()
            if u:
                return u
    return ""


def source_selector_style(get_setting):
    value = (get_setting("source_selector_style") or "Compact").strip().lower()
    if (
        "detallado" in value
        or "detailed" in value
        or "detaille" in value
        or "dettagliato" in value
        or "detailliert" in value
    ):
        return "detailed"
    return "compact"
