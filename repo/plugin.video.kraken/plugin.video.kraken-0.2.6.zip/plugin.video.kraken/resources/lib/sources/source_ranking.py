from resources.lib.sources.source_language import (
    language_bucket_from_normalized,
    normalize_language_label,
)


def _setting_bool(get_setting, setting_id, default=False):
    try:
        raw = str(get_setting(setting_id) or "").strip().lower()
    except Exception:
        return default
    if raw in ("true", "yes", "1", "on"):
        return True
    if raw in ("false", "no", "0", "off"):
        return False
    return default


def _setting_float(get_setting, setting_id, default=0.0):
    try:
        raw = str(get_setting(setting_id) or "").strip().replace(",", ".")
        return float(raw) if raw else default
    except Exception:
        return default


def _candidate_text(item):
    if not isinstance(item, dict):
        return ""
    return " ".join(
        str(item.get(k) or "")
        for k in ("label", "title", "origin", "url", "_raw_text", "raw_text")
    ).lower()


def normalize_quality(value):
    text = str(value or "").strip().lower()
    if "4k" in text or "2160" in text:
        return "4K"
    if "1080" in text:
        return "1080p"
    if "720" in text:
        return "720p"
    if "480" in text or "sd" in text:
        return "SD"
    return "Auto"


def quality_rank(value, normalize_quality_fn):
    q = normalize_quality_fn(value)
    if q == "4K":
        return 0
    if q == "1080p":
        return 1
    if q == "720p":
        return 2
    if q == "SD":
        return 3
    return 4


def allows_unknown_quality_streams(get_setting):
    if not get_setting:
        return True
    try:
        return str(get_setting("kraken_quality_filter_allow_auto") or "").strip().lower() != "false"
    except Exception:
        return True


def _allowed_quality_ranks_from_settings(get_setting):
    """Ranks 0..3 permitidos según interruptores; None = todos (equivale a filtro off)."""
    keys = (
        ("kraken_quality_allow_4k", 0),
        ("kraken_quality_allow_1080p", 1),
        ("kraken_quality_allow_720p", 2),
        ("kraken_quality_allow_sd", 3),
    )
    allowed = []
    for sid, rk in keys:
        try:
            raw = str(get_setting(sid) or "true").strip().lower()
            if raw != "false":
                allowed.append(rk)
        except Exception:
            allowed.append(rk)
    return allowed


def filter_candidates_by_quality_prefs(candidates, get_setting):
    """
    Con filtro activo: sólo mantener fuentes cuya resolución detectada esté permitida
    por los interruptores (4K / 1080p / 720p / SD); Auto/desconocido según opción aparte.
    Si ningún tipo está marcado o el filtro vacía todo, se devuelve la lista original.
    """
    if not candidates or not get_setting:
        return candidates
    try:
        if str(get_setting("kraken_quality_filter_enabled") or "").strip().lower() != "true":
            return candidates
    except Exception:
        return candidates

    allow_auto = allows_unknown_quality_streams(get_setting)
    allowed_ranks = _allowed_quality_ranks_from_settings(get_setting)
    if not allowed_ranks:
        return candidates

    filtered = []
    for it in candidates:
        qval = ""
        try:
            qval = (it or {}).get("quality")
        except Exception:
            qval = ""
        qr = quality_rank(qval, normalize_quality)
        if qr >= 4:
            if allow_auto:
                filtered.append(it)
            continue
        if qr in allowed_ranks:
            filtered.append(it)

    return filtered if filtered else list(candidates)


def detect_size_gb(item):
    text = _candidate_text(item)
    if not text:
        return None
    import re

    patterns = (
        r"(\d+(?:[\.,]\d+)?)\s*(?:gib|gb)\b",
        r"(\d+(?:[\.,]\d+)?)\s*(?:mib|mb)\b",
    )
    for idx, pat in enumerate(patterns):
        m = re.search(pat, text, flags=re.I)
        if not m:
            continue
        try:
            value = float(str(m.group(1)).replace(",", "."))
        except Exception:
            continue
        if idx == 1:
            value = value / 1024.0
        return value
    return None


def detect_codec(item):
    text = _candidate_text(item)
    if any(x in text for x in ("h.265", "h265", "x265", "hevc")):
        return "h265"
    if any(x in text for x in ("h.264", "h264", "x264", "avc")):
        return "h264"
    if "av1" in text or "aom" in text:
        return "av1"
    return "other"


def detect_hdr(item):
    text = _candidate_text(item)
    if any(x in text for x in ("dolby vision", "dovi", " dv ", ".dv.", "[dv]", "hdr dv")):
        return "dv"
    if any(x in text for x in ("hdr10+", "hdr10plus", "hdr10")):
        return "hdr10"
    if "hdr" in text or "hlg" in text:
        return "hdr10"
    if any(x in text for x in (" sdr ", ".sdr.", "[sdr]", "webrip", "web-dl")):
        return "sdr"
    return "unknown"


def filter_candidates_by_extra_prefs(candidates, get_setting):
    if not candidates or not get_setting:
        return candidates
    filtered = list(candidates)

    if _setting_bool(get_setting, "kraken_size_filter_enabled", False):
        min_gb = max(0.0, _setting_float(get_setting, "kraken_size_min_gb", 0.0))
        max_gb = max(0.0, _setting_float(get_setting, "kraken_size_max_gb", 0.0))
        if min_gb > 0.0 or max_gb > 0.0:
            sized = []
            allow_unknown = _setting_bool(
                get_setting, "kraken_size_filter_allow_unknown", True
            )
            for it in filtered:
                size_gb = detect_size_gb(it)
                if size_gb is None:
                    if allow_unknown:
                        sized.append(it)
                    continue
                if min_gb > 0.0 and size_gb < min_gb:
                    continue
                if max_gb > 0.0 and size_gb > max_gb:
                    continue
                sized.append(it)
            if sized:
                filtered = sized

    if _setting_bool(get_setting, "kraken_codec_filter_enabled", False):
        allowed = {
            "h264": _setting_bool(get_setting, "kraken_codec_allow_h264", True),
            "h265": _setting_bool(get_setting, "kraken_codec_allow_h265", True),
            "av1": _setting_bool(get_setting, "kraken_codec_allow_av1", True),
            "other": _setting_bool(get_setting, "kraken_codec_allow_other", True),
        }
        coded = [it for it in filtered if allowed.get(detect_codec(it), False)]
        if coded:
            filtered = coded

    if _setting_bool(get_setting, "kraken_hdr_filter_enabled", False):
        allowed = {
            "hdr10": _setting_bool(get_setting, "kraken_hdr_allow_hdr10", True),
            "dv": _setting_bool(get_setting, "kraken_hdr_allow_dolby_vision", True),
            "sdr": _setting_bool(get_setting, "kraken_hdr_allow_sdr", True),
            "unknown": _setting_bool(get_setting, "kraken_hdr_allow_unknown", True),
        }
        hdr_filtered = [it for it in filtered if allowed.get(detect_hdr(it), False)]
        if hdr_filtered:
            filtered = hdr_filtered

    return filtered if filtered else list(candidates)


def filter_candidates_by_source_prefs(candidates, get_setting):
    out = filter_candidates_by_quality_prefs(candidates, get_setting)
    return filter_candidates_by_extra_prefs(out, get_setting)


def compact_origin(value):
    text = str(value or "").strip()
    if not text:
        return "—"
    if text.lower().startswith("stremio "):
        text = text[8:].strip() or "Stremio"
    if len(text) <= 28:
        return text
    return text[:26] + "…"


def _sources_order_is_scrapers_first(value):
    """Label traducido del labelenum (#30176) u opciones antiguas guardadas en castellano."""
    v = (value or "").strip().lower()
    if not v:
        return False
    if "scrapers externos primero" in v:
        return True
    markers = (
        "scrapers first",
        "scrapers primero",
        "scrapers en premier",
        "scraper zuerst",
        "scraper prima",
    )
    return any(m in v for m in markers)


def sources_order_priority(get_setting):
    value = (get_setting("sources_order_priority") or "Stremio first").strip().lower()
    if _sources_order_is_scrapers_first(value):
        return "external_first"
    if "mixto" in value:
        return "mixed_quality"
    return "stremio_first"


def sort_stremio_stream_rows_for_play(rows, get_setting):
    """
    Orden VOD: mismo criterio que el selector de fuentes (Inglés primero si la interfaz
    de Kodi es inglés; Castellano primero si es español, etc.), luego sub/multi/otros.
    """
    _ = get_setting  # firma estable con resolver.py
    if not rows:
        return rows

    def _lang_order(row):
        if not isinstance(row, dict):
            return 99
        lng = normalize_language_label(
            row.get("language"),
            label=row.get("label"),
            title=row.get("title"),
            stream_url=row.get("url"),
        )
        order, _ = language_bucket_from_normalized(lng)
        return order

    def _sort_key(row):
        return (_lang_order(row), quality_rank(row.get("quality"), normalize_quality))

    return sorted([r for r in rows if isinstance(r, dict)], key=_sort_key)
