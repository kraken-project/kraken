"""
Parametros Stremio que afectan al flujo de fuentes (catalogo, HTTP, orden en el selector).
Un solo sitio para constantes y lectura de ajustes; el proveedor y las rutas importan desde aqui.
"""

from __future__ import annotations

import json

from resources.lib.ui.ui_helpers import _t

# Complementos con *_url en settings.xml que alimentan el catalogo por nombre (orden de lista).
# Orden: primero torrents / VOD; Tvvoo al final (TV en directo, no pelis/series).
STREMIO_CATALOG_NAMED_ADDONS = (
    ("Torrentio", "stremio_torrentio"),
    ("Preeflix", "stremio_preeflix"),
    ("Comet", "stremio_comet"),
    ("MediaFusion", "stremio_mediafusion"),
    ("AIOStreams", "stremio_aiostreams"),
    ("Jackettio", "stremio_jackettio"),
    ("KnightCrawler", "stremio_knightcrawler"),
    ("Annatar", "stremio_annatar"),
    ("Tvvoo", "stremio_tvvoo"),
)

# Nombres de fuente (display) orientados a tv en directo; no usar para resolver movie/series VOD.
STREMIO_TV_LIVE_ONLY_NAMES = frozenset({"tvvoo", "tvavvo"})


def is_stremio_tv_live_only_source(display_name) -> bool:
    return str(display_name or "").strip().lower() in STREMIO_TV_LIVE_ONLY_NAMES


def skip_stremio_source_for_vod(meta_type, display_name) -> bool:
    """
    Peliculas, series y episodios (meta series) no deben pasar por addons solo-TV.
    Si en el futuro se resuelve meta tv|channel, no filtrar.
    """
    mt = str(meta_type or "").strip().lower()
    if mt in ("tv", "channel"):
        return False
    return is_stremio_tv_live_only_source(display_name)


# Manifest por defecto (alineado con settings.xml). Si `stremio_addons_state` o el setting
# quedan vacíos, el proveedor debe seguir teniendo URL (evita quedar solo en Torrentio).
STREMIO_DEFAULT_MANIFEST_BY_PREFIX = {
    "stremio_torrentio": "https://torrentio.strem.fun/manifest.json",
    "stremio_preeflix": "https://peerflix.mov/manifest.json",
    "stremio_aiostreams": "https://aiostreams.elfhosted.com/stremio/manifest.json",
    "stremio_comet": "https://comet.elfhosted.com/manifest.json",
    "stremio_mediafusion": "https://mediafusion.elfhosted.com/manifest.json",
    "stremio_tvvoo": "https://tvvoo.hayd.uk/manifest.json",
    "stremio_jackettio": "https://jackettio.elfhosted.com/manifest.json",
    "stremio_knightcrawler": "https://knightcrawler.elfhosted.com/manifest.json",
    "stremio_annatar": "https://annatar.elfhosted.com/manifest.json",
}


def default_manifest_url_for_prefix(prefix: str) -> str:
    return str(STREMIO_DEFAULT_MANIFEST_BY_PREFIX.get(str(prefix or "").strip()) or "").strip()


SETTING_HTTP_TIMEOUT = "stremio_http_timeout"
SETTING_CATALOG_MASTER = "provider_stremio_catalog"
SETTING_ALLDEBRID_AUTO_MANIFEST = "stremio_alldebrid_auto_torrentio"
SETTING_SOURCES_ORDER = "sources_order_priority"
# Fase C: solo incluir complementos nombrados marcados en multicheck / *_enabled.
SETTING_PER_ADDON_TOGGLE = "stremio_use_per_addon_toggle"
# Fase F: subconjunto de entradas catalogs[] del manifest (tipo + id) por prefijo de complemento.
SETTING_USE_MANIFEST_CATALOG_FILTER = "stremio_use_manifest_catalog_filter"
SETTING_MANIFEST_CATALOG_PICK = "stremio_manifest_catalog_pick"


def http_timeout_seconds_from_addon(addon) -> int:
    """Timeout para manifest.json, catalogos y JSON de streams (labelenum en settings)."""
    raw = ""
    try:
        raw = str(addon.getSetting(SETTING_HTTP_TIMEOUT) or "").strip()
    except Exception:
        try:
            raw = str(addon.getSettingString(SETTING_HTTP_TIMEOUT) or "").strip()
        except Exception:
            raw = ""
    if not raw:
        raw = "25"
    try:
        return max(8, min(120, int(raw)))
    except (TypeError, ValueError):
        return 25


def http_timeout_seconds_from_get_setting(get_setting) -> int:
    """Misma logica que `http_timeout_seconds_from_addon` para entornos sin objeto Addon."""

    def _one(sid):
        try:
            return get_setting(sid)
        except Exception:
            return ""

    raw = str(_one(SETTING_HTTP_TIMEOUT) or "").strip()
    if not raw:
        raw = "25"
    try:
        return max(8, min(120, int(raw)))
    except (TypeError, ValueError):
        return 25


def catalog_master_enabled(get_bool_setting) -> bool:
    return bool(get_bool_setting(SETTING_CATALOG_MASTER))


def named_addon_prefix_from_source_label(source_label):
    """Prefijo settings (p. ej. stremio_torrentio) o None si no es complemento nombrado Kraken."""
    sl = (source_label or "").strip()
    for disp, prefix in STREMIO_CATALOG_NAMED_ADDONS:
        if disp == sl:
            return prefix
    return None


def parse_manifest_catalog_filter_map(addon):
    """
    dict prefijo -> set de (tipo, id) desde JSON guardado.
    Clave ausente en el dict => no restringir ese complemento; lista vacia => ningun catalogo.
    """
    from resources.lib.core.settings_helpers import get_setting as gs

    raw = (gs(addon, SETTING_MANIFEST_CATALOG_PICK) or "").strip()
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except (TypeError, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    out = {}
    for key, val in data.items():
        prefix = str(key or "").strip()
        if not prefix:
            continue
        pairs = set()
        if isinstance(val, list):
            for item in val:
                if isinstance(item, (list, tuple)) and len(item) >= 2:
                    mt = str(item[0] or "").strip().lower()
                    cid = str(item[1] or "").strip()
                    if mt and cid:
                        pairs.add((mt, cid))
        out[prefix] = pairs
    return out


def stremio_catalog_triple_allowed(
    addon, source_label, meta_type, catalog_id, fmap=None
):
    """
    Respeta manifest catalog pick cuando el interruptor esta activo.
    fmap: resultado de parse_manifest_catalog_filter_map (una vez por peticion) o None para calcular dentro.
    """
    from resources.lib.core.settings_helpers import get_bool_setting as gb

    if not gb(addon, SETTING_USE_MANIFEST_CATALOG_FILTER):
        return True
    if fmap is None:
        fmap = parse_manifest_catalog_filter_map(addon)
    pref = named_addon_prefix_from_source_label(source_label)
    if pref is None:
        return True
    if pref not in fmap:
        return True
    pairs = fmap[pref]
    if not pairs:
        return False
    mt = (meta_type or "").strip().lower()
    cid = (catalog_id or "").strip()
    return (mt, cid) in pairs


def alldebrid_manifest_augment_enabled(get_bool_setting) -> bool:
    """Inyectar token AllDebrid de Kraken en URLs de complementos compatibles."""
    try:
        return bool(get_bool_setting(SETTING_ALLDEBRID_AUTO_MANIFEST))
    except Exception:
        return True


def _addon_auto_alldebrid_manifest(addon) -> bool:
    """Misma lectura tolerante que antes en `augment_stremio_catalog_url`."""
    try:
        return bool(addon.getSettingBool(SETTING_ALLDEBRID_AUTO_MANIFEST))
    except Exception:
        return (
            addon.getSetting(SETTING_ALLDEBRID_AUTO_MANIFEST) or ""
        ).strip().lower() == "true"


def _addon_bool_setting(addon, key):
    try:
        return bool(addon.getSettingBool(key))
    except Exception:
        return (addon.getSetting(key) or "").strip().lower() in ("true", "1", "yes")


def _addon_token_setting(addon, key):
    try:
        return (addon.getSettingString(key) or "").strip()
    except Exception:
        return (addon.getSetting(key) or "").strip()


def debrid_manifest_augment_pipe(addon):
    """
    (token, pipe_key) para inyectar en URL manifest estilo Torrentio, o ("", "").
    Solo AllDebrid.
    """
    if not _addon_auto_alldebrid_manifest(addon):
        return "", ""
    if not _addon_bool_setting(addon, "debrid_ad_enabled"):
        return "", ""
    tok = _addon_token_setting(addon, "debrid_ad_token")
    return (tok, "alldebrid") if tok else ("", "")


def alldebrid_manifest_augment_applies(addon) -> bool:
    """
    True si debe aplicarse inyeccion Debrid en manifest (opcion on + cuenta Debrid con token).
    """
    tok, _ = debrid_manifest_augment_pipe(addon)
    return bool(tok)


def alldebrid_token_for_manifest_augment(addon) -> str:
    """Compat: solo el token del primer proveedor Debrid activo."""
    tok, _ = debrid_manifest_augment_pipe(addon)
    return tok


def alldebrid_augment_pipeline_ready(get_bool_setting, get_setting) -> bool:
    """Estado efectivo para resumenes (inyeccion posible AllDebrid + token)."""
    if not alldebrid_manifest_augment_enabled(get_bool_setting):
        return False
    try:
        en = bool(get_bool_setting("debrid_ad_enabled"))
    except Exception:
        en = _safe_text(get_setting, "debrid_ad_enabled").lower() in ("true", "1", "yes")
    return bool(en and _safe_text(get_setting, "debrid_ad_token"))


def _safe_text(get_setting, key):
    try:
        return str(get_setting(key) or "").strip()
    except Exception:
        return ""


def format_sources_configuration_summary(get_bool_setting, get_setting) -> str:
    """Texto multilinea para el centro de fuentes / Stremio (solo lectura)."""
    lines = []
    lines.append(
        _t(
            "Catalogo Stremio (global): {s}",
            "Stremio catalog (global): {s}",
            "Catalogue Stremio (global) : {s}",
            "Catalogo Stremio (globale): {s}",
            "Stremio-Katalog (global): {s}",
        ).format(
            s=_t("activo", "active", "actif", "attivo", "aktiv")
            if catalog_master_enabled(get_bool_setting)
            else _t("inactivo", "inactive", "inactif", "inattivo", "inaktiv")
        )
    )
    try:
        filt = bool(get_bool_setting(SETTING_PER_ADDON_TOGGLE))
    except Exception:
        filt = False
    lines.append(
        _t(
            "Filtrar complementos nombrados (multicheck): {s}",
            "Filter named add-ons (multicheck): {s}",
            "Filtrer extensions nommees (multicheck) : {s}",
            "Filtra addon nominati (multicheck): {s}",
            "Benannte Add-ons filtern (Mehrfachwahl): {s}",
        ).format(
            s=_t("si", "yes", "oui", "sì", "ja")
            if filt
            else _t(
                "no (todas las URLs)",
                "no (all URLs)",
                "non (toutes les URLs)",
                "no (tutti gli URL)",
                "nein (alle URLs)",
            )
        )
    )
    try:
        mcat = bool(get_bool_setting(SETTING_USE_MANIFEST_CATALOG_FILTER))
    except Exception:
        mcat = False
    lines.append(
        _t(
            "Filtrar por catalogos manifest (tipo/id): {s}",
            "Filter by manifest catalogs (type/id): {s}",
            "Filtrer par catalogues manifest (type/id) : {s}",
            "Filtra per cataloghi manifest (tipo/id): {s}",
            "Nach Manifest-Katalogen filtern (Typ/ID): {s}",
        ).format(s=_t("si", "yes", "oui", "sì", "ja") if mcat else _t("no", "no", "non", "no", "nein"))
    )
    lines.append(
        _t(
            "Inyectar token Debrid en manifest compatible: {s}",
            "Inject Debrid token in compatible manifest: {s}",
            "Injecter token Debrid dans manifest compatible : {s}",
            "Inietta token Debrid nel manifest compatibile: {s}",
            "Debrid-Token in kompatibles Manifest injizieren: {s}",
        ).format(
            s=_t("si", "yes", "oui", "sì", "ja")
            if alldebrid_manifest_augment_enabled(get_bool_setting)
            else _t("no", "no", "non", "no", "nein")
        )
    )
    lines.append(
        _t(
            "Debrid listo para inyectar (AllDebrid + token): {s}",
            "Debrid ready to inject (AllDebrid + token): {s}",
            "Debrid pret a injecter (AllDebrid + token) : {s}",
            "Debrid pronto per iniezione (AllDebrid + token): {s}",
            "Debrid bereit zum Injizieren (AllDebrid + Token): {s}",
        ).format(
            s=_t("si", "yes", "oui", "sì", "ja")
            if alldebrid_augment_pipeline_ready(get_bool_setting, get_setting)
            else _t("no", "no", "non", "no", "nein")
        )
    )
    lines.append(
        _t(
            "Timeout HTTP catalogo/stream: {n} s",
            "HTTP timeout catalog/stream: {n} s",
            "Delai HTTP catalogue/stream : {n} s",
            "Timeout HTTP catalogo/stream: {n} s",
            "HTTP-Timeout Katalog/Stream: {n} s",
        ).format(n=http_timeout_seconds_from_get_setting(get_setting))
    )
    order = _safe_text(get_setting, SETTING_SOURCES_ORDER)
    if order:
        lines.append(
            _t(
                "Orden de fuentes en selector: {o}",
                "Source order in picker: {o}",
                "Ordre des sources dans le selecteur : {o}",
                "Ordine fonti nel selettore: {o}",
                "Reihenfolge der Quellen: {o}",
            ).format(o=order)
        )

    lines.append("")
    lines.append(
        _t(
            "Complementos con URL de catalogo:",
            "Add-ons with catalog URL:",
            "Extensions avec URL de catalogue :",
            "Addon con URL catalogo:",
            "Add-ons mit Katalog-URL:",
        )
    )
    state_raw = _safe_text(get_setting, "stremio_addons_state")
    state = {}
    if state_raw:
        try:
            state = json.loads(state_raw)
        except (TypeError, ValueError):
            state = {}
    known_state = state.get("known") if isinstance(state, dict) else {}
    custom_state = state.get("custom") if isinstance(state, dict) else []
    any_url = False
    for name, prefix in STREMIO_CATALOG_NAMED_ADDONS:
        row = known_state.get(prefix) if isinstance(known_state, dict) else None
        if isinstance(row, dict):
            u = str(row.get("url") or "").strip()
            en = bool(row.get("enabled", False))
        else:
            u = _safe_text(get_setting, f"{prefix}_url")
            try:
                en = bool(get_bool_setting(f"{prefix}_enabled"))
            except Exception:
                en = False
        if u:
            any_url = True
            lines.append(
                _t(
                    "  · {n}: OK · catalogo {s}",
                    "  · {n}: OK · catalog {s}",
                    "  · {n} : OK · catalogue {s}",
                    "  · {n}: OK · catalogo {s}",
                    "  · {n}: OK · Katalog {s}",
                ).format(
                    n=name,
                    s=_t("incluido", "included", "inclus", "incluso", "eingeschlossen")
                    if en
                    else _t(
                        "excluido",
                        "excluded",
                        "exclu",
                        "escluso",
                        "ausgeschlossen",
                    ),
                )
            )
        else:
            lines.append(
                _t(
                    "  · {n}: (sin URL)",
                    "  · {n}: (no URL)",
                    "  · {n} : (pas d'URL)",
                    "  · {n}: (nessun URL)",
                    "  · {n}: (keine URL)",
                ).format(n=name)
            )

    custom_n = 0
    if isinstance(custom_state, list):
        for row in custom_state:
            if not isinstance(row, dict):
                continue
            if str(row.get("url") or "").strip():
                custom_n += 1
    if custom_n:
        any_url = True
        lines.append(
            _t(
                "  · Custom: {n} complemento(s)",
                "  · Custom: {n} add-on(s)",
                "  · Perso : {n} extension(s)",
                "  · Custom: {n} addon",
                "  · Custom: {n} Add-on(s)",
            ).format(n=custom_n)
        )

    if not any_url:
        lines.append(
            _t(
                "  (ninguna fuente Stremio configurada; usa Sync o Gestor de addons)",
                "  (no Stremio sources configured; use Sync or Add-on manager)",
                "  (aucune source Stremio ; utilisez Sync ou le gestionnaire d'extensions)",
                "  (nessuna fonte Stremio; usa Sync o gestore addon)",
                "  (keine Stremio-Quellen; Sync oder Add-on-Manager nutzen)",
            )
        )

    return "\n".join(lines)
