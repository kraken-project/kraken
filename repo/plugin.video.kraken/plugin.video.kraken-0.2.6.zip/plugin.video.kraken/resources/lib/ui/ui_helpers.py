import os

import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib.core.language_prefs import preferred_text_lang_code
from resources.lib.core.view_prefs import (
    list_extra_sort_enabled,
    schedule_saved_skin_view_media_filter,
    simple_list_art_enabled,
    skin_content_hint,
)


def _t(es_text, en_text, fr_text=None, it_text=None, de_text=None):
    lang = preferred_text_lang_code()
    if lang == "fr":
        return fr_text or en_text
    if lang == "it":
        return it_text or en_text
    if lang == "de":
        return de_text or en_text
    if lang == "en":
        return en_text
    return es_text


def _t_mapped(auto_map, es_text, en_text, fr_text=None, it_text=None, de_text=None):
    """
    Extiende _t con un mapa (ES,EN)->(FR,IT,DE) para frases repetidas.
    Si se pasan fr_text/it_text/de_text y son truthy, tienen prioridad (misma regla legacy).
    """
    tpl = auto_map.get((es_text, en_text))
    fr_e = fr_text if fr_text else (tpl[0] if tpl else None)
    it_e = it_text if it_text else (tpl[1] if tpl else None)
    de_e = de_text if de_text else (tpl[2] if tpl else None)
    return _t(es_text, en_text, fr_e, it_e, de_e)


def _addon_wallpaper_path(addon):
    try:
        base = addon.getAddonInfo("path") or ""
    except Exception:
        base = ""
    if not base:
        return ""
    p = os.path.join(base, "resources", "art", "wallpaper.png")
    try:
        if xbmcvfs.exists(p):
            return p
    except Exception:
        pass
    return ""


def default_list_art(addon, content_panel_texture, get_setting=None):
    icon = addon.getAddonInfo("icon") or "DefaultVideo.png"
    try:
        raw_fan = addon.getAddonInfo("fanart") or ""
    except Exception:
        raw_fan = ""
    fanart = str(raw_fan).strip()
    if not fanart:
        fanart = _addon_wallpaper_path(addon)
    if not fanart:
        fanart = content_panel_texture
    art = {"icon": icon, "thumb": icon, "poster": icon}
    if fanart:
        art["fanart"] = fanart
    if get_setting is not None and simple_list_art_enabled(get_setting):
        return {"icon": icon, "thumb": icon}
    return art


def apply_directory_style(plugin_handle, media_filter, addon=None, get_setting=None):
    media_filter = (media_filter or "all").strip().lower()
    if media_filter == "movie":
        xbmcplugin.setPluginCategory(
            plugin_handle,
            _t(
                "Kraken - Buscar peliculas",
                "Kraken - Search movies",
                "Kraken - Rechercher des films",
                "Kraken - Cerca film",
                "Kraken - Filme suchen",
            ),
        )
        xbmcplugin.setContent(plugin_handle, "movies")
    elif media_filter == "show":
        xbmcplugin.setPluginCategory(
            plugin_handle,
            _t(
                "Kraken - Buscar series",
                "Kraken - Search TV shows",
                "Kraken - Rechercher des series",
                "Kraken - Cerca serie TV",
                "Kraken - Serien suchen",
            ),
        )
        xbmcplugin.setContent(plugin_handle, "tvshows")
    else:
        xbmcplugin.setPluginCategory(
            plugin_handle,
            _t("Kraken - Buscar", "Kraken - Search", "Kraken - Rechercher", "Kraken - Cerca", "Kraken - Suche"),
        )
        # "videos" fuerza vistas que a veces sustituyen el label por datos del InfoTag sin BBCode.
        xbmcplugin.setContent(plugin_handle, "files")
        if get_setting is not None:
            hint = skin_content_hint(get_setting)
            if hint == "movie":
                xbmcplugin.setContent(plugin_handle, "movies")
            elif hint == "show":
                xbmcplugin.setContent(plugin_handle, "tvshows")
    hint_res = skin_content_hint(get_setting) if get_setting else ""
    rich_hint = media_filter in ("movie", "show") or hint_res in ("movie", "show")
    if addon is not None:
        wp = _addon_wallpaper_path(addon)
        if wp:
            try:
                xbmcplugin.setPluginFanart(plugin_handle, wp)
            except Exception:
                try:
                    xbmcplugin.setPluginFanart(plugin_handle, wp, "fanart")
                except Exception:
                    pass
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    if get_setting is not None and list_extra_sort_enabled(get_setting):
        for const in (
            "SORT_METHOD_VIDEO_RATING",
            "SORT_METHOD_GENRE",
            "SORT_METHOD_DATE",
        ):
            try:
                c = getattr(xbmcplugin, const, None)
                if c is not None:
                    xbmcplugin.addSortMethod(plugin_handle, c)
            except Exception:
                pass
    if get_setting is not None and not rich_hint:
        schedule_saved_skin_view_media_filter(media_filter, get_setting)



def kraken_progress(dialog, percent, phase, detail=""):
    """Soporta DialogProgress y DialogProgressBG."""
    p = max(0, min(100, int(percent)))
    line1 = f"[{p}%] {phase}"
    detail = detail or ""
    if isinstance(dialog, xbmcgui.DialogProgressBG):
        try:
            if dialog.isFinished():
                return
        except Exception:
            pass
        m1 = line1.replace("\n", " ")
        if len(m1) > 200:
            m1 = m1[:197] + "..."
        m2 = detail.replace("\n", " | ")
        if len(m2) > 400:
            m2 = m2[:397] + "..."
        dialog.update(p, m1, m2)
        return
    line = line1
    if detail:
        line = f"{line1}\n{detail}"
    try:
        if dialog.iscanceled():
            return
    except Exception:
        pass
    dialog.update(p, line)
