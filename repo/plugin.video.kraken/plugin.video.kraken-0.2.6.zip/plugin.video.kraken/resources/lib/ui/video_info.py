def apply_video_info(list_item, info):
    """
    Aplica metadatos de video usando InfoTagVideo (Kodi 20+),
    con fallback a setInfo para compatibilidad.
    """
    data = dict(info or {})
    if not data:
        return
    tag = None
    try:
        tag = list_item.getVideoInfoTag()
    except Exception:
        tag = None

    if tag is not None:
        title = str(data.get("title") or "").strip()
        if title:
            try:
                tag.setTitle(title)
            except Exception:
                pass
        tvshow = str(data.get("tvshowtitle") or "").strip()
        if tvshow:
            try:
                tag.setTvShowTitle(tvshow)
            except Exception:
                pass
        plot = data.get("plot")
        if plot is not None:
            try:
                tag.setPlot(str(plot))
            except Exception:
                pass
        for key, setter in (
            ("season", "setSeason"),
            ("episode", "setEpisode"),
            ("duration", "setDuration"),
            ("year", "setYear"),
        ):
            val = data.get(key)
            if val in (None, ""):
                continue
            try:
                getattr(tag, setter)(int(val))
            except Exception:
                pass
        mtype = str(data.get("mediatype") or "").strip().lower()
        if mtype:
            try:
                tag.setMediaType(mtype)
            except Exception:
                pass
        return

    try:
        list_item.setInfo("video", data)
    except Exception:
        pass
