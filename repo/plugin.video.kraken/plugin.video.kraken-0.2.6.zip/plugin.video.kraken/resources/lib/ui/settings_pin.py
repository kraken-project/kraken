"""Código PIN antes de abrir los ajustes de Kodi del addon."""

import xbmcgui

from resources.lib.ui.ui_helpers import _t


def allow_open_settings_kodi(*, get_setting) -> bool:
    from resources.lib.core.view_prefs import settings_pin_enabled, settings_pin_value

    if not settings_pin_enabled(get_setting):
        return True
    expected = settings_pin_value(get_setting)
    if not expected:
        xbmcgui.Dialog().ok(
            _t("PIN", "PIN", "PIN", "PIN", "PIN"),
            _t(
                "Activa PIN en ajustes pero no hay codigo guardado. Pon un PIN primero.",
                "PIN is enabled but no code saved. Set a PIN in settings first.",
                "PIN active mais aucun code defini. Choisissez un code d'abord.",
                "PIN attivo ma non c'e un codice salvato. Imposta un PIN.",
                "PIN aktiviert aber kein Code gespeichert. Bitte zuerst einen PIN setzen.",
            ),
        )
        return False
    dlg = xbmcgui.Dialog()
    num_type = getattr(xbmcgui, "INPUT_NUMERIC", None)
    if num_type is None:
        num_type = getattr(xbmcgui, "INPUT_NUMBER", 0)
    got = dlg.input(
        _t("Introduce el PIN", "Enter PIN", "Saisir le PIN", "Inserisci il PIN", "PIN eingeben"),
        type=num_type if num_type else 0,
    )
    if (got or "").strip() != expected:
        dlg.ok(
            _t("PIN incorrecto", "Incorrect PIN", "PIN incorrect", "PIN errato", "Falscher PIN"),
            "",
        )
        return False
    return True
