"""Programa Container.SetViewMode tras el listado (mejor soporte skins tipo Estuary)."""

import threading

import xbmc


def schedule_container_set_view_mode(view_id_raw):
    try:
        vid = int(view_id_raw)
    except Exception:
        return
    if vid <= 0:
        return

    def _run():
        xbmc.sleep(450)
        xbmc.executebuiltin(f"Container.SetViewMode({vid})")

    threading.Thread(target=_run, daemon=True).start()
