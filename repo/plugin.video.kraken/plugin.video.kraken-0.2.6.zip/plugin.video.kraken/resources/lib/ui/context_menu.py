from urllib.parse import quote

import xbmcaddon


def _addon():
    return xbmcaddon.Addon()


def _setting_bool(setting_id, default=False):
    try:
        return bool(_addon().getSettingBool(setting_id))
    except Exception:
        raw = str(_addon().getSetting(setting_id) or "").strip().lower()
        if raw in ("true", "1", "yes", "on"):
            return True
        if raw in ("false", "0", "no", "off"):
            return False
        return bool(default)


def add_movie_download_context(li, result_id):
    """Añade 'Descargar pelicula' al menú contextual si está activado."""
    if not result_id:
        return
    if not _setting_bool("context_download_movies_enabled", default=False):
        return
    rid = str(result_id).strip()
    if not (rid.startswith("trakt::movie::") or rid.startswith("fallback::movie::")):
        return
    addon_id = (
        str(_addon().getAddonInfo("id") or "plugin.video.kraken").strip()
        or "plugin.video.kraken"
    )
    route = "plugin://{}/download/{}".format(addon_id, quote(rid, safe=""))
    li.addContextMenuItems([("Descargar pelicula", f"RunPlugin({route})")])


def add_episode_download_context(li, show_trakt_id, season_number, episode_number):
    if not _setting_bool("context_download_series_enabled", default=False):
        return
    sid = str(show_trakt_id or "").strip()
    if not sid:
        return
    addon_id = (
        str(_addon().getAddonInfo("id") or "plugin.video.kraken").strip()
        or "plugin.video.kraken"
    )
    route = "plugin://{}/download/series/{}/season/{}/episode/{}".format(
        addon_id,
        quote(sid, safe=""),
        quote(str(season_number), safe=""),
        quote(str(episode_number), safe=""),
    )
    li.addContextMenuItems([("Descargar episodio", f"RunPlugin({route})")])


def add_season_download_context(li, show_trakt_id, season_number):
    if not _setting_bool("context_download_series_enabled", default=False):
        return
    sid = str(show_trakt_id or "").strip()
    if not sid:
        return
    addon_id = (
        str(_addon().getAddonInfo("id") or "plugin.video.kraken").strip()
        or "plugin.video.kraken"
    )
    route = "plugin://{}/download/series/{}/season/{}".format(
        addon_id,
        quote(sid, safe=""),
        quote(str(season_number), safe=""),
    )
    li.addContextMenuItems([("Descargar temporada", f"RunPlugin({route})")])


def add_show_download_context(li, show_trakt_id):
    if not _setting_bool("context_download_series_enabled", default=False):
        return
    sid = str(show_trakt_id or "").strip()
    if not sid:
        return
    addon_id = (
        str(_addon().getAddonInfo("id") or "plugin.video.kraken").strip()
        or "plugin.video.kraken"
    )
    route = "plugin://{}/download/series/{}/complete".format(
        addon_id,
        quote(sid, safe=""),
    )
    li.addContextMenuItems([("Descargar serie completa", f"RunPlugin({route})")])
