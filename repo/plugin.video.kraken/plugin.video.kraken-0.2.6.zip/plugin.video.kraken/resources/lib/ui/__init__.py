"""Diálogos XML y helpers de interfaz."""
