# Iconos para TV en directo (Tvvoo): banderas por catálogo/país e iconos por categoría.
# Banderas: https://flagcdn.com (ISO 3166-1 alpha-2).
# Categorías: Twemoji PNG vía cdnjs (sin archivos locales).

import re

# Twemoji 14 — PNG 72x72 en cdnjs
_TW_BASE = "https://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/72x72"


def _twemoji_file(hex_code):
    return f"{_TW_BASE}/{hex_code}.png"


def _iso_from_catalog_id(catalog_id):
    """
    Muchos manifiestos Tvvoo usan ids tipo `es.xxx`, `it_rail`, `de-tdt` o directamente `fr`.
    """
    raw = (catalog_id or "").strip()
    if not raw:
        return ""
    low = raw.lower()
    if len(low) == 2 and low.isalpha():
        return low
    # prefijo ISO2 al inicio
    m = re.match(r"^([a-z]{2})[\._\-]", low)
    if m:
        return m.group(1)
    # sufijo -xx (menos frecuente)
    m = re.search(r"[\._\-]([a-z]{2})$", low)
    if m:
        return m.group(1)
    return ""


def _iso_from_name_fragment(name_lower):
    """
    Heurística por nombre visible del catálogo (idiomas UI / inglés / español).
    Orden: cadenas más largas / específicas antes que cortas (p. ej. 'uk' vs 'u').
    """
    if not name_lower:
        return ""
    pairs = (
        ("united kingdom", "gb"),
        ("great britain", "gb"),
        ("england", "gb"),
        ("scotland", "gb"),
        ("wales", "gb"),
        ("northern ireland", "gb"),
        ("united states", "us"),
        ("america latina", "mx"),
        ("latin america", "mx"),
        ("united arab emirates", "ae"),
        ("south africa", "za"),
        ("new zealand", "nz"),
        ("costa rica", "cr"),
        ("puerto rico", "pr"),
        ("dominican republic", "do"),
        ("el salvador", "sv"),
        ("saudi arabia", "sa"),
        ("south korea", "kr"),
        ("north korea", "kp"),
        ("czech republic", "cz"),
        ("bosnia", "ba"),
        ("luxembourg", "lu"),
        ("switzerland", "ch"),
        ("spain", "es"),
        ("españa", "es"),
        ("espana", "es"),
        ("spanien", "es"),
        ("italy", "it"),
        ("italia", "it"),
        ("italie", "it"),
        ("france", "fr"),
        ("francia", "fr"),
        ("germany", "de"),
        ("germania", "de"),
        ("allemagne", "de"),
        ("deutschland", "de"),
        ("portugal", "pt"),
        ("brasile", "br"),
        ("brasil", "br"),
        ("brazil", "br"),
        ("argentin", "ar"),
        ("chile", "cl"),
        ("colombia", "co"),
        ("méxico", "mx"),
        ("mexico", "mx"),
        ("canada", "ca"),
        ("canadá", "ca"),
        ("peru", "pe"),
        ("perú", "pe"),
        ("venezuela", "ve"),
        ("ecuador", "ec"),
        ("uruguay", "uy"),
        ("paraguay", "py"),
        ("bolivia", "bo"),
        ("honduras", "hn"),
        ("guatemala", "gt"),
        ("panama", "pa"),
        ("nicaragua", "ni"),
        ("cuba", "cu"),
        ("ireland", "ie"),
        ("irland", "ie"),
        ("netherlands", "nl"),
        ("holland", "nl"),
        ("belgium", "be"),
        ("belgique", "be"),
        ("poland", "pl"),
        ("polska", "pl"),
        ("polonia", "pl"),
        ("romania", "ro"),
        ("hungary", "hu"),
        ("austria", "at"),
        ("sweden", "se"),
        ("suecia", "se"),
        ("norway", "no"),
        ("noruega", "no"),
        ("denmark", "dk"),
        ("dinamarca", "dk"),
        ("finland", "fi"),
        ("greece", "el"),
        ("grecia", "el"),
        ("cyprus", "cy"),
        ("malta", "mt"),
        ("croatia", "hr"),
        ("serbia", "rs"),
        ("slovenia", "si"),
        ("slovakia", "sk"),
        ("bulgaria", "bg"),
        ("ukraine", "ua"),
        ("turkey", "tr"),
        ("turquía", "tr"),
        ("türkiye", "tr"),
        ("russia", "ru"),
        ("russie", "ru"),
        ("israel", "il"),
        ("japan", "jp"),
        ("giappone", "jp"),
        ("china", "cn"),
        ("india", "in"),
        ("pakistan", "pk"),
        ("bangladesh", "bd"),
        ("thailand", "th"),
        ("vietnam", "vn"),
        ("indonesia", "id"),
        ("philippines", "ph"),
        ("australia", "au"),
        ("australie", "au"),
        ("morocco", "ma"),
        ("maroc", "ma"),
        ("argelia", "dz"),
        ("algeria", "dz"),
        ("tunisia", "tn"),
        ("egypt", "eg"),
        ("nigeria", "ng"),
        ("kenya", "ke"),
        ("international", "xx"),
        ("internacional", "xx"),
        ("mondial", "xx"),
        ("world", "xx"),
        ("europa", "eu"),
        ("europe", "eu"),
        ("european union", "eu"),
    )
    for needle, code in pairs:
        if needle in name_lower:
            return code
    # Palabras cortas al final (riesgo de falsos positivos)
    short = (
        ("esp", "es"),
        ("ita", "it"),
        ("fra", "fr"),
        ("deu", "de"),
        ("prt", "pt"),
        ("latino", "mx"),
    )
    for needle, code in short:
        if needle in name_lower:
            return code
    return ""


def tv_catalog_country_flag_url(catalog_id, catalog_name):
    """
    URL PNG de bandera (flagcdn) o None si no se deduce país.
    """
    cid = (catalog_id or "").strip()
    name_l = (catalog_name or "").strip().lower()
    code = _iso_from_catalog_id(cid) or _iso_from_name_fragment(name_l)
    if not code:
        return None
    if code == "xx":
        return _twemoji_file("1f310")  # globo (internacional)
    if code == "eu":
        return f"https://flagcdn.com/w80/{code}.png"
    if len(code) != 2:
        return None
    return f"https://flagcdn.com/w80/{code.lower()}.png"


def _genre_blob(genre_raw, genre_label):
    return f"{genre_raw or ''} {genre_label or ''}".strip().lower()


def tv_genre_category_icon_url(genre_raw, genre_label):
    """
    Icono representativo por tipo de categoría (genres extra del manifiesto Tvvoo).
    """
    b = _genre_blob(genre_raw, genre_label)
    if not b:
        return _twemoji_file("1f4fa")

    def hit(needles):
        return any(n in b for n in needles)

    if hit(("sport", "deport", "futbol", "football", "nba", "ufc", "tennis", "f1", "rugby", "golf", "motogp")):
        return _twemoji_file("26bd")
    if hit(("news", "notic", "actualit", "nachricht", "journal")):
        return _twemoji_file("1f4f0")
    if hit(("movie", "cine", "film", "pelic", "cinema")):
        return _twemoji_file("1f3ac")
    if hit(("anime",)):
        return _twemoji_file("1f3a8")
    if hit(("serie", "show", "tv show", "drama")):
        return _twemoji_file("1f4fa")
    if hit(("kid", "infantil", "cartoon", "bambini", "enfant", "kinder")):
        return _twemoji_file("1f466")
    if hit(("docu", "history", "nature", "document")):
        return _twemoji_file("1f4fd")
    if hit(("music", "musica", "radio", "concert", "musique")):
        return _twemoji_file("1f3b5")
    if hit(("entertain", "variety", "reality", "comedy", "entreten")):
        return _twemoji_file("1f3ad")
    if hit(("world", "internacional", "global", "mond", "internat")):
        return _twemoji_file("1f30d")
    if hit(("local", "regional", "autonom", "provinc", "comunidad")):
        return _twemoji_file("1f3d9")
    if hit(("general", "nacional", "nazional", "public", "tdt", "generalista")):
        return _twemoji_file("1f4fa")
    if hit(("tutti", "todas", "todo", "toutes", "tutte", "alle", "tutto")):
        return _twemoji_file("1f4c1")
    return _twemoji_file("1f4fa")


def tv_listitem_art_country(base_art, catalog_id, catalog_name):
    art = dict(base_art or {})
    url = tv_catalog_country_flag_url(catalog_id, catalog_name)
    if not url:
        return art
    art.pop("poster", None)
    art.pop("banner", None)
    art.pop("landscape", None)
    art.update({"icon": url, "thumb": url})
    return art


def tv_listitem_art_category(base_art, catalog_id, catalog_name, genre_raw, genre_label):
    """
    Categoría: icono temático. Si hay bandera deducible del mismo país, se usa en thumb e icon en categoría
    para mantener contexto visual (país + tipo).
    """
    art = dict(base_art or {})
    cat_url = tv_genre_category_icon_url(genre_raw, genre_label)
    flag_url = tv_catalog_country_flag_url(catalog_id, catalog_name)
    art.pop("poster", None)
    art.pop("banner", None)
    art.pop("landscape", None)
    if flag_url:
        art.update({"thumb": flag_url, "icon": cat_url or flag_url})
    elif cat_url:
        art.update({"icon": cat_url, "thumb": cat_url})
    return art
