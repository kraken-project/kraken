"""Parches puntuales a setContent/endOfDirectory para vistas con fanart en listados ricos."""

import xbmcplugin

from resources.lib.ui.view_schedule import schedule_container_set_view_mode

_FANART_CONTENT_TYPES = frozenset(
    {"movies", "tvshows", "seasons", "episodes", "musicvideos"}
)

_PATCHED = False
_orig_setContent = None
_orig_endOfDirectory = None
_content_by_handle = {}
_suppress_fanart_depth = 0
_get_setting = None
_DEFAULT_FANART_VIEW = 508


def install(get_setting_fn):
    """Registra el lector de ajustes y sustituye setContent/endOfDirectory una sola vez."""
    global _get_setting, _PATCHED, _orig_setContent, _orig_endOfDirectory
    _get_setting = get_setting_fn
    if _PATCHED:
        return
    _PATCHED = True
    _orig_setContent = xbmcplugin.setContent
    _orig_endOfDirectory = xbmcplugin.endOfDirectory
    xbmcplugin.setContent = _wrapped_setContent
    xbmcplugin.endOfDirectory = _wrapped_endOfDirectory


def _handle_key(handle):
    try:
        return int(handle)
    except Exception:
        return handle


def _normalize_ctype(raw):
    if raw is None:
        return ""
    return str(raw).strip().lower()


def _fanart_force_enabled():
    if not _get_setting:
        return True
    try:
        raw = str(_get_setting("kraken_listings_fanart_force") or "").strip().lower()
    except Exception:
        return True
    if raw in ("false", "0", "no"):
        return False
    return True


def _fanart_view_id():
    if not _get_setting:
        return _DEFAULT_FANART_VIEW
    try:
        raw = str(_get_setting("kraken_listings_fanart_view_id") or "").strip()
        vid = int(raw) if raw else _DEFAULT_FANART_VIEW
        return vid if vid > 0 else _DEFAULT_FANART_VIEW
    except Exception:
        return _DEFAULT_FANART_VIEW


def _wrapped_setContent(handle, content):
    _content_by_handle[_handle_key(handle)] = content
    return _orig_setContent(handle, content)


def _wrapped_endOfDirectory(handle, *args, **kwargs):
    h = _handle_key(handle)
    ctype = _content_by_handle.pop(h, None)
    skip_fanart = _suppress_fanart_depth > 0
    out = _orig_endOfDirectory(handle, *args, **kwargs)
    if skip_fanart or not _fanart_force_enabled():
        return out
    norm = _normalize_ctype(ctype)
    if norm not in _FANART_CONTENT_TYPES:
        return out
    schedule_container_set_view_mode(_fanart_view_id())
    return out


class suppress_fanart_listing_cm:
    """Evita programar la vista fanart en el próximo listado bajo este contexto."""

    def __enter__(self):
        global _suppress_fanart_depth
        _suppress_fanart_depth += 1
        return self

    def __exit__(self, exc_type, exc, tb):
        global _suppress_fanart_depth
        _suppress_fanart_depth = max(0, _suppress_fanart_depth - 1)
        return False
