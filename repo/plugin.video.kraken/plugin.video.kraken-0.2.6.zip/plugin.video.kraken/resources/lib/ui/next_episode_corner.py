# Ventana esquina inferior derecha: cuenta atras + Siguiente / Cancelar.
# Riesgo (Kodi): el hilo secundario llama a controles xbmcgui (p. ej. setLabel en 103) y
# puede llamar a close() al llegar a 0. Kodi no garantiza hilos seguros para la GUI;
# en algunas plataformas puede provocar cuelgues o comportamiento indefinido. Mitigar
# minimizando trabajo en el hilo (solo etiqueta 103 y cierre al timeout) y no tocar
# otros controles desde el worker.
import threading

import xbmc
import xbmcgui


class NextEpisodeCornerDialog(xbmcgui.WindowXMLDialog):
    """Dialogo WindowXML pequeno; resultado True = Siguiente (o timeout), False = Cancelar."""

    def __init__(self, *args, **kwargs):
        self._remain_cap = int(kwargs.pop("remain_seconds_cap", 30))
        self._title = kwargs.pop("dialog_title", "Kraken - Siguiente")
        self._body = kwargs.pop("body_text", "")
        self._countdown_start = int(kwargs.pop("countdown_seconds", 10))
        self._stop = threading.Event()
        self._result = False
        self._closed = threading.Lock()
        super().__init__(*args, **kwargs)

    def onInit(self):
        self._set_label(100, self._title)
        self._set_label(101, self._body)
        self._set_label(103, str(self._countdown_start))
        self.setFocusId(301)
        self._stop.clear()
        self._result = False
        t = threading.Thread(
            target=self._countdown_worker, name="KrakenNextCornerCountdown", daemon=True
        )
        t.start()

    def _set_label(self, control_id, value):
        try:
            self.getControl(control_id).setLabel(value)
        except Exception:
            pass

    def _countdown_worker(self):
        s = self._countdown_start
        while s >= 0 and not self._stop.is_set():
            try:
                self.getControl(103).setLabel(str(s))
            except Exception:
                pass
            if s == 0:
                self._finish_timeout_buscar()
                return
            for _ in range(10):
                if self._stop.is_set():
                    return
                xbmc.sleep(100)
            s -= 1

    def _finish_timeout_buscar(self):
        with self._closed:
            if self._stop.is_set():
                return
            self._result = True
            self._stop.set()
        try:
            self.close()
        except Exception:
            pass

    def onClick(self, control_id):
        if control_id == 301:
            with self._closed:
                if self._stop.is_set():
                    return
                self._result = True
                self._stop.set()
            self.close()
        elif control_id == 302:
            with self._closed:
                if self._stop.is_set():
                    return
                self._result = False
                self._stop.set()
            self.close()

    def onAction(self, action):
        aid = action.getId()
        if aid in (10, 11, 92):
            with self._closed:
                if self._stop.is_set():
                    return
                self._result = False
                self._stop.set()
            self.close()

    def close(self):
        self._stop.set()
        try:
            super().close()
        except Exception:
            pass

    def buscar_selected(self):
        """True si Siguiente o cuenta atras llego a 0; False si Cancelar o back."""
        return bool(self._result)
