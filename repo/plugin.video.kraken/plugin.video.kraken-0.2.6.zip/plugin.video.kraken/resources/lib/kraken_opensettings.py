# -*- coding: utf-8 -*-
"""Punto de entrada program (Umbrella-style) para abrir ajustes nativos de Kraken."""
import xbmc

if __name__ == "__main__":
    xbmc.executebuiltin("Addon.OpenSettings(plugin.video.kraken)")
