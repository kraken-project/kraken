"""Paquete principal del add-on (rutas, core, fuentes, Trakt)."""
