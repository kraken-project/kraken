"""
Listados (tendencias, populares, etc.) vía Trakt (API pública) + TMDb para arte.
"""

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.core.metadata_tmdb import prefetch_tmdb_details_parallel
from resources.lib.routes.trakt_show_routes import _trakt_listing_translation_lang
from resources.lib.ui.context_menu import (
    add_movie_download_context,
    add_show_download_context,
)
from resources.lib.routes.i18n_routes import make_mapped_t

# Sufijos de path Trakt (sin base). extended=full para overview y notas.
TRAKT_MOVIE_ENDPOINTS = {
    "trending": "movies/trending?limit=40&extended=full",
    "popular": "movies/popular?limit=40&extended=full",
    "played": "movies/played/weekly?limit=40&extended=full",
    "boxoffice": "movies/boxoffice?extended=full",
    "anticipated": "movies/anticipated?limit=40&extended=full",
}

TRAKT_SHOW_ENDPOINTS = {
    "trending": "shows/trending?limit=40&extended=full",
    "popular": "shows/popular?limit=40&extended=full",
    "played": "shows/played/weekly?limit=40&extended=full",
    "anticipated": "shows/anticipated?limit=40&extended=full",
}

_TRAKT_DISCOVER_PHRASE_MAP = {
    ("Película", "Movie"): ("Film", "Film", "Film"),
    ("Kraken - Películas - {}", "Kraken - Movies - {}"): (
        "Kraken - Films - {}",
        "Kraken - Film - {}",
        "Kraken - Filme - {}",
    ),
    ("Series", "TV Shows"): ("Séries", "Serie TV", "Serien"),
    ("Tendencias", "Trending"): ("Tendances", "Tendenze", "Trending"),
    ("Populares", "Popular"): ("Populaires", "Popolari", "Beliebt"),
    ("Más vistos (semana)", "Most watched (week)"): (
        "Les plus vus (semaine)",
        "Più visti (settimana)",
        "Meistgesehen (Woche)",
    ),
    ("Próximamente", "Upcoming"): ("À venir", "In arrivo", "Demnächst"),
    ("Mejor valoradas (rating Trakt)", "Top rated (Trakt rating)"): (
        "Mieux notés (note Trakt)",
        "Più votati (rating Trakt)",
        "Top bewertet (Trakt-Rating)",
    ),
    ("Kraken - {} - {}", "Kraken - {} - {}"): ("Kraken - {} - {}", "Kraken - {} - {}", "Kraken - {} - {}"),
    ("No se pudo cargar el listado de Trakt.", "Could not load Trakt list."): (
        "Impossible de charger la liste Trakt.",
        "Impossibile caricare la lista Trakt.",
        "Trakt-Liste konnte nicht geladen werden.",
    ),
}


_t = make_mapped_t(_TRAKT_DISCOVER_PHRASE_MAP)


def _trakt_url_with_filters(suffix, genres=None, years=None):
    """Añade genres= y years= a la URL de la API Trakt (filtros oficiales)."""
    from urllib.parse import quote

    url = f"https://api.trakt.tv/{suffix}"
    parts = []
    if genres:
        parts.append("genres={}".format(quote(str(genres), safe="")))
    if years:
        parts.append("years={}".format(quote(str(years), safe="")))
    if not parts:
        return url
    sep = "&" if "?" in url else "?"
    return "{}{}{}".format(url, sep, "&".join(parts))


def _unwrap_trakt_row(row, media_key):
    """Tendencia / played envuelve el objeto; popular es directo."""
    if not isinstance(row, dict):
        return None
    if media_key in row and isinstance(row[media_key], dict):
        return row[media_key]
    if "title" in row and "ids" in row:
        return row
    return None


def _coerce_trakt_movie_list_payload(payload):
    """La API suele devolver lista; si cambia el envoltorio, seguir mostrando filas válidas."""
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for k in ("movies", "data", "results"):
            v = payload.get(k)
            if isinstance(v, list):
                return v
    return []


def _media_to_result_dict(media, item_type, trakt_parse_year, trakt_float_or_none):
    item_type = "show" if item_type == "show" else "movie"
    if not media or not isinstance(media, dict):
        return None
    ids = media.get("ids") or {}
    tid = str(ids.get("trakt") or "").strip()
    if not tid:
        return None
    title = str(media.get("title") or "").strip() or _t(
        "Sin título", "Untitled", "Sans titre", "Senza titolo", "Ohne Titel"
    )
    year = None
    has_year = False
    y = media.get("year")
    if y is not None:
        year, has_year = trakt_parse_year(y)
    if not has_year and item_type == "movie":
        rel = str(media.get("released") or "").strip()
        if len(rel) >= 4 and rel[:4].isdigit():
            year, has_year = trakt_parse_year(int(rel[:4]))
    if not has_year and item_type == "show":
        fa = str(media.get("first_aired") or "").strip()
        if len(fa) >= 4 and fa[:4].isdigit():
            year, has_year = trakt_parse_year(int(fa[:4]))
    r2 = (media.get("ratings") or {}) if isinstance(media.get("ratings"), dict) else {}
    rating = trakt_float_or_none(media.get("rating"))
    if rating is None or rating <= 0:
        rating = trakt_float_or_none(r2.get("rating"))
    votes = 0
    try:
        vraw = r2.get("votes")
        if vraw is not None and str(vraw).strip() != "":
            votes = int(vraw)
    except (TypeError, ValueError):
        votes = 0
    genres_lc = []
    for g in media.get("genres") or []:
        if isinstance(g, str) and g.strip():
            genres_lc.append(g.strip().lower())
        elif isinstance(g, dict):
            nm = str(g.get("name") or "").strip()
            if nm:
                genres_lc.append(nm.lower())
    return {
        "id": f"trakt::{item_type}::{tid}",
        "title": title,
        "year": year,
        "has_year": has_year,
        "rating": rating,
        "votes": votes,
        "plot": str(media.get("overview") or "").strip(),
        "tmdb_id": ids.get("tmdb"),
        "imdb_id": str(ids.get("imdb") or "").strip(),
        "genres_lc": genres_lc,
    }


def _parallel_tmdb_map_for_results(
    results, media_type_kw, tmdb_id_details_fn, *, max_workers=8
):
    return prefetch_tmdb_details_parallel(
        [it.get("tmdb_id") for it in (results or []) if it.get("tmdb_id")],
        lambda nid: tmdb_id_details_fn(nid, media_type=media_type_kw) or {},
        max_workers=max_workers,
    )


def _sort_key_rated_trakt_item(item):
    r = item.get("rating")
    try:
        rf = float(r) if r is not None else 0.0
    except (TypeError, ValueError):
        rf = 0.0
    v = int(item.get("votes") or 0)
    title = (item.get("title") or "").lower()
    return (-rf, -v, title)


def _apply_trakt_translations(
    results, item_type, trakt_progress_translator=None, language=None
):
    if not results:
        return
    if not callable(trakt_progress_translator):
        return
    try:
        provider, auto_lang = trakt_progress_translator()
    except Exception:
        provider, auto_lang = None, None
    if not provider:
        return
    lang = language if language else auto_lang
    if not lang:
        return
    media_key = "show" if item_type == "show" else "movie"
    tr_cache = {}
    for item in results:
        rid = str((item or {}).get("id") or "")
        tid = rid.split("::")[-1].strip() if rid else ""
        if not tid:
            continue
        if tid not in tr_cache:
            try:
                t_tr, o_tr = provider._translation_title_and_overview(
                    media_key, tid, lang
                )
            except Exception:
                t_tr, o_tr = "", ""
            tr_cache[tid] = {
                "title": str(t_tr or "").strip(),
                "plot": str(o_tr or "").strip(),
            }
        trn = tr_cache.get(tid) or {}
        if trn.get("title"):
            item["title"] = trn.get("title")
        if trn.get("plot"):
            item["plot"] = trn.get("plot")


def _build_trakt_movie_directory(
    *,
    plugin_handle,
    results,
    category_title,
    default_list_art,
    tmdb_id_details,
    trakt_list_label1_with_year_rating,
    trakt_listitem_set_info_and_videotag,
    url_for_play,
    url_for_noop,
    tmdb_prefetch=None,
):
    xbmcplugin.setPluginCategory(plugin_handle, category_title)
    xbmcplugin.setContent(plugin_handle, "movies")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_NONE)
    base_art = default_list_art()
    directory = []
    for item in results:
        tid = str((item.get("id") or "").split("::")[-1] or "").strip()
        if not tid:
            continue
        year = item.get("year")
        has_year = bool(item.get("has_year"))
        rating = item.get("rating")
        try:
            rating_pos = rating is not None and float(rating) > 0.0
        except (TypeError, ValueError):
            rating_pos = False
        line1 = trakt_list_label1_with_year_rating(
            item.get("title") or _t("Película", "Movie", "Film", "Film", "Film"),
            has_year,
            year,
            (rating if rating_pos else None),
        )
        tmdb_id_raw = item.get("tmdb_id")
        if tmdb_id_raw and isinstance(tmdb_prefetch, dict):
            try:
                _nid = int(str(tmdb_id_raw).strip())
                tmdb = dict(tmdb_prefetch.get(_nid) or {})
            except (TypeError, ValueError):
                tmdb = tmdb_id_details(tmdb_id_raw, media_type="movie") or {}
        elif tmdb_id_raw:
            tmdb = tmdb_id_details(tmdb_id_raw, media_type="movie") or {}
        else:
            tmdb = {}
        r_info = rating
        if (
            (r_info is None or r_info <= 0)
            and tmdb.get("rating") is not None
            and tmdb.get("rating") > 0
        ):
            r_info = tmdb.get("rating")
        y_info = int(year) if (has_year and year is not None) else 0
        if not y_info and tmdb.get("has_year") and tmdb.get("year") is not None:
            y_info = int(tmdb.get("year") or 0)
        info = {
            "title": line1,
            "plot": item.get("plot") or "",
            "mediatype": "movie",
            "year": y_info,
            "rating": r_info if (r_info is not None and r_info > 0) else 0,
        }
        li = xbmcgui.ListItem(label=line1, label2=item.get("plot", "")[:120])
        trakt_listitem_set_info_and_videotag(
            li,
            item.get("title") or "",
            item.get("plot") or "",
            False,
            has_year and year is not None,
            year,
            r_info,
            None,
            info,
        )
        art = dict(base_art)
        p = str((tmdb or {}).get("poster") or "").strip()
        f = str((tmdb or {}).get("fanart") or "").strip()
        if p:
            art.update({"poster": p, "thumb": p, "icon": p})
        if f:
            art.update({"fanart": f, "landscape": f, "banner": f})
        li.setArt(art)
        li.setProperty("IsPlayable", "true")
        play_id = f"trakt::movie::{tid}"
        add_movie_download_context(li, play_id)
        directory.append((url_for_play(play_id), li, False))

    if not directory:
        li = xbmcgui.ListItem(
            label=_t(
                "Sin resultados en este listado",
                "No results in this list",
                "Aucun résultat dans cette liste",
                "Nessun risultato in questa lista",
                "Keine Ergebnisse in dieser Liste",
            )
        )
        li.setProperty("IsPlayable", "false")
        li.setArt(base_art)
        directory.append((url_for_noop(), li, False))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle, True)


def _build_trakt_show_directory(
    *,
    plugin_handle,
    results,
    category_title,
    default_list_art,
    tmdb_id_details,
    trakt_list_label1_with_year_rating,
    trakt_listitem_set_info_and_videotag,
    url_for_show_seasons,
    url_for_noop,
    tmdb_prefetch=None,
):
    xbmcplugin.setPluginCategory(plugin_handle, category_title)
    xbmcplugin.setContent(plugin_handle, "tvshows")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_NONE)
    base_art = default_list_art()
    directory = []
    for item in results:
        tid = str((item.get("id") or "").split("::")[-1] or "").strip()
        if not tid:
            continue
        year = item.get("year")
        has_year = bool(item.get("has_year"))
        rating = item.get("rating")
        try:
            rating_pos = rating is not None and float(rating) > 0.0
        except (TypeError, ValueError):
            rating_pos = False
        line1 = trakt_list_label1_with_year_rating(
            item.get("title")
            or _t("Serie", "TV Show", "Série", "Serie TV", "Serie"),
            has_year,
            year,
            (rating if rating_pos else None),
        )
        tmdb_id_raw = item.get("tmdb_id")
        if tmdb_id_raw and isinstance(tmdb_prefetch, dict):
            try:
                _nid = int(str(tmdb_id_raw).strip())
                tmdb = dict(tmdb_prefetch.get(_nid) or {})
            except (TypeError, ValueError):
                tmdb = tmdb_id_details(tmdb_id_raw, media_type="series") or {}
        elif tmdb_id_raw:
            tmdb = tmdb_id_details(tmdb_id_raw, media_type="series") or {}
        else:
            tmdb = {}
        r_info = rating
        if (
            (r_info is None or r_info <= 0)
            and tmdb.get("rating") is not None
            and tmdb.get("rating") > 0
        ):
            r_info = tmdb.get("rating")
        y_info = int(year) if (has_year and year is not None) else 0
        if not y_info and tmdb.get("has_year") and tmdb.get("year") is not None:
            y_info = int(tmdb.get("year") or 0)
        info = {
            "title": line1,
            "plot": item.get("plot") or "",
            "mediatype": "tvshow",
            "year": y_info,
            "rating": r_info if (r_info is not None and r_info > 0) else 0,
        }
        li = xbmcgui.ListItem(label=line1, label2=item.get("plot", "")[:120])
        trakt_listitem_set_info_and_videotag(
            li,
            item.get("title") or "",
            item.get("plot") or "",
            True,
            has_year and year is not None,
            year,
            r_info,
            None,
            info,
        )
        art = dict(base_art)
        p = str((tmdb or {}).get("poster") or "").strip()
        f = str((tmdb or {}).get("fanart") or "").strip()
        if p:
            art.update({"poster": p, "thumb": p, "icon": p})
        if f:
            art.update({"fanart": f, "landscape": f, "banner": f})
        li.setArt(art)
        li.setProperty("IsPlayable", "false")
        add_show_download_context(li, tid)
        directory.append((url_for_show_seasons(tid), li, True))

    if not directory:
        li = xbmcgui.ListItem(
            label=_t(
                "Sin resultados en este listado",
                "No results in this list",
                "Aucun résultat dans cette liste",
                "Nessun risultato in questa lista",
                "Keine Ergebnisse in dieser Liste",
            )
        )
        li.setProperty("IsPlayable", "false")
        li.setArt(base_art)
        directory.append((url_for_noop(), li, False))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle, True)


def run_trakt_discover_movie_list(
    *,
    plugin_handle,
    list_id,
    trakt_public_get,
    default_list_art,
    tmdb_id_details,
    trakt_parse_year,
    trakt_float_or_none,
    trakt_progress_translator=None,
    trakt_list_label1_with_year_rating,
    trakt_listitem_set_info_and_videotag,
    url_for_play,
    url_for_noop,
):
    lid = (list_id or "").strip().lower()
    if lid == "boxoffice":
        from resources.lib.routes.tmdb_discover_routes import (
            run_tmdb_now_playing_boxoffice_list,
        )

        if run_tmdb_now_playing_boxoffice_list(
            plugin_handle=plugin_handle,
            trakt_public_get=trakt_public_get,
            default_list_art=default_list_art,
            tmdb_id_details=tmdb_id_details,
            trakt_progress_translator=trakt_progress_translator,
            trakt_list_label1_with_year_rating=trakt_list_label1_with_year_rating,
            trakt_listitem_set_info_and_videotag=trakt_listitem_set_info_and_videotag,
            url_for_play=url_for_play,
            url_for_noop=url_for_noop,
        ):
            return

    if lid == "rated":
        url = _trakt_url_with_filters("movies/popular?limit=100&extended=full")
    else:
        suffix = TRAKT_MOVIE_ENDPOINTS.get(lid)
        if not suffix:
            xbmcgui.Dialog().ok(
                "Kraken",
                _t(
                    "Listado de películas no válido.",
                    "Invalid movie list.",
                    "Liste de films non valide.",
                    "Lista film non valida.",
                    "Ungültige Filmliste.",
                ),
            )
            xbmcplugin.endOfDirectory(plugin_handle, True)
            return
        url = _trakt_url_with_filters(suffix)
    try:
        payload = trakt_public_get(url)
    except Exception as err:
        xbmc.log(f"[Kraken][discover] movies {list_id}: {err}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            "Kraken",
            _t(
                "No se pudo cargar el listado de Trakt.",
                "Could not load Trakt list.",
                "Impossible de charger la liste Trakt.",
                "Impossibile caricare la lista Trakt.",
                "Trakt-Liste konnte nicht geladen werden.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return

    results = []
    for row in _coerce_trakt_movie_list_payload(payload):
        m = _unwrap_trakt_row(row, "movie")
        r = _media_to_result_dict(m, "movie", trakt_parse_year, trakt_float_or_none)
        if r:
            results.append(r)
    _apply_trakt_translations(
        results, "movie", trakt_progress_translator=trakt_progress_translator
    )
    if lid == "rated":
        results = sorted(results, key=_sort_key_rated_trakt_item)[:40]

    titles = {
        "trending": _t("Tendencias", "Trending", "Tendances", "Di tendenza", "Trends"),
        "popular": _t("Populares", "Popular", "Populaires", "Popolari", "Beliebt"),
        "played": _t("Más vistos (semana)", "Most watched (week)", "Les plus vus (semaine)", "Più visti (settimana)", "Meistgesehen (Woche)"),
        "boxoffice": _t("Taquilla", "Box office", "Box-office", "Box office", "Box Office"),
        "anticipated": _t("Más esperados", "Most anticipated", "Les plus attendus", "I più attesi", "Am meisten erwartet"),
        "rated": _t("Mejor valoradas (rating Trakt)", "Top rated (Trakt rating)", "Mieux notés (note Trakt)", "Più votati (rating Trakt)", "Am besten bewertet (Trakt-Rating)"),
    }
    cat = _t(
        "Kraken - Películas - {}",
        "Kraken - Movies - {}",
        "Kraken - Films - {}",
        "Kraken - Film - {}",
        "Kraken - Filme - {}",
    ).format(
        titles.get((list_id or "").lower(), list_id)
    )
    tmdb_px = _parallel_tmdb_map_for_results(results, "movie", tmdb_id_details)
    _build_trakt_movie_directory(
        plugin_handle=plugin_handle,
        results=results,
        category_title=cat,
        default_list_art=default_list_art,
        tmdb_id_details=tmdb_id_details,
        tmdb_prefetch=tmdb_px,
        trakt_list_label1_with_year_rating=trakt_list_label1_with_year_rating,
        trakt_listitem_set_info_and_videotag=trakt_listitem_set_info_and_videotag,
        url_for_play=url_for_play,
        url_for_noop=url_for_noop,
    )


def run_trakt_discover_show_list(
    *,
    plugin_handle,
    list_id,
    genres,
    trakt_public_get,
    default_list_art,
    tmdb_id_details,
    trakt_parse_year,
    trakt_float_or_none,
    trakt_progress_translator=None,
    trakt_list_label1_with_year_rating,
    trakt_listitem_set_info_and_videotag,
    url_for_show_seasons,
    url_for_noop,
):
    lid = (list_id or "").strip().lower()
    if lid == "rated":
        url = _trakt_url_with_filters(
            "shows/popular?limit=100&extended=full", genres=genres
        )
    else:
        suffix = TRAKT_SHOW_ENDPOINTS.get(lid)
        if not suffix:
            xbmcgui.Dialog().ok(
                "Kraken",
                _t(
                    "Listado de series no válido.",
                    "Invalid TV shows list.",
                    "Liste de séries non valide.",
                    "Lista serie TV non valida.",
                    "Ungültige Serienliste.",
                ),
            )
            xbmcplugin.endOfDirectory(plugin_handle, True)
            return
        url = _trakt_url_with_filters(suffix, genres=genres)
    try:
        payload = trakt_public_get(url)
    except Exception as err:
        xbmc.log(f"[Kraken][discover] shows {list_id}: {err}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            "Kraken",
            _t(
                "No se pudo cargar el listado de Trakt.",
                "Could not load Trakt list.",
                "Impossible de charger la liste Trakt.",
                "Impossibile caricare la lista Trakt.",
                "Trakt-Liste konnte nicht geladen werden.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return

    results = []
    for row in payload or []:
        s = _unwrap_trakt_row(row, "show")
        r = _media_to_result_dict(s, "show", trakt_parse_year, trakt_float_or_none)
        if r:
            results.append(r)
    _apply_trakt_translations(
        results,
        "show",
        trakt_progress_translator=trakt_progress_translator,
        language=_trakt_listing_translation_lang(),
    )
    if lid == "rated":
        results = sorted(results, key=_sort_key_rated_trakt_item)[:40]

    sub = "Anime" if (genres or "").lower() == "anime" else _t("Series", "TV Shows", "Séries", "Serie TV", "Serien")
    titles = {
        "trending": _t("Tendencias", "Trending", "Tendances", "Di tendenza", "Trends"),
        "popular": _t("Populares", "Popular", "Populaires", "Popolari", "Beliebt"),
        "played": _t("Más vistos (semana)", "Most watched (week)", "Les plus vus (semaine)", "Più visti (settimana)", "Meistgesehen (Woche)"),
        "anticipated": _t("Próximamente", "Upcoming", "À venir", "In arrivo", "Demnächst"),
        "rated": _t("Mejor valoradas (rating Trakt)", "Top rated (Trakt rating)", "Mieux notés (note Trakt)", "Più votati (rating Trakt)", "Top bewertet (Trakt-Rating)"),
    }
    cat = _t(
        "Kraken - {} - {}",
        "Kraken - {} - {}",
        "Kraken - {} - {}",
        "Kraken - {} - {}",
        "Kraken - {} - {}",
    ).format(
        sub, titles.get((list_id or "").lower(), list_id)
    )
    tmdb_px = _parallel_tmdb_map_for_results(results, "series", tmdb_id_details)
    _build_trakt_show_directory(
        plugin_handle=plugin_handle,
        results=results,
        category_title=cat,
        default_list_art=default_list_art,
        tmdb_id_details=tmdb_id_details,
        tmdb_prefetch=tmdb_px,
        trakt_list_label1_with_year_rating=trakt_list_label1_with_year_rating,
        trakt_listitem_set_info_and_videotag=trakt_listitem_set_info_and_videotag,
        url_for_show_seasons=url_for_show_seasons,
        url_for_noop=url_for_noop,
    )


def run_trakt_filtered_movie_list(
    *,
    plugin_handle,
    years,
    genres_slug,
    category_title,
    trakt_public_get,
    default_list_art,
    tmdb_id_details,
    trakt_parse_year,
    trakt_float_or_none,
    trakt_progress_translator=None,
    trakt_list_label1_with_year_rating,
    trakt_listitem_set_info_and_videotag,
    url_for_play,
    url_for_noop,
):
    url = _trakt_url_with_filters(
        "movies/popular?limit=50&extended=full",
        genres=genres_slug,
        years=years,
    )
    try:
        payload = trakt_public_get(url)
    except Exception as err:
        xbmc.log(f"[Kraken][discover] movies filtro: {err}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            "Kraken",
            _t(
                "No se pudo cargar el listado de Trakt.",
                "Could not load Trakt list.",
                "Impossible de charger la liste Trakt.",
                "Impossibile caricare la lista Trakt.",
                "Trakt-Liste konnte nicht geladen werden.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    results = []
    for row in payload or []:
        m = _unwrap_trakt_row(row, "movie")
        r = _media_to_result_dict(m, "movie", trakt_parse_year, trakt_float_or_none)
        if r:
            results.append(r)
    _apply_trakt_translations(
        results, "movie", trakt_progress_translator=trakt_progress_translator
    )
    tmdb_px = _parallel_tmdb_map_for_results(results, "movie", tmdb_id_details)
    _build_trakt_movie_directory(
        plugin_handle=plugin_handle,
        results=results,
        category_title=category_title,
        default_list_art=default_list_art,
        tmdb_id_details=tmdb_id_details,
        tmdb_prefetch=tmdb_px,
        trakt_list_label1_with_year_rating=trakt_list_label1_with_year_rating,
        trakt_listitem_set_info_and_videotag=trakt_listitem_set_info_and_videotag,
        url_for_play=url_for_play,
        url_for_noop=url_for_noop,
    )


def run_trakt_filtered_show_list(
    *,
    plugin_handle,
    years,
    genres_slug,
    require_genre_lc,
    category_title,
    trakt_public_get,
    default_list_art,
    tmdb_id_details,
    trakt_parse_year,
    trakt_float_or_none,
    trakt_progress_translator=None,
    trakt_list_label1_with_year_rating,
    trakt_listitem_set_info_and_videotag,
    url_for_show_seasons,
    url_for_noop,
):
    url = _trakt_url_with_filters(
        "shows/popular?limit=100&extended=full",
        genres=genres_slug,
        years=years,
    )
    try:
        payload = trakt_public_get(url)
    except Exception as err:
        xbmc.log(f"[Kraken][discover] shows filtro: {err}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            "Kraken",
            _t(
                "No se pudo cargar el listado de Trakt.",
                "Could not load Trakt list.",
                "Impossible de charger la liste Trakt.",
                "Impossibile caricare la lista Trakt.",
                "Trakt-Liste konnte nicht geladen werden.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    results = []
    for row in payload or []:
        s = _unwrap_trakt_row(row, "show")
        r = _media_to_result_dict(s, "show", trakt_parse_year, trakt_float_or_none)
        if r:
            results.append(r)
    _apply_trakt_translations(
        results,
        "show",
        trakt_progress_translator=trakt_progress_translator,
        language=_trakt_listing_translation_lang(),
    )
    req = (require_genre_lc or "").strip().lower()
    if req:
        results = [r for r in results if req in (r.get("genres_lc") or [])][:40]
    else:
        results = results[:40]
    tmdb_px = _parallel_tmdb_map_for_results(results, "series", tmdb_id_details)
    _build_trakt_show_directory(
        plugin_handle=plugin_handle,
        results=results,
        category_title=category_title,
        default_list_art=default_list_art,
        tmdb_id_details=tmdb_id_details,
        tmdb_prefetch=tmdb_px,
        trakt_list_label1_with_year_rating=trakt_list_label1_with_year_rating,
        trakt_listitem_set_info_and_videotag=trakt_listitem_set_info_and_videotag,
        url_for_show_seasons=url_for_show_seasons,
        url_for_noop=url_for_noop,
    )
