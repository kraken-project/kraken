def run_actor_listing_route(*, run_actor_listing_entry, mode, actor_listing_fn):
    run_actor_listing_entry(mode=mode, actor_listing_fn=actor_listing_fn)


def run_actor_person_route(
    *, run_actor_person_entry, person_id, mode, actor_credits_fn, plugin_handle
):
    run_actor_person_entry(
        person_id=person_id,
        mode=mode,
        actor_credits_fn=actor_credits_fn,
        plugin_handle=plugin_handle,
    )
