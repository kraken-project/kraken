"""Rutas plugin:// y handlers de listados Kodi."""
