import webbrowser

import xbmcgui

from resources.lib.core.debrid_provider_config import PROVIDERS
from resources.lib.routes.stremio_routes import open_url_or_show
from resources.lib.routes.i18n_routes import make_mapped_t

_STATUS_PHRASE_MAP = {
    ("Codigo QR de portales (Trakt / Debrid)", "Account portal QR codes (Trakt / Debrid)",): (
        "Codes QR portails (Trakt / Debrid)",
        "Codici QR portali (Trakt / Debrid)",
        "Portal-QR (Trakt / Debrid)",
    ),
    ("Configurado", "Configured"): ("Configuré", "Configurato", "Konfiguriert"),
    ("Sin configurar", "Not configured"): ("Non configuré", "Non configurato", "Nicht konfiguriert"),
    ("Activado", "Enabled"): ("Activé", "Abilitato", "Aktiviert"),
    ("Desactivado", "Disabled"): ("Désactivé", "Disabilitato", "Deaktiviert"),
    ("Autorizada", "Authorized"): ("Autorisée", "Autorizzata", "Autorisiert"),
    ("No autorizada", "Not authorized"): ("Non autorisée", "Non autorizzata", "Nicht autorisiert"),
    ("Complementos: {}", "Addons: {}"): ("Addons : {}", "Addon: {}", "Add-ons: {}"),
    ("Debrid (por proveedor):", "Debrid (by provider):"): ("Debrid (par fournisseur) :", "Debrid (per provider):", "Debrid (pro Anbieter):"),
    ("sin token", "no token"): ("sans jeton", "senza token", "kein Token"),
    ("No conectada", "Not connected"): ("Non connecté", "Non connesso", "Nicht verbunden"),
}


_t = make_mapped_t(_STATUS_PHRASE_MAP)


def run_stremio_open_all_configs(
    *,
    stremio_addons_config,
    stremio_open_all_peerflix,
    peerflix_web_url,
    get_setting,
    addon_path=None,
    qr_dialog_cls=None,
):
    if addon_path and qr_dialog_cls:
        entries = []
        missing = []
        for addon_name, _enabled_setting, url_setting in stremio_addons_config():
            if url_setting == stremio_open_all_peerflix:
                url = peerflix_web_url
            else:
                url = (get_setting(url_setting) or "").strip()
            if not url:
                missing.append(
                    _t(
                        "{}: sin URL",
                        "{}: no URL",
                        "{} : sans URL",
                        "{}: senza URL",
                        "{}: keine URL",
                    ).format(addon_name)
                )
                continue
            entries.append((addon_name, url))
        if not entries:
            xbmcgui.Dialog().ok(
                "Kraken - Stremio",
                _t(
                    "No hay URLs de configuración para mostrar.",
                    "No configuration URLs to show.",
                    "Aucune URL de configuration a afficher.",
                    "Nessun URL di configurazione da mostrare.",
                    "Keine Konfigurations-URLs zum Anzeigen.",
                ),
            )
            return
        if len(entries) > 1:
            ok = xbmcgui.Dialog().yesno(
                "Kraken - Stremio",
                _t(
                    f"Se mostrarán {len(entries)} códigos QR (uno por complemento).\n\n¿Continuar?",
                    f"{len(entries)} QR codes will be shown (one per addon).\n\nContinue?",
                    f"{len(entries)} codes QR seront affichés (un par add-on).\n\nContinuer ?",
                    f"Verranno mostrati {len(entries)} codici QR (uno per addon).\n\nContinuare?",
                    f"Es werden {len(entries)} QR-Codes angezeigt (einer pro Add-on).\n\nFortfahren?",
                ),
                nolabel=_t("Cancelar", "Cancel", "Annuler", "Annulla", "Abbrechen"),
                yeslabel=_t("Mostrar QR", "Show QR", "Afficher QR", "Mostra QR", "QR anzeigen"),
            )
            if not ok:
                return
        for addon_name, url in entries:
            open_url_or_show(
                url=url,
                title=f"Kraken - Stremio ({addon_name})",
                addon_path=addon_path,
                qr_dialog_cls=qr_dialog_cls,
            )
        if missing:
            lines = [
                _t(
                    "No se mostraron estos complementos:",
                    "These addons were not shown:",
                    "Ces add-ons n'ont pas été affichés :",
                    "Questi addon non sono stati mostrati:",
                    "Diese Add-ons wurden nicht angezeigt:",
                )
            ] + missing
            xbmcgui.Dialog().ok("Kraken - Stremio", "\n".join(lines))
        return

    missing_or_failed = []
    opened_count = 0
    for addon_name, _enabled_setting, url_setting in stremio_addons_config():
        if url_setting == stremio_open_all_peerflix:
            url = peerflix_web_url
        else:
            url = (get_setting(url_setting) or "").strip()
        if not url:
            missing_or_failed.append(
                _t(
                    "{}: sin URL",
                    "{}: no URL",
                    "{} : sans URL",
                    "{}: senza URL",
                    "{}: keine URL",
                ).format(addon_name)
            )
            continue
        try:
            if webbrowser.open(url):
                opened_count += 1
            else:
                missing_or_failed.append(f"{addon_name}: {url}")
        except Exception:
            missing_or_failed.append(f"{addon_name}: {url}")

    if opened_count == 0 and not missing_or_failed:
        xbmcgui.Dialog().ok(
            "Kraken - Stremio",
            _t("No hay complementos Stremio activos.", "No active Stremio addons.", "Aucun addon Stremio actif.", "Nessun addon Stremio attivo.", "Keine aktiven Stremio-Add-ons."),
        )
        return

    if not missing_or_failed:
        xbmcgui.Dialog().notification(
            "Kraken - Stremio",
            _t(
                f"Abriendo {opened_count} configuraciones...",
                f"Opening {opened_count} configurations...",
                f"Ouverture de {opened_count} configurations...",
                f"Apertura di {opened_count} configurazioni...",
                f"Öffne {opened_count} Konfigurationen...",
            ),
            xbmcgui.NOTIFICATION_INFO,
        )
        return

    lines = [
        _t(f"Abiertas: {opened_count}", f"Opened: {opened_count}", f"Ouvertes : {opened_count}", f"Aperte: {opened_count}", f"Geöffnet: {opened_count}"),
        "",
        _t("Revisar manualmente:", "Check manually:", "Verifier manuellement :", "Controllare manualmente:", "Manuell prüfen:"),
    ]
    lines.extend(missing_or_failed)
    xbmcgui.Dialog().ok("Kraken - Stremio", "\n".join(lines))


def run_accounts_status(
    *,
    get_bool_setting,
    get_setting,
    get_stremio_toggle_names,
    tmdb_enabled,
    omdb_enabled,
    addon_path=None,
    qr_dialog_cls=None,
):
    trakt_enabled = get_bool_setting("trakt_enabled")
    trakt_access_token = (get_setting("trakt_access_token") or "").strip()
    trakt_info = (
        get_setting("trakt_account_info")
        or _t("No conectada", "Not connected", "Non connectée", "Non connessa", "Nicht verbunden")
    ).strip()

    stremio_toggle_names = get_stremio_toggle_names()
    stremio_count = len(stremio_toggle_names)

    lines = [
        _t("Stremio: {} ({} URL)", "Stremio: {} ({} URLs)", "Stremio : {} ({} URL)", "Stremio: {} ({} URL)", "Stremio: {} ({} URL)").format(
            _t("Configurado", "Configured", "Configuré", "Configurato", "Konfiguriert")
            if stremio_count
            else _t("Sin configurar", "Not configured", "Non configuré", "Non configurato", "Nicht konfiguriert"),
            stremio_count,
        ),
        _t("Trakt: {}", "Trakt: {}", "Trakt : {}", "Trakt: {}", "Trakt: {}").format(
            _t("Activado", "Enabled", "Activé", "Abilitato", "Aktiviert")
            if trakt_enabled
            else _t("Desactivado", "Disabled", "Désactivé", "Disabilitato", "Deaktiviert")
        ),
        _t("Trakt API: Configurado", "Trakt API: Configured", "API Trakt : configurée", "API Trakt: configurata", "Trakt-API: konfiguriert"),
        _t("Trakt Cuenta: {}", "Trakt Account: {}", "Compte Trakt : {}", "Account Trakt: {}", "Trakt-Konto: {}").format(
            _t("Autorizada", "Authorized", "Autorisée", "Autorizzata", "Autorisiert")
            if trakt_access_token
            else _t("No autorizada", "Not authorized", "Non autorisée", "Non autorizzata", "Nicht autorisiert")
        ),
        _t("Trakt Info: {}", "Trakt Info: {}", "Info Trakt : {}", "Info Trakt: {}", "Trakt-Info: {}").format(trakt_info),
        _t("Torrent / magnet: {}", "Torrent / magnet: {}", "Torrent / magnet : {}", "Torrent / magnet: {}", "Torrent / Magnet: {}").format(
            (get_setting("torrent_player") or _t("Directo (Kodi)", "Direct (Kodi)", "Direct (Kodi)", "Diretto (Kodi)", "Direkt (Kodi)")).strip()
        ),
        _t("TMDB: {}", "TMDB: {}", "TMDB : {}", "TMDB: {}", "TMDB: {}").format(
            _t("Activado", "Enabled", "Activé", "Abilitato", "Aktiviert")
            if tmdb_enabled()
            else _t("Desactivado", "Disabled", "Désactivé", "Disabilitato", "Deaktiviert")
        ),
        _t("OMDb: {}", "OMDb: {}", "OMDb : {}", "OMDb: {}", "OMDb: {}").format(
            _t("Activado", "Enabled", "Activé", "Abilitato", "Aktiviert")
            if omdb_enabled()
            else _t("Desactivado", "Disabled", "Désactivé", "Disabilitato", "Deaktiviert")
        ),
    ]
    if stremio_toggle_names:
        lines.append(_t("Complementos: {}", "Addons: {}", "Addons : {}", "Addon: {}", "Add-ons: {}").format(", ".join(stremio_toggle_names)))
    lines.append(_t("Debrid (por proveedor):", "Debrid (by provider):", "Debrid (par fournisseur) :", "Debrid (per provider):", "Debrid (pro Anbieter):"))
    for p in PROVIDERS:
        on = get_bool_setting(p["enabled_key"])
        tok_key = p.get("token_key")
        if tok_key:
            tok_ok = bool((get_setting(tok_key) or "").strip())
            tok_s = _t("token OK", "token OK", "jeton OK", "token OK", "Token OK") if tok_ok else _t("sin token", "no token", "sans jeton", "senza token", "kein Token")
        else:
            tok_s = _t("sin API token", "no API token", "sans jeton API", "senza token API", "kein API-Token")
        info = (get_setting(p["info_key"]) or _t("No conectada", "Not connected", "Non connectée", "Non connessa", "Nicht verbunden")).strip()
        lines.append(
            "  {}: {} | {} | {}".format(p["title"], "ON" if on else "OFF", tok_s, info)
        )
    xbmcgui.Dialog().ok(
        _t("Kraken - Estado", "Kraken - Status", "Kraken - Etat", "Kraken - Stato", "Kraken - Status"),
        "\n".join(lines),
    )

    if not addon_path or not qr_dialog_cls:
        return

    portals = (
        (
            _t(
                "Trakt (activar cuenta)",
                "Trakt (activate)",
                "Trakt (activer)",
                "Trakt (attiva)",
                "Trakt (aktivieren)",
            ),
            "https://trakt.tv/activate",
            _t(
                "Kraken - Trakt (activar)",
                "Kraken - Trakt (activate)",
                "Kraken - Trakt (activation)",
                "Kraken - Trakt (attiva)",
                "Kraken - Trakt aktivieren",
            ),
        ),
        (
            _t(
                "AllDebrid (PIN)",
                "AllDebrid (PIN)",
                "AllDebrid (PIN)",
                "AllDebrid (PIN)",
                "AllDebrid (PIN)",
            ),
            "https://alldebrid.com/pin/",
            "Kraken - AllDebrid (PIN)",
        ),
    )
    labels = [_t("— Cerrar —", "— Close —", "— Fermer —", "— Chiudi —", "— Schließen —")]
    labels.extend(p[0] for p in portals)
    hdr = _t(
        "Codigo QR de portales (Trakt / Debrid)",
        "Account portal QR codes (Trakt / Debrid)",
    )
    ix = xbmcgui.Dialog().select(hdr, labels)
    if ix < 1 or ix >= len(labels):
        return
    portal = portals[ix - 1]
    open_url_or_show(url=portal[1], title=portal[2], addon_path=addon_path, qr_dialog_cls=qr_dialog_cls)
