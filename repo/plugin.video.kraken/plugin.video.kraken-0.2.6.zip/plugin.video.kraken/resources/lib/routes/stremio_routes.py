import webbrowser
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

import xbmcgui

from resources.lib.core.kraken_qr_ui import (
    open_kraken_qr_modal,
    write_qr_png_to_special_temp,
)
from resources.lib.ui.ui_helpers import _t


def _force_spanish_config_url(url):
    """
    Si es una URL de configuración web, intenta fijar idioma español.
    No toca manifiestos ni URLs no configurables.
    """
    raw = str(url or "").strip()
    if not raw:
        return ""
    low = raw.lower()
    if "/configure" not in low and "/config" not in low and "/settings" not in low:
        return raw
    try:
        parts = urlsplit(raw)
        query = dict(parse_qsl(parts.query, keep_blank_values=True))
        # Muchos addons usan lang=es; algunos esperan language=es.
        if not str(query.get("lang") or "").strip():
            query["lang"] = "es"
        if not str(query.get("language") or "").strip():
            query["language"] = "es"
        new_q = urlencode(query, doseq=True)
        return urlunsplit(
            (parts.scheme, parts.netloc, parts.path, new_q, parts.fragment)
        )
    except Exception:
        return raw


def stremio_url_setting_id(addon_key):
    mapping = {
        "tvvoo": "stremio_tvvoo_url",
        "comet": "stremio_comet_url",
        "mediafusion": "stremio_mediafusion_url",
        "aiostreams": "stremio_aiostreams_url",
        "jackettio": "stremio_jackettio_url",
        "knightcrawler": "stremio_knightcrawler_url",
        "annatar": "stremio_annatar_url",
        "preeflix": "stremio_preeflix_url",
        "torrentio": "stremio_torrentio_url",
    }
    return mapping.get((addon_key or "").strip().lower(), "")


def stremio_web_url_setting_id(addon_key):
    mapping = {
        "tvvoo": "stremio_tvvoo_web_url",
        "comet": "stremio_comet_web_url",
        "mediafusion": "stremio_mediafusion_web_url",
        "aiostreams": "stremio_aiostreams_web_url",
        "jackettio": "stremio_jackettio_web_url",
        "knightcrawler": "stremio_knightcrawler_web_url",
        "annatar": "stremio_annatar_web_url",
        "preeflix": "stremio_preeflix_web_url",
        "torrentio": "stremio_torrentio_web_url",
    }
    return mapping.get((addon_key or "").strip().lower(), "")


def open_url_or_show(*, url, title, addon_path, qr_dialog_cls):
    url = _force_spanish_config_url(url)
    if not url:
        xbmcgui.Dialog().ok(
            title,
            _t(
                "No hay URL configurada para este complemento.",
                "No URL configured for this addon.",
                "Aucune URL configuree pour cet addon.",
                "Nessun URL configurato per questo addon.",
                "Keine URL für dieses Add-on konfiguriert.",
            ),
        )
        return

    qr_path = write_qr_png_to_special_temp(
        "kraken_stremio_config_qr.png", url, scale=5, border=4
    )

    opened = False
    try:
        opened = bool(webbrowser.open(url))
    except Exception:
        opened = False

    if not opened:
        xbmcgui.Dialog().notification(
            title,
            _t(
                "No se pudo abrir navegador",
                "Could not open browser",
                "Impossible d'ouvrir le navigateur",
                "Impossibile aprire il browser",
                "Browser konnte nicht geöffnet werden",
            ),
            xbmcgui.NOTIFICATION_WARNING,
            3000,
        )

    if not qr_path:
        xbmcgui.Dialog().ok(
            title,
            _t(
                f"{url}\n\nNo se pudo generar el código QR en local.",
                f"{url}\n\nCould not generate local QR code.",
                f"{url}\n\nImpossible de générer le code QR local.",
                f"{url}\n\nImpossibile generare il codice QR locale.",
                f"{url}\n\nLokaler QR-Code konnte nicht erzeugt werden.",
            ),
        )
        return

    open_kraken_qr_modal(
        qr_dialog_cls,
        addon_path,
        dialog_title=title,
        body_text=url,
        qr_special_path=qr_path,
    )


def run_stremio_open_config(
    *,
    addon_key,
    peerflix_web_url,
    get_setting,
    addon_path,
    qr_dialog_cls,
):
    key = (addon_key or "").strip().lower()
    if key == "peerflix":
        open_url_or_show(
            url=peerflix_web_url,
            title="Kraken - Stremio (Peerflix)",
            addon_path=addon_path,
            qr_dialog_cls=qr_dialog_cls,
        )
        return
    web_setting = stremio_web_url_setting_id(addon_key)
    plain_setting = stremio_url_setting_id(addon_key)
    url = (get_setting(web_setting) or "").strip() if web_setting else ""
    if not url and plain_setting:
        url = (get_setting(plain_setting) or "").strip()
    title = "Kraken - Stremio"
    if key == "aiostreams":
        title = "Kraken - Stremio (AIOStreams)"
    elif key == "comet":
        title = "Kraken - Stremio (Comet)"
    elif key == "mediafusion":
        title = "Kraken - Stremio (MediaFusion)"
    elif key == "torrentio":
        title = "Kraken - Stremio (Torrentio)"
    elif key == "jackettio":
        title = "Kraken - Stremio (Jackettio)"
    elif key == "knightcrawler":
        title = "Kraken - Stremio (KnightCrawler)"
    elif key == "annatar":
        title = "Kraken - Stremio (Annatar)"
    elif key == "preeflix":
        title = "Kraken - Stremio (Preeflix)"
    elif key == "tvvoo":
        title = "Kraken - Stremio (Tvvoo)"
    open_url_or_show(
        url=url,
        title=title,
        addon_path=addon_path,
        qr_dialog_cls=qr_dialog_cls,
    )
