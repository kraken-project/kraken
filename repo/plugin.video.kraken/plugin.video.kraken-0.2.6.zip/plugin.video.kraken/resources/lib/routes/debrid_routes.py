from urllib.parse import urlencode

import xbmcgui

from resources.lib.core.debrid_provider_config import provider_by_slug
from resources.lib.ui.ui_helpers import _t


def run_debrid_provider_connect(
    *,
    slug,
    get_bool_setting,
    set_setting,
    alldebrid_pin_authorize,
):
    cfg = provider_by_slug(slug)
    if not cfg:
        xbmcgui.Dialog().ok(
            "Kraken - Debrid",
            _t("Proveedor desconocido.", "Unknown provider.", "Fournisseur inconnu.", "Provider sconosciuto.", "Unbekannter Anbieter."),
        )
        return
    if not get_bool_setting(cfg["enabled_key"]):
        if not xbmcgui.Dialog().yesno(
            "Kraken - Debrid",
            _t(
                "«{}» está desactivado.\n\n¿Quieres activarlo ahora y continuar con la conexión?",
                '"{}" is disabled.\n\nDo you want to enable it now and continue connecting?',
                "«{}» est désactivé.\n\nVoulez-vous l'activer maintenant et continuer la connexion ?",
                '"{}" è disabilitato.\n\nVuoi abilitarlo ora e continuare la connessione?',
                "„{}“ ist deaktiviert.\n\nMöchtest du es jetzt aktivieren und mit der Verbindung fortfahren?",
            ).format(cfg["title"]),
            yeslabel=_t("Activar y continuar", "Enable and continue", "Activer et continuer", "Abilita e continua", "Aktivieren und fortfahren"),
            nolabel=_t("Cancelar", "Cancel", "Annuler", "Annulla", "Abbrechen"),
        ):
            return
        try:
            set_setting(cfg["enabled_key"], True)
        except Exception:
            try:
                set_setting(cfg["enabled_key"], "true")
            except Exception:
                xbmcgui.Dialog().ok(
                    "Kraken - Debrid",
                    _t(
                        "No se pudo activar «{}» automáticamente.",
                        'Could not enable "{}" automatically.',
                        'Impossible d\'activer "{}" automatiquement.',
                        'Impossibile abilitare "{}" automaticamente.',
                        '"{}" konnte nicht automatisch aktiviert werden.',
                    ).format(cfg["title"]),
                )
                return
    if slug == "alldebrid":
        alldebrid_pin_authorize()
        return
    if slug == "rapidgator":
        xbmcgui.Dialog().ok(
            "Kraken - Debrid (Rapidgator)",
            _t(
                "Rapidgator no tiene API token en Kraken.\n\n"
                "El desbridado de magnetes y enlaces usa AllDebrid si lo tienes conectado.",
                "Rapidgator has no API token support in Kraken.\n\n"
                "Magnet/link unrestrict uses AllDebrid if connected.",
                "Rapidgator n'a pas de support de token API dans Kraken.\n\n"
                "Le débridage magnet/lien utilise AllDebrid si connecté.",
                "Rapidgator non supporta token API in Kraken.\n\n"
                "Lo sblocco magnet/link usa AllDebrid se connesso.",
                "Rapidgator unterstützt in Kraken kein API-Token.\n\n"
                "Magnet-/Link-Unlock nutzt AllDebrid, wenn verbunden.",
            ),
        )
        set_setting(
            cfg["info_key"],
            _t(
                "Rapidgator: sin API en Kraken",
                "Rapidgator: no API in Kraken",
                "Rapidgator : pas d'API dans Kraken",
                "Rapidgator: nessuna API in Kraken",
                "Rapidgator: keine API in Kraken",
            ),
        )
        return


def run_debrid_provider_disconnect(*, slug, set_setting):
    cfg = provider_by_slug(slug)
    if not cfg:
        return
    tk = cfg.get("token_key")
    if tk:
        set_setting(tk, "")
    rk = cfg.get("refresh_key")
    if rk:
        set_setting(rk, "")
    set_setting(
        cfg["info_key"],
        _t("No conectada", "Not connected", "Non connecté", "Non connesso", "Nicht verbunden"),
    )
    xbmcgui.Dialog().ok(
        "Kraken - Debrid",
        _t(
            "Sesion cerrada: {}.",
            "Signed out: {}.",
            "Session fermée : {}.",
            "Sessione chiusa: {}.",
            "Sitzung beendet: {}.",
        ).format(cfg["title"]),
    )


def run_debrid_provider_test(
    *, slug, get_bool_setting, get_setting, set_setting, json_get
):
    cfg = provider_by_slug(slug)
    if not cfg:
        return
    if not get_bool_setting(cfg["enabled_key"]):
        xbmcgui.Dialog().ok(
            "Kraken - Debrid",
            _t(
                'Activa primero «{}» en los ajustes.',
                'Enable "{}" first in settings.',
                'Active d\'abord «{}» dans les paramètres.',
                'Attiva prima «{}» nelle impostazioni.',
                'Aktiviere zuerst „{}“ in den Einstellungen.',
            ).format(
                cfg["title"]
            ),
        )
        return
    title = cfg["title"]
    if slug == "rapidgator":
        xbmcgui.Dialog().ok(
            "Kraken - Debrid",
            _t(
                "Rapidgator: no hay token API que validar en Kraken.",
                "Rapidgator: there is no API token to validate in Kraken.",
                "Rapidgator : aucun jeton API à valider dans Kraken.",
                "Rapidgator: nessun token API da validare in Kraken.",
                "Rapidgator: kein API-Token in Kraken zu validieren.",
            ),
        )
        return
    token_key = cfg.get("token_key")
    if not token_key:
        return
    token = (get_setting(token_key) or "").strip()
    if not token:
        set_setting(
            cfg["info_key"],
            _t(
                "Error de validacion: sin token ({})",
                "Validation error: no token ({})",
                "Erreur de validation : pas de jeton ({})",
                "Errore di validazione: nessun token ({})",
                "Validierungsfehler: kein Token ({})",
            ).format(
                title
            ),
        )
        xbmcgui.Dialog().ok(
            "Kraken - Debrid",
            _t(
                "No hay token guardado para {}.",
                "No saved token for {}.",
                "Aucun jeton enregistré pour {}.",
                "Nessun token salvato per {}.",
                "Kein gespeichertes Token für {}.",
            ).format(title),
        )
        return

    ok = False
    info_label = ""
    try:
        if slug == "alldebrid":
            data = json_get(
                "https://api.alldebrid.com/v4/user?{}".format(
                    urlencode({"apikey": token, "agent": "KrakenKodi"})
                )
            )
            ok = data.get("status") == "success"
            user = (data.get("data") or {}).get("user") or {}
            info_label = user.get("username", "") or user.get("email", "")
    except Exception:
        ok = False

    if ok:
        set_setting(
            cfg["info_key"],
            _t(
                "Conectada: {} {}",
                "Connected: {} {}",
                "Connecté : {} {}",
                "Connesso: {} {}",
                "Verbunden: {} {}",
            ).format(title, info_label or "OK"),
        )
        xbmcgui.Dialog().ok(
            "Kraken - Debrid",
            _t(
                "Cuenta valida para {}.",
                "Valid account for {}.",
                "Compte valide pour {}.",
                "Account valido per {}.",
                "Gültiges Konto für {}.",
            ).format(title),
        )
    else:
        set_setting(
            cfg["info_key"],
            _t(
                "Error de validacion: {}",
                "Validation error: {}",
                "Erreur de validation : {}",
                "Errore di validazione: {}",
                "Validierungsfehler: {}",
            ).format(title),
        )
        xbmcgui.Dialog().ok(
            "Kraken - Debrid",
            _t(
                "No se pudo validar {}.",
                "Could not validate {}.",
                "Impossible de valider {}.",
                "Impossibile validare {}.",
                "{} konnte nicht validiert werden.",
            ).format(title),
        )


def run_debrid_provider_show_info(*, slug, get_bool_setting, get_setting):
    cfg = provider_by_slug(slug)
    if not cfg:
        return
    title = cfg["title"]
    on = get_bool_setting(cfg["enabled_key"])
    tok_key = cfg.get("token_key")
    if tok_key:
        has_tok = bool((get_setting(tok_key) or "").strip())
        tok_line = _t(
            "Token guardado: {}",
            "Saved token: {}",
            "Jeton enregistré : {}",
            "Token salvato: {}",
            "Gespeichertes Token: {}",
        ).format(
            _t("Si", "Yes", "Oui", "Sì", "Ja")
            if has_tok
            else _t("No", "No", "Non", "No", "Nein")
        )
    else:
        tok_line = _t(
            "Token API: no aplica en Kraken",
            "API token: not applicable in Kraken",
            "Jeton API : non applicable dans Kraken",
            "Token API: non applicabile in Kraken",
            "API-Token: in Kraken nicht anwendbar",
        )
    info = (
        get_setting(cfg["info_key"])
        or _t("Sin informacion", "No information", "Sans information", "Nessuna informazione", "Keine Informationen")
    ).strip()
    body = "\n".join(
        [
            _t("Proveedor: {}", "Provider: {}", "Fournisseur : {}", "Provider: {}", "Anbieter: {}").format(title),
            _t("Activado en ajustes: {}", "Enabled in settings: {}", "Activé dans les paramètres : {}", "Abilitato nelle impostazioni: {}", "In Einstellungen aktiviert: {}").format(
                _t("Si", "Yes", "Oui", "Sì", "Ja")
                if on
                else _t("No", "No", "Non", "No", "Nein")
            ),
            tok_line,
            "",
            _t("Estado / cuenta:", "Status / account:", "État / compte :", "Stato / account:", "Status / Konto:"),
            info,
        ]
    )
    xbmcgui.Dialog().ok(
        _t("Kraken - Debrid - Info", "Kraken - Debrid - Info", "Kraken - Debrid - Infos", "Kraken - Debrid - Info", "Kraken - Debrid - Info"),
        body,
    )
