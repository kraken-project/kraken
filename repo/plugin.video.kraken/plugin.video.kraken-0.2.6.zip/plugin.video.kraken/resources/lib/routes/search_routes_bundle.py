def run_search_folder_route(
    *,
    run_search_folder,
    plugin_handle,
    default_list_art,
    url_for_search_all,
    url_for_search_movies,
    url_for_search_series,
    url_for_search_anime,
    url_for_search_movies_by_actor,
    url_for_search_series_by_actor,
    url_for_search_history,
):
    run_search_folder(
        plugin_handle=plugin_handle,
        default_list_art=default_list_art,
        url_for_search_all=url_for_search_all,
        url_for_search_movies=url_for_search_movies,
        url_for_search_series=url_for_search_series,
        url_for_search_anime=url_for_search_anime,
        url_for_search_movies_by_actor=url_for_search_movies_by_actor,
        url_for_search_series_by_actor=url_for_search_series_by_actor,
        url_for_search_history=url_for_search_history,
    )


def run_search_history_route(
    *,
    run_search_history,
    plugin_handle,
    default_list_art,
    search_history_load,
    url_for_search_history_clear,
    url_for_search_history_delete,
    url_for_search_history_run,
    url_for_noop,
):
    run_search_history(
        plugin_handle=plugin_handle,
        default_list_art=default_list_art,
        search_history_load=search_history_load,
        url_for_search_history_clear=url_for_search_history_clear,
        url_for_search_history_delete=url_for_search_history_delete,
        url_for_search_history_run=url_for_search_history_run,
        url_for_noop=url_for_noop,
    )


def run_search_history_run_route(
    *,
    run_search_history_run,
    token,
    search_history_token_read,
    run_actor_listing,
    run_search_trakt_media,
    plugin_handle,
):
    run_search_history_run(
        token=token,
        search_history_token_read=search_history_token_read,
        run_actor_listing=run_actor_listing,
        run_search_trakt_media=run_search_trakt_media,
        plugin_handle=plugin_handle,
    )


def run_search_history_delete_route(
    *,
    run_search_history_delete,
    token,
    search_history_token_read,
    search_history_load,
    search_history_save,
    plugin_handle,
):
    run_search_history_delete(
        token=token,
        search_history_token_read=search_history_token_read,
        search_history_load=search_history_load,
        search_history_save=search_history_save,
        plugin_handle=plugin_handle,
    )


def run_search_history_clear_route(
    *, run_search_history_clear, search_history_save, plugin_handle
):
    run_search_history_clear(
        search_history_save=search_history_save, plugin_handle=plugin_handle
    )


def run_simple_search_route(
    *,
    run_simple_search,
    mode,
    search_trakt_media,
    plugin_handle,
    search_history_last=None,
):
    run_simple_search(
        mode=mode,
        plugin_handle=plugin_handle,
        search_trakt_media=search_trakt_media,
        search_history_last=search_history_last,
    )
