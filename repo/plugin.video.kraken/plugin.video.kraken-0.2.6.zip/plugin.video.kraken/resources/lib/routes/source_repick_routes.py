import xbmc
import xbmcgui

from resources.lib.core.kodi_run_plugin import escape_for_quoted_builtin
from resources.lib.core.playback_listitem import configure_listitem_stream_properties
from resources.lib.ui.ui_helpers import _t


def run_source_repick(*, pick_stream_dialog, finalize_playback_stream_url):
    from resources.lib.core.playback_source_stash import (
        get_stash_context,
        load_stashed_candidates,
    )

    ctx = get_stash_context()
    title = (
        _t(
            f"Kraken - Otra fuente ({ctx})",
            f"Kraken - Another source ({ctx})",
            f"Kraken - Autre source ({ctx})",
            f"Kraken - Altra fonte ({ctx})",
            f"Kraken - Andere Quelle ({ctx})",
        )
        if ctx
        else _t(
            "Kraken - Otra fuente",
            "Kraken - Another source",
            "Kraken - Autre source",
            "Kraken - Altra fonte",
            "Kraken - Andere Quelle",
        )
    )
    cands = load_stashed_candidates()
    if not cands:
        xbmcgui.Dialog().ok(
            "Kraken",
            _t(
                "No hay fuentes guardadas.\n\nVuelve a abrir el título desde el listado.",
                "There are no saved sources.\n\nOpen the title again from the list.",
                "Aucune source sauvegardée.\n\nRouvre le titre depuis la liste.",
                "Nessuna fonte salvata.\n\nRiapri il titolo dalla lista.",
                "Keine gespeicherten Quellen.\n\nÖffne den Titel erneut aus der Liste.",
            ),
        )
        return
    playback_kind = None
    try:
        wkind = str(
            xbmcgui.Window(10000).getProperty("Kraken.LastPlaybackKind") or ""
        ).strip().lower()
        if wkind == "movie":
            playback_kind = "movie"
        elif wkind == "episode":
            playback_kind = "episode"
    except Exception:
        playback_kind = None

    if len(cands) == 1:
        if not xbmcgui.Dialog().yesno(
            "Kraken",
            _t(
                "Solo hay una fuente en la lista guardada.\n\n¿Reintentar la misma?",
                "There is only one source in the saved list.\n\nRetry the same one?",
                "Une seule source dans la liste sauvegardée.\n\nRéessayer la même ?",
                "C'è solo una fonte nella lista salvata.\n\nRiprovare la stessa?",
                "Nur eine Quelle in der gespeicherten Liste.\n\nDieselbe erneut versuchen?",
            ),
            nolabel=_t("Cancelar", "Cancel", "Annuler", "Annulla", "Abbrechen"),
            yeslabel=_t("Reintentar", "Retry", "Reessayer", "Riprova", "Erneut versuchen"),
        ):
            return
        stream_url = str((cands[0] or {}).get("url") or "").strip()
    else:
        stream_url = pick_stream_dialog(
            title, cands, playback_kind=playback_kind
        )
    if not stream_url:
        return
    path = finalize_playback_stream_url(stream_url)
    if not path:
        return
    try:
        w = xbmcgui.Window(10000)
        w.setProperty("Kraken.LastPlaybackAttemptUrl", str(path))
        w.clearProperty("Kraken.FallbackAutoAttempts")
    except Exception:
        pass
    li = xbmcgui.ListItem(path=str(path), label="Kraken")
    li.setProperty("IsPlayable", "true")
    try:
        li.setContentLookup(False)
    except Exception:
        pass
    configure_listitem_stream_properties(li, path)
    xbmc.sleep(150)
    ok = False
    pl = xbmc.Player()
    try:
        pl.play(str(path), li, False)
        ok = True
    except Exception as ex:
        xbmc.log(f"[Kraken] repick Player.play: {ex}", xbmc.LOGWARNING)
    if not ok:
        try:
            plv = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            plv.clear()
            plv.add(str(path), li)
            pl.play(plv, li, False)
            ok = True
        except Exception as ex:
            xbmc.log(f"[Kraken] repick PlayList: {ex}", xbmc.LOGWARNING)
    if not ok:
        try:
            xbmc.executebuiltin(f'PlayMedia("{escape_for_quoted_builtin(path)}")')
            ok = True
        except Exception as ex:
            xbmc.log(f"[Kraken] repick PlayMedia: {ex}", xbmc.LOGWARNING)
    if not ok:
        xbmcgui.Dialog().ok(
            "Kraken",
            _t(
                "No se pudo iniciar la reproducción con la fuente elegida.",
                "Could not start playback with the selected source.",
                "Impossible de démarrer la lecture avec la source choisie.",
                "Impossibile avviare la riproduzione con la fonte selezionata.",
                "Wiedergabe mit der gewählten Quelle konnte nicht gestartet werden.",
            ),
        )
