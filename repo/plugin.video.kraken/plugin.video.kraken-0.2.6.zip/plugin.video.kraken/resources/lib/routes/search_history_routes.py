import base64
import json
import time

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.ui.video_info import apply_video_info
from resources.lib.ui.ui_helpers import _t


def run_search_history(
    *,
    plugin_handle,
    default_list_art,
    search_history_load,
    url_for_search_history_clear,
    url_for_search_history_delete,
    url_for_search_history_run,
    url_for_noop,
):
    xbmcplugin.setPluginCategory(
        plugin_handle,
        _t(
            "Kraken - Historial de búsquedas",
            "Kraken - Search history",
            "Kraken - Historique des recherches",
            "Kraken - Cronologia ricerche",
            "Kraken - Suchverlauf",
        ),
    )
    xbmcplugin.setContent(plugin_handle, "files")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_NONE)
    base_art = default_list_art()
    items = search_history_load()
    directory = []

    li_clear = xbmcgui.ListItem(
        label=_t("Borrar historial completo", "Clear full history", "Effacer tout l'historique", "Cancella cronologia completa", "Gesamten Verlauf löschen"),
    )
    apply_video_info(
        li_clear,
        {
            "title": _t("Borrar historial completo", "Clear full history", "Effacer tout l'historique", "Cancella cronologia completa", "Gesamten Verlauf löschen"),
            "mediatype": "video",
        },
    )
    li_clear.setArt(base_art)
    li_clear.setProperty("IsPlayable", "false")
    li_clear.addContextMenuItems(
        [
            (
                _t("Borrar historial completo", "Clear full history", "Effacer tout l'historique", "Cancella cronologia completa", "Gesamten Verlauf löschen"),
                f"RunPlugin({url_for_search_history_clear()})",
            )
        ]
    )
    directory.append((url_for_search_history_clear(), li_clear, False))

    for it in items:
        q = str((it or {}).get("q") or "").strip()
        if not q:
            continue
        media = str((it or {}).get("media") or "all").strip().lower()
        ts = int((it or {}).get("ts") or 0)
        when = ""
        if ts > 0:
            try:
                when = time.strftime("%d/%m %H:%M", time.localtime(ts))
            except Exception:
                when = ""
        suffix = {
            "movie": _t("Películas", "Movies", "Films", "Film", "Filme"),
            "show": _t("Series", "TV Shows", "Séries", "Serie TV", "Serien"),
            "all": _t("Todo", "All", "Tout", "Tutto", "Alle"),
            "actor_movie": _t("Actor/actriz · Películas", "Actor · Movies", "Acteur/actrice · Films", "Attore/attrice · Film", "Schauspieler/in · Filme"),
            "actor_show": _t("Actor/actriz · Series", "Actor · TV Shows", "Acteur/actrice · Séries", "Attore/attrice · Serie TV", "Schauspieler/in · Serien"),
        }.get(media, _t("Todo", "All", "Tout", "Tutto", "Alle"))
        sub = "{}{}".format(suffix, f"  ·  {when}" if when else "")
        li = xbmcgui.ListItem(label=q, label2=sub)
        apply_video_info(li, {"title": q, "plot": sub, "mediatype": "video"})
        li.setArt(base_art)
        li.setProperty("IsPlayable", "false")
        tok = (
            base64.urlsafe_b64encode(
                json.dumps(
                    {"q": q, "m": media}, ensure_ascii=False, separators=(",", ":")
                ).encode("utf-8")
            )
            .decode("ascii")
            .rstrip("=")
        )
        li.addContextMenuItems(
            [
                (
                    _t("Eliminar esta búsqueda", "Delete this search", "Supprimer cette recherche", "Elimina questa ricerca", "Diese Suche löschen"),
                    f"RunPlugin({url_for_search_history_delete(tok)})",
                ),
                (
                    _t("Borrar historial completo", "Clear full history", "Effacer tout l'historique", "Cancella cronologia completa", "Gesamten Verlauf löschen"),
                    f"RunPlugin({url_for_search_history_clear()})",
                ),
            ]
        )
        u = url_for_search_history_run(tok)
        directory.append((u, li, True))

    if len(directory) == 1:
        li = xbmcgui.ListItem(
            label=_t("(Historial vacío)", "(Empty history)", "(Historique vide)", "(Cronologia vuota)", "(Leerer Verlauf)")
        )
        li.setArt(base_art)
        li.setProperty("IsPlayable", "false")
        directory.append((url_for_noop(), li, False))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)


def run_search_history_run(
    *,
    token,
    search_history_token_read,
    run_actor_listing,
    run_search_trakt_media,
    plugin_handle,
):
    q, m = search_history_token_read(token)
    if not q:
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    if m == "actor_movie":
        run_actor_listing("movie", forced_query=q)
        return
    if m == "actor_show":
        run_actor_listing("show", forced_query=q)
        return
    run_search_trakt_media(m, forced_query=q)


def run_search_history_delete(
    *,
    token,
    search_history_token_read,
    search_history_load,
    search_history_save,
    plugin_handle,
):
    q, m = search_history_token_read(token)
    if q:
        left = []
        for it in search_history_load():
            same_q = str(it.get("q") or "").strip().lower() == q.lower()
            same_m = str(it.get("media") or "all").strip().lower() == m
            if same_q and same_m:
                continue
            left.append(it)
        search_history_save(left)
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(plugin_handle, True)


def run_search_history_clear(*, search_history_save, plugin_handle):
    search_history_save([])
    xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(plugin_handle, True)
