import traceback

import xbmc
import xbmcgui
import xbmcplugin
from routing import RoutingError

from resources.lib.routes.root_routes import _item_art_with_icon
from resources.lib.ui.tv_nav_icons import (
    tv_listitem_art_category,
    tv_listitem_art_country,
)
from resources.lib.ui.video_info import apply_video_info
from resources.lib.ui.ui_helpers import _t


def _tv_genre_label_es(raw_genre, _catalog_id=""):
    raw = str(raw_genre or "").strip()
    if not raw:
        return ""
    low = raw.lower()

    # Main normalization categories (localized output)
    if low in ("tutti", "all", "todas", "todo"):
        return _t("Todas", "All", "Toutes", "Tutte", "Alle")
    if any(
        x in low
        for x in ("sport", "deport", "futbol", "football", "nba", "ufc", "tennis", "f1")
    ):
        return _t("Deportes", "Sports", "Sports", "Sport", "Sport")
    if any(x in low for x in ("news", "notic")):
        return _t("Noticias", "News", "Actualités", "Notizie", "Nachrichten")
    if any(x in low for x in ("movie", "cine", "film", "pelic")):
        return _t("Cine", "Movies", "Films", "Film", "Filme")
    if any(x in low for x in ("serie", "show", "tv show")):
        return _t("Series", "TV Shows", "Séries", "Serie TV", "Serien")
    if any(x in low for x in ("kids", "child", "infantil", "cartoon", "anime")):
        return _t("Infantil", "Kids", "Enfants", "Bambini", "Kinder")
    if any(x in low for x in ("docu", "history", "nature")):
        return _t("Documentales", "Documentaries", "Documentaires", "Documentari", "Dokumentationen")
    if any(x in low for x in ("music", "musica", "radio", "concert")):
        return _t("Música", "Music", "Musique", "Musica", "Musik")
    if any(x in low for x in ("entertain", "variety", "reality", "comedy")):
        return _t("Entretenimiento", "Entertainment", "Divertissement", "Intrattenimento", "Unterhaltung")
    if any(x in low for x in ("general", "nacional", "nazional", "public", "tdt")):
        return _t("Generalistas", "General", "Généralistes", "Generalisti", "Allgemein")
    if any(x in low for x in ("world", "internacional", "global")):
        return _t("Internacional", "International", "International", "Internazionale", "International")
    if any(x in low for x in ("local", "regional", "autonom")):
        return _t("Autonómicas y locales", "Regional and local", "Régionales et locales", "Regionali e locali", "Regional und lokal")
    return raw


def _tv_genre_visible(raw_genre):
    g = str(raw_genre or "").strip().lower()
    if not g:
        return False
    # Oculta entradas tecnicas/no navegables
    if any(x in g for x in ("search", "buscar", "query", "vavoo_search")):
        return False
    return True


def _tv_genre_sort_key_es(label):
    value = str(label or "").strip().lower()
    order = [
        _t("tdt espana", "tdt spain", "tdt espagne", "tdt spagna", "tdt spanien"),
        _t("todas", "all", "toutes", "tutte", "alle"),
        _t("deportes", "sports", "sports", "sport", "sport"),
        _t("noticias", "news", "actualités", "notizie", "nachrichten"),
        _t("cine", "movies", "films", "film", "filme"),
        _t("series", "tv shows", "séries", "serie tv", "serien"),
        _t("infantil", "kids", "enfants", "bambini", "kinder"),
        _t("documentales", "documentaries", "documentaires", "documentari", "dokumentationen"),
        _t("entretenimiento", "entertainment", "divertissement", "intrattenimento", "unterhaltung"),
        _t("musica", "music", "musique", "musica", "musik"),
        _t("generalistas", "general", "généralistes", "generalisti", "allgemein"),
        _t("autonómicas y locales", "regional and local", "régionales et locales", "regionali e locali", "regional und lokal"),
        _t("internacional", "international", "international", "internazionale", "international"),
    ]
    try:
        idx = order.index(value)
        return (0, idx, value)
    except ValueError:
        return (1, 999, value)


def run_tv_pais_categorias(
    *,
    plugin_handle,
    token,
    get_stremio_provider,
    query_arg_first_str,
    tv_catalog_token_read,
    default_list_art,
    tv_catalog_token_dict,
    url_for_tv_browse_channel,
    url_for_noop,
):
    """Categorias (Tutti, Deportes, etc.) como Tvvoo en Stremio; luego se abre /tv/c con genre."""
    provider = get_stremio_provider()
    if not provider:
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    token_value = (
        (token or "").replace(" ", "").strip() if (token and str(token).strip()) else ""
    )
    if not token_value:
        token_value = query_arg_first_str("token", b"token", b"t", "t")
    media_type, catalog_id, _unused, catalog_display_name = tv_catalog_token_read(
        token_value
    )
    catalog_display_name = (catalog_display_name or "").strip() or catalog_id
    if not (catalog_id or "").strip():
        xbmcgui.Dialog().ok(
            "Kraken - TV",
            _t(
                "Enlace al país inválido. Vuelve a la lista y elige otra vez.",
                "Invalid country link. Return to the list and choose again.",
                "Lien de pays invalide. Retourne à la liste et réessaie.",
                "Link paese non valido. Torna alla lista e riprova.",
                "Ungültiger Länderlink. Zur Liste zurückkehren und erneut wählen.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    genre_options = provider.list_genre_options("Tvvoo", media_type, catalog_id) or []
    _mt = str(media_type or "tv").strip() or "tv"
    _cid = (str(catalog_id or "").strip() or _t("país", "country", "pays", "paese", "Land"))[:48]
    xbmcplugin.setPluginCategory(
        plugin_handle,
        _t(
            "Kraken - TV - {}/{}",
            "Kraken - TV - {}/{}",
            "Kraken - TV - {}/{}",
            "Kraken - TV - {}/{}",
            "Kraken - TV - {}/{}",
        ).format(_mt, _cid),
    )
    xbmcplugin.setContent(plugin_handle, "files")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_NONE)
    base_art = default_list_art()
    directory = []
    if not genre_options:
        li_fallback = xbmcgui.ListItem(
            label=_t(
                "(Sin categorías en manifiesto) - Abrir canales",
                "(No categories in manifest) - Open channels",
                "(Aucune catégorie dans le manifeste) - Ouvrir les chaînes",
                "(Nessuna categoria nel manifest) - Apri canali",
                "(Keine Kategorien im Manifest) - Sender öffnen",
            ),
            label2=catalog_id,
        )
        apply_video_info(
            li_fallback,
            {
                "title": _t("Canales", "Channels", "Chaînes", "Canali", "Sender"),
                "mediatype": "video",
            },
        )
        li_fallback.setArt(
            tv_listitem_art_category(
                base_art,
                catalog_id,
                catalog_display_name,
                "",
                _t("Canales", "Channels", "Chaînes", "Canali", "Sender"),
            )
        )
        li_fallback.setProperty("IsPlayable", "false")
        token_next = tv_catalog_token_dict(
            media_type, catalog_id, catalog_name=catalog_display_name
        )
        directory.append((url_for_tv_browse_channel(token_next), li_fallback, True))
    entries = []
    seen_labels = set()
    for genre in genre_options:
        if not _tv_genre_visible(genre):
            continue
        label_es = _tv_genre_label_es(genre, catalog_id)
        if not label_es:
            continue
        key = label_es.strip().lower()
        if key in seen_labels:
            continue
        seen_labels.add(key)
        entries.append((str(genre), label_es))
    entries.sort(key=lambda x: _tv_genre_sort_key_es(x[1]))

    for genre_raw, genre_label in entries:
        li = xbmcgui.ListItem(
            label=str(genre_label),
            label2=f"{media_type} / {catalog_id} / genre",
        )
        apply_video_info(li, {"title": str(genre_label), "mediatype": "video"})
        li.setArt(
            tv_listitem_art_category(
                base_art,
                catalog_id,
                catalog_display_name,
                str(genre_raw),
                str(genre_label),
            )
        )
        li.setProperty("IsPlayable", "false")
        token_next = tv_catalog_token_dict(
            media_type, catalog_id, genre=genre_raw, catalog_name=catalog_display_name
        )
        directory.append((url_for_tv_browse_channel(token_next), li, True))
    if not directory:
        li_empty = xbmcgui.ListItem(
            label=_t("Sin accesos", "No entries", "Aucune entrée", "Nessuna voce", "Keine Einträge")
        )
        li_empty.setProperty("IsPlayable", "false")
        li_empty.setArt(base_art)
        directory.append((url_for_noop(), li_empty, False))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)


def run_tv_browse(
    *,
    plugin_handle,
    get_bool_setting,
    get_stremio_provider,
    tvvoo_url,
    default_list_art,
    tv_catalog_token_dict,
    url_for_tv_browse_search,
    url_for_tv_pais_categorias,
    url_for_tv_browse_channel,
    url_for_noop,
):
    if not get_bool_setting("provider_stremio_catalog"):
        xbmcgui.Dialog().ok(
            "Kraken - TV",
            _t(
                "Activa Stremio (Proveedores) en Ajustes.",
                "Enable Stremio (Providers) in Settings.",
                "Active Stremio (Fournisseurs) dans les paramètres.",
                "Attiva Stremio (Provider) nelle impostazioni.",
                "Aktiviere Stremio (Anbieter) in den Einstellungen.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    provider = get_stremio_provider()
    if not provider or not tvvoo_url:
        xbmcgui.Dialog().ok(
            "Kraken - TV",
            _t(
                "Configura 'Tvvoo - URL manifiesto' y guarda, en Ajustes - Stremio.",
                "Set 'Tvvoo - Manifest URL' and save it in Settings - Stremio.",
                "Configure 'Tvvoo - URL du manifeste' puis enregistre dans Paramètres - Stremio.",
                "Configura 'Tvvoo - URL manifest' e salva in Impostazioni - Stremio.",
                "Setze 'Tvvoo - Manifest-URL' und speichere unter Einstellungen - Stremio.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    xbmcplugin.setPluginCategory(
        plugin_handle,
        _t("Kraken - TV (Tvvoo)", "Kraken - TV (Tvvoo)", "Kraken - TV (Tvvoo)", "Kraken - TV (Tvvoo)", "Kraken - TV (Tvvoo)"),
    )
    xbmcplugin.setContent(plugin_handle, "videos")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_NONE)
    base_art = default_list_art()
    directory = []
    li_search = xbmcgui.ListItem(
        label=_t("Buscar en Tvvoo", "Search in Tvvoo", "Rechercher dans Tvvoo", "Cerca in Tvvoo", "In Tvvoo suchen")
    )
    apply_video_info(
        li_search,
        {"title": _t("Buscar", "Search", "Rechercher", "Cerca", "Suchen"), "mediatype": "video"},
    )
    li_search.setArt(
        _item_art_with_icon(
            base_art,
            _t("Buscar en Tvvoo", "Search in Tvvoo", "Rechercher dans Tvvoo", "Cerca in Tvvoo", "In Tvvoo suchen"),
        )
    )
    li_search.setProperty("IsPlayable", "false")
    try:
        directory.append((url_for_tv_browse_search(), li_search, True))
        catalogs = provider.list_catalogs_for_types("Tvvoo", ("tv", "channel")) or []
        for catalog in catalogs:
            media_type = catalog.get("type", "tv")
            catalog_id = catalog.get("id", "")
            if not catalog_id:
                continue
            label = catalog.get("name", catalog_id) or catalog_id
            token = tv_catalog_token_dict(
                media_type, catalog_id, catalog_name=str(label or "").strip()
            )
            genre_options = catalog.get("genres") or []
            if genre_options:
                url = url_for_tv_pais_categorias(token)
            else:
                url = url_for_tv_browse_channel(token)
            li_item = xbmcgui.ListItem(
                label=label, label2=f"{media_type} / {catalog_id}"
            )
            apply_video_info(
                li_item,
                {
                    "title": label,
                    "mediatype": "tvshow",
                    "plot": catalog.get("name", ""),
                },
            )
            li_item.setArt(tv_listitem_art_country(base_art, catalog_id, label))
            li_item.setProperty("IsPlayable", "false")
            directory.append((url, li_item, True))
        if not catalogs and len(directory) <= 1:
            li_empty = xbmcgui.ListItem(
                label=_t(
                    "(El manifiesto Tvvoo no declara catalogos de tipo TV)",
                    "(Tvvoo manifest does not declare TV catalogs)",
                    "(Le manifeste Tvvoo ne déclare pas de catalogues TV)",
                    "(Il manifest Tvvoo non dichiara cataloghi TV)",
                    "(Tvvoo-Manifest deklariert keine TV-Kataloge)",
                ),
                label2=_t(
                    "Usa Buscar o revisa el addon en Stremio",
                    "Use Search or check the addon in Stremio",
                    "Utilise Rechercher ou vérifie l'addon dans Stremio",
                    "Usa Cerca o controlla l'addon in Stremio",
                    "Nutze Suchen oder prüfe das Addon in Stremio",
                ),
            )
            li_empty.setArt(base_art)
            li_empty.setProperty("IsPlayable", "false")
            directory.append((url_for_noop(), li_empty, False))
    except RoutingError as err:
        xbmc.log(f"[Kraken][TV] Routing: {err}", xbmc.LOGERROR)
    except (OSError, ValueError, TypeError, KeyError) as err:
        xbmc.log(
            f"[Kraken][TV] {_t('error listing TV', 'error listing TV', 'erreur listing TV', 'errore elenco TV', 'fehler TV-Liste')}: {err} -- {traceback.format_exc()}",
            xbmc.LOGERROR,
        )
    except Exception as err:
        xbmc.log(
            f"[Kraken][TV] error: {err} -- {traceback.format_exc()}",
            xbmc.LOGERROR,
        )
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle, True)


def run_tv_browse_search(
    *,
    plugin_handle,
    get_stremio_provider,
    default_list_art,
    url_for_play,
    url_for_noop,
):
    provider = get_stremio_provider()
    if not provider:
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    query = xbmcgui.Dialog().input(
        _t(
            "Buscar en Tvvoo (Stremio)",
            "Search in Tvvoo (Stremio)",
            "Rechercher dans Tvvoo (Stremio)",
            "Cerca in Tvvoo (Stremio)",
            "In Tvvoo suchen (Stremio)",
        ),
        "",
    )
    if not query or not (query or "").strip():
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    results = provider.search_tvvoo_only((query or "").strip())
    xbmcplugin.setPluginCategory(
        plugin_handle,
        _t(
            "Kraken - TV - Búsqueda Tvvoo",
            "Kraken - TV - Tvvoo search",
            "Kraken - TV - Recherche Tvvoo",
            "Kraken - TV - Ricerca Tvvoo",
            "Kraken - TV - Tvvoo Suche",
        ),
    )
    xbmcplugin.setContent(plugin_handle, "movies")
    base_art = default_list_art()
    directory = []
    for item in results or []:
        result_id = str((item or {}).get("id") or "").strip()
        title = (item or {}).get("title") or _t("Sin titulo", "Untitled", "Sans titre", "Senza titolo", "Ohne Titel")
        if not result_id:
            continue
        plot = (item or {}).get("plot") or ""
        art = dict(base_art)
        poster = (item or {}).get("poster") or ""
        if poster:
            art.update({"poster": poster, "thumb": poster, "icon": poster})
        li = xbmcgui.ListItem(label=title)
        apply_video_info(li, {"title": title, "plot": plot, "mediatype": "video"})
        li.setArt(art)
        li.setProperty("IsPlayable", "true")
        directory.append((url_for_play(result_id), li, False))
    if not directory:
        message = _t(
            "Sin resultados para: {}",
            "No results for: {}",
            "Aucun résultat pour : {}",
            "Nessun risultato per: {}",
            "Keine Ergebnisse für: {}",
        ).format(query)
        li_empty = xbmcgui.ListItem(label=message)
        apply_video_info(li_empty, {"title": message, "mediatype": "video"})
        li_empty.setArt(base_art)
        li_empty.setProperty("IsPlayable", "false")
        directory.append((url_for_noop(), li_empty, False))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)


def run_tv_browse_channel(
    *,
    plugin_handle,
    token,
    get_stremio_provider,
    query_arg_first_str,
    tv_catalog_token_read,
    default_list_art,
    url_for_play,
    url_for_noop,
):
    from resources.lib.providers.stremio_catalog import StremioCatalogProvider

    provider = get_stremio_provider()
    if not provider:
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    token_value = (
        (token or "").replace(" ", "").strip() if (token and str(token).strip()) else ""
    )
    if not token_value:
        token_value = query_arg_first_str("token", "t", b"token", b"t")
    media_type, catalog_id, genre_selected, _catalog_name_from_token = (
        tv_catalog_token_read(token_value)
    )
    if not (catalog_id or "").strip():
        xbmcgui.Dialog().ok(
            "Kraken - TV",
            _t(
                "No se pudo abrir el listado (enlace o token invalido). Vuelve a Kraken - TV e intentalo otra vez.",
                "Could not open listing (invalid link or token). Return to Kraken - TV and try again.",
                "Impossible d'ouvrir la liste (lien ou jeton invalide). Retourne à Kraken - TV et réessaie.",
                "Impossibile aprire la lista (link o token non valido). Torna su Kraken - TV e riprova.",
                "Liste konnte nicht geöffnet werden (ungültiger Link oder Token). Zu Kraken - TV zurückkehren und erneut versuchen.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    metas = provider.fetch_catalog_browse(
        "Tvvoo", media_type, catalog_id, genre=genre_selected
    )
    xbmcplugin.setPluginCategory(
        plugin_handle,
        _t("Kraken - TV - Tvvoo", "Kraken - TV - Tvvoo", "Kraken - TV - Tvvoo", "Kraken - TV - Tvvoo", "Kraken - TV - Tvvoo"),
    )
    xbmcplugin.setContent(plugin_handle, "episodes")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_NONE)
    base_art = default_list_art()
    directory = []
    metas_sorted = sorted(
        metas or [], key=lambda m: str((m or {}).get("name") or "").strip().lower()
    )
    for meta in metas_sorted:
        result_id = StremioCatalogProvider.stremio_result_id_from_meta("Tvvoo", meta)
        if not result_id:
            continue
        title = str((meta or {}).get("name") or _t("Canal", "Channel", "Chaîne", "Canale", "Sender"))
        plot = str((meta or {}).get("description") or (meta or {}).get("summary") or "")
        art = dict(base_art)
        poster = str(
            (meta or {}).get("poster") or (meta or {}).get("logo") or ""
        ).strip()
        if poster:
            art.update({"poster": poster, "thumb": poster, "icon": poster})
        li = xbmcgui.ListItem(label=title, label2=str((meta or {}).get("id") or ""))
        apply_video_info(li, {"title": title, "plot": plot, "mediatype": "episode"})
        li.setArt(art)
        li.setProperty("IsPlayable", "true")
        directory.append((url_for_play(result_id), li, False))
    if not directory:
        token_hint = (token or "")[:20]
        li_empty = xbmcgui.ListItem(
            label=_t(
                "Sin entradas en este listado o URL de catálogo no compatible",
                "No entries in this list or incompatible catalog URL",
                "Aucune entrée dans cette liste ou URL de catalogue incompatible",
                "Nessuna voce in questa lista o URL catalogo incompatibile",
                "Keine Einträge in dieser Liste oder inkompatible Katalog-URL",
            )
        )
        apply_video_info(
            li_empty,
            {
                "title": "Tvvoo",
                "plot": _t(
                    "Revisa manifiesto y reintenta. Token: ",
                    "Check manifest and retry. Token: ",
                    "Vérifie le manifeste puis réessaie. Jeton : ",
                    "Controlla il manifest e riprova. Token: ",
                    "Manifest prüfen und erneut versuchen. Token: ",
                )
                + token_hint,
            },
        )
        li_empty.setProperty("IsPlayable", "false")
        li_empty.setArt(base_art)
        directory.append((url_for_noop(), li_empty, False))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)
