# Fase F: persistir subconjunto de catalogs[] (tipo + id) por complemento nombrado (manifest.json).
import json

import xbmcgui

from resources.lib.providers.stremio_catalog import StremioCatalogProvider
from resources.lib.ui.ui_helpers import _t
from resources.lib.sources.stremio_sources_config import (
    SETTING_MANIFEST_CATALOG_PICK,
    SETTING_USE_MANIFEST_CATALOG_FILTER,
    STREMIO_CATALOG_NAMED_ADDONS,
)


def _load_pick_dict(raw):
    if not raw or not str(raw).strip():
        return {}
    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except (TypeError, ValueError):
        return {}


def run_stremio_manifest_catalog_pick(*, addon, get_setting, set_setting):
    entries = []
    for name, prefix in STREMIO_CATALOG_NAMED_ADDONS:
        url = (get_setting(f"{prefix}_url") or "").strip()
        if url:
            entries.append((name, prefix))

    if not entries:
        xbmcgui.Dialog().ok(
            "Kraken - Stremio",
            _t(
                "No hay complementos nombrados con URL.\n\nConfigura Kraken - Stremio.",
                "No named add-ons with URL.\n\nConfigure Kraken - Stremio.",
                "Aucune extension nommée avec URL.\n\nConfigurez Kraken - Stremio.",
                "Nessun addon nominato con URL.\n\nConfigura Kraken - Stremio.",
                "Keine benannten Add-ons mit URL.\n\nKraken - Stremio konfigurieren.",
            ),
        )
        return

    labels = [e[0] for e in entries]
    idx = xbmcgui.Dialog().select(
        _t(
            "Complemento (catalogos del manifest)",
            "Add-on (manifest catalogs)",
            "Extension (catalogues manifest)",
            "Addon (cataloghi manifest)",
            "Add-on (Manifest-Kataloge)",
        ),
        labels,
    )
    if idx < 0:
        return

    display_name, prefix = entries[idx]
    prov = StremioCatalogProvider(addon)
    cats = prov.list_manifest_catalog_entries_for_picker(display_name)
    if not cats:
        xbmcgui.Dialog().ok(
            "Kraken - Stremio",
            _t(
                "No se obtuvieron catalogos del manifest para {n}.",
                "No manifest catalogs obtained for {n}.",
                "Aucun catalogue manifest obtenu pour {n}.",
                "Nessun catalogo manifest ottenuto per {n}.",
                "Keine Manifest-Kataloge für {n} erhalten.",
            ).format(n=display_name),
        )
        return

    opt_labels = []
    for c in cats:
        nm = (c.get("name") or "")[:52]
        opt_labels.append("{} · {} — {}".format(c.get("type"), c.get("id"), nm))

    raw_pick = (get_setting(SETTING_MANIFEST_CATALOG_PICK) or "").strip()
    data = _load_pick_dict(raw_pick)
    key_pairs = []
    block = data.get(prefix)
    if isinstance(block, list):
        for item in block:
            if isinstance(item, (list, tuple)) and len(item) >= 2:
                key_pairs.append((str(item[0]).strip().lower(), str(item[1]).strip()))

    saved = set(key_pairs)
    preselect = []
    for i, c in enumerate(cats):
        t = str(c.get("type") or "").strip().lower()
        cid = str(c.get("id") or "").strip()
        if (t, cid) in saved:
            preselect.append(i)

    dlg = xbmcgui.Dialog()
    picked = dlg.multiselect(
        _t(
            "Catalogos permitidos ({n})",
            "Allowed catalogs ({n})",
            "Catalogues autorises ({n})",
            "Cataloghi consentiti ({n})",
            "Erlaubte Kataloge ({n})",
        ).format(n=display_name),
        opt_labels,
        preselect=preselect,
    )
    if picked is None:
        return

    pairs = [[str(cats[i]["type"]), str(cats[i]["id"])] for i in picked]
    data[prefix] = pairs

    try:
        set_setting(SETTING_MANIFEST_CATALOG_PICK, json.dumps(data, ensure_ascii=False))
        set_setting(SETTING_USE_MANIFEST_CATALOG_FILTER, True)
    except Exception as ex:
        dlg.notification(
            "Kraken",
            _t(
                "No se pudo guardar: {e}",
                "Could not save: {e}",
                "Impossible d'enregistrer : {e}",
                "Impossibile salvare: {e}",
                "Speichern fehlgeschlagen: {e}",
            ).format(e=ex),
            xbmcgui.NOTIFICATION_ERROR,
            5000,
        )
        return

    dlg.notification(
        "Kraken",
        _t(
            "{c} catalogo(s) guardados para {n}.",
            "{c} catalog(s) saved for {n}.",
            "{c} catalogue(s) enregistre(s) pour {n}.",
            "{c} catalogo/i salvati per {n}.",
            "{c} Katalog(e) gespeichert fuer {n}.",
        ).format(c=len(picked), n=display_name),
        xbmcgui.NOTIFICATION_INFO,
        4500,
    )


def run_stremio_manifest_catalog_pick_disable(*, set_setting):
    dlg = xbmcgui.Dialog()
    try:
        set_setting(SETTING_USE_MANIFEST_CATALOG_FILTER, False)
    except Exception:
        try:
            set_setting(SETTING_USE_MANIFEST_CATALOG_FILTER, "false")
        except Exception:
            dlg.notification(
                "Kraken",
                _t(
                    "No se pudo desactivar.",
                    "Could not disable.",
                    "Impossible de desactiver.",
                    "Impossibile disattivare.",
                    "Konnte nicht deaktivieren.",
                ),
                xbmcgui.NOTIFICATION_WARNING,
                4500,
            )
            return
    dlg.notification(
        "Kraken",
        _t(
            "Filtro por catalogos del manifest desactivado.",
            "Manifest catalog filter disabled.",
            "Filtre catalogues manifest desactive.",
            "Filtro cataloghi manifest disattivato.",
            "Manifest-Katalogfilter deaktiviert.",
        ),
        xbmcgui.NOTIFICATION_INFO,
        4500,
    )
