"""Iniciar / detener servidor web local para editar JSON y textos largos desde el movil."""

import xbmc
import xbmcgui

from resources.lib.core.kraken_mobile_config_server import (
    guess_lan_ip,
    is_mobile_server_running,
    mobile_server_port,
    mobile_server_token,
    start_mobile_config_server,
    stop_mobile_config_server,
)
from resources.lib.core.kraken_qr_ui import (
    open_kraken_qr_modal,
    write_qr_png_to_special_temp,
)
from resources.lib.ui.ui_helpers import _t


def run_kraken_mobile_web_start(*, addon, addon_path=None, qr_dialog_cls=None):
    if not is_mobile_server_running():
        ok, err = start_mobile_config_server(addon)
        if not ok:
            xbmcgui.Dialog().ok(
                "Kraken",
                _t(
                    "No se pudo iniciar el servidor web.\n\n{e}\n\nPrueba otro puerto en Ajustes (kraken_mobile_web_port).",
                    "Could not start the web server.\n\n{e}\n\nTry another port in Settings (kraken_mobile_web_port).",
                    "Impossible de demarrer le serveur web.\n\n{e}\n\nEssaye un autre port dans les parametres (kraken_mobile_web_port).",
                    "Impossibile avviare il server web.\n\n{e}\n\nProva un'altra porta nelle impostazioni (kraken_mobile_web_port).",
                    "Webserver konnte nicht gestartet werden.\n\n{e}\n\nAnderen Port in den Einstellungen versuchen (kraken_mobile_web_port).",
                ).format(e=err),
            )
            return

    ip = guess_lan_ip()
    port = mobile_server_port()
    tok = mobile_server_token()
    # Ruta /k/<token>/ evita que apps de QR pierdan ?token= al abrir el enlace.
    url = f"http://{ip}:{port}/k/{tok}/"

    body_text = _t(
        "Escanea el codigo QR con la camara del movil (misma WiFi que Kodi).\n\n"
        "Si no puedes escanear, copia esta URL en el navegador:\n\n"
        "{url}\n\n"
        "El token va en la ruta (/k/.../), no hace falta pegar parametros aparte. "
        "Para apagar: Ajustes Kraken - Detener servidor web, o el boton en la pagina.\n\n"
        "Puerto {port} (ajustable en kraken_mobile_web_port). Revisa firewall si no carga.",
        "Scan the QR code with your phone camera (same WiFi as Kodi).\n\n"
        "If you cannot scan, copy this URL in the browser:\n\n"
        "{url}\n\n"
        "The token is in the path (/k/.../); no extra query parameters needed. "
        "To stop: Kraken Settings - Stop web server, or the button on the page.\n\n"
        "Port {port} (adjustable in kraken_mobile_web_port). Check the firewall if it does not load.",
        "Scannez le QR avec l'appareil photo du mobile (meme WiFi que Kodi).\n\n"
        "Si vous ne pouvez pas scanner, copiez cette URL dans le navigateur :\n\n"
        "{url}\n\n"
        "Le jeton est dans le chemin (/k/.../), pas besoin de parametres separes. "
        "Pour arreter : Parametres Kraken - Arreter le serveur web, ou le bouton sur la page.\n\n"
        "Port {port} (reglable dans kraken_mobile_web_port). Verifiez le pare-feu.",
        "Scansiona il QR con la fotocamera del telefono (stessa WiFi di Kodi).\n\n"
        "Se non puoi scansionare, copia questo URL nel browser:\n\n"
        "{url}\n\n"
        "Il token e nel percorso (/k/.../), non servono altri parametri. "
        "Per spegnere: Impostazioni Kraken - Arresta server web, o il pulsante nella pagina.\n\n"
        "Porta {port} (regolabile in kraken_mobile_web_port). Controlla il firewall.",
        "QR-Code mit der Handykamera scannen (gleiches WLAN wie Kodi).\n\n"
        "Wenn kein Scan: diese URL im Browser oeffnen:\n\n"
        "{url}\n\n"
        "Das Token steht im Pfad (/k/.../), keine extra Parameter. "
        "Zum Stoppen: Kraken-Einstellungen - Webserver stoppen, oder Button auf der Seite.\n\n"
        "Port {port} (kraken_mobile_web_port). Firewall pruefen, wenn nichts laedt.",
    ).format(url=url, port=port)

    qr_png = write_qr_png_to_special_temp("kraken_mobile_web_qr.png", url)
    if not qr_png:
        xbmc.log("[Kraken][WebCfg] local QR not generated", xbmc.LOGWARNING)

    if qr_dialog_cls and addon_path:
        if qr_png:
            open_kraken_qr_modal(
                qr_dialog_cls,
                addon_path,
                dialog_title=_t(
                    "Kraken — Config web movil (escanea QR)",
                    "Kraken — Mobile web config (scan QR)",
                    "Kraken — Config web mobile (scan QR)",
                    "Kraken — Config web mobile (scansiona QR)",
                    "Kraken — Mobile-Webkonfig (QR scannen)",
                ),
                body_text=body_text,
                qr_special_path=qr_png,
            )
        else:
            xbmcgui.Dialog().textviewer(
                _t(
                    "Kraken — Configuración web (móvil)",
                    "Kraken — Web configuration (mobile)",
                    "Kraken — Configuration web (mobile)",
                    "Kraken — Configurazione web (mobile)",
                    "Kraken — Web-Konfiguration (Mobil)",
                ),
                body_text,
            )
        xbmcgui.Dialog().notification(
            "Kraken",
            _t(
                "Servidor web activo en puerto {p}. Detenlo en Ajustes cuando termines.",
                "Web server active on port {p}. Stop it in Settings when done.",
                "Serveur web actif sur le port {p}. Arretez-le dans les parametres apres usage.",
                "Server web attivo sulla porta {p}. Arrestalo nelle impostazioni quando hai finito.",
                "Webserver aktiv auf Port {p}. In den Einstellungen stoppen, wenn fertig.",
            ).format(p=port),
            xbmcgui.NOTIFICATION_INFO,
            4200,
        )
        return

    fallback = _t(
        "Abre esta URL en el móvil (misma red WiFi que Kodi):\n\n"
        "{url}\n\n"
        "El token está en la ruta (/k/.../). Evita que otros equipos cambien tus ajustes.\n\n"
        "Para apagar el servidor:\n"
        "- Ajustes Kraken «Detener servidor web de configuración», o\n"
        "- Botón «Detener servidor» en la propia página.\n\n"
        "Si el teléfono no carga la página, revisa firewall en el PC/Android TV y que el puerto {port} esté libre.",
        "Open this URL on your phone (same WiFi as Kodi):\n\n"
        "{url}\n\n"
        "The token is in the path (/k/.../). This prevents other devices from changing your settings.\n\n"
        "To stop the server:\n"
        "- Kraken Settings «Stop configuration web server», or\n"
        "- «Stop server» button on the page.\n\n"
        "If the phone does not load the page, check the firewall on PC/Android TV and that port {port} is free.",
        "Ouvrez cette URL sur le mobile (meme WiFi que Kodi) :\n\n"
        "{url}\n\n"
        "Le jeton est dans le chemin (/k/.../). Cela empeche d'autres appareils de modifier vos reglages.\n\n"
        "Pour arreter le serveur :\n"
        "- Parametres Kraken «Arreter le serveur web de configuration», ou\n"
        "- Bouton «Arreter le serveur» sur la page.\n\n"
        "Si la page ne charge pas, verifiez le pare-feu et que le port {port} est libre.",
        "Apri questo URL sul telefono (stessa WiFi di Kodi):\n\n"
        "{url}\n\n"
        "Il token e nel percorso (/k/.../). Evita che altri dispositivi modifichino le impostazioni.\n\n"
        "Per spegnere il server:\n"
        "- Impostazioni Kraken «Arresta server web di configurazione», o\n"
        "- Pulsante «Arresta server» sulla pagina.\n\n"
        "Se non carica, controlla firewall e che la porta {port} sia libera.",
        "Diese URL auf dem Handy oeffnen (gleiches WLAN wie Kodi):\n\n"
        "{url}\n\n"
        "Das Token steht im Pfad (/k/.../), damit andere Geraete deine Einstellungen nicht aendern.\n\n"
        "Server stoppen:\n"
        "- Kraken-Einstellungen «Konfig-Webserver stoppen», oder\n"
        "- «Server stoppen» auf der Seite.\n\n"
        "Wenn nichts laedt: Firewall pruefen und Port {port} frei.",
    ).format(url=url, port=port)
    xbmcgui.Dialog().textviewer(
        _t(
            "Kraken — Configuración web (móvil)",
            "Kraken — Web configuration (mobile)",
            "Kraken — Configuration web (mobile)",
            "Kraken — Configurazione web (mobile)",
            "Kraken — Web-Konfiguration (Mobil)",
        ),
        fallback,
    )


def run_kraken_mobile_web_stop():
    stop_mobile_config_server()
    xbmcgui.Dialog().notification(
        "Kraken",
        _t(
            "Servidor web de configuración detenido.",
            "Configuration web server stopped.",
            "Serveur web de configuration arrete.",
            "Server web di configurazione arrestato.",
            "Konfigurations-Webserver gestoppt.",
        ),
        xbmcgui.NOTIFICATION_INFO,
        3500,
    )
