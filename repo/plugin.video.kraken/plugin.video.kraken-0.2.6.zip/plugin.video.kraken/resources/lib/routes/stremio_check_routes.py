# Fase D: comprobar disponibilidad HTTP de manifest.json por complemento configurado (tipo ping Jacktook).
import json
from urllib.error import URLError
from urllib.request import Request, urlopen

import xbmcgui

from resources.lib.providers.stremio_catalog import StremioCatalogProvider
from resources.lib.sources.stremio_sources_config import http_timeout_seconds_from_addon
from resources.lib.ui.ui_helpers import _t


def _probe_manifest_json(manifest_url, timeout):
    """HEAD no siempre soportado; GET ligero y parse JSON parcial."""
    req = Request(manifest_url, headers={"User-Agent": "Kraken-Stremio-Ping/1.0"})
    with urlopen(req, timeout=timeout) as resp:
        raw = resp.read()
        code = int(getattr(resp, "status", 200) or 200)
    try:
        doc = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError, json.JSONDecodeError) as err:
        return (
            False,
            code,
            _t(
                "JSON invalido: {}",
                "Invalid JSON: {}",
                "JSON invalide : {}",
                "JSON non valido: {}",
                "Ungültiges JSON: {}",
            ).format(err)[:80],
        )
    name = (doc.get("name") or doc.get("id") or "").strip()
    ver = (doc.get("version") or "").strip()
    tail = name[:56] if name else _t(
        "sin nombre en manifest",
        "no name in manifest",
        "sans nom dans le manifest",
        "nessun nome nel manifest",
        "kein Name im Manifest",
    )
    if ver:
        tail = f"{tail} · v{ver[:12]}"
    return True, code, tail


def run_stremio_manifest_check(*, addon):
    """
    Una peticion GET por URL de manifest derivada de cada entrada de catalogo configurada.
    No usa la caché de manifests del proveedor (lectura directa).
    """
    timeout = max(10, min(45, http_timeout_seconds_from_addon(addon)))
    try:
        pairs = list(StremioCatalogProvider(addon)._catalog_sources or [])
    except Exception as ex:
        xbmcgui.Dialog().ok(
            "Kraken - Stremio",
            _t(
                "No se pudo leer complementos:\n{}",
                "Could not read addons:\n{}",
                "Impossible de lire les addons :\n{}",
                "Impossibile leggere gli addon:\n{}",
                "Add-ons konnten nicht gelesen werden:\n{}",
            ).format(ex),
        )
        return

    if not pairs:
        xbmcgui.Dialog().ok(
            "Kraken - Stremio",
            _t(
                "No hay URLs de complementos configuradas.\n\n"
                "Rellena al menos una URL en Kraken - Stremio (o usa el menu rapido para activar).",
                "No addon URLs are configured.\n\n"
                "Fill at least one URL in Kraken - Stremio (or use the quick menu to enable it).",
                "Aucune URL d'extension configuree.\n\n"
                "Renseignez au moins une URL dans Kraken - Stremio (ou le menu rapide pour activer).",
                "Nessun URL addon configurato.\n\n"
                "Imposta almeno un URL in Kraken - Stremio (o il menu rapido per attivare).",
                "Keine Add-on-URLs konfiguriert.\n\n"
                "Mindestens eine URL in Kraken - Stremio eintragen (oder Schnellmenu zum Aktivieren).",
            ),
        )
        return

    prog = None
    total = len(pairs)
    if total >= 4:
        prog = xbmcgui.DialogProgress()
        prog.create(
            "Kraken - Stremio",
            _t(
                "Comprobando manifest.json…",
                "Checking manifest.json...",
                "Verification de manifest.json...",
                "Controllo manifest.json...",
                "Prüfe manifest.json...",
            ),
        )

    lines = []
    ok_n = 0
    fail_n = 0

    for i, (source_name, catalog_url) in enumerate(pairs):
        if prog:
            pct = int(100 * i / max(1, total))
            prog.update(pct, f"{source_name} ({i + 1}/{total})")

        murl = StremioCatalogProvider.manifest_url_from_catalog_entry(catalog_url)
        if not murl:
            lines.append(
                _t(
                    f"[SKIP] {source_name} — sin URL manifest derivada",
                    f"[SKIP] {source_name} — no derived manifest URL",
                    f"[SKIP] {source_name} — aucune URL de manifest dérivée",
                    f"[SKIP] {source_name} — nessun URL manifest derivato",
                    f"[SKIP] {source_name} — keine abgeleitete Manifest-URL",
                )
            )
            fail_n += 1
            continue

        try:
            ok, code, detail = _probe_manifest_json(murl, timeout)
        except URLError as err:
            ok, code, detail = False, 0, str(err.reason or err)[:100]
        except Exception as err:
            ok, code, detail = False, 0, str(err)[:100]

        if ok:
            ok_n += 1
            lines.append(
                _t(
                    "[OK] {n} — HTTP {c} — {d}",
                    "[OK] {n} — HTTP {c} — {d}",
                    "[OK] {n} — HTTP {c} — {d}",
                    "[OK] {n} — HTTP {c} — {d}",
                    "[OK] {n} — HTTP {c} — {d}",
                ).format(n=source_name, c=code, d=detail)
            )
        else:
            fail_n += 1
            lines.append(
                _t(
                    "[ERROR] {n} — {d}",
                    "[ERROR] {n} — {d}",
                    "[ERREUR] {n} — {d}",
                    "[ERRORE] {n} — {d}",
                    "[FEHLER] {n} — {d}",
                ).format(n=source_name, d=detail)
            )

    if prog:
        try:
            prog.close()
        except Exception:
            pass

    summary = (
        _t(
            "Timeout por peticion: {} s\n"
            "Resultado: {} correctos, {} fallidos / {} URLs\n\n{}",
            "Timeout per request: {} s\n"
            "Result: {} ok, {} failed / {} URLs\n\n{}",
            "Timeout par requête : {} s\n"
            "Résultat : {} ok, {} échecs / {} URLs\n\n{}",
            "Timeout per richiesta: {} s\n"
            "Risultato: {} ok, {} falliti / {} URL\n\n{}",
            "Timeout pro Anfrage: {} s\n"
            "Ergebnis: {} ok, {} fehlgeschlagen / {} URLs\n\n{}",
        )
    ).format(timeout, ok_n, fail_n, total, "\n".join(lines))

    xbmcgui.Dialog().textviewer(
        _t(
            "Kraken - Stremio · Comprobacion manifest",
            "Kraken - Stremio · Manifest check",
            "Kraken - Stremio · Verification manifest",
            "Kraken - Stremio · Controllo manifest",
            "Kraken - Stremio · Manifest-Prüfung",
        ),
        summary,
    )
