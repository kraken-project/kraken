"""
Listados TMDb discover (año / género) con resolución a Trakt cuando existe; películas pueden usar fallback.
"""

from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import quote, urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib.core.language_prefs import (
    tmdb_language_param,
    tmdb_theatrical_region_code,
)
from resources.lib.core.metadata_tmdb import prefetch_tmdb_details_parallel
from resources.lib.core.network import json_get as _json_get_network
from resources.lib.routes.trakt_discover_routes import (
    _apply_trakt_translations,
    _build_trakt_movie_directory,
    _build_trakt_show_directory,
)
from resources.lib.ui.context_menu import add_movie_download_context
from resources.lib.ui.ui_helpers import _t


def _trakt_ids_from_tmdb_search(trakt_public_get, tmdb_numeric_id, media_kind):
    """Devuelve (trakt_id_str o None, tipo trakt movie|show)."""
    mt = "movie" if media_kind == "movie" else "show"
    url = f"https://api.trakt.tv/search/tmdb/{int(tmdb_numeric_id)}?type={mt}"
    try:
        payload = trakt_public_get(url)
    except Exception as err:
        xbmc.log(f"[Kraken][tmdb_discover] lookup Trakt: {err}", xbmc.LOGDEBUG)
        return None, mt
    if not isinstance(payload, list):
        return None, mt
    for row in payload:
        if mt == "movie" and row.get("type") == "movie":
            m = row.get("movie") or {}
            tid = (m.get("ids") or {}).get("trakt")
            if tid:
                return str(tid).strip(), mt
        if mt == "show" and row.get("type") == "show":
            s = row.get("show") or {}
            tid = (s.get("ids") or {}).get("trakt")
            if tid:
                return str(tid).strip(), mt
    return None, mt


def _prefetch_trakt_ids_from_tmdb(
    trakt_public_get, tmdb_numeric_ids, media_kind, max_workers=8
):
    """Mapeo id numérico TMDb → id Trakt (str) o None; peticiones search/tmdb en paralelo."""
    uniq = []
    seen = set()
    for raw in tmdb_numeric_ids or []:
        try:
            n = int(raw)
        except (TypeError, ValueError):
            continue
        if n in seen:
            continue
        seen.add(n)
        uniq.append(n)
    out = {}

    def one(nid):
        trakt_id, _mk = _trakt_ids_from_tmdb_search(trakt_public_get, nid, media_kind)
        return nid, trakt_id

    if not uniq:
        return out
    workers = min(max(1, int(max_workers)), len(uniq))
    try:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futures = [ex.submit(one, nid) for nid in uniq]
            for fut in as_completed(futures):
                try:
                    nid, trakt_id = fut.result()
                    out[nid] = trakt_id
                except Exception:
                    pass
    except Exception:
        for nid in uniq:
            try:
                nid2, trakt_id = one(nid)
                out[nid2] = trakt_id
            except Exception:
                pass
    for nid in uniq:
        out.setdefault(nid, None)
    return out


def _tmdb_discover_fetch_pages(
    kind, json_get, timeout, params, max_pages=3, cap_rows=54
):
    """kind: 'movie' | 'tv'. Varias páginas y dedupe por id TMDb."""
    endpoint = "discover/movie" if kind == "movie" else "discover/tv"
    all_rows = []
    seen = set()
    last_payload = {}
    for page in range(1, max_pages + 1):
        pp = dict(params)
        pp["page"] = str(page)
        url = f"https://api.themoviedb.org/3/{endpoint}?{urlencode(pp)}"
        try:
            payload = json_get(url, timeout=timeout)
        except Exception as err:
            xbmc.log(
                f"[Kraken][tmdb_discover] {kind} p{page}: {err}",
                xbmc.LOGDEBUG,
            )
            break
        if not isinstance(payload, dict):
            break
        last_payload = payload
        batch = payload.get("results") or []
        try:
            total_pages = int(payload.get("total_pages") or 1)
        except (TypeError, ValueError):
            total_pages = 1
        for r in batch:
            if isinstance(r, dict):
                nid = r.get("id")
                if nid is not None and nid not in seen:
                    seen.add(nid)
                    all_rows.append(r)
        if len(all_rows) >= cap_rows or page >= total_pages or not batch:
            break
    return all_rows[:cap_rows], last_payload


def _watch_provider_discovery_attempt_regions(watch_provider_id, primary_region):
    """ES vacío pero US con catálogo: probar segunda región."""
    if watch_provider_id is None:
        return [str(primary_region or "ES").strip().upper() or "ES"]
    regs = []
    pr = str(primary_region or "ES").strip().upper() or "ES"
    regs.append(pr)
    if pr != "US":
        regs.append("US")
    # sin duplicados conservando orden
    out = []
    for r in regs:
        if r and r not in out:
            out.append(r)
    return out


def _watch_provider_discovery_attempt_provider_ids(watch_provider_id):
    """Probar IDs equivalentes cuando TMDb cambia proveedores por región/época."""
    try:
        pid = int(watch_provider_id) if watch_provider_id is not None else None
    except (TypeError, ValueError):
        pid = None
    if pid is None:
        return [None]
    aliases = {
        384: [384, 1899],  # HBO Max / Max
        1899: [1899, 384],  # Max / HBO Max
        29: [29, 149],  # Movistar Plus+ (variantes en TMDb)
        149: [149, 29],  # Movistar Plus+ (variantes en TMDb)
    }
    out = aliases.get(pid, [pid])
    # sin duplicados conservando orden
    uniq = []
    for p in out:
        if p not in uniq:
            uniq.append(p)
    return uniq


def _trakt_best_show_search(trakt_public_get, title, year_hint):
    """Si search/tmdb no devolvió ids, buscar show por texto en Trakt."""
    t = str(title or "").strip()
    if len(t) < 2 or not callable(trakt_public_get):
        return None
    try:
        q = quote(t[:118], safe="")
    except Exception:
        return None
    if not q:
        return None
    url = f"https://api.trakt.tv/search/show?query={q}&extended=noseasons&limit=12"
    try:
        payload = trakt_public_get(url)
    except Exception:
        return None
    if not isinstance(payload, list) or not payload:
        return None
    try:
        yh = int(year_hint) if year_hint is not None else None
    except (TypeError, ValueError):
        yh = None
    best_tid = None
    best_pen = 999999
    for row in payload:
        if row.get("type") != "show":
            continue
        sh = row.get("show") or {}
        ids = sh.get("ids") or {}
        tid = ids.get("trakt")
        if not tid:
            continue
        yy = None
        try:
            yraw = sh.get("year")
            if yraw is not None and str(yraw).strip():
                yy = int(yraw)
        except (TypeError, ValueError):
            yy = None
        if yh is not None and yy is not None:
            pen = abs(yy - yh)
        elif yh is not None:
            pen = 20
        else:
            pen = 0
        if pen < best_pen:
            best_tid = tid
            best_pen = pen
            if pen == 0:
                break
    return str(best_tid).strip() if best_tid else None


def _prefill_trakt_tv_from_title_search(
    trakt_public_get, rows, trakt_lookup, max_workers=8, cap=36
):
    """Rellena trakt_lookup para TMDb shows sin resultado search/tmdb (común en contenido ES)."""
    need = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        try:
            tid = int(row.get("id"))
        except (TypeError, ValueError):
            continue
        if trakt_lookup.get(tid):
            continue
        title = str(row.get("name") or "").strip()
        if not title:
            continue
        fd = str(row.get("first_air_date") or "").strip()
        yhint = None
        if len(fd) >= 4 and fd[:4].isdigit():
            try:
                yhint = int(fd[:4])
            except ValueError:
                yhint = None
        need.append((tid, title, yhint))
    if not need:
        return
    need = need[: int(cap)]

    def one(item):
        tid, title, yhint = item
        found = _trakt_best_show_search(trakt_public_get, title, yhint)
        return tid, found

    try:
        with ThreadPoolExecutor(max_workers=min(max_workers, max(1, len(need)))) as ex:
            futures = [ex.submit(one, tup) for tup in need]
            for fut in as_completed(futures):
                try:
                    tid, found = fut.result()
                    if found and not trakt_lookup.get(tid):
                        trakt_lookup[tid] = found
                except Exception:
                    pass
    except Exception:
        for tup in need:
            try:
                tid, found = one(tup)
                if found and not trakt_lookup.get(tid):
                    trakt_lookup[tid] = found
            except Exception:
                pass


def run_tmdb_discover_movies_list(
    *,
    plugin_handle,
    year,
    genre_id,
    watch_provider_id,
    watch_region,
    category_title,
    tmdb_enabled,
    tmdb_api_key,
    json_get,
    metadata_timeout,
    trakt_public_get,
    default_list_art,
    tmdb_id_details,
    trakt_list_label1_with_year_rating,
    trakt_listitem_set_info_and_videotag,
    url_for_play,
    url_for_noop,
):
    if not tmdb_enabled():
        xbmcgui.Dialog().ok(
            "Kraken",
            _t(
                "Activa TMDb y la API key en ajustes para usar listados TMDb.",
                "Enable TMDb and API key in settings to use TMDb lists.",
                "Active TMDb et la clé API dans les paramètres pour utiliser les listes TMDb.",
                "Attiva TMDb e la chiave API nelle impostazioni per usare le liste TMDb.",
                "Aktiviere TMDb und API-Schlüssel in den Einstellungen, um TMDb-Listen zu nutzen.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    key = (tmdb_api_key() or "").strip()
    if not key:
        xbmcgui.Dialog().ok(
            "Kraken",
            _t(
                "Falta la API key de TMDb.",
                "TMDb API key is missing.",
                "La cle API TMDb est manquante.",
                "Manca la chiave API TMDb.",
                "TMDb API-Schlüssel fehlt.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    params = {
        "api_key": key,
        "language": tmdb_language_param(),
        "sort_by": "popularity.desc",
        "page": "1",
        "include_adult": "false",
    }
    if year is not None:
        params["primary_release_year"] = str(int(year))
    if genre_id is not None:
        params["with_genres"] = str(int(genre_id))
    wp = watch_provider_id
    provider_ids = _watch_provider_discovery_attempt_provider_ids(wp)
    regions = _watch_provider_discovery_attempt_regions(wp, watch_region)

    timeout = metadata_timeout()
    raw_rows = []
    try:
        for reg in regions:
            for pid_try in provider_ids:
                p_run = dict(params)
                if pid_try is not None:
                    p_run["with_watch_providers"] = str(int(pid_try))
                    p_run["watch_region"] = reg
                raw_rows, _payload = _tmdb_discover_fetch_pages(
                    "movie", json_get, timeout, p_run
                )
                if raw_rows:
                    break
            if raw_rows:
                break
    except Exception as err:
        xbmc.log(f"[Kraken][tmdb_discover] movie: {err}", xbmc.LOGERROR)
        raw_rows = []

    if not raw_rows:
        _build_trakt_movie_directory(
            plugin_handle=plugin_handle,
            results=[],
            category_title=category_title,
            default_list_art=default_list_art,
            tmdb_id_details=tmdb_id_details,
            trakt_list_label1_with_year_rating=trakt_list_label1_with_year_rating,
            trakt_listitem_set_info_and_videotag=trakt_listitem_set_info_and_videotag,
            url_for_play=url_for_play,
            url_for_noop=url_for_noop,
        )
        return
    raw_rows = [r for r in raw_rows[:48] if isinstance(r, dict)]
    tmdb_for_trakt = [r.get("id") for r in raw_rows if r.get("id") is not None]
    trakt_lookup = _prefetch_trakt_ids_from_tmdb(
        trakt_public_get, tmdb_for_trakt, "movie"
    )
    results = []
    for row in raw_rows:
        tid = row.get("id")
        title = str(row.get("title") or "").strip() or _t(
            "Sin título", "Untitled", "Sans titre", "Senza titolo", "Ohne Titel"
        )
        overview = str(row.get("overview") or "").strip()
        rd = str(row.get("release_date") or "").strip()
        y = int(rd[:4]) if len(rd) >= 4 and rd[:4].isdigit() else None
        hy = y is not None
        try:
            trakt_tid = trakt_lookup.get(int(tid)) if tid is not None else None
        except (TypeError, ValueError):
            trakt_tid = None
        if trakt_tid:
            rid = f"trakt::movie::{trakt_tid}"
        else:
            ypart = y if hy else 0
            rid = "fallback::movie::{}::{}".format(ypart, quote(title, safe=""))
        va = row.get("vote_average")
        try:
            rating = float(va) if va is not None else None
        except (TypeError, ValueError):
            rating = None
        results.append(
            {
                "id": rid,
                "title": title,
                "year": y,
                "has_year": hy,
                "rating": rating,
                "plot": overview,
                "tmdb_id": tid,
                "imdb_id": "",
            }
        )
    tmdb_px = prefetch_tmdb_details_parallel(
        [it.get("tmdb_id") for it in results if it.get("tmdb_id")],
        lambda nid: tmdb_id_details(nid, media_type="movie") or {},
        max_workers=8,
    )
    xbmcplugin.setPluginCategory(plugin_handle, category_title)
    xbmcplugin.setContent(plugin_handle, "movies")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_NONE)
    base_art = default_list_art()
    directory = []
    for item in results:
        rid = item.get("id") or ""
        year = item.get("year")
        has_year = bool(item.get("has_year"))
        rating = item.get("rating")
        try:
            rating_pos = rating is not None and float(rating) > 0.0
        except (TypeError, ValueError):
            rating_pos = False
        line1 = trakt_list_label1_with_year_rating(
            item.get("title") or _t("Película", "Movie", "Film", "Film", "Film"),
            has_year,
            year,
            (rating if rating_pos else None),
        )
        tmdb_id_raw = item.get("tmdb_id")
        if tmdb_id_raw:
            try:
                _tn = int(str(tmdb_id_raw).strip())
                tmdb = dict(tmdb_px.get(_tn) or {})
            except (TypeError, ValueError):
                tmdb = tmdb_id_details(tmdb_id_raw, media_type="movie") or {}
        else:
            tmdb = {}
        r_info = rating
        if (
            (r_info is None or r_info <= 0)
            and tmdb.get("rating") is not None
            and tmdb.get("rating") > 0
        ):
            r_info = tmdb.get("rating")
        y_info = int(year) if (has_year and year is not None) else 0
        if not y_info and tmdb.get("has_year") and tmdb.get("year") is not None:
            y_info = int(tmdb.get("year") or 0)
        info = {
            "title": line1,
            "plot": item.get("plot") or "",
            "mediatype": "movie",
            "year": y_info,
            "rating": r_info if (r_info is not None and r_info > 0) else 0,
        }
        li = xbmcgui.ListItem(label=line1, label2=item.get("plot", "")[:120])
        trakt_listitem_set_info_and_videotag(
            li,
            item.get("title") or "",
            item.get("plot") or "",
            False,
            has_year and year is not None,
            year,
            r_info,
            None,
            info,
        )
        art = dict(base_art)
        p = str((tmdb or {}).get("poster") or "").strip()
        f = str((tmdb or {}).get("fanart") or "").strip()
        if p:
            art.update({"poster": p, "thumb": p, "icon": p})
        if f:
            art.update({"fanart": f, "landscape": f, "banner": f})
        li.setArt(art)
        li.setProperty("IsPlayable", "true")
        add_movie_download_context(li, rid)
        directory.append((url_for_play(rid), li, False))
    if not directory:
        li = xbmcgui.ListItem(
            label=_t(
                "Sin resultados en este listado",
                "No results in this list",
                "Aucun résultat dans cette liste",
                "Nessun risultato in questa lista",
                "Keine Ergebnisse in dieser Liste",
            )
        )
        li.setProperty("IsPlayable", "false")
        li.setArt(base_art)
        directory.append((url_for_noop(), li, False))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle, True)


def run_tmdb_discover_tv_list(
    *,
    plugin_handle,
    year,
    genre_id,
    with_genres_extra,
    watch_provider_id,
    watch_region,
    category_title,
    tmdb_enabled,
    tmdb_api_key,
    json_get,
    metadata_timeout,
    trakt_public_get,
    default_list_art,
    tmdb_id_details,
    trakt_list_label1_with_year_rating,
    trakt_listitem_set_info_and_videotag,
    url_for_show_seasons,
    url_for_noop,
):
    if not tmdb_enabled():
        xbmcgui.Dialog().ok(
            "Kraken",
            _t(
                "Activa TMDb y la API key en ajustes para usar listados TMDb.",
                "Enable TMDb and API key in settings to use TMDb lists.",
                "Active TMDb et la clé API dans les paramètres pour utiliser les listes TMDb.",
                "Attiva TMDb e la chiave API nelle impostazioni per usare le liste TMDb.",
                "Aktiviere TMDb und API-Schlüssel in den Einstellungen, um TMDb-Listen zu nutzen.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    key = (tmdb_api_key() or "").strip()
    if not key:
        xbmcgui.Dialog().ok(
            "Kraken",
            _t(
                "Falta la API key de TMDb.",
                "TMDb API key is missing.",
                "La clé API TMDb est manquante.",
                "Manca la chiave API TMDb.",
                "TMDb API-Schlüssel fehlt.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    base = {
        "api_key": key,
        "language": tmdb_language_param(),
        "sort_by": "popularity.desc",
        "page": "1",
        "include_adult": "false",
    }
    if year is not None:
        base["first_air_date_year"] = str(int(year))

    wp = watch_provider_id
    provider_ids = _watch_provider_discovery_attempt_provider_ids(wp)

    def _tv_params_with_genres(wg_extra, gid):
        pp = dict(base)
        gparts = []
        if wg_extra is not None:
            gparts.append(str(int(wg_extra)))
        if gid is not None:
            gparts.append(str(int(gid)))
        if gparts:
            pp["with_genres"] = ",".join(gparts)
        return pp

    regions = _watch_provider_discovery_attempt_regions(wp, watch_region)
    genre_tries = [(with_genres_extra, genre_id)]
    if wp is not None:
        try:
            if (
                with_genres_extra is not None
                and int(with_genres_extra) == 16
                and genre_id is None
            ):
                genre_tries.append((None, genre_id))
        except (TypeError, ValueError):
            pass

    timeout = metadata_timeout()
    raw_rows = []
    net_errors = []
    for reg in regions:
        for wg_try, gid_try in genre_tries:
            for pid_try in provider_ids:
                p_run = _tv_params_with_genres(wg_try, gid_try)
                if pid_try is not None:
                    p_run["with_watch_providers"] = str(int(pid_try))
                    p_run["watch_region"] = reg
                try:
                    batch, _pld = _tmdb_discover_fetch_pages(
                        "tv", json_get, timeout, p_run
                    )
                except Exception as err:
                    net_errors.append(err)
                    batch = []
                if batch:
                    raw_rows = batch
                    break
            if raw_rows:
                break
        if raw_rows:
            break

    if net_errors and not raw_rows:
        xbmc.log(f"[Kraken][tmdb_discover] tv: {net_errors[-1]}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            "Kraken",
            _t(
                "No se pudo cargar TMDb discover (TV).",
                "Could not load TMDb discover (TV).",
                "Impossible de charger TMDb discover (TV).",
                "Impossibile caricare TMDb discover (TV).",
                "TMDb Discover (TV) konnte nicht geladen werden.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return

    raw_rows = [r for r in raw_rows[:52] if isinstance(r, dict)]
    if not raw_rows:
        _build_trakt_show_directory(
            plugin_handle=plugin_handle,
            results=[],
            category_title=category_title,
            default_list_art=default_list_art,
            tmdb_id_details=tmdb_id_details,
            trakt_list_label1_with_year_rating=trakt_list_label1_with_year_rating,
            trakt_listitem_set_info_and_videotag=trakt_listitem_set_info_and_videotag,
            url_for_show_seasons=url_for_show_seasons,
            url_for_noop=url_for_noop,
            tmdb_prefetch=None,
        )
        return

    tmdb_for_trakt = [r.get("id") for r in raw_rows if r.get("id") is not None]
    trakt_lookup = _prefetch_trakt_ids_from_tmdb(
        trakt_public_get, tmdb_for_trakt, "show"
    )
    _prefill_trakt_tv_from_title_search(trakt_public_get, raw_rows, trakt_lookup)
    results = []
    for row in raw_rows:
        tid = row.get("id")
        title = str(row.get("name") or "").strip() or _t(
            "Sin título", "Untitled", "Sans titre", "Senza titolo", "Ohne Titel"
        )
        overview = str(row.get("overview") or "").strip()
        fd = str(row.get("first_air_date") or "").strip()
        y = int(fd[:4]) if len(fd) >= 4 and fd[:4].isdigit() else None
        hy = y is not None
        try:
            trakt_tid = trakt_lookup.get(int(tid)) if tid is not None else None
        except (TypeError, ValueError):
            trakt_tid = None
        if not trakt_tid:
            continue
        va = row.get("vote_average")
        try:
            rating = float(va) if va is not None else None
        except (TypeError, ValueError):
            rating = None
        results.append(
            {
                "id": f"trakt::show::{trakt_tid}",
                "title": title,
                "year": y,
                "has_year": hy,
                "rating": rating,
                "plot": overview,
                "tmdb_id": tid,
                "imdb_id": "",
            }
        )
    tmdb_px = prefetch_tmdb_details_parallel(
        [it.get("tmdb_id") for it in results if it.get("tmdb_id")],
        lambda nid: tmdb_id_details(nid, media_type="series") or {},
        max_workers=8,
    )
    _build_trakt_show_directory(
        plugin_handle=plugin_handle,
        results=results,
        category_title=category_title,
        default_list_art=default_list_art,
        tmdb_id_details=tmdb_id_details,
        trakt_list_label1_with_year_rating=trakt_list_label1_with_year_rating,
        trakt_listitem_set_info_and_videotag=trakt_listitem_set_info_and_videotag,
        url_for_show_seasons=url_for_show_seasons,
        url_for_noop=url_for_noop,
        tmdb_prefetch=tmdb_px,
    )


def run_tmdb_now_playing_boxoffice_list(
    *,
    plugin_handle,
    trakt_public_get,
    default_list_art,
    tmdb_id_details,
    trakt_progress_translator,
    trakt_list_label1_with_year_rating,
    trakt_listitem_set_info_and_videotag,
    url_for_play,
    url_for_noop,
):
    """
    Cartelera regional vía TMDb now_playing + región Kodi (mejor que solo taquilla USA de Trakt).
    Devuelve True si se pintó el listado; False para usar el fallback Trakt.
    """
    try:
        addon = xbmcaddon.Addon("plugin.video.kraken")
        if not addon.getSettingBool("tmdb_enabled"):
            return False
        key = (addon.getSetting("tmdb_api_key") or "").strip()
        if not key:
            return False
    except Exception:
        return False

    region = tmdb_theatrical_region_code()
    params = {
        "api_key": key,
        "language": tmdb_language_param(),
        "region": region,
        "page": "1",
    }
    raw_rows = []
    total_pages = 1
    for page in (1, 2):
        p = dict(params)
        p["page"] = str(page)
        url = "https://api.themoviedb.org/3/movie/now_playing?{}".format(
            urlencode(p)
        )
        try:
            payload = _json_get_network(url, timeout=15)
        except Exception as err:
            xbmc.log(
                "[Kraken][now_playing] page {}: {}".format(page, err),
                xbmc.LOGDEBUG,
            )
            payload = {}
        if not isinstance(payload, dict):
            break
        try:
            total_pages = int(payload.get("total_pages") or 1)
        except (TypeError, ValueError):
            total_pages = 1
        batch = payload.get("results") or []
        for r in batch:
            if isinstance(r, dict):
                raw_rows.append(r)
        if page >= total_pages or page >= 2:
            break

    raw_rows = raw_rows[:40]
    if not raw_rows:
        return False

    tmdb_for_trakt = [r.get("id") for r in raw_rows if r.get("id") is not None]
    trakt_lookup = _prefetch_trakt_ids_from_tmdb(
        trakt_public_get, tmdb_for_trakt, "movie"
    )
    results = []
    for row in raw_rows:
        tid = row.get("id")
        title = str(row.get("title") or "").strip() or _t(
            "Sin título", "Untitled", "Sans titre", "Senza titolo", "Ohne Titel"
        )
        overview = str(row.get("overview") or "").strip()
        rd = str(row.get("release_date") or "").strip()
        y = int(rd[:4]) if len(rd) >= 4 and rd[:4].isdigit() else None
        hy = y is not None
        try:
            trakt_tid = trakt_lookup.get(int(tid)) if tid is not None else None
        except (TypeError, ValueError):
            trakt_tid = None
        if trakt_tid:
            rid = f"trakt::movie::{trakt_tid}"
        else:
            ypart = y if hy else 0
            rid = "fallback::movie::{}::{}".format(ypart, quote(title, safe=""))
        va = row.get("vote_average")
        try:
            rating = float(va) if va is not None else None
        except (TypeError, ValueError):
            rating = None
        results.append(
            {
                "id": rid,
                "title": title,
                "year": y,
                "has_year": hy,
                "rating": rating,
                "plot": overview,
                "tmdb_id": tid,
                "imdb_id": "",
            }
        )

    _apply_trakt_translations(
        results, "movie", trakt_progress_translator=trakt_progress_translator
    )

    cat = _t(
        "Kraken - Películas - Taquilla / Cartelera ({})",
        "Kraken - Movies - Box office / Now playing ({})",
        "Kraken - Films - Box-office / À l'affiche ({})",
        "Kraken - Film - Box office / In sala ({})",
        "Kraken - Filme - Box Office / Aktuell im Kino ({})",
    ).format(region)

    tmdb_px = prefetch_tmdb_details_parallel(
        [it.get("tmdb_id") for it in results if it.get("tmdb_id")],
        lambda nid: tmdb_id_details(nid, media_type="movie") or {},
        max_workers=8,
    )
    xbmcplugin.setPluginCategory(plugin_handle, cat)
    xbmcplugin.setContent(plugin_handle, "movies")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_NONE)
    base_art = default_list_art()
    directory = []
    for item in results:
        rid = item.get("id") or ""
        year = item.get("year")
        has_year = bool(item.get("has_year"))
        rating = item.get("rating")
        try:
            rating_pos = rating is not None and float(rating) > 0.0
        except (TypeError, ValueError):
            rating_pos = False
        line1 = trakt_list_label1_with_year_rating(
            item.get("title") or _t("Película", "Movie", "Film", "Film", "Film"),
            has_year,
            year,
            (rating if rating_pos else None),
        )
        tmdb_id_raw = item.get("tmdb_id")
        if tmdb_id_raw:
            try:
                _tn = int(str(tmdb_id_raw).strip())
                tmdb = dict(tmdb_px.get(_tn) or {})
            except (TypeError, ValueError):
                tmdb = tmdb_id_details(tmdb_id_raw, media_type="movie") or {}
        else:
            tmdb = {}
        r_info = rating
        if (
            (r_info is None or r_info <= 0)
            and tmdb.get("rating") is not None
            and tmdb.get("rating") > 0
        ):
            r_info = tmdb.get("rating")
        y_info = int(year) if (has_year and year is not None) else 0
        if not y_info and tmdb.get("has_year") and tmdb.get("year") is not None:
            y_info = int(tmdb.get("year") or 0)
        info = {
            "title": line1,
            "plot": item.get("plot") or "",
            "mediatype": "movie",
            "year": y_info,
            "rating": r_info if (r_info is not None and r_info > 0) else 0,
        }
        li = xbmcgui.ListItem(label=line1, label2=item.get("plot", "")[:120])
        trakt_listitem_set_info_and_videotag(
            li,
            item.get("title") or "",
            item.get("plot") or "",
            False,
            has_year and year is not None,
            year,
            r_info,
            None,
            info,
        )
        art = dict(base_art)
        p = str((tmdb or {}).get("poster") or "").strip()
        f = str((tmdb or {}).get("fanart") or "").strip()
        if p:
            art.update({"poster": p, "thumb": p, "icon": p})
        if f:
            art.update({"fanart": f, "landscape": f, "banner": f})
        li.setArt(art)
        li.setProperty("IsPlayable", "true")
        add_movie_download_context(li, rid)
        directory.append((url_for_play(rid), li, False))

    if not directory:
        li = xbmcgui.ListItem(
            label=_t(
                "Sin resultados en este listado",
                "No results in this list",
                "Aucun résultat dans cette liste",
                "Nessun risultato in questa lista",
                "Keine Ergebnisse in dieser Liste",
            )
        )
        li.setProperty("IsPlayable", "false")
        li.setArt(base_art)
        directory.append((url_for_noop(), li, False))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle, True)
    return True
