"""
Arranque Stremio:
- Activa TODOS los complementos Stremio soportados por Kraken.
- Prepara/normaliza manifest/catalog URLs.
- Persistir `stremio_addons_state` para que el proveedor funcione al instante.
"""

import json

import xbmcaddon

from resources.lib.sources.stremio_sources_config import STREMIO_DEFAULT_MANIFEST_BY_PREFIX
from resources.lib.core.stremio_alldebrid_url import augment_stremio_debrid_pipe_url
from resources.lib.core.stremio_debrid_pipe import best_debrid_pipe_for_stremio
from resources.lib.core.stremio_manifest_urls import normalize_manifest_or_catalog_url

# IDs legacy en settings.xml (compatibilidad con usuarios que ya tienen perfil guardado)
SETTING_FIRST_RUN_DONE = "kraken_setup_wizard_done"
SETTING_FIRST_RUN_PROFILE = "kraken_setup_wizard_profile"

_ALL_STREMIO_TOGGLE_PREFIXES = (
    "stremio_torrentio",
    "stremio_preeflix",
    "stremio_aiostreams",
    "stremio_comet",
    "stremio_mediafusion",
    "stremio_tvvoo",
    "stremio_jackettio",
    "stremio_knightcrawler",
    "stremio_annatar",
)

def _localized_fallback(string_id, english_fallback):
    try:
        s = xbmcaddon.Addon().getLocalizedString(string_id)
        t = str(s).strip()
        if t:
            return t
    except Exception:
        pass
    return english_fallback


_RECOMMENDED_ADDONS = (
    ("Torrentio", "stremio_torrentio"),
    ("Preeflix", "stremio_preeflix"),
    ("AIOStreams", "stremio_aiostreams"),
    ("Comet", "stremio_comet"),
    ("MediaFusion", "stremio_mediafusion"),
    ("Jackettio", "stremio_jackettio"),
    ("KnightCrawler", "stremio_knightcrawler"),
    ("Annatar", "stremio_annatar"),
)


def _auto_manifest_for_addon(prefix, get_setting, debrid_pipe):
    current = str(get_setting(f"{prefix}_url") or "").strip()
    if "debridoptions=torrentlinks" in current.lower():
        current = current.replace(
            "debridoptions=torrentlinks", "debridoptions=streamlinks"
        )
    # AIOStreams: el URL "/manifest.json" suele apuntar a un manifest web (PWA),
    # mientras que el addon Stremio está bajo "/stremio/manifest.json".
    if prefix == "stremio_aiostreams" and current:
        if (
            "aiostreams.elfhosted.com/manifest.json" in current.lower()
            and "aiostreams.elfhosted.com/stremio/manifest.json" not in current.lower()
        ):
            current = current.replace(
                "aiostreams.elfhosted.com/manifest.json",
                "aiostreams.elfhosted.com/stremio/manifest.json",
            )
    if current:
        return current

    base = STREMIO_DEFAULT_MANIFEST_BY_PREFIX.get(prefix, "")
    if not base:
        base = str(get_setting(f"{prefix}_web_url") or "").strip()
    if not base:
        return ""
    if debrid_pipe:
        base = augment_stremio_debrid_pipe_url(
            base, debrid_pipe.get("token"), debrid_pipe.get("pipe_key")
        )
    return normalize_manifest_or_catalog_url(base)


def sync_stremio_all_named_addons(get_bool_setting, get_setting, set_setting):
    """
    Todos los complementos Stremio soportados: enabled=true, manifest URL rellenada
    y `stremio_addons_state` alineado (comportamiento esperado en Kraken).
    """
    debrid_pipe = best_debrid_pipe_for_stremio(get_bool_setting, get_setting)
    inject_debrid = bool(
        get_bool_setting("stremio_alldebrid_auto_torrentio") and debrid_pipe
    )
    pipe = debrid_pipe if inject_debrid else None

    custom_rows = []
    try:
        raw = str(get_setting("stremio_addons_state") or "").strip()
        if raw:
            parsed = json.loads(raw)
            if isinstance(parsed, dict) and isinstance(parsed.get("custom"), list):
                custom_rows = parsed.get("custom") or []
    except Exception:
        pass

    for prefix in _ALL_STREMIO_TOGGLE_PREFIXES:
        set_setting(f"{prefix}_enabled", True)

    urls_by_prefix = {}
    for prefix in _ALL_STREMIO_TOGGLE_PREFIXES:
        norm = _auto_manifest_for_addon(prefix, get_setting, pipe)
        if not norm:
            norm = STREMIO_DEFAULT_MANIFEST_BY_PREFIX.get(prefix, "")
        if norm:
            set_setting(f"{prefix}_url", norm)
            urls_by_prefix[prefix] = norm.strip()
        else:
            urls_by_prefix[prefix] = str(get_setting(f"{prefix}_url") or "").strip()

    name_by_prefix = {p: n for n, p in _RECOMMENDED_ADDONS}
    name_by_prefix["stremio_tvvoo"] = "Tvvoo"
    known_state = {}
    for prefix in _ALL_STREMIO_TOGGLE_PREFIXES:
        name = name_by_prefix.get(prefix) or prefix.replace("stremio_", "").title()
        u = str(urls_by_prefix.get(prefix) or get_setting(f"{prefix}_url") or "").strip()
        if not u:
            u = STREMIO_DEFAULT_MANIFEST_BY_PREFIX.get(prefix, "")
        known_state[prefix] = {
            "name": name,
            "enabled": True,
            "url": u,
            "web_url": str(get_setting(f"{prefix}_web_url") or "").strip(),
        }

    set_setting(
        "stremio_addons_state",
        json.dumps({"known": known_state, "custom": custom_rows}, ensure_ascii=True),
    )


def apply_stremio_autostart_defaults(get_bool_setting, get_setting, set_setting):
    """Catálogo Stremio, toggles recomendados y URLs de manifest (Debrid opcional)."""
    set_setting("provider_stremio_catalog", True)
    set_setting("stremio_use_per_addon_toggle", True)
    set_setting("stremio_http_timeout", "25")
    # Idioma en automático según Kodi (el usuario puede forzarlo luego).
    set_setting("autoplay_source_by_language", True)
    set_setting("autoplay_movies_enabled", False)
    set_setting("autoplay_series_enabled", True)
    _any = _localized_fallback(30186, "Any")
    _auto = _localized_fallback(30169, "Auto (Kodi)")
    set_setting("autoplay_lang_primary", _any)
    set_setting("autoplay_lang_secondary", _any)
    set_setting("trakt_plot_language", _auto)
    set_setting("opensubtitles_preferred_lang", _auto)
    set_setting("opensubtitles_fallback_lang", "en")

    sync_stremio_all_named_addons(get_bool_setting, get_setting, set_setting)

    set_setting(SETTING_FIRST_RUN_DONE, "true")
    set_setting(SETTING_FIRST_RUN_PROFILE, "recommended")


def ensure_stremio_ready_for_search(get_bool_setting, get_setting, set_setting):
    """
    Garantiza que Stremio esté utilizable para búsqueda desde el inicio.
    No pisa una configuración ya válida del usuario; solo repara mínimos.
    """
    try:
        set_setting("provider_stremio_catalog", True)
        set_setting("stremio_use_per_addon_toggle", True)
        # Reforzar defaults de idioma en instalaciones limpias o dañadas.
        if not str(get_setting("autoplay_lang_primary") or "").strip():
            set_setting("autoplay_lang_primary", _localized_fallback(30186, "Any"))
        if not str(get_setting("autoplay_lang_secondary") or "").strip():
            set_setting("autoplay_lang_secondary", _localized_fallback(30186, "Any"))
        if str(get_setting("autoplay_movies_enabled") or "").strip() == "":
            set_setting("autoplay_movies_enabled", "false")
        if str(get_setting("autoplay_series_enabled") or "").strip() == "":
            set_setting("autoplay_series_enabled", "true")
        if not str(get_setting("trakt_plot_language") or "").strip():
            set_setting("trakt_plot_language", _localized_fallback(30169, "Auto (Kodi)"))
        if not str(get_setting("opensubtitles_preferred_lang") or "").strip():
            set_setting(
                "opensubtitles_preferred_lang", _localized_fallback(30169, "Auto (Kodi)")
            )
    except Exception:
        pass

    # Si falta alguno de los complementos, forzamos activación de todos.
    missing = []
    for prefix in _ALL_STREMIO_TOGGLE_PREFIXES:
        try:
            enabled = bool(get_bool_setting(f"{prefix}_enabled"))
        except Exception:
            enabled = (
                str(get_setting(f"{prefix}_enabled") or "")
                .strip()
                .lower()
                == "true"
            )
        url = str(get_setting(f"{prefix}_url") or "").strip()
        if (not enabled) or (not url):
            missing.append(prefix)

    # Además, verificar que el proveedor leerá algo válido:
    # si `stremio_addons_state` está incompleto o desincronizado,
    # aplicamos defaults para regenerar el estado "known".
    try:
        raw = str(get_setting("stremio_addons_state") or "").strip()
        if raw:
            parsed = json.loads(raw)
            known = parsed.get("known") if isinstance(parsed, dict) else None
            if isinstance(known, dict):
                for prefix in _ALL_STREMIO_TOGGLE_PREFIXES:
                    row = known.get(prefix) if known else None
                    if not isinstance(row, dict):
                        if prefix not in missing:
                            missing.append(prefix)
                        continue
                    en_val = row.get("enabled", False)
                    if isinstance(en_val, str):
                        en = en_val.strip().lower() == "true"
                    else:
                        en = bool(en_val)
                    if (not en) or not str(row.get("url") or "").strip():
                        if prefix not in missing:
                            missing.append(prefix)
            else:
                missing.extend(
                    [p for p in _ALL_STREMIO_TOGGLE_PREFIXES if p not in missing]
                )
    except Exception:
        # Si no podemos parsear, asumimos estado corrupto/incompleto.
        missing.extend([p for p in _ALL_STREMIO_TOGGLE_PREFIXES if p not in missing])
    if missing:
        apply_stremio_autostart_defaults(
            get_bool_setting, get_setting, set_setting
        )
    else:
        # Aunque nada falte, mantener todos los complementos activos y estado/URLs coherentes.
        sync_stremio_all_named_addons(get_bool_setting, get_setting, set_setting)
