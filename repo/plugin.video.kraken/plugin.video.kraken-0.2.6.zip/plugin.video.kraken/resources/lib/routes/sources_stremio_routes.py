"""Centro Stremio con diálogos nativos de Kodi (sin ventana XML propia)."""

import json
import re
import time
from urllib.error import URLError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

import xbmc
import xbmcgui

from resources.lib.core.kodi_run_plugin import escape_for_quoted_builtin
from resources.lib.core.kraken_qr_ui import (
    open_kraken_qr_modal,
    write_qr_png_to_special_temp,
)
from resources.lib.core.stremio_alldebrid_url import augment_stremio_debrid_pipe_url
from resources.lib.core.stremio_debrid_pipe import best_debrid_pipe_for_stremio
from resources.lib.core.stremio_manifest_urls import normalize_manifest_or_catalog_url
from resources.lib.providers.stremio_catalog import (
    StremioCatalogProvider,
    clear_stremio_manifest_session_cache,
)
from resources.lib.routes.stremio_catalog_pick_routes import (
    run_stremio_manifest_catalog_pick,
    run_stremio_manifest_catalog_pick_disable,
)
from resources.lib.routes.stremio_check_routes import run_stremio_manifest_check
from resources.lib.sources.stremio_sources_config import (
    SETTING_PER_ADDON_TOGGLE,
    STREMIO_CATALOG_NAMED_ADDONS,
    format_sources_configuration_summary,
)
from resources.lib.stremio.domain import (
    apply_remote_addons_to_settings,
    fetch_remote_addons,
    login_stremio,
    merge_remote_with_locals,
    normalize_manifest_url,
    parse_named_custom,
    resolve_manifest_icon,
    serialize_named_custom,
)
from resources.lib.stremio.logo_assets import (
    cache_remote_logo,
    clear_cached_logos,
    default_logo,
)
from resources.lib.ui.ui_helpers import _t

_MASTER = "provider_stremio_catalog"
_STREMIO_ICON_CACHE = {}
_STREMIO_DEBRID_LIST_URL = "https://stremio-addons.netlify.app/?label=debrid-support"


def run_stremio_bootstrap_es_debrid(*, get_bool_setting, get_setting, set_setting):
    """
    Ajuste inicial estilo Jacktook:
    - activa catálogo Stremio.
    - prepara URLs base en español.
    - intenta usar el token Debrid activo (AD/RD/PM) en addons compatibles.
    """
    debrid_data = best_debrid_pipe_for_stremio(get_bool_setting, get_setting)
    updates = {
        _MASTER: True,
        SETTING_PER_ADDON_TOGGLE: True,
    }

    enabled_count = 0
    for _name, prefix in STREMIO_CATALOG_NAMED_ADDONS:
        sid = f"{prefix}_url"
        url = str(updates.get(sid, get_setting(sid)) or "").strip()
        is_enabled = bool(url)
        updates[f"{prefix}_enabled"] = is_enabled
        if is_enabled:
            enabled_count += 1

    for sid, value in updates.items():
        try:
            set_setting(sid, value)
        except Exception:
            pass

    token_line = (
        debrid_data["display"]
        if debrid_data
        else _t(
            "sin token Debrid activo",
            "no active Debrid token",
            "pas de token Debrid actif",
            "nessun token Debrid attivo",
            "kein aktives Debrid-Token",
        )
    )
    xbmcgui.Dialog().notification(
        "Kraken - Stremio",
        _t(
            f"Autoconfig ES aplicada: {enabled_count} add-ons | Debrid: {token_line}",
            f"ES autoconfig applied: {enabled_count} add-ons | Debrid: {token_line}",
            f"Autoconfig ES appliquée : {enabled_count} add-ons | Debrid : {token_line}",
            f"Autoconfig ES applicata: {enabled_count} add-on | Debrid: {token_line}",
            f"ES-Autokonfig angewendet: {enabled_count} Add-ons | Debrid: {token_line}",
        ),
        xbmcgui.NOTIFICATION_INFO,
        5500,
    )


def run_stremio_sync_assistant(*, get_bool_setting, get_setting, set_setting):
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(
        _t(
            "Kraken - Stremio Sync",
            "Kraken - Stremio Sync",
            "Kraken - Synchronisation Stremio",
            "Kraken - Sincronizzazione Stremio",
            "Kraken - Stremio-Sync",
        ),
        _t(
            "Asistente interno (sin navegador):\n"
            "1) elegir complementos\n"
            "2) pegar manifests/catalog URLs\n"
            "3) guardar y sincronizar en Kraken\n\n"
            "¿Empezar ahora?",
            "Internal assistant (no browser):\n"
            "1) choose add-ons\n"
            "2) paste manifest/catalog URLs\n"
            "3) save and sync in Kraken\n\n"
            "Start now?",
            "Assistant interne (sans navigateur) :\n"
            "1) choisir les extensions\n"
            "2) coller les URLs manifest/catalogue\n"
            "3) enregistrer et synchroniser dans Kraken\n\n"
            "Commencer maintenant ?",
            "Assistente interno (senza browser):\n"
            "1) scegli addon\n"
            "2) incolla URL manifest/catalogo\n"
            "3) salva e sincronizza in Kraken\n\n"
            "Iniziare ora?",
            "Interner Assistent (ohne Browser):\n"
            "1) Add-ons waehlen\n"
            "2) Manifest-/Katalog-URLs einfuegen\n"
            "3) speichern und in Kraken synchronisieren\n\n"
            "Jetzt starten?",
        ),
        nolabel=_t("Cancelar", "Cancel", "Annuler", "Annulla", "Abbrechen"),
        yeslabel=_t("Empezar", "Start", "Demarrer", "Inizia", "Start"),
    ):
        return

    entries = []
    for name, prefix in STREMIO_CATALOG_NAMED_ADDONS:
        url_sid = f"{prefix}_url"
        web_sid = f"{prefix}_web_url"
        entries.append((name, prefix, url_sid, web_sid))
    labels = [name for name, _p, _u, _w in entries]
    preselect = []
    for i, (_name, prefix, url_sid, _web_sid) in enumerate(entries):
        enabled = str(get_setting(f"{prefix}_enabled") or "").strip().lower() == "true"
        has_url = bool(str(get_setting(url_sid) or "").strip())
        if enabled or has_url:
            preselect.append(i)

    picked = dialog.multiselect(
        _t(
            "Complementos Stremio a sincronizar",
            "Stremio add-ons to sync",
            "Extensions Stremio à synchroniser",
            "Addon Stremio da sincronizzare",
            "Zu synchronisierende Stremio-Add-ons",
        ),
        labels,
        preselect=preselect,
    )
    if picked is None:
        return
    picked_set = set(picked)

    set_setting(_MASTER, True)
    set_setting(SETTING_PER_ADDON_TOGGLE, True)
    for i, (_name, prefix, _url_sid, _web_sid) in enumerate(entries):
        set_setting(f"{prefix}_enabled", i in picked_set)

    debrid_data = best_debrid_pipe_for_stremio(get_bool_setting, get_setting)
    inject_debrid = bool(
        debrid_data and get_bool_setting("stremio_alldebrid_auto_torrentio")
    )

    updated = 0
    for i, (name, _prefix, url_sid, web_sid) in enumerate(entries):
        if i not in picked_set:
            continue
        current_url = str(get_setting(url_sid) or "").strip()
        web_hint = str(get_setting(web_sid) or "").strip()
        prompt = f"{name}{_t(' · pega URL manifest/catalog', ' · paste manifest/catalog URL', ' · URL manifest/catalogue', ' · URL manifest/catalogo', ' · Manifest-/Katalog-URL')}"
        if web_hint:
            prompt += "\n" + _t(
                "(web config guardada: {h})",
                "(saved web config: {h})",
                "(config web enregistrée : {h})",
                "(config web salvata: {h})",
                "(Web-Konfig gespeichert: {h})",
            ).format(h=web_hint)
        typed = dialog.input(
            prompt,
            defaultt=current_url,
            type=xbmcgui.INPUT_ALPHANUM,
        )
        typed = str(typed or "").strip()
        if not typed:
            continue
        norm = normalize_manifest_or_catalog_url(typed)
        if not norm:
            continue
        if inject_debrid:
            norm = augment_stremio_debrid_pipe_url(
                norm,
                str(debrid_data.get("token") or "").strip(),
                str(debrid_data.get("pipe_key") or "").strip(),
            )
        set_setting(url_sid, norm)
        updated += 1

    clear_stremio_manifest_session_cache()
    if inject_debrid:
        token_txt = _t(
            "sí ({d})",
            "yes ({d})",
            "oui ({d})",
            "sì ({d})",
            "ja ({d})",
        ).format(d=debrid_data.get("display"))
    else:
        token_txt = _t("no", "no", "non", "no", "nein")
    dialog.notification(
        "Kraken - Stremio",
        _t(
            "Sync listo: URLs actualizadas {u} | Debrid inyectado: {t}",
            "Sync done: URLs updated {u} | Debrid injected: {t}",
            "Sync terminé : URLs mises à jour {u} | Debrid injecté : {t}",
            "Sync pronto: URL aggiornate {u} | Debrid iniettato: {t}",
            "Sync fertig: URLs aktualisiert {u} | Debrid injiziert: {t}",
        ).format(u=updated, t=token_txt),
        xbmcgui.NOTIFICATION_INFO,
        6500,
    )
    _persist_stremio_state(get_setting, set_setting)


def run_stremio_sync_from_account(*, get_setting, set_setting):
    dialog = xbmcgui.Dialog()
    email = str(get_setting("stremio_account_email") or "").strip()
    password = str(get_setting("stremio_account_password") or "").strip()
    if not email or not password:
        dialog.ok(
            "Kraken - Stremio",
            _t(
                "No hay cuenta guardada.\n\nIntroduce email y contraseña de Stremio en Ajustes del add-on (pestaña Stremio / cuenta).",
                "No account saved.\n\nEnter your Stremio email and password in Add-on settings (Stremio / account tab).",
                "Aucun compte enregistré.\n\nEntrez l'e-mail et le mot de passe Stremio dans les paramètres de l'extension (onglet Stremio / compte).",
                "Nessun account salvato.\n\nInserisci email e password Stremio nelle impostazioni dell'addon (scheda Stremio / account).",
                "Kein Konto gespeichert.\n\nStremio E-Mail und Passwort in den Addon-Einstellungen (Tab Stremio / Konto) eingeben.",
            ),
        )
        return
    ok_stremio, stremio_err, auth_key, _user = login_stremio(email, password)
    if not ok_stremio:
        unk = _t("error desconocido", "unknown error", "erreur inconnue", "errore sconosciuto", "unbekannter Fehler")
        dialog.notification(
            "Kraken - Stremio",
            _t(
                "No se pudo validar la cuenta: {e}",
                "Could not validate account: {e}",
                "Impossible de valider le compte : {e}",
                "Impossibile validare l'account: {e}",
                "Konto konnte nicht bestätigt werden: {e}",
            ).format(e=stremio_err or unk),
            xbmcgui.NOTIFICATION_WARNING,
            5000,
        )
        return
    ok_pull, pull_err, remote = fetch_remote_addons(auth_key)
    if not ok_pull:
        dialog.notification(
            "Kraken - Stremio", pull_err, xbmcgui.NOTIFICATION_WARNING, 5000
        )
        return
    applied, custom_applied = apply_remote_addons_to_settings(
        remote_addons=remote,
        get_setting=get_setting,
        set_setting=set_setting,
        known_addons=STREMIO_CATALOG_NAMED_ADDONS,
    )
    dialog.notification(
        "Kraken - Stremio",
        _t(
            "Sincronización completada: {k} conocidos + {c} custom.",
            "Sync completed: {k} known + {c} custom.",
            "Synchronisation terminée : {k} connus + {c} personnalisés.",
            "Sincronizzazione completata: {k} noti + {c} personalizzati.",
            "Synchronisation abgeschlossen: {k} bekannt + {c} benutzerdefiniert.",
        ).format(k=applied, c=custom_applied),
        xbmcgui.NOTIFICATION_INFO,
        5000,
    )
    _persist_stremio_state(get_setting, set_setting)


def run_stremio_sync_review(*, get_setting, set_setting):
    dialog = xbmcgui.Dialog()
    before_known = set()
    for _name, prefix in STREMIO_CATALOG_NAMED_ADDONS:
        if str(get_setting(f"{prefix}_url") or "").strip():
            before_known.add(prefix)
    before_custom = {
        str(x.get("manifest_url") or "").lower()
        for x in parse_named_custom(get_setting("stremio_catalog_named"))
    }
    email = str(get_setting("stremio_account_email") or "").strip()
    password = str(get_setting("stremio_account_password") or "").strip()
    ok, err, auth_key, _user = login_stremio(email, password)
    if not ok:
        dialog.notification(
            "Kraken - Stremio",
            err
            or _t(
                "No se pudo iniciar sesión en Stremio.",
                "Could not sign in to Stremio.",
                "Impossible de se connecter a Stremio.",
                "Impossibile accedere a Stremio.",
                "Stremio-Anmeldung fehlgeschlagen.",
            ),
            xbmcgui.NOTIFICATION_WARNING,
            5000,
        )
        return
    ok_pull, pull_err, remote = fetch_remote_addons(auth_key)
    if not ok_pull:
        dialog.notification(
            "Kraken - Stremio",
            pull_err
            or _t(
                "No se pudieron obtener los complementos remotos.",
                "Could not fetch remote add-ons.",
                "Impossible d'obtenir les extensions distantes.",
                "Impossibile ottenere gli addon remoti.",
                "Remote-Add-ons konnten nicht abgerufen werden.",
            ),
            xbmcgui.NOTIFICATION_WARNING,
            5000,
        )
        return
    known, custom = merge_remote_with_locals(remote)
    known_new = set(known.keys()) - before_known
    custom_new = {
        str(x.get("manifest_url") or "").lower() for x in custom
    } - before_custom
    apply_remote_addons_to_settings(
        remote_addons=remote,
        get_setting=get_setting,
        set_setting=set_setting,
        known_addons=STREMIO_CATALOG_NAMED_ADDONS,
    )
    _persist_stremio_state(get_setting, set_setting)
    lines = [
        _t(
            "Sincronización y revisión completadas.",
            "Sync and review completed.",
            "Synchronisation et révision terminées.",
            "Sincronizzazione e revisione completate.",
            "Synchronisation und Überprüfung abgeschlossen.",
        ),
        "",
        _t(
            "Nuevos addons conocidos: {n}",
            "New known add-ons: {n}",
            "Nouvelles extensions connues : {n}",
            "Nuovi addon noti: {n}",
            "Neue bekannte Add-ons: {n}",
        ).format(n=len(known_new)),
        _t(
            "Nuevos addons custom: {n}",
            "New custom add-ons: {n}",
            "Nouvelles extensions personnalisées : {n}",
            "Nuovi addon personalizzati: {n}",
            "Neue benutzerdefinierte Add-ons: {n}",
        ).format(n=len(custom_new)),
    ]
    if known_new:
        lines.append("")
        lines.append(
            _t(
                "Conocidos nuevos: {l}",
                "New known: {l}",
                "Nouveaux connus : {l}",
                "Nuovi noti: {l}",
                "Neu bekannt: {l}",
            ).format(l=", ".join(sorted(known_new)))
        )
    dialog.textviewer(
        _t(
            "Kraken - Stremio Sync Review",
            "Kraken - Stremio Sync Review",
            "Kraken - Revue sync Stremio",
            "Kraken - Revisione sync Stremio",
            "Kraken - Stremio-Sync-Überprüfung",
        ),
        "\n".join(lines),
    )


def _extract_stremio_install_pairs(raw_text):
    """
    Extrae pares (nombre, manifest_url) desde el markdown/html de stremio-addons.netlify.app.
    Busca bloques con:
      [Addon Name vX.Y.Z](...) ... [Install](stremio://.../manifest.json)
    """
    text = str(raw_text or "")
    if not text:
        return []
    pattern = re.compile(
        r"\[([^\]]+?)\s+v[^\]]*\]\([^)]+\).*?\[Install\]\(stremio://([^)]+manifest\.json[^)]*)\)",
        re.IGNORECASE | re.DOTALL,
    )
    out = []
    seen = set()
    for name, strem_part in pattern.findall(text):
        manifest = "https://" + str(strem_part or "").strip().lstrip("/")
        manifest = normalize_manifest_url(manifest)
        if not manifest:
            continue
        low = manifest.lower()
        if low in seen:
            continue
        seen.add(low)
        clean_name = str(name or "").strip() or "Stremio Community"
        out.append((clean_name, manifest))
    return out


def run_stremio_import_debrid_manifests(*, get_setting, set_setting):
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(
        "Kraken - Stremio",
        _t(
            f"Se importarán manifests desde:\n{_STREMIO_DEBRID_LIST_URL}\n\n"
            "Fuente: listado comunitario (debrid support).\n"
            "Se guardarán como complementos custom en Kraken.\n\n¿Continuar?",
            f"Manifests will be imported from:\n{_STREMIO_DEBRID_LIST_URL}\n\n"
            "Source: community list (debrid support).\n"
            "They will be saved as custom add-ons in Kraken.\n\nContinue?",
            f"Import des manifests depuis :\n{_STREMIO_DEBRID_LIST_URL}\n\n"
            "Source : liste communautaire (debrid support).\n"
            "Ils seront enregistrés comme extensions personnalisées dans Kraken.\n\nContinuer ?",
            f"Import dei manifest da:\n{_STREMIO_DEBRID_LIST_URL}\n\n"
            "Fonte: elenco community (debrid support).\n"
            "Saranno salvati come addon personalizzati in Kraken.\n\nContinuare?",
            f"Manifeste werden importiert von:\n{_STREMIO_DEBRID_LIST_URL}\n\n"
            "Quelle: Community-Liste (debrid support).\n"
            "Sie werden als benutzerdefinierte Add-ons in Kraken gespeichert.\n\nFortfahren?",
        ),
        nolabel=_t("Cancelar", "Cancel", "Annuler", "Annulla", "Abbrechen"),
        yeslabel=_t("Importar", "Import", "Importer", "Importa", "Importieren"),
    ):
        return

    try:
        req = Request(
            _STREMIO_DEBRID_LIST_URL,
            headers={"User-Agent": "Kraken-Stremio-Import/1.0"},
        )
        with urlopen(req, timeout=20) as response:
            payload = response.read().decode("utf-8", errors="replace")
    except Exception as ex:
        dialog.notification(
            "Kraken - Stremio",
            _t(
                "No se pudo descargar la lista: {e}",
                "Could not download the list: {e}",
                "Impossible de télécharger la liste : {e}",
                "Impossibile scaricare l'elenco: {e}",
                "Liste konnte nicht heruntergeladen werden: {e}",
            ).format(e=ex),
            xbmcgui.NOTIFICATION_WARNING,
            5500,
        )
        return

    pairs = _extract_stremio_install_pairs(payload)
    if not pairs:
        dialog.notification(
            "Kraken - Stremio",
            _t(
                "No se encontraron manifests en la página.",
                "No manifests found on the page.",
                "Aucun manifest trouvé sur la page.",
                "Nessun manifest trovato nella pagina.",
                "Keine Manifeste auf der Seite gefunden.",
            ),
            xbmcgui.NOTIFICATION_WARNING,
            5000,
        )
        return

    rows = parse_named_custom(get_setting("stremio_catalog_named"))
    seen = {
        str((r or {}).get("manifest_url") or "").strip().lower()
        for r in rows
        if isinstance(r, dict)
    }
    added = 0
    for name, manifest in pairs:
        low = manifest.lower()
        if low in seen:
            continue
        seen.add(low)
        rows.append({"name": name, "manifest_url": manifest})
        added += 1

    set_setting("provider_stremio_catalog", True)
    set_setting("stremio_use_per_addon_toggle", True)
    set_setting("stremio_catalog_named", serialize_named_custom(rows))
    _persist_stremio_state(get_setting, set_setting)
    clear_stremio_manifest_session_cache()

    dialog.notification(
        "Kraken - Stremio",
        _t(
            "Importación lista: {a} nuevos ({t}/{p} en total).",
            "Import done: {a} new ({t}/{p} total).",
            "Import terminé : {a} nouveaux ({t}/{p} au total).",
            "Import completato: {a} nuovi ({t}/{p} totale).",
            "Import fertig: {a} neu ({t}/{p} gesamt).",
        ).format(a=added, t=len(rows), p=len(pairs)),
        xbmcgui.NOTIFICATION_INFO,
        6500,
    )


def run_stremio_logo_refresh():
    removed = clear_cached_logos()
    _STREMIO_ICON_CACHE.clear()
    xbmcgui.Dialog().notification(
        "Kraken - Stremio",
        _t(
            "Cache de logos recargada ({r} archivo(s) limpiados).",
            "Logo cache refreshed ({r} file(s) cleaned).",
            "Cache des logos rechargée ({r} fichier(s) nettoyés).",
            "Cache logo aggiornata ({r} file ripuliti).",
            "Logo-Cache aktualisiert ({r} Datei(en) bereinigt).",
        ).format(r=removed),
        xbmcgui.NOTIFICATION_INFO,
        4500,
    )


def _known_addon_web_setting(prefix):
    return f"{prefix}_web_url"


def _persist_stremio_state(get_setting, set_setting):
    known = {}
    for _name, prefix in STREMIO_CATALOG_NAMED_ADDONS:
        known[prefix] = {
            "enabled": str(get_setting(f"{prefix}_enabled") or "").strip().lower()
            == "true",
            "url": str(get_setting(f"{prefix}_url") or "").strip(),
            "web_url": str(get_setting(f"{prefix}_web_url") or "").strip(),
        }
    custom_rows = []
    for row in parse_named_custom(get_setting("stremio_catalog_named")):
        custom_rows.append(
            {
                "name": row.get("name") or "Stremio",
                "url": row.get("manifest_url") or "",
                "enabled": True,
            }
        )
    set_setting(
        "stremio_addons_state", json.dumps({"known": known, "custom": custom_rows})
    )


def _logo_from_url(raw_url):
    try:
        host = (urlsplit(str(raw_url or "").strip()).hostname or "").strip().lower()
    except Exception:
        host = ""
    if not host:
        return ""
    return f"https://{host}/favicon.ico"


def _known_addon_logo(prefix, current_url):
    by_prefix = {
        "stremio_torrentio": "https://strem.fun/favicon.ico",
        "stremio_preeflix": "https://peerflix.mov/favicon.ico",
        "stremio_tvvoo": "https://hayd.uk/favicon.ico",
        "stremio_comet": "https://elfhosted.com/favicon.ico",
        "stremio_mediafusion": "https://elfhosted.com/favicon.ico",
        "stremio_aiostreams": "https://elfhosted.com/favicon.ico",
        "stremio_jackettio": "https://elfhosted.com/favicon.ico",
        "stremio_knightcrawler": "https://elfhosted.com/favicon.ico",
        "stremio_annatar": "https://elfhosted.com/favicon.ico",
    }
    if prefix in by_prefix:
        return by_prefix[prefix]
    return _logo_from_url(current_url)


def _default_logo_path():
    return default_logo()


def _cache_remote_icon_local(get_setting, icon_url):
    timeout = 25
    try:
        timeout = int(str(get_setting("stremio_http_timeout") or "25").strip() or "25")
    except Exception:
        timeout = 25
    return cache_remote_logo(icon_url, timeout=timeout)


def _manifest_icon_for_url(get_setting, raw_url):
    manifest_url = normalize_manifest_url(raw_url)
    if not manifest_url:
        return ""
    cache_key = manifest_url.strip().lower()
    if cache_key in _STREMIO_ICON_CACHE:
        return _STREMIO_ICON_CACHE.get(cache_key) or ""
    timeout = 25
    try:
        timeout = int(str(get_setting("stremio_http_timeout") or "25").strip() or "25")
    except Exception:
        timeout = 25
    timeout = max(8, min(120, timeout))
    req = Request(manifest_url, headers={"User-Agent": "Kraken-Stremio-Icon/1.0"})
    icon = _default_logo_path()
    try:
        with urlopen(req, timeout=timeout) as resp:  # nosec B310
            payload = json.loads(resp.read().decode("utf-8", errors="replace"))
        icon = (
            resolve_manifest_icon(
                manifest_url, str((payload or {}).get("icon") or "").strip()
            )
            or _default_logo_path()
        )
    except Exception:
        icon = _default_logo_path()
    icon = _cache_remote_icon_local(get_setting, icon)
    _STREMIO_ICON_CACHE[cache_key] = icon or _default_logo_path()
    return _STREMIO_ICON_CACHE[cache_key]


def _stremio_listitem(label, label2, icon):
    li = xbmcgui.ListItem(label=label, label2=label2)
    if icon:
        try:
            li.setArt({"icon": icon, "thumb": icon})
        except Exception:
            pass
    return li


def _parse_named_custom_addons(get_setting):
    rows = parse_named_custom(get_setting("stremio_catalog_named"))
    return [
        {"name": x.get("name") or "Stremio", "url": x.get("manifest_url") or ""}
        for x in rows
    ]


def _save_named_custom_addons(set_setting, rows):
    payload = [
        {"name": (r or {}).get("name"), "manifest_url": (r or {}).get("url")}
        for r in (rows or [])
    ]
    set_setting("stremio_catalog_named", serialize_named_custom(payload))


def _show_qr_for_url(
    dialog,
    *,
    title,
    url,
    mobile=False,
    addon_path=None,
    qr_dialog_cls=None,
):
    clean = str(url or "").strip()
    if not clean:
        dialog.ok(
            title,
            _t(
                "No hay URL para mostrar.",
                "No URL to display.",
                "Aucune URL à afficher.",
                "Nessun URL da mostrare.",
                "Keine URL anzuzeigen.",
            ),
        )
        return
    mobile_txt = "movil" if mobile else "web"
    fname = f"kraken_stremio_{mobile_txt}_qr.png"
    qr_special = write_qr_png_to_special_temp(fname, clean)

    body = _t(
        "URL de configuracion:\n\n{u}\n\nEscanea el codigo con el movil (misma red que Kodi).",
        "Configuration URL:\n\n{u}\n\nScan the code with your phone (same network as Kodi).",
        "URL de configuration :\n\n{u}\n\nScannez le code avec le mobile (même réseau que Kodi).",
        "URL di configurazione:\n\n{u}\n\nScansiona il codice con il telefono (stessa rete di Kodi).",
        "Konfigurations-URL:\n\n{u}\n\nCode mit dem Handy scannen (gleiches Netz wie Kodi).",
    ).format(u=clean)
    if qr_dialog_cls and (addon_path or "").strip() and qr_special:
        open_kraken_qr_modal(
            qr_dialog_cls,
            addon_path,
            dialog_title=title,
            body_text=body,
            qr_special_path=qr_special,
        )
        return

    if qr_special:
        try:
            xbmc.executebuiltin(f'ShowPicture("{qr_special}")')
        except Exception:
            pass
        else:
            return
    dialog.textviewer(
        title,
        _t(
            "No se pudo generar el QR local.\n\nCopia la URL en el navegador del movil:\n\n{u}",
            "Could not generate local QR.\n\nCopy the URL in your phone browser:\n\n{u}",
            "Impossible de générer le QR local.\n\nCopiez l'URL dans le navigateur du mobile :\n\n{u}",
            "Impossibile generare il QR locale.\n\nCopia l'URL nel browser del telefono:\n\n{u}",
            "Lokales QR konnte nicht erzeugt werden.\n\nURL im Browser des Handys oeffnen:\n\n{u}",
        ).format(u=clean),
    )


def _probe_manifest_url(get_setting, raw_url):
    url = normalize_manifest_or_catalog_url(raw_url)
    if not url:
        return False, _t(
            "URL vacía o inválida.",
            "Empty or invalid URL.",
            "URL vide ou invalide.",
            "URL vuota o non valida.",
            "URL leer oder ungueltig.",
        )
    timeout = 25
    try:
        timeout = int(str(get_setting("stremio_http_timeout") or "25").strip() or "25")
    except Exception:
        timeout = 25
    timeout = max(8, min(120, timeout))
    req = Request(url, headers={"User-Agent": "Kraken-Stremio-Probe/1.0"})
    try:
        with urlopen(req, timeout=timeout) as resp:  # nosec B310
            raw = resp.read()
            code = int(getattr(resp, "status", 200) or 200)
    except URLError as err:
        return False, _t(
            "Fallo HTTP: {e}",
            "HTTP failure: {e}",
            "Echec HTTP : {e}",
            "Errore HTTP: {e}",
            "HTTP-Fehler: {e}",
        ).format(e=str(getattr(err, "reason", err))[:120])
    except Exception as err:
        return False, _t(
            "Fallo de red: {e}",
            "Network failure: {e}",
            "Echec reseau : {e}",
            "Errore di rete: {e}",
            "Netzwerkfehler: {e}",
        ).format(e=str(err)[:120])
    try:
        payload = json.loads(raw.decode("utf-8", errors="replace"))
    except Exception as err:
        return False, _t(
            "Respuesta no JSON: {e}",
            "Not valid JSON: {e}",
            "Reponse pas JSON : {e}",
            "Risposta non JSON: {e}",
            "Kein gueltiges JSON: {e}",
        ).format(e=str(err)[:120])
    nn = _t("sin nombre", "no name", "sans nom", "senza nome", "ohne Namen")
    name = str(payload.get("name") or payload.get("id") or nn).strip()
    version = str(payload.get("version") or "").strip()
    if version:
        return True, _t(
            "HTTP {c} · {n} v{v}",
            "HTTP {c} · {n} v{v}",
            "HTTP {c} · {n} v{v}",
            "HTTP {c} · {n} v{v}",
            "HTTP {c} · {n} v{v}",
        ).format(c=code, n=name, v=version)
    return True, _t(
        "HTTP {c} · {n}",
        "HTTP {c} · {n}",
        "HTTP {c} · {n}",
        "HTTP {c} · {n}",
        "HTTP {c} · {n}",
    ).format(c=code, n=name)


def _edit_known_addon(
    dialog,
    *,
    name,
    prefix,
    get_setting,
    set_setting,
    addon_path=None,
    qr_dialog_cls=None,
):
    while True:
        enabled = str(get_setting(f"{prefix}_enabled") or "").strip().lower() == "true"
        manifest_url = str(get_setting(f"{prefix}_url") or "").strip()
        web_url = str(get_setting(_known_addon_web_setting(prefix)) or "").strip()
        opts = [
            (
                _t("Activar", "Enable", "Activer", "Attiva", "Aktivieren")
                if not enabled
                else _t("Desactivar", "Disable", "Desactiver", "Disattiva", "Deaktivieren")
            ),
            _t(
                "Editar URL manifest/catalog",
                "Edit manifest/catalog URL",
                "Modifier URL manifest/catalogue",
                "Modifica URL manifest/catalogo",
                "Manifest-/Katalog-URL bearbeiten",
            ),
            _t(
                "Probar addon ahora",
                "Test add-on now",
                "Tester l'extension maintenant",
                "Prova addon ora",
                "Add-on jetzt testen",
            ),
        ]
        if web_url:
            opts.append(
                _t(
                    "Editar URL web",
                    "Edit web URL",
                    "Modifier URL web",
                    "Modifica URL web",
                    "Web-URL bearbeiten",
                )
            )
            opts.append(
                _t(
                    "Abrir URL web",
                    "Open web URL",
                    "Ouvrir URL web",
                    "Apri URL web",
                    "Web-URL oeffnen",
                )
            )
        opts.append(_t("Volver", "Back", "Retour", "Indietro", "Zurueck"))
        idx = dialog.select(
            _t("Stremio · {n}", "Stremio · {n}", "Stremio · {n}", "Stremio · {n}", "Stremio · {n}").format(
                n=name
            ),
            opts,
        )
        if idx < 0 or idx == len(opts) - 1:
            return
        if idx == 0:
            set_setting(f"{prefix}_enabled", not enabled)
            _persist_stremio_state(get_setting, set_setting)
            continue
        if idx == 1:
            typed = dialog.input(
                f"{name}{_t(' · URL manifest/catalog', ' · manifest/catalog URL', ' · URL manifest/catalogue', ' · URL manifest/catalogo', ' · Manifest-/Katalog-URL')}",
                defaultt=manifest_url,
                type=xbmcgui.INPUT_ALPHANUM,
            )
            typed = str(typed or "").strip()
            if typed:
                norm = normalize_manifest_or_catalog_url(typed)
                if norm:
                    set_setting(f"{prefix}_url", norm)
                    set_setting(f"{prefix}_enabled", True)
                    _STREMIO_ICON_CACHE.clear()
                    _persist_stremio_state(get_setting, set_setting)
            continue
        if idx == 2:
            ok, msg = _probe_manifest_url(get_setting, manifest_url)
            dialog.notification(
                "Kraken - Stremio",
                "{}: {}".format(
                    _t("OK", "OK", "OK", "OK", "OK") if ok else _t("ERROR", "ERROR", "ERREUR", "ERRORE", "FEHLER"),
                    msg,
                ),
                xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_WARNING,
                5500,
            )
            continue
        if web_url and idx == 3:
            typed = dialog.input(
                f"{name}{_t(' · URL web', ' · web URL', ' · URL web', ' · URL web', ' · Web-URL')}",
                defaultt=web_url,
                type=xbmcgui.INPUT_ALPHANUM,
            )
            typed = str(typed or "").strip()
            if typed:
                set_setting(_known_addon_web_setting(prefix), typed)
                _persist_stremio_state(get_setting, set_setting)
            continue
        if web_url and idx == 4:
            in_mobile = dialog.yesno(
                _t(
                    "Kraken - Stremio · Configuracion",
                    "Kraken - Stremio · Setup",
                    "Kraken - Stremio · Configuration",
                    "Kraken - Stremio · Configurazione",
                    "Kraken - Stremio · Konfiguration",
                ),
                _t(
                    "¿Quieres configurar este addon desde el movil?\n\n"
                    "Si eliges SI, se mostrara el QR para movil.\n"
                    "Si eliges NO, se mostrara el QR web normal.",
                    "Configure this add-on from your phone?\n\n"
                    "Yes shows the mobile QR.\n"
                    "No shows the regular web QR.",
                    "Configurer cette extension depuis le mobile ?\n\n"
                    "Oui affiche le QR mobile.\n"
                    "Non affiche le QR web habituel.",
                    "Configurare questo addon dal telefono?\n\n"
                    "Si mostra il QR mobile.\n"
                    "No mostra il QR web normale.",
                    "Dieses Add-on vom Handy aus konfigurieren?\n\n"
                    "Ja zeigt mobiles QR.\n"
                    "Nein zeigt normales Web-QR.",
                ),
                nolabel=_t("No", "No", "Non", "No", "Nein"),
                yeslabel=_t("Si", "Yes", "Oui", "Sì", "Ja"),
            )
            _show_qr_for_url(
                dialog,
                title=_t(
                    "Kraken - Stremio · URL web",
                    "Kraken - Stremio · Web URL",
                    "Kraken - Stremio · URL web",
                    "Kraken - Stremio · URL web",
                    "Kraken - Stremio · Web-URL",
                ),
                url=web_url,
                mobile=in_mobile,
                addon_path=addon_path,
                qr_dialog_cls=qr_dialog_cls,
            )
            continue


def _edit_custom_addon(dialog, *, custom_rows, row_idx, get_setting, set_setting):
    if row_idx < 0 or row_idx >= len(custom_rows):
        return custom_rows
    while True:
        row = custom_rows[row_idx]
        name = str(row.get("name") or "Stremio Custom").strip() or "Stremio Custom"
        url = str(row.get("url") or "").strip()
        opts = [
            _t("Editar nombre", "Edit name", "Modifier le nom", "Modifica nome", "Namen bearbeiten"),
            _t(
                "Editar URL manifest/catalog",
                "Edit manifest/catalog URL",
                "Modifier URL manifest/catalogue",
                "Modifica URL manifest/catalogo",
                "Manifest-/Katalog-URL bearbeiten",
            ),
            _t(
                "Probar addon ahora",
                "Test add-on now",
                "Tester l'extension maintenant",
                "Prova addon ora",
                "Add-on jetzt testen",
            ),
            _t(
                "Eliminar complemento",
                "Remove add-on",
                "Supprimer l'extension",
                "Rimuovi addon",
                "Add-on entfernen",
            ),
            _t("Volver", "Back", "Retour", "Indietro", "Zurueck"),
        ]
        idx = dialog.select(
            _t(
                "Stremio Custom · {n}",
                "Stremio Custom · {n}",
                "Stremio perso · {n}",
                "Stremio Custom · {n}",
                "Stremio Custom · {n}",
            ).format(n=name),
            opts,
        )
        if idx < 0 or idx == 4:
            return custom_rows
        if idx == 0:
            typed = dialog.input(
                _t(
                    "Nombre del complemento",
                    "Add-on name",
                    "Nom de l'extension",
                    "Nome addon",
                    "Add-on-Name",
                ),
                defaultt=name,
                type=xbmcgui.INPUT_ALPHANUM,
            )
            typed = str(typed or "").strip()
            if typed:
                row["name"] = typed
            custom_rows[row_idx] = row
            _save_named_custom_addons(set_setting, custom_rows)
            _persist_stremio_state(get_setting, set_setting)
            continue
        if idx == 1:
            typed = dialog.input(
                _t(
                    "URL manifest/catalog",
                    "Manifest/catalog URL",
                    "URL manifest/catalogue",
                    "URL manifest/catalogo",
                    "Manifest-/Katalog-URL",
                ),
                defaultt=url,
                type=xbmcgui.INPUT_ALPHANUM,
            )
            typed = str(typed or "").strip()
            norm = normalize_manifest_or_catalog_url(typed)
            if norm:
                row["url"] = norm
                custom_rows[row_idx] = row
                _save_named_custom_addons(set_setting, custom_rows)
                _STREMIO_ICON_CACHE.clear()
                _persist_stremio_state(get_setting, set_setting)
            continue
        if idx == 2:
            ok, msg = _probe_manifest_url(get_setting, url)
            dialog.notification(
                "Kraken - Stremio",
                "{}: {}".format(
                    _t("OK", "OK", "OK", "OK", "OK") if ok else _t("ERROR", "ERROR", "ERREUR", "ERRORE", "FEHLER"),
                    msg,
                ),
                xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_WARNING,
                5500,
            )
            continue
        if idx == 3:
            del custom_rows[row_idx]
            _save_named_custom_addons(set_setting, custom_rows)
            _persist_stremio_state(get_setting, set_setting)
            return custom_rows


def run_stremio_addons_manager(
    *,
    addon,
    get_setting,
    set_setting,
    addon_path=None,
    qr_dialog_cls=None,
):
    dialog = xbmcgui.Dialog()
    while True:
        rows = []
        for name, prefix in STREMIO_CATALOG_NAMED_ADDONS:
            enabled = (
                str(get_setting(f"{prefix}_enabled") or "").strip().lower() == "true"
            )
            manifest_url = str(get_setting(f"{prefix}_url") or "").strip()
            has_url = bool(manifest_url)
            state = _t("ON", "ON", "ON", "ON", "ON") if enabled else _t("OFF", "OFF", "OFF", "OFF", "OFF")
            no_url = _t("sin URL", "no URL", "pas d'URL", "nessun URL", "keine URL")
            status = "{} · {}".format(
                state,
                _t("URL", "URL", "URL", "URL", "URL") if has_url else no_url,
            )
            icon = ""
            if manifest_url:
                icon = _manifest_icon_for_url(get_setting, manifest_url)
            if not icon:
                icon = _known_addon_logo(prefix, manifest_url)
            rows.append(
                {
                    "type": "known",
                    "name": name,
                    "prefix": prefix,
                    "icon": icon,
                    "label": _t(
                        "[K] {n} ({s})",
                        "[K] {n} ({s})",
                        "[K] {n} ({s})",
                        "[K] {n} ({s})",
                        "[K] {n} ({s})",
                    ).format(n=name, s=status),
                    "label2": _t(
                        "Complemento conocido",
                        "Known add-on",
                        "Extension connue",
                        "Addon noto",
                        "Bekanntes Add-on",
                    ),
                    "bottom": _t(
                        "Gestionar {n} (activar, editar URL, probar)",
                        "Manage {n} (enable, edit URL, test)",
                        "Gerer {n} (activer, modifier URL, tester)",
                        "Gestisci {n} (attiva, modifica URL, prova)",
                        "{n} verwalten (aktivieren, URL bearbeiten, testen)",
                    ).format(n=name),
                    "selectable": True,
                }
            )
        custom_rows = _parse_named_custom_addons(get_setting)
        for i, item in enumerate(custom_rows):
            cname = str(item.get("name") or _t("Custom", "Custom", "Perso", "Personalizzato", "Custom")).strip() or _t(
                "Custom", "Custom", "Perso", "Personalizzato", "Custom"
            )
            custom_url = str(item.get("url") or "").strip()
            custom_icon = (
                _manifest_icon_for_url(get_setting, custom_url) if custom_url else ""
            )
            if not custom_icon:
                custom_icon = _logo_from_url(custom_url)
            rows.append(
                {
                    "type": "custom",
                    "idx": i,
                    "icon": custom_icon,
                    "label": _t(
                        "[C] {n} (URL)",
                        "[C] {n} (URL)",
                        "[C] {n} (URL)",
                        "[C] {n} (URL)",
                        "[C] {n} (URL)",
                    ).format(n=cname),
                    "label2": _t(
                        "Complemento personalizado",
                        "Custom add-on",
                        "Extension personnalisee",
                        "Addon personalizzato",
                        "Benutzerdefiniertes Add-on",
                    ),
                    "bottom": _t(
                        "Gestionar complemento custom",
                        "Manage custom add-on",
                        "Gerer extension personnalisee",
                        "Gestisci addon personalizzato",
                        "Benutzerdefiniertes Add-on verwalten",
                    ),
                    "selectable": True,
                }
            )
        add_idx = len(rows)
        close_idx = len(rows) + 1
        items = [
            _stremio_listitem(r["label"], r.get("label2", ""), r.get("icon", ""))
            for r in rows
        ]
        items.append(
            _stremio_listitem(
                _t(
                    "+ Añadir complemento custom",
                    "+ Add custom add-on",
                    "+ Extension personnalisee",
                    "+ Addon personalizzato",
                    "+ Benutzerdefiniertes Add-on",
                ),
                _t(
                    "Agregar manifest propio",
                    "Add your own manifest",
                    "Ajouter votre propre manifest",
                    "Aggiungi manifest proprio",
                    "Eigenes Manifest hinzufuegen",
                ),
                "",
            )
        )
        items.append(
            _stremio_listitem(
                _t("Cerrar", "Close", "Fermer", "Chiudi", "Schliessen"),
                _t("Salir del gestor", "Exit manager", "Quitter le gestionnaire", "Esci dal gestore", "Manager verlassen"),
                "",
            )
        )
        try:
            idx = dialog.select(
                _t(
                    "Kraken - Gestor Addons Stremio",
                    "Kraken - Stremio add-on manager",
                    "Kraken - Gestionnaire extensions Stremio",
                    "Kraken - Gestore addon Stremio",
                    "Kraken - Stremio Add-on-Manager",
                ),
                items,
                useDetails=True,
            )
        except TypeError:
            labels = [r["label"] for r in rows] + [
                _t(
                    "+ Añadir complemento custom",
                    "+ Add custom add-on",
                    "+ Extension personnalisee",
                    "+ Addon personalizzato",
                    "+ Benutzerdefiniertes Add-on",
                ),
                _t("Cerrar", "Close", "Fermer", "Chiudi", "Schliessen"),
            ]
            idx = dialog.select(
                _t(
                    "Kraken - Gestor Addons Stremio",
                    "Kraken - Stremio add-on manager",
                    "Kraken - Gestionnaire extensions Stremio",
                    "Kraken - Gestore addon Stremio",
                    "Kraken - Stremio Add-on-Manager",
                ),
                labels,
            )
        if idx < 0:
            return
        if idx == close_idx:
            return
        if idx == add_idx:
            name = dialog.input(
                _t(
                    "Nombre complemento custom",
                    "Custom add-on name",
                    "Nom extension personnalisee",
                    "Nome addon personalizzato",
                    "Name benutzerdefiniertes Add-on",
                ),
                defaultt=_t(
                    "Stremio Custom",
                    "Stremio Custom",
                    "Stremio perso",
                    "Stremio Custom",
                    "Stremio Custom",
                ),
                type=xbmcgui.INPUT_ALPHANUM,
            )
            name = str(name or "").strip() or _t(
                "Stremio Custom",
                "Stremio Custom",
                "Stremio perso",
                "Stremio Custom",
                "Stremio Custom",
            )
            url = dialog.input(
                _t(
                    "URL manifest/catalog",
                    "Manifest/catalog URL",
                    "URL manifest/catalogue",
                    "URL manifest/catalogo",
                    "Manifest-/Katalog-URL",
                ),
                defaultt="",
                type=xbmcgui.INPUT_ALPHANUM,
            )
            norm = normalize_manifest_or_catalog_url(url)
            if norm:
                custom_rows.append({"name": name, "url": norm})
                _save_named_custom_addons(set_setting, custom_rows)
                _STREMIO_ICON_CACHE.clear()
                _persist_stremio_state(get_setting, set_setting)
            continue
        selected = rows[idx]
        if selected["type"] == "known":
            _edit_known_addon(
                dialog,
                name=selected["name"],
                prefix=selected["prefix"],
                get_setting=get_setting,
                set_setting=set_setting,
                addon_path=addon_path,
                qr_dialog_cls=qr_dialog_cls,
            )
            continue
        custom_rows = _edit_custom_addon(
            dialog,
            custom_rows=custom_rows,
            row_idx=int(selected["idx"]),
            get_setting=get_setting,
            set_setting=set_setting,
        )


def run_stremio_named_addons_multiselect(*, get_bool_setting, get_setting, set_setting):
    """Fase C: persiste *_enabled y activa el filtro por complemento (Jacktook-style)."""
    entries = []
    for name, prefix in STREMIO_CATALOG_NAMED_ADDONS:
        url = (get_setting(f"{prefix}_url") or "").strip()
        if url:
            entries.append((name, prefix))

    if not entries:
        xbmcgui.Dialog().ok(
            "Kraken - Stremio",
            _t(
                "No hay complementos con URL configurada.\n\n"
                "Define al menos una URL en Ajustes > Kraken - Stremio.",
                "No add-ons with a configured URL.\n\n"
                "Set at least one URL in Settings > Kraken - Stremio.",
                "Aucune extension avec URL configuree.\n\n"
                "Definissez au moins une URL dans Parametres > Kraken - Stremio.",
                "Nessun addon con URL configurata.\n\n"
                "Imposta almeno un URL in Impostazioni > Kraken - Stremio.",
                "Keine Add-ons mit konfigurierter URL.\n\n"
                "Mindestens eine URL unter Einstellungen > Kraken - Stremio setzen.",
            ),
        )
        return

    labels = [e[0] for e in entries]
    use_toggle = bool(get_bool_setting(SETTING_PER_ADDON_TOGGLE))
    preselect = []
    for i, (_name, prefix) in enumerate(entries):
        if use_toggle and get_bool_setting(f"{prefix}_enabled"):
            preselect.append(i)
        if not use_toggle:
            preselect.append(i)

    dlg = xbmcgui.Dialog()
    picked = dlg.multiselect(
        _t(
            "Complementos en el catalogo (marca los activos)",
            "Catalog add-ons (check active ones)",
            "Extensions du catalogue (cochez les actives)",
            "Addon del catalogo (seleziona quelli attivi)",
            "Katalog-Add-ons (Aktive markieren)",
        ),
        labels,
        preselect=preselect,
    )
    if picked is None:
        return

    picked_set = set(picked)
    try:
        set_setting(SETTING_PER_ADDON_TOGGLE, True)
        for i, (_name, prefix) in enumerate(entries):
            set_setting(f"{prefix}_enabled", i in picked_set)
        _persist_stremio_state(get_setting, set_setting)
    except Exception as ex:
        dlg.notification(
            "Kraken",
            _t(
                "No se pudo guardar: {e}",
                "Could not save: {e}",
                "Impossible d'enregistrer : {e}",
                "Impossibile salvare: {e}",
                "Speichern fehlgeschlagen: {e}",
            ).format(e=ex),
            xbmcgui.NOTIFICATION_ERROR,
            5000,
        )
        return

    dlg.notification(
        "Kraken",
        _t(
            "Filtro activo: {n} complemento(s) en el catalogo.",
            "Filter active: {n} add-on(s) in the catalog.",
            "Filtre actif : {n} extension(s) dans le catalogue.",
            "Filtro attivo: {n} addon nel catalogo.",
            "Filter aktiv: {n} Add-on(s) im Katalog.",
        ).format(n=len(picked)),
        xbmcgui.NOTIFICATION_INFO,
        4500,
    )


def run_stremio_movie_search_test(*, addon, get_setting):
    """
    Prueba rápida de búsqueda de película por addon Stremio activo.
    Muestra cuántos resultados devuelve cada complemento.
    """
    dlg = xbmcgui.Dialog()
    query = dlg.input(
        _t(
            "Prueba Stremio · Película a buscar",
            "Stremio test · Movie to search",
            "Test Stremio · Film a rechercher",
            "Test Stremio · Film da cercare",
            "Stremio-Test · Zu suchender Film",
        ),
        defaultt="Avatar",
        type=xbmcgui.INPUT_ALPHANUM,
    )
    query = str(query or "").strip()
    if not query:
        return

    provider = StremioCatalogProvider(addon)
    lines = [
        _t("Consulta: {q}", "Query: {q}", "Requete : {q}", "Query: {q}", "Abfrage: {q}").format(
            q=query
        ),
        "",
    ]
    tested = 0
    ok_count = 0
    fail_count = 0

    for name, prefix in STREMIO_CATALOG_NAMED_ADDONS:
        url = str(get_setting(f"{prefix}_url") or "").strip()
        if not url:
            lines.append(
                _t("· {n}: sin URL", "· {n}: no URL", "· {n}: pas d'URL", "· {n}: nessun URL", "· {n}: keine URL").format(
                    n=name
                )
            )
            continue
        enabled = str(get_setting(f"{prefix}_enabled") or "").strip().lower() == "true"
        if not enabled:
            lines.append(
                _t(
                    "· {n}: desactivado",
                    "· {n}: disabled",
                    "· {n}: desactive",
                    "· {n}: disattivato",
                    "· {n}: deaktiviert",
                ).format(n=name)
            )

        tested += 1
        transport = provider.transport_base_from_catalog_url(url)
        manifest_url = (
            "{}/manifest.json".format(transport.rstrip("/")) if transport else ""
        )
        if not manifest_url:
            fail_count += 1
            lines.append(
                _t(
                    "· {n}: ERROR (URL no válida)",
                    "· {n}: ERROR (invalid URL)",
                    "· {n}: ERREUR (URL invalide)",
                    "· {n}: ERRORE (URL non valida)",
                    "· {n}: FEHLER (ungueltige URL)",
                ).format(n=name)
            )
            continue

        # Paso 1: salud de manifest.
        try:
            t0 = time.time()
            manifest = provider._fetch_json(manifest_url)
            ms_manifest = int((time.time() - t0) * 1000.0)
        except Exception as ex:
            fail_count += 1
            lines.append(
                _t("· {n}: ERROR manifest ({e})", "· {n}: manifest ERROR ({e})", "· {n}: ERREUR manifest ({e})", "· {n}: ERRORE manifest ({e})", "· {n}: Manifest-FEHLER ({e})").format(
                    n=name, e=ex
                )
            )
            continue

        catalogs = manifest.get("catalogs") if isinstance(manifest, dict) else []
        catalogs = catalogs if isinstance(catalogs, list) else []
        movie_catalogs = []
        movie_search_catalogs = []
        for c in catalogs:
            if not isinstance(c, dict):
                continue
            mt = str(c.get("type") or "").strip().lower()
            if mt not in ("movie",):
                continue
            cid = str(c.get("id") or "").strip()
            if not cid:
                continue
            movie_catalogs.append((mt, cid))
            extra = c.get("extra") or []
            extra_supported = c.get("extraSupported") or []
            supports_search = False
            for item in extra:
                if (
                    isinstance(item, dict)
                    and str(item.get("name") or "").strip().lower() == "search"
                ):
                    supports_search = True
                    break
            if not supports_search:
                for item in extra_supported:
                    if str(item).strip().lower() == "search":
                        supports_search = True
                        break
            if supports_search:
                movie_search_catalogs.append((mt, cid))

        if not movie_search_catalogs:
            fail_count += 1
            if movie_catalogs:
                lines.append(
                    _t(
                        "· {n}: manifest OK ({ms} ms), tiene catálogos de película ({c}) pero no endpoint search",
                        "· {n}: manifest OK ({ms} ms), has movie catalogs ({c}) but no search endpoint",
                        "· {n}: manifest OK ({ms} ms), catalogues film ({c}) mais pas d'endpoint search",
                        "· {n}: manifest OK ({ms} ms), cataloghi film ({c}) ma nessun endpoint search",
                        "· {n}: manifest OK ({ms} ms), Film-Kataloge ({c}) aber kein Search-Endpoint",
                    ).format(n=name, ms=ms_manifest, c=len(movie_catalogs))
                )
            else:
                lines.append(
                    _t(
                        "· {n}: manifest OK ({ms} ms) pero sin catálogo de películas",
                        "· {n}: manifest OK ({ms} ms) but no movie catalogs",
                        "· {n}: manifest OK ({ms} ms) mais sans catalogues film",
                        "· {n}: manifest OK ({ms} ms) ma senza cataloghi film",
                        "· {n}: manifest OK ({ms} ms) aber keine Film-Kataloge",
                    ).format(n=name, ms=ms_manifest)
                )
            continue

        # Paso 2: búsqueda real.
        t1 = time.time()
        try:
            results = provider.search(
                query,
                allowed_types=("movie",),
                include_sources=(name.lower(),),
                exclude_sources=(),
            )
            ms_search = int((time.time() - t1) * 1000.0)
            hits = len(results or [])
            if hits > 0:
                ok_count += 1
                lines.append(
                    _t(
                        "· {n}: OK ({h} resultados, {c} catálogos movie/search, {ms} ms)",
                        "· {n}: OK ({h} results, {c} movie/search catalogs, {ms} ms)",
                        "· {n}: OK ({h} resultats, {c} catalogues movie/search, {ms} ms)",
                        "· {n}: OK ({h} risultati, {c} cataloghi movie/search, {ms} ms)",
                        "· {n}: OK ({h} Treffer, {c} movie/search-Kataloge, {ms} ms)",
                    ).format(
                        n=name, h=hits, c=len(movie_search_catalogs), ms=ms_search
                    )
                )
            else:
                fail_count += 1
                lines.append(
                    _t(
                        "· {n}: sin resultados ({c} catálogos movie/search, {ms} ms)",
                        "· {n}: no results ({c} movie/search catalogs, {ms} ms)",
                        "· {n}: aucun resultat ({c} catalogues movie/search, {ms} ms)",
                        "· {n}: nessun risultato ({c} cataloghi movie/search, {ms} ms)",
                        "· {n}: keine Treffer ({c} movie/search-Kataloge, {ms} ms)",
                    ).format(n=name, c=len(movie_search_catalogs), ms=ms_search)
                )
        except Exception as ex:
            fail_count += 1
            lines.append(
                _t(
                    "· {n}: ERROR búsqueda ({e})",
                    "· {n}: search ERROR ({e})",
                    "· {n}: ERREUR recherche ({e})",
                    "· {n}: ERRORE ricerca ({e})",
                    "· {n}: Such-FEHLER ({e})",
                ).format(n=name, e=ex)
            )

    lines.extend(
        [
            "",
            _t(
                "Resumen: {t} probado(s) · {o} OK · {f} sin resultados/error",
                "Summary: {t} tested · {o} OK · {f} no results/errors",
                "Resume : {t} teste(s) · {o} OK · {f} sans resultat/erreur",
                "Riepilogo: {t} testati · {o} OK · {f} senza risultati/errore",
                "Zusammenfassung: {t} getestet · {o} OK · {f} ohne Treffer/Fehler",
            ).format(t=tested, o=ok_count, f=fail_count),
            _t(
                "Nota: un addon puede fallar por región, rate limit o catálogo no compatible con la búsqueda.",
                "Note: an add-on may fail due to region, rate limit, or catalog not supporting search.",
                "Note : une extension peut echouer (region, limite, catalogue incompatible).",
                "Nota: un addon puo fallire (regione, limite, catalogo non compatibile).",
                "Hinweis: Add-ons koennen wegen Region, Rate-Limit oder Katalog scheitern.",
            ),
        ]
    )
    dlg.textviewer(
        _t(
            "Kraken - Test de búsqueda Stremio",
            "Kraken - Stremio search test",
            "Kraken - Test recherche Stremio",
            "Kraken - Test ricerca Stremio",
            "Kraken - Stremio-Suchtest",
        ),
        "\n".join(lines),
    )


def run_stremio_quick_settings(
    *,
    addon,
    get_bool_setting,
    get_setting,
    set_setting,
    addon_path=None,
    qr_dialog_cls=None,
):
    """Configuración simple con desplegables (tipo 'settings')."""
    dialog = xbmcgui.Dialog()
    section = dialog.select(
        _t(
            "Kraken - Stremio · Configuración rápida",
            "Kraken - Stremio · Quick settings",
            "Kraken - Stremio · Reglages rapides",
            "Kraken - Stremio · Impostazioni rapide",
            "Kraken - Stremio · Schnelleinstellungen",
        ),
        [
            _t("Catálogo", "Catalog", "Catalogue", "Catalogo", "Katalog"),
            _t("Cuenta", "Account", "Compte", "Account", "Konto"),
            _t(
                "Web de complementos",
                "Add-on website",
                "Web des extensions",
                "Sito web addon",
                "Add-on-Webseite",
            ),
            _t("Volver", "Back", "Retour", "Indietro", "Zurueck"),
        ],
    )
    if section < 0 or section == 3:
        return

    if section == 0:
        try:
            use_filter = bool(get_bool_setting(SETTING_PER_ADDON_TOGGLE))
        except Exception:
            use_filter = (
                str(get_setting(SETTING_PER_ADDON_TOGGLE) or "").strip().lower()
                == "true"
            )
        try:
            inject_debrid = bool(get_bool_setting("stremio_alldebrid_auto_torrentio"))
        except Exception:
            inject_debrid = (
                str(get_setting("stremio_alldebrid_auto_torrentio") or "")
                .strip()
                .lower()
                == "true"
            )
        try:
            timeout_now = int(
                str(get_setting("stremio_http_timeout") or "25").strip() or "25"
            )
        except Exception:
            timeout_now = 25

        on_s, off_s = (
            _t("ON", "ON", "ON", "ON", "ON"),
            _t("OFF", "OFF", "OFF", "OFF", "OFF"),
        )
        action = dialog.select(
            _t(
                "Stremio · Catálogo",
                "Stremio · Catalog",
                "Stremio · Catalogue",
                "Stremio · Catalogo",
                "Stremio · Katalog",
            ),
            [
                _t(
                    "Filtro por complementos: {s}",
                    "Per-add-on filter: {s}",
                    "Filtre par extension : {s}",
                    "Filtro per addon: {s}",
                    "Filter pro Add-on: {s}",
                ).format(s=on_s if use_filter else off_s),
                _t(
                    "Elegir complementos activos",
                    "Choose active add-ons",
                    "Choisir les extensions actives",
                    "Scegli addon attivi",
                    "Aktive Add-ons waehlen",
                ),
                _t(
                    "Filtro catálogos por tipo/id",
                    "Filter catalogs by type/id",
                    "Filtrer catalogues par type/id",
                    "Filtra cataloghi per tipo/id",
                    "Kataloge nach Typ/ID filtern",
                ),
                _t(
                    "Quitar filtro tipo/id",
                    "Clear type/id filter",
                    "Retirer le filtre type/id",
                    "Rimuovi filtro tipo/id",
                    "Typ/ID-Filter aufheben",
                ),
                _t(
                    "Inyectar token Debrid: {s}",
                    "Inject Debrid token: {s}",
                    "Injecter le token Debrid : {s}",
                    "Inietta token Debrid: {s}",
                    "Debrid-Token injizieren: {s}",
                ).format(s=on_s if inject_debrid else off_s),
                _t(
                    "Timeout HTTP: {n} s",
                    "HTTP timeout: {n} s",
                    "Delai HTTP : {n} s",
                    "Timeout HTTP: {n} s",
                    "HTTP-Timeout: {n} s",
                ).format(n=timeout_now),
                _t("Volver", "Back", "Retour", "Indietro", "Zurueck"),
            ],
        )
        if action < 0 or action == 6:
            return
        if action == 0:
            set_setting(SETTING_PER_ADDON_TOGGLE, not use_filter)
            dialog.notification(
                "Kraken",
                _t(
                    "Filtro por complementos: {s}",
                    "Per-add-on filter: {s}",
                    "Filtre par extension : {s}",
                    "Filtro per addon: {s}",
                    "Filter pro Add-on: {s}",
                ).format(s=on_s if not use_filter else off_s),
            )
            return
        if action == 1:
            run_stremio_named_addons_multiselect(
                get_bool_setting=get_bool_setting,
                get_setting=get_setting,
                set_setting=set_setting,
            )
            return
        if action == 2:
            run_stremio_manifest_catalog_pick(
                addon=addon, get_setting=get_setting, set_setting=set_setting
            )
            return
        if action == 3:
            run_stremio_manifest_catalog_pick_disable(set_setting=set_setting)
            return
        if action == 4:
            set_setting("stremio_alldebrid_auto_torrentio", not inject_debrid)
            dialog.notification(
                "Kraken",
                _t(
                    "Inyección Debrid: {s}",
                    "Debrid injection: {s}",
                    "Injection Debrid : {s}",
                    "Iniezione Debrid: {s}",
                    "Debrid-Injection: {s}",
                ).format(s=on_s if not inject_debrid else off_s),
            )
            return
        if action == 5:
            labels = ["15 s", "20 s", "25 s", "30 s", "45 s", "60 s"]
            vals = ["15", "20", "25", "30", "45", "60"]
            pre = 2
            try:
                pre = max(0, vals.index(str(timeout_now)))
            except ValueError:
                pre = 2
            pick = dialog.select(
                _t(
                    "Stremio · Timeout HTTP",
                    "Stremio · HTTP timeout",
                    "Stremio · Delai HTTP",
                    "Stremio · Timeout HTTP",
                    "Stremio · HTTP-Timeout",
                ),
                labels,
                preselect=pre,
            )
            if pick >= 0:
                set_setting("stremio_http_timeout", vals[pick])
            return

    if section == 1:
        action = dialog.select(
            _t(
                "Stremio · Cuenta",
                "Stremio · Account",
                "Stremio · Compte",
                "Stremio · Account",
                "Stremio · Konto",
            ),
            [
                _t(
                    "Sincronizar (asistente)",
                    "Sync (wizard)",
                    "Synchroniser (assistant)",
                    "Sincronizza (guida)",
                    "Synchronisieren (Assistent)",
                ),
                _t(
                    "Sincronizar automático",
                    "Automatic sync",
                    "Synchronisation automatique",
                    "Sincronizza automatico",
                    "Automatische Sync",
                ),
                _t("Volver", "Back", "Retour", "Indietro", "Zurueck"),
            ],
        )
        if action == 0:
            run_stremio_sync_assistant(
                get_bool_setting=get_bool_setting,
                get_setting=get_setting,
                set_setting=set_setting,
            )
            return
        if action == 1:
            run_stremio_sync_from_account(
                get_setting=get_setting, set_setting=set_setting
            )
            return
        return

    entries = []
    for name, prefix in STREMIO_CATALOG_NAMED_ADDONS:
        entries.append((name, prefix))
    if not entries:
        dialog.ok(
            "Kraken - Stremio",
            _t(
                "No hay complementos configurables.",
                "No configurable add-ons.",
                "Aucune extension configurable.",
                "Nessun addon configurabile.",
                "Keine konfigurierbaren Add-ons.",
            ),
        )
        return
    labels = [name for name, _prefix in entries] + [
        _t("Volver", "Back", "Retour", "Indietro", "Zurueck")
    ]
    pick = dialog.select(
        _t(
            "Stremio · Web de complementos",
            "Stremio · Add-on website",
            "Stremio · Web des extensions",
            "Stremio · Sito web addon",
            "Stremio · Add-on-Web",
        ),
        labels,
    )
    if pick < 0 or pick == len(labels) - 1:
        return
    name, prefix = entries[pick]
    _edit_known_addon(
        dialog,
        name=name,
        prefix=prefix,
        get_setting=get_setting,
        set_setting=set_setting,
        addon_path=addon_path,
        qr_dialog_cls=qr_dialog_cls,
    )


def run_sources_stremio_hub(
    *,
    addon,
    get_bool_setting,
    get_setting,
    set_setting,
    plugin_url_open_all,
    plugin_url_settings_stremio,
    addon_path=None,
    qr_dialog_cls=None,
):
    dialog = xbmcgui.Dialog()
    current = bool(get_bool_setting(_MASTER))
    toggle_label = (
        _t(
            "Desactivar catálogo Stremio",
            "Disable Stremio catalog",
            "Desactiver le catalogue Stremio",
            "Disattiva catalogo Stremio",
            "Stremio-Katalog deaktivieren",
        )
        if current
        else _t(
            "Activar catálogo Stremio",
            "Enable Stremio catalog",
            "Activer le catalogue Stremio",
            "Attiva catalogo Stremio",
            "Stremio-Katalog aktivieren",
        )
    )
    # Orden: uso diario arriba (sync → elegir addons → ajustes rápidos), Kodi settings, setup inicial.
    main_options = [
        (0, toggle_label),
        (
            13,
            _t(
                "Sincronizar cuenta Stremio",
                "Sync Stremio account",
                "Synchroniser le compte Stremio",
                "Sincronizza account Stremio",
                "Stremio-Konto synchronisieren",
            ),
        ),
        (
            9,
            _t(
                "Elegir complementos del catálogo",
                "Choose catalog add-ons",
                "Choisir les extensions du catalogue",
                "Scegli addon del catalogo",
                "Katalog-Add-ons waehlen",
            ),
        ),
        (
            18,
            _t(
                "Ajustes rápidos",
                "Quick settings",
                "Réglages rapides",
                "Impostazioni rapide",
                "Schnelleinstellungen",
            ),
        ),
        (
            5,
            _t(
                "Abrir pestaña Stremio en ajustes Kodi",
                "Open Stremio tab in Kodi settings",
                "Ouvrir l’onglet Stremio dans Kodi",
                "Apri scheda Stremio nelle impostazioni Kodi",
                "Stremio-Register in Kodi-Einstellungen",
            ),
        ),
        (
            6,
            _t(
                "Primera configuración (ES + Debrid)",
                "First-time setup (Spanish + Debrid)",
                "Première config (ES + Debrid)",
                "Prima configurazione (ES + Debrid)",
                "Ersteinrichtung (ES + Debrid)",
            ),
        ),
    ]
    # Avanzado: diagnóstico → catálogo/sync/importación → cachés al final.
    advanced_options = [
        (
            1,
            _t(
                "Ver resumen de configuración",
                "View configuration summary",
                "Voir le résumé de configuration",
                "Vedi riepilogo configurazione",
                "Konfigurationsübersicht",
            ),
        ),
        (
            8,
            _t(
                "Comprobar manifest de complementos (ping HTTP)",
                "Check add-on manifests (HTTP ping)",
                "Vérifier les manifestes (ping HTTP)",
                "Verifica manifest addon (ping HTTP)",
                "Add-on-Manifeste prüfen (HTTP-Ping)",
            ),
        ),
        (
            17,
            _t(
                "Test de búsqueda película",
                "Movie search test",
                "Test recherche film",
                "Test ricerca film",
                "Film-Suchtest",
            ),
        ),
        (
            2,
            _t(
                "Abrir configuración web de todos los complementos",
                "Open web config for all add-ons",
                "Ouvrir la configuration web de toutes les extensions",
                "Apri configurazione web di tutti gli addon",
                "Web-Konfiguration aller Add-ons öffnen",
            ),
        ),
        (
            3,
            _t(
                "Gestionar complementos Stremio (uno por uno)",
                "Manage Stremio add-ons (one by one)",
                "Gérer les extensions Stremio (une par une)",
                "Gestisci addon Stremio (uno per uno)",
                "Stremio-Add-ons verwalten (einzeln)",
            ),
        ),
        (
            11,
            _t(
                "Filtrar catálogos del manifest (tipo + id)",
                "Filter manifest catalogs (type + id)",
                "Filtrer catalogues du manifest (type + id)",
                "Filtra cataloghi manifest (tipo + id)",
                "Manifest-Kataloge filtern (Typ + ID)",
            ),
        ),
        (
            14,
            _t(
                "Sincronizar desde cuenta Stremio (automático)",
                "Sync from Stremio account (automatic)",
                "Synchroniser depuis le compte (auto)",
                "Sync da account Stremio (automatico)",
                "Vom Stremio-Konto synchronisieren (auto)",
            ),
        ),
        (
            15,
            _t(
                "Sync cuenta + revisión (addons nuevos)",
                "Account sync + review (new add-ons)",
                "Sync compte + revue (nouvelles extensions)",
                "Sync account + revisione (addon nuovi)",
                "Konto-Sync + Prüfung (neue Add-ons)",
            ),
        ),
        (
            16,
            _t(
                "Importar lista Debrid (web comunidad)",
                "Import Debrid list (community web)",
                "Importer liste Debrid (web communautaire)",
                "Importa lista Debrid (web community)",
                "Debrid-Liste importieren (Community-Web)",
            ),
        ),
        (
            4,
            _t(
                "Refrescar caché de logos",
                "Refresh logo cache",
                "Rafraîchir le cache des logos",
                "Aggiorna cache loghi",
                "Logo-Cache aktualisieren",
            ),
        ),
        (
            7,
            _t(
                "Vaciar caché Stremio (manifiestos en memoria)",
                "Clear Stremio cache (manifests in memory)",
                "Vider le cache Stremio (manifestes en mémoire)",
                "Svuota cache Stremio (manifest in memoria)",
                "Stremio-Cache leeren (Manifeste im RAM)",
            ),
        ),
    ]
    opts = [label for _old_idx, label in main_options] + [
        _t(
            "Más opciones...",
            "More options...",
            "Plus d'options...",
            "Altre opzioni...",
            "Weitere Optionen...",
        )
    ]
    picked = dialog.select(
        _t(
            "Kraken - Stremio",
            "Kraken - Stremio",
            "Kraken - Stremio",
            "Kraken - Stremio",
            "Kraken - Stremio",
        ),
        opts,
    )
    if picked < 0:
        return
    if picked == len(opts) - 1:
        adv_labels = [label for _old_idx, label in advanced_options]
        adv_pick = dialog.select(
            _t(
                "Kraken - Stremio · Más opciones",
                "Kraken - Stremio · More options",
                "Kraken - Stremio · Plus d'options",
                "Kraken - Stremio · Altre opzioni",
                "Kraken - Stremio · Weitere Optionen",
            ),
            adv_labels,
        )
        if adv_pick < 0:
            return
        idx = advanced_options[adv_pick][0]
    else:
        idx = main_options[picked][0]

    if idx == 0:
        new_val = not current
        try:
            set_setting(_MASTER, new_val)
        except Exception:
            try:
                set_setting(_MASTER, "true" if new_val else "false")
            except Exception:
                dialog.notification(
                    "Kraken",
                    _t(
                        "No se pudo guardar el ajuste.",
                        "Could not save the setting.",
                        "Impossible d'enregistrer le reglage.",
                        "Impossibile salvare l'impostazione.",
                        "Einstellung konnte nicht gespeichert werden.",
                    ),
                    xbmcgui.NOTIFICATION_WARNING,
                    4500,
                )
                return
        dialog.notification(
            "Kraken",
            _t(
                "Catálogo Stremio: {s}",
                "Stremio catalog: {s}",
                "Catalogue Stremio : {s}",
                "Catalogo Stremio: {s}",
                "Stremio-Katalog: {s}",
            ).format(
                s=_t(
                    "activado",
                    "enabled",
                    "active",
                    "attivo",
                    "aktiviert",
                )
                if new_val
                else _t(
                    "desactivado",
                    "disabled",
                    "desactive",
                    "disattivato",
                    "deaktiviert",
                )
            ),
            xbmcgui.NOTIFICATION_INFO,
            4500,
        )
        return

    if idx == 18:
        run_stremio_quick_settings(
            addon=addon,
            get_bool_setting=get_bool_setting,
            get_setting=get_setting,
            set_setting=set_setting,
            addon_path=addon_path,
            qr_dialog_cls=qr_dialog_cls,
        )
        return

    if idx == 1:
        try:
            body = format_sources_configuration_summary(get_bool_setting, get_setting)
        except Exception:
            body = ""
        dialog.textviewer(
            _t(
                "Kraken - Stremio · Resumen",
                "Kraken - Stremio · Summary",
                "Kraken - Stremio · Resume",
                "Kraken - Stremio · Riepilogo",
                "Kraken - Stremio · Uebersicht",
            ),
            body
            or _t(
                "(sin datos)",
                "(no data)",
                "(aucune donnee)",
                "(nessun dato)",
                "(keine Daten)",
            ),
        )
        return

    if idx == 2:
        u = escape_for_quoted_builtin(plugin_url_open_all)
        if u:
            try:
                xbmc.executebuiltin(f'RunPlugin("{u}")')
            except Exception:
                pass
        return

    if idx == 3:
        run_stremio_addons_manager(
            addon=addon,
            get_setting=get_setting,
            set_setting=set_setting,
            addon_path=addon_path,
            qr_dialog_cls=qr_dialog_cls,
        )
        return

    if idx == 4:
        run_stremio_logo_refresh()
        return

    if idx == 5:
        u = escape_for_quoted_builtin(plugin_url_settings_stremio)
        if u:
            try:
                xbmc.executebuiltin(f'RunPlugin("{u}")')
            except Exception:
                pass
        return

    if idx == 6:
        run_stremio_bootstrap_es_debrid(
            get_bool_setting=get_bool_setting,
            get_setting=get_setting,
            set_setting=set_setting,
        )
        return

    if idx == 7:
        clear_stremio_manifest_session_cache()
        dialog.notification(
            "Kraken",
            _t(
                "Caché Stremio vaciada (manifest.json en esta sesión).",
                "Stremio cache cleared (manifest.json this session).",
                "Cache Stremio videe (manifest.json cette session).",
                "Cache Stremio svuotata (manifest.json in questa sessione).",
                "Stremio-Cache geleert (manifest.json diese Sitzung).",
            ),
            xbmcgui.NOTIFICATION_INFO,
            4500,
        )
        return

    if idx == 8:
        run_stremio_manifest_check(addon=addon)
        return

    if idx == 9:
        run_stremio_named_addons_multiselect(
            get_bool_setting=get_bool_setting,
            get_setting=get_setting,
            set_setting=set_setting,
        )
        return

    if idx == 11:
        run_stremio_manifest_catalog_pick(
            addon=addon, get_setting=get_setting, set_setting=set_setting
        )
        return

    if idx == 13:
        run_stremio_sync_assistant(
            get_bool_setting=get_bool_setting,
            get_setting=get_setting,
            set_setting=set_setting,
        )
        return

    if idx == 14:
        run_stremio_sync_from_account(get_setting=get_setting, set_setting=set_setting)
        return

    if idx == 15:
        run_stremio_sync_review(get_setting=get_setting, set_setting=set_setting)
        return

    if idx == 16:
        run_stremio_import_debrid_manifests(
            get_setting=get_setting, set_setting=set_setting
        )
        return

    if idx == 17:
        run_stremio_movie_search_test(addon=addon, get_setting=get_setting)
        return
