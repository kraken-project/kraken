import xbmcgui
import xbmcplugin

from resources.lib.routes.root_routes import _item_art_with_icon
from resources.lib.ui.video_info import apply_video_info
from resources.lib.ui.ui_helpers import _t


def run_search_folder(
    *,
    plugin_handle,
    default_list_art,
    url_for_search_all,
    url_for_search_movies,
    url_for_search_series,
    url_for_search_anime,
    url_for_search_movies_by_actor,
    url_for_search_series_by_actor,
    url_for_search_history,
):
    xbmcplugin.setPluginCategory(
        plugin_handle,
        _t("Kraken - Búsqueda", "Kraken - Search", "Kraken - Recherche", "Kraken - Ricerca", "Kraken - Suche"),
    )
    xbmcplugin.setContent(plugin_handle, "files")
    items = [
        {"label": _t("Buscar en todo", "Search all", "Rechercher partout", "Cerca ovunque", "Alles durchsuchen"), "url": url_for_search_all()},
        {"label": _t("Buscar películas", "Search movies", "Rechercher films", "Cerca film", "Filme suchen"), "url": url_for_search_movies()},
        {"label": _t("Buscar series", "Search TV shows", "Rechercher series", "Cerca serie TV", "Serien suchen"), "url": url_for_search_series()},
        {"label": _t("Buscar anime", "Search anime", "Rechercher anime", "Cerca anime", "Anime suchen"), "url": url_for_search_anime()},
        {
            "label": _t("Buscar película por actor o actriz", "Search movie by actor", "Rechercher un film par acteur", "Cerca film per attore", "Film nach Schauspieler suchen"),
            "url": url_for_search_movies_by_actor(),
        },
        {
            "label": _t("Buscar serie por actor o actriz", "Search TV show by actor", "Rechercher serie par acteur", "Cerca serie TV per attore", "Serie nach Schauspieler suchen"),
            "url": url_for_search_series_by_actor(),
        },
        {
            "label": _t("Buscar anime por actor o actriz", "Search anime by actor", "Rechercher anime par acteur", "Cerca anime per attore", "Anime nach Schauspieler suchen"),
            "url": url_for_search_series_by_actor(),
        },
        {"label": _t("Historial de búsquedas", "Search history", "Historique des recherches", "Cronologia ricerche", "Suchverlauf"), "url": url_for_search_history()},
    ]
    base_art = default_list_art()
    directory = []
    for it in items:
        li = xbmcgui.ListItem(label=it["label"])
        li.setArt(_item_art_with_icon(base_art, it["label"]))
        apply_video_info(li, {"title": it["label"]})
        directory.append((it["url"], li, True))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)


def run_simple_search(
    *,
    mode,
    plugin_handle,
    search_trakt_media,
    search_history_last=None,
):
    """Teclado primero; resultados en esta misma llamada (Container.Update+replace fallaba en algunos Kodi)."""
    from resources.lib.trakt.search_flow import search_prompt_trakt_query

    query = search_prompt_trakt_query(mode, search_history_last)
    if not query:
        xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)
        return
    search_trakt_media(mode, forced_query=query)



def run_actor_listing_entry(*, mode, actor_listing_fn):
    actor_listing_fn(mode)


def run_actor_person_entry(*, person_id, mode, actor_credits_fn, plugin_handle):
    try:
        pid = int(str(person_id).strip())
    except (TypeError, ValueError):
        xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)
        return
    if pid < 1:
        xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)
        return
    actor_credits_fn(mode, pid)
