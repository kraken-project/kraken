import re

import xbmcgui
import xbmcplugin

from resources.lib.ui.video_info import apply_video_info
from resources.lib.ui.ui_helpers import _t
from resources.lib.core.view_prefs import (
    home_is_hub,
    home_show_anime_menu_enabled,
    home_show_movies_menu_enabled,
    home_show_series_menu_enabled,
    hub_anime_trakt_enabled,
    hub_anime_trending_enabled,
    hub_movie_trakt_enabled,
    hub_movie_trending_enabled,
    hub_series_trakt_enabled,
    hub_series_trending_enabled,
    schedule_saved_skin_view_slug,
    skin_content_hint,
    submenu_anime_actor_enabled,
    submenu_anime_search_enabled,
    submenu_anime_tmdb_browse_enabled,
    submenu_anime_trakt_browse_enabled,
    submenu_anime_trakt_lists_enabled,
    submenu_movie_actor_enabled,
    submenu_movie_search_enabled,
    submenu_movie_tmdb_browse_enabled,
    submenu_movie_trakt_browse_enabled,
    submenu_movie_trakt_lists_enabled,
    submenu_series_actor_enabled,
    submenu_series_search_enabled,
    submenu_series_tmdb_browse_enabled,
    submenu_series_trakt_browse_enabled,
    submenu_series_trakt_lists_enabled,
)
from resources.lib.ui.listing_skin_hooks import suppress_fanart_listing_cm


_ICON_PACK_DIR = "icons-white"
_ICON_BASE = (
    "special://home/addons/plugin.video.kraken/resources/media/" + _ICON_PACK_DIR
)


def _strip_kodi_tags(text):
    return re.sub(r"\[[^\]]+\]", "", str(text or "")).strip().lower()


def _icon_file_for_label(label):
    t = _strip_kodi_tags(label)
    # Seguimiento Trakt (sin finalizar / in progress / en cours...): icono del tipo de contenido
    trakt_progress = any(
        x in t
        for x in (
            "sin finalizar",
            "en seguimiento",
            "in progress",
            "unfinished",
            "non termin",  # Films non terminés
            "non complet",  # Film non completati
            "unfertig",  # Unfertige Filme
            "en cours",  # Séries en cours, Anime en cours
            "in corso",  # Serie TV in corso, Anime in corso
            "in bearbeitung",  # Serien/Anime in Bearbeitung
        )
    )
    if trakt_progress:
        if "anime" in t:
            return "anime.png"
        if any(
            x in t
            for x in (
                "series",
                "shows",
                "séries",
                "serie tv",
                "serien",
            )
        ):
            return "series.png"
        if any(
            x in t
            for x in (
                "peliculas",
                "películas",
                "movies",
                "films",
                "filme",
                "film non",  # IT: Film non completati (Trakt)
            )
        ):
            return "movies.png"
        return "trakt-progress.png"
    if any(x in t for x in ("tendencias", "trending", "tendance", "tendenze", "trends")):
        return "trending.png"
    if any(x in t for x in ("mas vistos", "más vistos", "esperados", "anticipated", "most watched", "attesi", "erwartet")):
        return "trending.png"
    if any(x in t for x in ("populares", "popular", "valoradas", "rated", "taquilla", "box office")):
        return "popular.png"
    if any(x in t for x in ("actor", "actriz", "actress", "acteur", "attrice", "schauspiel")):
        return "actor.png"
    if any(x in t for x in ("por año", "por ano", "year", "annee", "anno", "jahr")):
        return "year.png"
    if any(x in t for x in ("por género", "por genero", "genre", "genero")):
        return "genre.png"
    if any(x in t for x in ("plataformas", "platform", "plateforme", "piattaforme", "plattform")):
        return "platforms.png"
    if any(x in t for x in ("relacionad", "related", "similaire", "correlat", "ähnlich", "aehnlich")):
        return "related.png"
    if any(
        x in t
        for x in (
            "aleatorio",
            "aleatoria",
            "aléatoire",
            "aleatoire",
            "random",
            "hasard",
            "casuale",
            "zufällig",
            "zufaellig",
            "zufall",
        )
    ):
        return "random.png"
    if any(
        x in t
        for x in (
            "buscar",
            "search",
            "rechercher",
            "cerca",
            "suche",
            "búsqueda",
            "busqueda",
            "ricerca",
        )
    ):
        return "search.png"
    if any(x in t for x in ("descargas", "downloads", "telecharg", "download", "herunter")):
        return "downloads.png"
    if any(x in t for x in ("tv en directo", "live tv", "tv live", "diretta", "live-tv")):
        return "tv-live.png"
    if any(x in t for x in ("ajustes", "settings", "param", "impostazioni", "einstellungen")):
        return "settings.png"
    if "anime" in t:
        return "anime.png"
    if any(x in t for x in ("series", "shows", "séries", "serie", "serien")):
        return "series.png"
    if any(x in t for x in ("peliculas", "películas", "movies", "films", "filme")):
        return "movies.png"
    return ""


def _item_art_with_icon(base_art, label):
    art = dict(base_art or {})
    icon_name = _icon_file_for_label(label)
    if not icon_name:
        return art
    if "://" in icon_name or "/" in icon_name:
        p = icon_name
    else:
        p = _ICON_BASE + "/" + icon_name
    # En menús de Kodi algunas skins tratan "poster" como carátula grande y
    # puede solaparse con el icono/texto. Para categorías usamos solo icon/thumb.
    art.pop("poster", None)
    art.pop("banner", None)
    art.pop("landscape", None)
    art.update({"icon": p, "thumb": p})
    return art


def run_root(
    *,
    plugin_handle,
    get_bool_setting,
    get_setting,
    default_list_art,
    url_for_search_folder,
    url_for_menu_movies,
    url_for_menu_series,
    url_for_menu_anime,
    url_for_tv_browse,
    url_for_downloads,
    url_for_trakt_series_in_progress,
    url_for_trakt_movies_in_progress,
    url_for_trakt_anime_in_progress,
    url_for_settings,
    url_for_quick_movie_trending=None,
    url_for_quick_series_trending=None,
    url_for_quick_anime_trending=None,
    url_for_kraken_tools=None,
    localize_addon_fn=None,
):
    xbmcplugin.setPluginCategory(
        plugin_handle, _t("Kraken - Inicio", "Kraken - Home", "Kraken - Accueil", "Kraken - Home", "Kraken - Startseite")
    )
    ct = "files"
    hint = skin_content_hint(get_setting) if get_setting else ""
    if hint == "movie":
        ct = "movies"
    elif hint == "show":
        ct = "tvshows"
    xbmcplugin.setContent(plugin_handle, ct)
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_NONE)

    _gs_root = get_setting or (lambda *_a, **_k: None)
    movie_menu_tuple = (
        _t("[B]Películas[/B]", "[B]Movies[/B]", "[B]Films[/B]", "[B]Film[/B]", "[B]Filme[/B]"),
        _t("Submenú de películas", "Movies submenu", "Sous-menu films", "Sottomenu film", "Filme-Untermenü"),
        _t("Abrir opciones de películas.", "Open movie options.", "Ouvrir les options de films.", "Apri opzioni film.", "Filmoptionen öffnen."),
        url_for_menu_movies(),
    )
    series_menu_tuple = (
        _t("[B]Series[/B]", "[B]TV Shows[/B]", "[B]Séries[/B]", "[B]Serie TV[/B]", "[B]Serien[/B]"),
        _t("Submenu de series", "TV shows submenu", "Sous-menu séries", "Sottomenu serie TV", "Serien-Untermenü"),
        _t("Abrir opciones de series.", "Open TV show options.", "Ouvrir les options de séries.", "Apri opzioni serie TV.", "Serienoptionen öffnen."),
        url_for_menu_series(),
    )
    anime_menu_tuple = (
        "[B]Anime[/B]",
        _t("Submenu de anime", "Anime submenu", "Sous-menu anime", "Sottomenu anime", "Anime-Untermenü"),
        _t("Abrir opciones de anime.", "Open anime options.", "Ouvrir les options anime.", "Apri opzioni anime.", "Anime-Optionen öffnen."),
        url_for_menu_anime(),
    )
    menu_rows = []
    if home_show_movies_menu_enabled(_gs_root):
        menu_rows.append(movie_menu_tuple)
    if home_show_series_menu_enabled(_gs_root):
        menu_rows.append(series_menu_tuple)
    if home_show_anime_menu_enabled(_gs_root):
        menu_rows.append(anime_menu_tuple)

    footer = (
        (
            _t(
                "[B]Buscar películas y series[/B]",
                "[B]Search movies and TV shows[/B]",
                "[B]Rechercher films et séries[/B]",
                "[B]Cerca film e serie TV[/B]",
                "[B]Filme und Serien suchen[/B]",
            ),
            _t(
                "Búsqueda global (Trakt/TMDb/OMDb)",
                "Global search (Trakt/TMDb/OMDb)",
                "Recherche globale (Trakt/TMDb/OMDb)",
                "Ricerca globale (Trakt/TMDb/OMDb)",
                "Globale Suche (Trakt/TMDb/OMDb)",
            ),
            _t(
                "Busca películas y series. Si Trakt no está configurado usa fallback automático.",
                "Search movies and TV shows. If Trakt is not configured, automatic fallback is used.",
                "Recherche des films et séries. Si Trakt n'est pas configuré, le fallback automatique est utilisé.",
                "Cerca film e serie TV. Se Trakt non è configurato, viene usato il fallback automatico.",
                "Suche Filme und Serien. Wenn Trakt nicht konfiguriert ist, wird automatischer Fallback verwendet.",
            ),
            url_for_search_folder(),
        ),
        (
            _t("[B]TV en directo[/B]", "[B]Live TV[/B]", "[B]TV en direct[/B]", "[B]TV in diretta[/B]", "[B]Live-TV[/B]"),
            _t("País → categoría → canales", "Country -> category -> channels", "Pays -> catégorie -> chaînes", "Paese -> categoria -> canali", "Land -> Kategorie -> Sender"),
            _t(
                "Canales en directo desde Tvvoo, navegación por país y categorías.",
                "Live channels from Tvvoo, browsing by country and category.",
                "Chaînes en direct depuis Tvvoo, navigation par pays et catégories.",
                "Canali live da Tvvoo, navigazione per paese e categorie.",
                "Live-Sender von Tvvoo, Navigation nach Land und Kategorien.",
            ),
            url_for_tv_browse(),
        ),
        (
            _t("[B]Mis descargas[/B]", "[B]My downloads[/B]", "[B]Mes téléchargements[/B]", "[B]I miei download[/B]", "[B]Meine Downloads[/B]"),
            _t(
                "Películas, series y anime guardados",
                "Saved movies, TV shows and anime",
                "Films, séries et anime enregistrés",
                "Film, serie TV e anime salvati",
                "Gespeicherte Filme, Serien und Anime",
            ),
            _t(
                "Lista lo descargado con Kraken y reproduce si el archivo sigue en disco.",
                "List downloaded items and play if files are still available.",
                "Affiche les téléchargements Kraken et lit si les fichiers sont encore disponibles.",
                "Elenca i download di Kraken e riproduce se i file sono ancora disponibili.",
                "Listet Kraken-Downloads auf und spielt sie ab, wenn Dateien noch verfügbar sind.",
            ),
            url_for_downloads(),
        ),
    )
    settings_item = {
        "label": _t("[B]Ajustes[/B]", "[B]Settings[/B]", "[B]Paramètres[/B]", "[B]Impostazioni[/B]", "[B]Einstellungen[/B]"),
        "label2": _t(
            "Vistas de lista, cachés y ajustes Kodi del addon",
            "View types, caches and Kodi add-on settings",
            "Vues de liste, caches et réglages Kodi du module",
            "Viste elenco, cache e impostazioni Kodi dell'addon",
            "Listenansichten, Caches und Kodi-Addon-Einstellungen",
        ),
        "plot": _t(
            "Modos de vista por sección, limpieza de cachés (OMDb, RAM, Stremio, logos) y acceso a la ventana completa de ajustes de Kodi.",
            "Per-section view modes, cache clearing (OMDb, RAM, Stremio, logos) and the full Kodi add-on settings window.",
            "Modes d'affichage par section, vidage des caches (OMDb, RAM, Stremio, logos) et fenêtre complète des réglages Kodi.",
            "Modalità vista per sezione, svuotamento cache (OMDb, RAM, Stremio, loghi) e finestra completa delle impostazioni Kodi.",
            "Ansichten pro Bereich, Cache leeren (OMDb, RAM, Stremio, Logos) und vollständiges Kodi-Addon-Einstellungsfenster.",
        ),
        "url": url_for_settings(),
    }

    trakt_connected = bool(
        get_bool_setting("trakt_enabled") and str(get_setting("trakt_access_token") or "").strip()
    )

    def row_to_item(lab, l2, pl, ur):
        return {"label": lab, "label2": l2, "plot": pl, "url": ur}

    if home_is_hub(get_setting):
        items = []
        if trakt_connected:
            _gs = get_setting or (lambda *_a, **_k: None)
            if hub_movie_trakt_enabled(_gs):
                items.append(
                    row_to_item(
                        _t(
                            "[B]Películas sin finalizar[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Unfinished movies[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Films non terminés[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Film non completati[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Unfertige Filme[/B] [COLOR gray](Trakt)[/COLOR]",
                        ),
                        _t(
                            "Continuar películas pendientes",
                            "Continue pending movies",
                            "Continuer les films en cours",
                            "Continua film in sospeso",
                            "Offene Filme fortsetzen",
                        ),
                        _t(
                            "Películas en progreso con porcentaje visto, año y rating.",
                            "Movies in progress with watched percentage, year and rating.",
                            "Films en cours avec pourcentage vu, année et note.",
                            "Film in corso con percentuale vista, anno e valutazione.",
                            "Filme in Bearbeitung mit gesehenem Prozentsatz, Jahr und Bewertung.",
                        ),
                        url_for_trakt_movies_in_progress(),
                    ),
                )
            if hub_series_trakt_enabled(_gs):
                items.append(
                    row_to_item(
                        _t(
                            "[B]Series en seguimiento[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]TV shows in progress[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Séries en cours[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Serie TV in corso[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Serien in Bearbeitung[/B] [COLOR gray](Trakt)[/COLOR]",
                        ),
                        _t("Continuar viendo series", "Continue TV shows", "Continuer les séries", "Continua serie TV", "Serien fortsetzen"),
                        _t(
                            "Series en progreso con porcentaje visto y metadatos.",
                            "TV shows in progress with watched percentage and metadata.",
                            "Séries en cours avec pourcentage vu et métadonnées.",
                            "Serie TV in corso con percentuale vista e metadati.",
                            "Serien in Bearbeitung mit gesehenem Prozentsatz und Metadaten.",
                        ),
                        url_for_trakt_series_in_progress(),
                    ),
                )
            if hub_anime_trakt_enabled(_gs):
                items.append(
                    row_to_item(
                        _t(
                            "[B]Anime en seguimiento[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Anime in progress[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Anime en cours[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Anime in corso[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Anime in Bearbeitung[/B] [COLOR gray](Trakt)[/COLOR]",
                        ),
                        _t("Continuar viendo anime", "Continue anime", "Continuer l'anime", "Continua anime", "Anime fortsetzen"),
                        _t(
                            "Anime en progreso con porcentaje visto y metadatos.",
                            "Anime in progress with watched percentage and metadata.",
                            "Anime en cours avec pourcentage vu et métadonnées.",
                            "Anime in corso con percentuale vista e metadati.",
                            "Anime in Bearbeitung mit gesehenem Prozentsatz und Metadaten.",
                        ),
                        url_for_trakt_anime_in_progress(),
                    ),
                )
        items.extend(row_to_item(lab, l2, pt, ur) for lab, l2, pt, ur in menu_rows)
        items.extend(row_to_item(lab, l2, pt, ur) for lab, l2, pt, ur in footer)
        items.append(settings_item.copy())
    else:
        items = []
        _gs_cl = get_setting or (lambda *_a, **_k: None)
        if home_show_movies_menu_enabled(_gs_cl):
            items.append(row_to_item(*movie_menu_tuple))
            if trakt_connected and hub_movie_trakt_enabled(_gs_cl):
                items.append(
                    row_to_item(
                        _t(
                            "[B]Películas sin finalizar[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Unfinished movies[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Films non terminés[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Film non completati[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Unfertige Filme[/B] [COLOR gray](Trakt)[/COLOR]",
                        ),
                        _t(
                            "Continuar películas pendientes",
                            "Continue pending movies",
                            "Continuer les films en cours",
                            "Continua film in sospeso",
                            "Offene Filme fortsetzen",
                        ),
                        _t(
                            "Películas en progreso con porcentaje visto, año y rating.",
                            "Movies in progress with watched percentage, year and rating.",
                            "Films en cours avec pourcentage vu, année et note.",
                            "Film in corso con percentuale vista, anno e valutazione.",
                            "Filme in Bearbeitung mit gesehenem Prozentsatz, Jahr und Bewertung.",
                        ),
                        url_for_trakt_movies_in_progress(),
                    ),
                )
        if home_show_series_menu_enabled(_gs_cl):
            items.append(row_to_item(*series_menu_tuple))
            if trakt_connected and hub_series_trakt_enabled(_gs_cl):
                items.append(
                    row_to_item(
                        _t(
                            "[B]Series en seguimiento[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]TV shows in progress[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Séries en cours[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Serie TV in corso[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Serien in Bearbeitung[/B] [COLOR gray](Trakt)[/COLOR]",
                        ),
                        _t("Continuar viendo series", "Continue TV shows", "Continuer les séries", "Continua serie TV", "Serien fortsetzen"),
                        _t(
                            "Series en progreso con porcentaje visto y metadatos.",
                            "TV shows in progress with watched percentage and metadata.",
                            "Séries en cours avec pourcentage vu et métadonnées.",
                            "Serie TV in corso con percentuale vista e metadati.",
                            "Serien in Bearbeitung mit gesehenem Prozentsatz und Metadaten.",
                        ),
                        url_for_trakt_series_in_progress(),
                    ),
                )
        if home_show_anime_menu_enabled(_gs_cl):
            items.append(row_to_item(*anime_menu_tuple))
            if trakt_connected and hub_anime_trakt_enabled(_gs_cl):
                items.append(
                    row_to_item(
                        _t(
                            "[B]Anime en seguimiento[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Anime in progress[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Anime en cours[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Anime in corso[/B] [COLOR gray](Trakt)[/COLOR]",
                            "[B]Anime in Bearbeitung[/B] [COLOR gray](Trakt)[/COLOR]",
                        ),
                        _t("Continuar viendo anime", "Continue anime", "Continuer l'anime", "Continua anime", "Anime fortsetzen"),
                        _t(
                            "Anime en progreso con porcentaje visto y metadatos.",
                            "Anime in progress with watched percentage and metadata.",
                            "Anime en cours avec pourcentage vu et métadonnées.",
                            "Anime in corso con percentuale vista e metadati.",
                            "Anime in Bearbeitung mit gesehenem Prozentsatz und Metadaten.",
                        ),
                        url_for_trakt_anime_in_progress(),
                    ),
                )
        items.extend(row_to_item(lab, l2, pt, ur) for lab, l2, pt, ur in footer)
        items.append(settings_item.copy())
    if home_is_hub(get_setting):
        # El menú principal debe mantener el orden clásico solicitado y no mostrar tendencias.
        ordered = []
        _gs_main = get_setting or (lambda *_a, **_k: None)
        if home_show_movies_menu_enabled(_gs_main):
            ordered.append(row_to_item(*movie_menu_tuple))
            if trakt_connected and hub_movie_trakt_enabled(_gs_main):
                ordered.append(
                    row_to_item(
                        _t("[B]Películas sin finalizar[/B] [COLOR gray](Trakt)[/COLOR]", "[B]Unfinished movies[/B] [COLOR gray](Trakt)[/COLOR]", "[B]Films non terminés[/B] [COLOR gray](Trakt)[/COLOR]", "[B]Film non completati[/B] [COLOR gray](Trakt)[/COLOR]", "[B]Unfertige Filme[/B] [COLOR gray](Trakt)[/COLOR]"),
                        _t("Continuar películas pendientes", "Continue pending movies", "Continuer les films en cours", "Continua film in sospeso", "Offene Filme fortsetzen"),
                        _t("Películas en progreso con porcentaje visto, año y rating.", "Movies in progress with watched percentage, year and rating.", "Films en cours avec pourcentage vu, année et note.", "Film in corso con percentuale vista, anno e valutazione.", "Filme in Bearbeitung mit gesehenem Prozentsatz, Jahr und Bewertung."),
                        url_for_trakt_movies_in_progress(),
                    )
                )
        if home_show_series_menu_enabled(_gs_main):
            ordered.append(row_to_item(*series_menu_tuple))
            if trakt_connected and hub_series_trakt_enabled(_gs_main):
                ordered.append(
                    row_to_item(
                        _t("[B]Series en seguimiento[/B] [COLOR gray](Trakt)[/COLOR]", "[B]TV shows in progress[/B] [COLOR gray](Trakt)[/COLOR]", "[B]Séries en cours[/B] [COLOR gray](Trakt)[/COLOR]", "[B]Serie TV in corso[/B] [COLOR gray](Trakt)[/COLOR]", "[B]Serien in Bearbeitung[/B] [COLOR gray](Trakt)[/COLOR]"),
                        _t("Continuar viendo series", "Continue TV shows", "Continuer les séries", "Continua serie TV", "Serien fortsetzen"),
                        _t("Series en progreso con porcentaje visto y metadatos.", "TV shows in progress with watched percentage and metadata.", "Séries en cours avec pourcentage vu et métadonnées.", "Serie TV in corso con percentuale vista e metadati.", "Serien in Bearbeitung mit gesehenem Prozentsatz und Metadaten."),
                        url_for_trakt_series_in_progress(),
                    )
                )
        if home_show_anime_menu_enabled(_gs_main):
            ordered.append(row_to_item(*anime_menu_tuple))
            if trakt_connected and hub_anime_trakt_enabled(_gs_main):
                ordered.append(
                    row_to_item(
                        _t("[B]Anime en seguimiento[/B] [COLOR gray](Trakt)[/COLOR]", "[B]Anime in progress[/B] [COLOR gray](Trakt)[/COLOR]", "[B]Anime en cours[/B] [COLOR gray](Trakt)[/COLOR]", "[B]Anime in corso[/B] [COLOR gray](Trakt)[/COLOR]", "[B]Anime in Bearbeitung[/B] [COLOR gray](Trakt)[/COLOR]"),
                        _t("Continuar viendo anime", "Continue anime", "Continuer l'anime", "Continua anime", "Anime fortsetzen"),
                        _t("Anime en progreso con porcentaje visto y metadatos.", "Anime in progress with watched percentage and metadata.", "Anime en cours avec pourcentage vu et métadonnées.", "Anime in corso con percentuale vista e metadati.", "Anime in Bearbeitung mit gesehenem Prozentsatz und Metadaten."),
                        url_for_trakt_anime_in_progress(),
                    )
                )
        ordered.extend(row_to_item(lab, l2, pt, ur) for lab, l2, pt, ur in footer)
        ordered.append(settings_item.copy())
        items = ordered
    directory = []
    base_art = default_list_art()
    for item in items:
        li = xbmcgui.ListItem(label=item["label"], label2=item.get("label2", ""))
        li.setInfo(
            "video",
            {
                "title": item["label"],
                "plot": item.get("plot", ""),
                "mediatype": "video",
            },
        )
        li.setArt(_item_art_with_icon(base_art, item.get("label")))
        directory.append((item["url"], li, True))
    if get_setting:
        schedule_saved_skin_view_slug(get_setting, "home")
    with suppress_fanart_listing_cm():
        xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
        xbmcplugin.endOfDirectory(plugin_handle)


def run_movies_menu(
    *,
    plugin_handle,
    get_bool_setting,
    get_setting,
    default_list_art,
    url_for_discover_movies,
    url_for_movies_by_actor,
    url_for_browse_trakt_years,
    url_for_browse_trakt_genres,
    url_for_browse_tmdb_years,
    url_for_browse_tmdb_genres,
    url_for_browse_tmdb_platforms,
    url_for_search_movies,
    url_for_trakt_movies_in_progress,
    url_for_trakt_movies_related_recent,
    url_for_trakt_movies_random_recent,
):
    xbmcplugin.setPluginCategory(
        plugin_handle, _t("Kraken - Películas", "Kraken - Movies", "Kraken - Films", "Kraken - Film", "Kraken - Filme")
    )
    xbmcplugin.setContent(plugin_handle, "files")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_NONE)
    _gsm = get_setting or (lambda *_a, **_k: None)
    items = []
    if hub_movie_trending_enabled(_gsm):
        items.append(
            {
                "label": _t("[B]Tendencias[/B]", "[B]Trending[/B]", "[B]Tendances[/B]", "[B]Tendenze[/B]", "[B]Trending[/B]"),
                "label2": _t("Trakt: lo más visto ahora", "Trakt: most watched now", "Trakt : les plus vus maintenant", "Trakt: i più visti ora", "Trakt: aktuell meistgesehen"),
                "plot": _t("Listados vía Trakt.", "Lists via Trakt.", "Listes via Trakt.", "Liste via Trakt.", "Listen über Trakt."),
                "url": url_for_discover_movies("trending"),
            },
        )
    if submenu_movie_trakt_lists_enabled(_gsm):
        items.extend(
            [
                {
                    "label": _t("[B]Populares[/B]", "[B]Popular[/B]", "[B]Populaires[/B]", "[B]Popolari[/B]", "[B]Beliebt[/B]"),
                    "label2": _t("Trakt: catálogo popular", "Trakt: popular catalog", "Trakt : catalogue populaire", "Trakt: catalogo popolare", "Trakt: beliebter Katalog"),
                    "plot": _t("Películas populares en Trakt.", "Popular movies on Trakt.", "Films populaires sur Trakt.", "Film popolari su Trakt.", "Beliebte Filme auf Trakt."),
                    "url": url_for_discover_movies("popular"),
                },
                {
                    "label": _t("Más vistos (semana)", "Most watched (week)", "Les plus vus (semaine)", "Più visti (settimana)", "Meistgesehen (Woche)"),
                    "label2": _t("Trakt: tendencia semanal", "Trakt: weekly trend", "Trakt : tendance hebdomadaire", "Trakt: tendenza settimanale", "Trakt: Wochentrend"),
                    "plot": _t("Lo más visto en la última semana.", "Most watched in the last week.", "Les plus vus la semaine dernière.", "I più visti nell'ultima settimana.", "Meistgesehen in der letzten Woche."),
                    "url": url_for_discover_movies("played"),
                },
                {
                    "label": _t("Taquilla", "Box office", "Box-office", "Box office", "Box Office"),
                    "label2": _t(
                        "Cartelera regional (TMDb) · respaldo taquilla USA (Trakt)",
                        "Regional theatrical (TMDb) · US weekend fallback (Trakt)",
                        "À l'affiche régional (TMDb) · secours box-office US (Trakt)",
                        "Cartellera regionale (TMDb) · fallback USA (Trakt)",
                        "Regional im Kino (TMDb) · US-Weekend-Fallback (Trakt)",
                    ),
                    "plot": _t(
                        "Películas en cartelera según la región de Kodi y TMDb (lo que suele verse en cines locales). Si falla TMDb, listado de taquilla fin de semana en EE.UU. vía Trakt.",
                        "Now playing in theaters for your Kodi/TMDb region (local listings). If TMDb is unavailable, U.S. weekend box office via Trakt.",
                        "Films à l'affiche selon la région Kodi/TMDb. Si TMDb échoue, box-office week-end USA via Trakt.",
                        "Film in sala per regione Kodi/TMDb. Se TMDb non è disponibile, box office weekend USA via Trakt.",
                        "Kinostart gemäß Kodi/TMDb-Region. Falls TMDb ausfällt: US-Wochenend-Boxoffice über Trakt.",
                    ),
                    "url": url_for_discover_movies("boxoffice"),
                },
                {
                    "label": _t("Más esperados (próximos estrenos)", "Most anticipated (upcoming releases)", "Les plus attendus (prochaines sorties)", "Più attesi (prossime uscite)", "Am meisten erwartet (kommende Starts)"),
                    "label2": _t("Trakt: anticipadas", "Trakt: anticipated", "Trakt : anticipés", "Trakt: attesi", "Trakt: erwartet"),
                    "plot": _t("Películas más esperadas en listas de Trakt.", "Most anticipated movies on Trakt lists.", "Films les plus attendus dans les listes Trakt.", "Film più attesi nelle liste Trakt.", "Am meisten erwartete Filme in Trakt-Listen."),
                    "url": url_for_discover_movies("anticipated"),
                },
                {
                    "label": _t("Mejor valoradas (puntuación / rating)", "Top rated (score / rating)", "Mieux notés (score / note)", "Più votati (punteggio / rating)", "Top bewertet (Punktzahl / Rating)"),
                    "label2": _t("Trakt: top por nota y votos", "Trakt: top by score and votes", "Trakt : top par note et votes", "Trakt: top per punteggio e voti", "Trakt: Top nach Bewertung und Stimmen"),
                    "plot": _t("Catálogo popular de Trakt ordenado por puntuación de la comunidad.", "Trakt popular catalog sorted by community rating.", "Catalogue populaire Trakt trié par note de la communauté.", "Catalogo popolare Trakt ordinato per valutazione della community.", "Beliebter Trakt-Katalog nach Community-Bewertung sortiert."),
                    "url": url_for_discover_movies("rated"),
                },
            ]
        )
    if submenu_movie_actor_enabled(_gsm):
        items.append(
            {
                "label": _t("Catálogo por actor o actriz", "Catalog by actor", "Catalogue par acteur/actrice", "Catalogo per attore/attrice", "Katalog nach Schauspieler/in"),
                "label2": _t("Búsqueda y filmografía en Trakt", "Search and filmography on Trakt", "Recherche et filmographie sur Trakt", "Ricerca e filmografia su Trakt", "Suche und Filmografie auf Trakt"),
                "plot": _t("Busca una persona y abre su listado de películas (créditos).", "Search a person and open their movie credits list.", "Recherche une personne et ouvre sa liste de films (crédits).", "Cerca una persona e apri la sua lista film (crediti).", "Suche eine Person und öffne ihre Filmliste (Credits)."),
                "url": url_for_movies_by_actor(),
            }
        )
    if submenu_movie_trakt_browse_enabled(_gsm):
        items.extend(
            [
                {
                    "label": _t("Por año (lista Trakt)", "By year (Trakt list)", "Par année (liste Trakt)", "Per anno (lista Trakt)", "Nach Jahr (Trakt-Liste)"),
                    "label2": _t("Años recientes · populares", "Recent years · popular", "Années récentes · populaires", "Anni recenti · popolari", "Neuere Jahre · beliebt"),
                    "plot": _t("Elige año: películas populares en Trakt con filtro years=.", "Choose year: popular movies on Trakt with years= filter.", "Choisis l'année : films populaires sur Trakt avec filtre years=.", "Scegli anno: film popolari su Trakt con filtro years=.", "Jahr wählen: beliebte Filme auf Trakt mit years=-Filter."),
                    "url": url_for_browse_trakt_years(),
                },
                {
                    "label": _t("Por género (lista Trakt)", "By genre (Trakt list)", "Par genre (liste Trakt)", "Per genere (lista Trakt)", "Nach Genre (Trakt-Liste)"),
                    "label2": _t("Acción, drama, comedia…", "Action, drama, comedy...", "Action, drame, comédie...", "Azione, dramma, commedia...", "Action, Drama, Komödie..."),
                    "plot": _t("Géneros Trakt (slug) sobre listado popular.", "Trakt genres (slug) over popular list.", "Genres Trakt (slug) sur la liste populaire.", "Generi Trakt (slug) sulla lista popolare.", "Trakt-Genres (Slug) über der beliebten Liste."),
                    "url": url_for_browse_trakt_genres(),
                },
            ]
        )
    if submenu_movie_tmdb_browse_enabled(_gsm):
        items.extend(
            [
                {
                    "label": _t("Por año (lista TMDb)", "By year (TMDb list)", "Par année (liste TMDb)", "Per anno (lista TMDb)", "Nach Jahr (TMDb-Liste)"),
                    "label2": _t("Discover por estreno", "Discover by release", "Discover par sortie", "Discover per uscita", "Discover nach Veröffentlichung"),
                    "plot": _t("TMDb discover por año; intenta enlazar a Trakt para reproducir.", "TMDb discover by year; tries linking to Trakt for playback.", "Discover TMDb par année ; essaie de lier à Trakt pour la lecture.", "TMDb discover per anno; prova a collegare a Trakt per la riproduzione.", "TMDb Discover nach Jahr; versucht für Wiedergabe mit Trakt zu verknüpfen."),
                    "url": url_for_browse_tmdb_years(),
                },
                {
                    "label": _t("Por género (lista TMDb)", "By genre (TMDb list)", "Par genre (liste TMDb)", "Per genere (lista TMDb)", "Nach Genre (TMDb-Liste)"),
                    "label2": _t(
                        "IDs discover TMDb",
                        "TMDb discover IDs",
                        "IDs discover TMDb",
                        "ID discover TMDb",
                        "TMDb-Discover-IDs",
                    ),
                    "plot": _t("Géneros TMDb (película) ordenados por popularidad.", "TMDb movie genres sorted by popularity.", "Genres TMDb (film) triés par popularité.", "Generi TMDb (film) ordinati per popolarità.", "TMDb-Genres (Film) nach Popularität sortiert."),
                    "url": url_for_browse_tmdb_genres(),
                },
                {
                    "label": _t("Por plataformas (Netflix, Prime, HBO...)", "By platforms (Netflix, Prime, HBO...)", "Par plateformes (Netflix, Prime, HBO...)", "Per piattaforme (Netflix, Prime, HBO...)", "Nach Plattformen (Netflix, Prime, HBO...)"),
                    "label2": _t(
                        "Proveedores TMDb (región ES)",
                        "TMDb providers (ES region)",
                        "Fournisseurs TMDb (région ES)",
                        "Provider TMDb (regione ES)",
                        "TMDb-Anbieter (ES-Region)",
                    ),
                    "plot": _t("Catálogo por plataforma de streaming en TMDb.", "Catalog by streaming platform on TMDb.", "Catalogue par plateforme de streaming sur TMDb.", "Catalogo per piattaforma streaming su TMDb.", "Katalog nach Streaming-Plattform auf TMDb."),
                    "url": url_for_browse_tmdb_platforms(),
                },
            ]
        )
    trakt_connected = bool(
        get_bool_setting("trakt_enabled")
        and str(get_setting("trakt_access_token") or "").strip()
    )
    if trakt_connected and hub_movie_trakt_enabled(_gsm):
        items.extend(
            [
                {
                    "label": _t("[B]Películas sin finalizar[/B] [COLOR gray](Trakt)[/COLOR]", "[B]Unfinished movies[/B] [COLOR gray](Trakt)[/COLOR]", "[B]Films non terminés[/B] [COLOR gray](Trakt)[/COLOR]", "[B]Film non completati[/B] [COLOR gray](Trakt)[/COLOR]", "[B]Unfertige Filme[/B] [COLOR gray](Trakt)[/COLOR]"),
                    "label2": _t("Continuar películas pendientes", "Continue pending movies", "Continuer les films en cours", "Continua film in sospeso", "Offene Filme fortsetzen"),
                    "plot": _t("Películas en progreso con porcentaje visto, año y rating.", "Movies in progress with watched %, year and rating.", "Films en cours avec % vu, année et note.", "Film in corso con % visto, anno e valutazione.", "Filme in Bearbeitung mit gesehenem %, Jahr und Bewertung."),
                    "url": url_for_trakt_movies_in_progress(),
                },
                {
                    "label": _t("Películas relacionadas (vistas recientemente)", "Related movies (recently watched)", "Films liés (vus récemment)", "Film correlati (visti di recente)", "Ähnliche Filme (kürzlich gesehen)"),
                    "label2": _t("Sugerencias según historial reciente", "Suggestions from recent history", "Suggestions selon l'historique récent", "Suggerimenti dalla cronologia recente", "Vorschläge aus dem jüngsten Verlauf"),
                    "plot": _t("Relacionadas con lo que has visto recientemente en Trakt.", "Related to what you watched recently on Trakt.", "Liés à ce que tu as récemment vu sur Trakt.", "Correlati a ciò che hai visto di recente su Trakt.", "Bezogen auf das, was du zuletzt auf Trakt gesehen hast."),
                    "url": url_for_trakt_movies_related_recent(),
                },
                {
                    "label": _t("Película aleatoria (últimas vistas)", "Random movie (latest watched)", "Film aléatoire (derniers vus)", "Film casuale (ultimi visti)", "Zufälliger Film (zuletzt gesehen)"),
                    "label2": _t("Una recomendación aleatoria", "A random recommendation", "Une recommandation aléatoire", "Un consiglio casuale", "Eine zufällige Empfehlung"),
                    "plot": _t("Elige una película aleatoria basada en tus últimas vistas.", "Choose a random movie based on your latest watched.", "Choisis un film aléatoire selon tes derniers visionnages.", "Scegli un film casuale in base alle ultime visioni.", "Wähle einen zufälligen Film basierend auf zuletzt Gesehenem."),
                    "url": url_for_trakt_movies_random_recent(),
                },
            ]
        )
    if submenu_movie_search_enabled(_gsm):
        items.append(
            {
                "label": _t("Buscar películas", "Search movies", "Rechercher des films", "Cerca film", "Filme suchen"),
                "label2": _t("Búsqueda por título", "Search by title", "Recherche par titre", "Ricerca per titolo", "Suche nach Titel"),
                "plot": _t("Búsqueda de películas en el catálogo.", "Search movies in the catalog.", "Recherche de films dans le catalogue.", "Ricerca film nel catalogo.", "Filmsuche im Katalog."),
                "url": url_for_search_movies(),
            }
        )
    directory = []
    base_art = default_list_art()
    for item in items:
        li = xbmcgui.ListItem(label=item["label"], label2=item.get("label2", ""))
        apply_video_info(
            li,
            {
                "title": item["label"],
                "plot": item.get("plot", ""),
                "mediatype": "video",
            },
        )
        li.setArt(_item_art_with_icon(base_art, item.get("label")))
        directory.append((item["url"], li, True))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)


def run_series_menu(
    *,
    plugin_handle,
    get_bool_setting,
    get_setting,
    default_list_art,
    url_for_discover_series,
    url_for_series_by_actor,
    url_for_browse_trakt_years,
    url_for_browse_trakt_genres,
    url_for_browse_tmdb_years,
    url_for_browse_tmdb_genres,
    url_for_browse_tmdb_platforms,
    url_for_search_series,
    url_for_trakt_series_in_progress,
    url_for_trakt_series_related_recent,
    url_for_trakt_series_random_recent,
):
    xbmcplugin.setPluginCategory(
        plugin_handle, _t("Kraken - Series", "Kraken - TV Shows", "Kraken - Séries", "Kraken - Serie TV", "Kraken - Serien")
    )
    xbmcplugin.setContent(plugin_handle, "files")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_NONE)
    _gss = get_setting or (lambda *_a, **_k: None)
    items = []
    if hub_series_trending_enabled(_gss):
        items.append(
            {
                "label": _t("[B]Tendencias[/B]", "[B]Trending[/B]", "[B]Tendances[/B]", "[B]Tendenze[/B]", "[B]Trending[/B]"),
                "label2": _t("Trakt: series en tendencia", "Trakt: trending TV shows", "Trakt : séries tendance", "Trakt: serie TV di tendenza", "Trakt: Serien im Trend"),
                "plot": _t("Listados vía Trakt.", "Lists via Trakt.", "Listes via Trakt.", "Liste via Trakt.", "Listen über Trakt."),
                "url": url_for_discover_series("trending"),
            },
        )
    if submenu_series_trakt_lists_enabled(_gss):
        items.extend(
            [
                {
                    "label": _t("[B]Populares[/B]", "[B]Popular[/B]", "[B]Populaires[/B]", "[B]Popolari[/B]", "[B]Beliebt[/B]"),
                    "label2": _t("Trakt: catálogo popular", "Trakt: popular catalog", "Trakt : catalogue populaire", "Trakt: catalogo popolare", "Trakt: beliebter Katalog"),
                    "plot": _t("Series populares en Trakt.", "Popular TV shows on Trakt.", "Séries populaires sur Trakt.", "Serie TV popolari su Trakt.", "Beliebte Serien auf Trakt."),
                    "url": url_for_discover_series("popular"),
                },
                {
                    "label": _t("Más vistos (semana)", "Most watched (week)", "Les plus vus (semaine)", "Più visti (settimana)", "Meistgesehen (Woche)"),
                    "label2": _t("Trakt: tendencia semanal", "Trakt: weekly trend", "Trakt : tendance hebdomadaire", "Trakt: tendenza settimanale", "Trakt: Wochentrend"),
                    "plot": _t("Lo más visto en la última semana.", "Most watched in the last week.", "Les plus vus la semaine dernière.", "I più visti nell'ultima settimana.", "Meistgesehen in der letzten Woche."),
                    "url": url_for_discover_series("played"),
                },
                {
                    "label": _t("Más esperados (próximos estrenos)", "Most anticipated (upcoming releases)", "Les plus attendus (prochaines sorties)", "Più attesi (prossime uscite)", "Am meisten erwartet (kommende Starts)"),
                    "label2": _t("Trakt: más esperados", "Trakt: most anticipated", "Trakt : les plus attendus", "Trakt: più attesi", "Trakt: am meisten erwartet"),
                    "plot": _t("Series más anticipadas en listas de Trakt.", "Most anticipated TV shows on Trakt lists.", "Séries les plus attendues dans les listes Trakt.", "Serie TV più attese nelle liste Trakt.", "Am meisten erwartete Serien in Trakt-Listen."),
                    "url": url_for_discover_series("anticipated"),
                },
                {
                    "label": _t("Mejor valoradas (puntuación / rating)", "Top rated (score / rating)", "Mieux notées (score / note)", "Più votate (punteggio / rating)", "Top bewertet (Punktzahl / Rating)"),
                    "label2": _t("Trakt: top por nota y votos", "Trakt: top by score and votes", "Trakt : top par note et votes", "Trakt: top per punteggio e voti", "Trakt: Top nach Bewertung und Stimmen"),
                    "plot": _t("Catálogo popular de Trakt ordenado por puntuación de la comunidad.", "Trakt popular catalog sorted by community rating.", "Catalogue populaire Trakt trié par note de la communauté.", "Catalogo popolare Trakt ordinato per valutazione della community.", "Beliebter Trakt-Katalog nach Community-Bewertung sortiert."),
                    "url": url_for_discover_series("rated"),
                },
            ]
        )
    if submenu_series_actor_enabled(_gss):
        items.append(
            {
                "label": _t("Catálogo por actor o actriz", "Catalog by actor", "Catalogue par acteur/actrice", "Catalogo per attore/attrice", "Katalog nach Schauspieler/in"),
                "label2": _t("Búsqueda y filmografía en Trakt", "Search and filmography on Trakt", "Recherche et filmographie sur Trakt", "Ricerca e filmografia su Trakt", "Suche und Filmografie auf Trakt"),
                "plot": _t("Busca una persona y abre su listado de series (creditos).", "Search a person and open their TV credits list.", "Recherche une personne et ouvre sa liste de séries (crédits).", "Cerca una persona e apri la sua lista serie TV (crediti).", "Suche eine Person und öffne ihre Serienliste (Credits)."),
                "url": url_for_series_by_actor(),
            }
        )
    if submenu_series_trakt_browse_enabled(_gss):
        items.extend(
            [
                {
                    "label": _t("Por año (lista Trakt)", "By year (Trakt list)", "Par année (liste Trakt)", "Per anno (lista Trakt)", "Nach Jahr (Trakt-Liste)"),
                    "label2": _t("Años recientes · populares", "Recent years · popular", "Années récentes · populaires", "Anni recenti · popolari", "Neuere Jahre · beliebt"),
                    "plot": _t("Series populares en Trakt filtradas por año.", "Popular TV shows on Trakt filtered by year.", "Séries populaires sur Trakt filtrées par année.", "Serie TV popolari su Trakt filtrate per anno.", "Beliebte Serien auf Trakt nach Jahr gefiltert."),
                    "url": url_for_browse_trakt_years(),
                },
                {
                    "label": _t("Por género (lista Trakt)", "By genre (Trakt list)", "Par genre (liste Trakt)", "Per genere (lista Trakt)", "Nach Genre (Trakt-Liste)"),
                    "label2": _t("Acción, drama, comedia…", "Action, drama, comedy...", "Action, drame, comédie...", "Azione, dramma, commedia...", "Action, Drama, Komödie..."),
                    "plot": _t("Géneros Trakt sobre listado popular de series.", "Trakt genres over popular TV shows list.", "Genres Trakt sur la liste populaire de séries.", "Generi Trakt sulla lista popolare di serie TV.", "Trakt-Genres über der beliebten Serienliste."),
                    "url": url_for_browse_trakt_genres(),
                },
            ]
        )
    if submenu_series_tmdb_browse_enabled(_gss):
        items.extend(
            [
                {
                    "label": _t("Por año (lista TMDb)", "By year (TMDb list)", "Par année (liste TMDb)", "Per anno (lista TMDb)", "Nach Jahr (TMDb-Liste)"),
                    "label2": _t(
                        "Discover TV por estreno",
                        "Discover TV by release",
                        "Discover TV par sortie",
                        "Discover TV per uscita",
                        "Discover TV nach Erscheinung",
                    ),
                    "plot": _t("TMDb discover TV por año; resuelve a Trakt para temporadas.", "TMDb discover TV by year; resolves to Trakt for seasons.", "Discover TV TMDb par année ; résout vers Trakt pour les saisons.", "TMDb discover TV per anno; risolve su Trakt per le stagioni.", "TMDb TV Discover nach Jahr; löst für Staffeln zu Trakt auf."),
                    "url": url_for_browse_tmdb_years(),
                },
                {
                    "label": _t("Por género (lista TMDb)", "By genre (TMDb list)", "Par genre (liste TMDb)", "Per genere (lista TMDb)", "Nach Genre (TMDb-Liste)"),
                    "label2": _t(
                        "Géneros discover (TV)",
                        "Discover genres (TV)",
                        "Genres discover (TV)",
                        "Generi discover (TV)",
                        "Discover-Genres (TV)",
                    ),
                    "plot": _t("TMDb discover por género de serie.", "TMDb discover by TV show genre.", "Discover TMDb par genre de série.", "TMDb discover per genere di serie TV.", "TMDb Discover nach Seriengenre."),
                    "url": url_for_browse_tmdb_genres(),
                },
                {
                    "label": _t("Por plataformas (Netflix, Prime, HBO...)", "By platforms (Netflix, Prime, HBO...)", "Par plateformes (Netflix, Prime, HBO...)", "Per piattaforme (Netflix, Prime, HBO...)", "Nach Plattformen (Netflix, Prime, HBO...)"),
                    "label2": _t(
                        "Proveedores TMDb (región ES)",
                        "TMDb providers (ES region)",
                        "Fournisseurs TMDb (région ES)",
                        "Provider TMDb (regione ES)",
                        "TMDb-Anbieter (ES-Region)",
                    ),
                    "plot": _t("Series por plataforma de streaming en TMDb.", "TV shows by streaming platform on TMDb.", "Séries par plateforme de streaming sur TMDb.", "Serie TV per piattaforma streaming su TMDb.", "Serien nach Streaming-Plattform auf TMDb."),
                    "url": url_for_browse_tmdb_platforms(),
                },
            ]
        )
    trakt_connected = bool(
        get_bool_setting("trakt_enabled")
        and str(get_setting("trakt_access_token") or "").strip()
    )
    if trakt_connected and hub_series_trakt_enabled(_gss):
        items.extend(
            [
                {
                    "label": _t("[B]Series en seguimiento[/B] [COLOR gray](Trakt)[/COLOR]", "[B]TV shows in progress[/B] [COLOR gray](Trakt)[/COLOR]", "[B]Séries en cours[/B] [COLOR gray](Trakt)[/COLOR]", "[B]Serie TV in corso[/B] [COLOR gray](Trakt)[/COLOR]", "[B]Serien in Bearbeitung[/B] [COLOR gray](Trakt)[/COLOR]"),
                    "label2": _t("Continuar series", "Continue TV shows", "Continuer les séries", "Continua serie TV", "Serien fortsetzen"),
                    "plot": _t("Series en progreso con porcentaje visto y metadatos.", "TV shows in progress with watched % and metadata.", "Séries en cours avec % vu et métadonnées.", "Serie TV in corso con % visto e metadati.", "Serien in Bearbeitung mit gesehenem % und Metadaten."),
                    "url": url_for_trakt_series_in_progress(),
                },
                {
                    "label": _t("Series relacionadas (vistas recientemente)", "Related TV shows (recently watched)", "Séries liées (vues récemment)", "Serie TV correlate (viste di recente)", "Ähnliche Serien (kürzlich gesehen)"),
                    "label2": _t("Sugerencias según historial reciente", "Suggestions from recent history", "Suggestions selon l'historique récent", "Suggerimenti dalla cronologia recente", "Vorschläge aus dem jüngsten Verlauf"),
                    "plot": _t("Relacionadas con lo que has visto recientemente en Trakt.", "Related to what you watched recently on Trakt.", "Liées à ce que tu as récemment vu sur Trakt.", "Correlate a ciò che hai visto di recente su Trakt.", "Bezogen auf das, was du zuletzt auf Trakt gesehen hast."),
                    "url": url_for_trakt_series_related_recent(),
                },
                {
                    "label": _t("Serie aleatoria (últimas vistas)", "Random TV show (latest watched)", "Série aléatoire (derniers vus)", "Serie TV casuale (ultime viste)", "Zufällige Serie (zuletzt gesehen)"),
                    "label2": _t("Una recomendación aleatoria", "A random recommendation", "Une recommandation aléatoire", "Un consiglio casuale", "Eine zufällige Empfehlung"),
                    "plot": _t("Elige una serie aleatoria basada en tus últimas vistas.", "Choose a random TV show based on your latest watched.", "Choisis une série aléatoire selon tes derniers visionnages.", "Scegli una serie TV casuale in base alle ultime visioni.", "Wähle eine zufällige Serie basierend auf zuletzt Gesehenem."),
                    "url": url_for_trakt_series_random_recent(),
                },
            ]
        )
    if submenu_series_search_enabled(_gss):
        items.append(
            {
                "label": _t("Buscar series", "Search TV shows", "Rechercher des séries", "Cerca serie TV", "Serien suchen"),
                "label2": _t("Búsqueda por título", "Search by title", "Recherche par titre", "Ricerca per titolo", "Suche nach Titel"),
                "plot": _t("Búsqueda de series en el catálogo.", "Search TV shows in the catalog.", "Recherche de séries dans le catalogue.", "Ricerca serie TV nel catalogo.", "Seriensuche im Katalog."),
                "url": url_for_search_series(),
            }
        )
    directory = []
    base_art = default_list_art()
    for item in items:
        li = xbmcgui.ListItem(label=item["label"], label2=item.get("label2", ""))
        apply_video_info(
            li,
            {
                "title": item["label"],
                "plot": item.get("plot", ""),
                "mediatype": "video",
            },
        )
        li.setArt(_item_art_with_icon(base_art, item.get("label")))
        directory.append((item["url"], li, True))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)


def run_anime_menu(
    *,
    plugin_handle,
    get_bool_setting,
    get_setting,
    default_list_art,
    url_for_search_anime,
    url_for_discover_anime,
    url_for_anime_by_actor,
    url_for_browse_trakt_years,
    url_for_browse_trakt_genres,
    url_for_browse_tmdb_years,
    url_for_browse_tmdb_genres,
    url_for_browse_tmdb_platforms,
    url_for_trakt_anime_in_progress,
    url_for_trakt_anime_related_recent,
    url_for_trakt_anime_random_recent,
):
    xbmcplugin.setPluginCategory(
        plugin_handle, _t("Kraken - Anime", "Kraken - Anime", "Kraken - Anime", "Kraken - Anime", "Kraken - Anime")
    )
    xbmcplugin.setContent(plugin_handle, "files")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_NONE)
    _gsa = get_setting or (lambda *_a, **_k: None)
    items = []
    if hub_anime_trending_enabled(_gsa):
        items.append(
            {
                "label": _t("[B]Tendencias[/B]", "[B]Trending[/B]", "[B]Tendances[/B]", "[B]Tendenze[/B]", "[B]Trending[/B]"),
                "label2": _t("Trakt · género anime", "Trakt · anime genre", "Trakt · genre anime", "Trakt · genere anime", "Trakt · Anime-Genre"),
                "plot": _t("Series anime en tendencia (Trakt, género anime).", "Trending anime TV shows (Trakt, anime genre).", "Séries anime en tendance (Trakt, genre anime).", "Serie anime di tendenza (Trakt, genere anime).", "Trendende Anime-Serien (Trakt, Anime-Genre)."),
                "url": url_for_discover_anime("trending"),
            },
        )
    if submenu_anime_trakt_lists_enabled(_gsa):
        items.extend(
            [
                {
                    "label": _t("[B]Populares[/B]", "[B]Popular[/B]", "[B]Populaires[/B]", "[B]Popolari[/B]", "[B]Beliebt[/B]"),
                    "label2": _t("Trakt · popular anime", "Trakt · popular anime", "Trakt · anime populaire", "Trakt · anime popolare", "Trakt · beliebte Anime"),
                    "plot": _t("Series anime populares en Trakt.", "Popular anime TV shows on Trakt.", "Séries anime populaires sur Trakt.", "Serie anime popolari su Trakt.", "Beliebte Anime-Serien auf Trakt."),
                    "url": url_for_discover_anime("popular"),
                },
                {
                    "label": _t("Más vistos (semana)", "Most watched (week)", "Les plus vus (semaine)", "Più visti (settimana)", "Meistgesehen (Woche)"),
                    "label2": _t("Trakt: tendencia semanal", "Trakt: weekly trend", "Trakt : tendance hebdomadaire", "Trakt: tendenza settimanale", "Trakt: Wochentrend"),
                    "plot": _t("Anime con más vistos en la última semana (Trakt).", "Most watched anime in the last week (Trakt).", "Anime les plus vus la semaine dernière (Trakt).", "Anime più visti nell'ultima settimana (Trakt).", "Meistgesehene Anime der letzten Woche (Trakt)."),
                    "url": url_for_discover_anime("played"),
                },
                {
                    "label": _t("Más esperados (próximos estrenos)", "Most anticipated (upcoming releases)", "Les plus attendus (prochaines sorties)", "Più attesi (prossime uscite)", "Am meisten erwartet (kommende Starts)"),
                    "label2": _t("Trakt: más esperados", "Trakt: most anticipated", "Trakt : les plus attendus", "Trakt: più attesi", "Trakt: am meisten erwartet"),
                    "plot": _t("Anime más anticipado en Trakt.", "Most anticipated anime on Trakt.", "Anime les plus attendus sur Trakt.", "Anime più attesi su Trakt.", "Am meisten erwartete Anime auf Trakt."),
                    "url": url_for_discover_anime("anticipated"),
                },
                {
                    "label": _t("Mejor valoradas (puntuación / rating)", "Top rated (score / rating)", "Mieux notés (score / note)", "Più votati (punteggio / rating)", "Top bewertet (Punktzahl / Rating)"),
                    "label2": _t("Trakt: top por nota y votos", "Trakt: top by score and votes", "Trakt : top par note et votes", "Trakt: top per punteggio e voti", "Trakt: Top nach Bewertung und Stimmen"),
                    "plot": _t("Catálogo popular (género anime) ordenado por puntuación de la comunidad en Trakt.", "Popular catalog (anime genre) sorted by community score on Trakt.", "Catalogue populaire (genre anime) trié par note de la communauté sur Trakt.", "Catalogo popolare (genere anime) ordinato per punteggio della community su Trakt.", "Beliebter Katalog (Anime-Genre) nach Community-Score auf Trakt sortiert."),
                    "url": url_for_discover_anime("rated"),
                },
            ]
        )
    if submenu_anime_actor_enabled(_gsa):
        items.append(
            {
                "label": _t("Catálogo por actor o actriz", "Catalog by actor", "Catalogue par acteur/actrice", "Catalogo per attore/attrice", "Katalog nach Schauspieler/in"),
                "label2": _t("Búsqueda y filmografía en Trakt", "Search and filmography on Trakt", "Recherche et filmographie sur Trakt", "Ricerca e filmografia su Trakt", "Suche und Filmografie auf Trakt"),
                "plot": _t("Búsqueda de persona y créditos de series; elige títulos anime en la lista.", "Search a person and TV credits; choose anime titles in the list.", "Recherche une personne et ses crédits séries ; choisis les titres anime dans la liste.", "Cerca una persona e i crediti serie TV; scegli i titoli anime nella lista.", "Suche eine Person und TV-Credits; wähle Anime-Titel in der Liste."),
                "url": url_for_anime_by_actor(),
            }
        )
    if submenu_anime_trakt_browse_enabled(_gsa):
        items.extend(
            [
                {
                    "label": _t("Por año (lista Trakt)", "By year (Trakt list)", "Par année (liste Trakt)", "Per anno (lista Trakt)", "Nach Jahr (Trakt-Liste)"),
                    "label2": _t("Años recientes · populares", "Recent years · popular", "Années récentes · populaires", "Anni recenti · popolari", "Neuere Jahre · beliebt"),
                    "plot": _t("Series con género anime en Trakt filtradas por año.", "Anime-genre TV shows on Trakt filtered by year.", "Séries au genre anime sur Trakt filtrées par année.", "Serie TV con genere anime su Trakt filtrate per anno.", "Anime-Genre-Serien auf Trakt nach Jahr gefiltert."),
                    "url": url_for_browse_trakt_years(),
                },
                {
                    "label": _t("Por género (lista Trakt)", "By genre (Trakt list)", "Par genre (liste Trakt)", "Per genere (lista Trakt)", "Nach Genre (Trakt-Liste)"),
                    "label2": _t("Acción, drama, comedia…", "Action, drama, comedy...", "Action, drame, comédie...", "Azione, dramma, commedia...", "Action, Drama, Komödie..."),
                    "plot": _t("Popular por slug en Trakt; solo títulos con género anime en la ficha.", "Popular by slug on Trakt; only titles with anime genre tag.", "Populaire par slug sur Trakt ; uniquement titres avec tag genre anime.", "Popolari per slug su Trakt; solo titoli con tag genere anime.", "Beliebt nach Slug auf Trakt; nur Titel mit Anime-Genre-Tag."),
                    "url": url_for_browse_trakt_genres(),
                },
            ]
        )
    if submenu_anime_tmdb_browse_enabled(_gsa):
        items.extend(
            [
                {
                    "label": _t("Por año (lista TMDb)", "By year (TMDb list)", "Par année (liste TMDb)", "Per anno (lista TMDb)", "Nach Jahr (TMDb-Liste)"),
                    "label2": _t(
                        "Discover TV por estreno",
                        "Discover TV by release",
                        "Discover TV par sortie",
                        "Discover TV per uscita",
                        "Discover TV nach Erscheinung",
                    ),
                    "plot": _t("Discover TMDb TV con Animación (16) y año de estreno.", "TMDb TV discover with Animation (16) and release year.", "Discover TMDb TV avec Animation (16) et année de sortie.", "TMDb TV discover con Animazione (16) e anno di uscita.", "TMDb TV Discover mit Animation (16) und Erscheinungsjahr."),
                    "url": url_for_browse_tmdb_years(),
                },
                {
                    "label": _t("Por género (lista TMDb)", "By genre (TMDb list)", "Par genre (liste TMDb)", "Per genere (lista TMDb)", "Nach Genre (TMDb-Liste)"),
                    "label2": _t(
                        "Géneros discover (TV)",
                        "Discover genres (TV)",
                        "Genres discover (TV)",
                        "Generi discover (TV)",
                        "Discover-Genres (TV)",
                    ),
                    "plot": _t("TMDb: Animación (16) y el género elegido (AND).", "TMDb: Animation (16) and selected genre (AND).", "TMDb : Animation (16) et genre sélectionné (AND).", "TMDb: Animazione (16) e genere selezionato (AND).", "TMDb: Animation (16) und gewähltes Genre (AND)."),
                    "url": url_for_browse_tmdb_genres(),
                },
                {
                    "label": _t("Por plataformas (Netflix, Prime, HBO...)", "By platforms (Netflix, Prime, HBO...)", "Par plateformes (Netflix, Prime, HBO...)", "Per piattaforme (Netflix, Prime, HBO...)", "Nach Plattformen (Netflix, Prime, HBO...)"),
                    "label2": _t(
                        "Proveedores TMDb (región ES)",
                        "TMDb providers (ES region)",
                        "Fournisseurs TMDb (région ES)",
                        "Provider TMDb (regione ES)",
                        "TMDb-Anbieter (ES-Region)",
                    ),
                    "plot": _t("Anime por plataforma en TMDb (Animación + proveedor).", "Anime by platform on TMDb (Animation + provider).", "Anime par plateforme sur TMDb (Animation + fournisseur).", "Anime per piattaforma su TMDb (Animazione + provider).", "Anime nach Plattform auf TMDb (Animation + Anbieter)."),
                    "url": url_for_browse_tmdb_platforms(),
                },
            ]
        )
    trakt_connected = bool(
        get_bool_setting("trakt_enabled")
        and str(get_setting("trakt_access_token") or "").strip()
    )
    if trakt_connected and hub_anime_trakt_enabled(_gsa):
        items.extend(
            [
                {
                    "label": _t("Anime en seguimiento [COLOR gray](Trakt)[/COLOR]", "Anime in progress [COLOR gray](Trakt)[/COLOR]", "Anime en cours [COLOR gray](Trakt)[/COLOR]", "Anime in corso [COLOR gray](Trakt)[/COLOR]", "Anime in Bearbeitung [COLOR gray](Trakt)[/COLOR]"),
                    "label2": _t("Continuar anime", "Continue anime", "Continuer l'anime", "Continua anime", "Anime fortsetzen"),
                    "plot": _t("Anime en progreso con porcentaje, año y rating.", "Anime in progress with percentage, year and rating.", "Anime en cours avec pourcentage, année et note.", "Anime in corso con percentuale, anno e valutazione.", "Anime in Bearbeitung mit Prozentsatz, Jahr und Bewertung."),
                    "url": url_for_trakt_anime_in_progress(),
                },
                {
                    "label": _t("Anime relacionados (vistas recientemente)", "Related anime (recently watched)", "Anime liés (vus récemment)", "Anime correlati (visti di recente)", "Ähnliche Anime (kürzlich gesehen)"),
                    "label2": _t("Sugerencias según historial reciente", "Suggestions from recent history", "Suggestions selon l'historique récent", "Suggerimenti dalla cronologia recente", "Vorschläge aus dem jüngsten Verlauf"),
                    "plot": _t("Relacionadas con lo último visto en anime.", "Related to what you watched recently in anime.", "Liés à ce que tu as vu récemment en anime.", "Correlati a ciò che hai visto di recente negli anime.", "Bezogen auf das, was du zuletzt bei Anime gesehen hast."),
                    "url": url_for_trakt_anime_related_recent(),
                },
                {
                    "label": _t("Anime aleatorio (últimas vistas)", "Random anime (latest watched)", "Anime aléatoire (derniers vus)", "Anime casuale (ultimi visti)", "Zufälliger Anime (zuletzt gesehen)"),
                    "label2": _t("Una recomendación aleatoria", "A random recommendation", "Une recommandation aléatoire", "Un consiglio casuale", "Eine zufällige Empfehlung"),
                    "plot": _t("Elige anime aleatorio según tus últimas vistas.", "Choose random anime based on latest watched.", "Choisis un anime aléatoire selon les derniers vus.", "Scegli anime casuale in base alle ultime visioni.", "Wähle zufälligen Anime basierend auf zuletzt Gesehenem."),
                    "url": url_for_trakt_anime_random_recent(),
                },
            ]
        )
    if submenu_anime_search_enabled(_gsa):
        items.append(
            {
                "label": _t("Buscar anime", "Search anime", "Rechercher anime", "Cerca anime", "Anime suchen"),
                "label2": _t("Búsqueda por título", "Search by title", "Recherche par titre", "Ricerca per titolo", "Suche nach Titel"),
                "plot": _t("Búsqueda orientada a anime (base series).", "Anime-focused search (TV shows base).", "Recherche orientée anime (base séries).", "Ricerca orientata anime (base serie TV).", "Anime-fokussierte Suche (Serienbasis)."),
                "url": url_for_search_anime(),
            }
        )
    directory = []
    base_art = default_list_art()
    for item in items:
        li = xbmcgui.ListItem(label=item["label"], label2=item.get("label2", ""))
        apply_video_info(
            li,
            {
                "title": item["label"],
                "plot": item.get("plot", ""),
                "mediatype": "video",
            },
        )
        li.setArt(_item_art_with_icon(base_art, item.get("label")))
        directory.append((item["url"], li, True))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)
