"""
Menús y listados: por año y por género (Trakt y TMDb) para películas, series y anime.
"""

import datetime

import xbmcgui
import xbmcplugin

from resources.lib.routes.i18n_routes import make_mapped_t
from resources.lib.routes.tmdb_discover_routes import (
    run_tmdb_discover_movies_list,
    run_tmdb_discover_tv_list,
)
from resources.lib.routes.trakt_discover_routes import (
    run_trakt_filtered_movie_list,
    run_trakt_filtered_show_list,
)
from resources.lib.ui.video_info import apply_video_info


TRAKT_GENRE_SLUGS = [
    "action",
    "adventure",
    "animation",
    "anime",
    "comedy",
    "crime",
    "documentary",
    "drama",
    "family",
    "fantasy",
    "history",
    "horror",
    "music",
    "mystery",
    "romance",
    "science-fiction",
    "thriller",
    "war",
    "western",
]

TMDB_MOVIE_GENRES = [
    (28,),
    (12,),
    (16,),
    (35,),
    (80,),
    (99,),
    (18,),
    (10751,),
    (14,),
    (36,),
    (27,),
    (10402,),
    (9648,),
    (10749,),
    (878,),
    (53,),
    (10752,),
    (37,),
]

TMDB_TV_GENRES = [
    (10759,),
    (16,),
    (35,),
    (80,),
    (99,),
    (18,),
    (10751,),
    (9648,),
    (10765,),
    (37,),
]

# (ES, EN) -> (FR, IT, DE) para etiquetas de género Trakt/TMDb (menús browse año/género).
_BROWSE_GENRE_PHRASE_MAP = {
    ("Acción", "Action"): ("Action", "Azione", "Action"),
    ("Acción y aventura", "Action & Adventure"): (
        "Action et aventure",
        "Azione e avventura",
        "Action und Abenteuer",
    ),
    ("Aventura", "Adventure"): ("Aventure", "Avventura", "Abenteuer"),
    ("Animación", "Animation"): ("Animation", "Animazione", "Animation"),
    ("Anime", "Anime"): ("Anime", "Anime", "Anime"),
    ("Comedia", "Comedy"): ("Comédie", "Commedia", "Komödie"),
    ("Crimen", "Crime"): ("Policier", "Poliziesco", "Krimi"),
    ("Ciencia ficción", "Science fiction"): (
        "Science-fiction",
        "Fantascienza",
        "Science-Fiction",
    ),
    (
        "Ciencia ficción y fantasía",
        "Sci-Fi & Fantasy",
    ): (
        "Science-fiction et fantasy",
        "Fantascienza e fantasy",
        "Science-Fiction und Fantasy",
    ),
    ("Documental", "Documentary"): ("Documentaire", "Documentario", "Dokumentation"),
    ("Drama", "Drama"): ("Drame", "Dramma", "Drama"),
    ("Familia", "Family"): ("Famille", "Famiglia", "Familie"),
    ("Fantasía", "Fantasy"): ("Fantastique", "Fantasy", "Fantasy"),
    ("Historia", "History"): ("Histoire", "Storia", "Geschichte"),
    ("Misterio", "Mystery"): ("Mystère", "Mistero", "Mystery"),
    ("Música", "Music"): ("Musique", "Musica", "Musik"),
    ("Romance", "Romance"): ("Romance", "Romantico", "Romanze"),
    ("Suspense", "Thriller"): ("Thriller", "Thriller", "Thriller"),
    ("Terror", "Horror"): ("Horreur", "Horror", "Horror"),
    ("Bélica", "War"): ("Guerre", "Guerra", "Krieg"),
    ("Western", "Western"): ("Western", "Western", "Western"),
}

# Menús browse (categorías, plots, plantillas Kraken) — mismas traducciones FR/IT/DE que antes.
_BROWSE_MENU_PHRASE_MAP = {
    ("Películas", "Movies"): ("Films", "Film", "Filme"),
    ("Series", "TV Shows"): ("Séries", "Serie TV", "Serien"),
    (
        "Kraken - {} - Trakt por año",
        "Kraken - {} - Trakt by year",
    ): (
        "Kraken - {} - Trakt par année",
        "Kraken - {} - Trakt per anno",
        "Kraken - {} - Trakt nach Jahr",
    ),
    (
        "Kraken - {} - Trakt por género",
        "Kraken - {} - Trakt by genre",
    ): (
        "Kraken - {} - Trakt par genre",
        "Kraken - {} - Trakt per genere",
        "Kraken - {} - Trakt nach Genre",
    ),
    (
        "Kraken - {} - TMDb por año",
        "Kraken - {} - TMDb by year",
    ): (
        "Kraken - {} - TMDb par année",
        "Kraken - {} - TMDb per anno",
        "Kraken - {} - TMDb nach Jahr",
    ),
    (
        "Kraken - {} - TMDb por género",
        "Kraken - {} - TMDb by genre",
    ): (
        "Kraken - {} - TMDb par genre",
        "Kraken - {} - TMDb per genere",
        "Kraken - {} - TMDb nach Genre",
    ),
    (
        "Kraken - {} - TMDb por plataforma",
        "Kraken - {} - TMDb by platform",
    ): (
        "Kraken - {} - TMDb par plateforme",
        "Kraken - {} - TMDb per piattaforma",
        "Kraken - {} - TMDb nach Plattform",
    ),
    (
        "Popular en Trakt · {}",
        "Popular on Trakt · {}",
    ): (
        "Populaire sur Trakt · {}",
        "Popolare su Trakt · {}",
        "Beliebt auf Trakt · {}",
    ),
    (
        "Películas o series populares filtradas por año en Trakt.",
        "Popular movies or TV shows filtered by year on Trakt.",
    ): (
        "Films ou séries populaires filtrées par année sur Trakt.",
        "Film o serie TV popolari filtrati per anno su Trakt.",
        "Beliebte Filme oder Serien nach Jahr auf Trakt gefiltert.",
    ),
    (
        "Listado popular Trakt con filtro de género.",
        "Popular Trakt list filtered by genre.",
    ): (
        "Liste populaire Trakt filtrée par genre.",
        "Lista popolare Trakt filtrata per genere.",
        "Beliebte Trakt-Liste nach Genre gefiltert.",
    ),
    (
        " Solo títulos que Trakt marque también como anime.",
        " Only titles that Trakt also marks as anime.",
    ): (
        " Uniquement les titres également marqués comme anime par Trakt.",
        " Solo titoli che Trakt contrassegna anche come anime.",
        " Nur Titel, die Trakt zusätzlich als Anime markiert.",
    ),
    (
        "TMDb discover · {}",
        "TMDb discover · {}",
    ): (
        "TMDb discover · {}",
        "TMDb discover · {}",
        "TMDb Discover · {}",
    ),
    (
        "Orden por popularidad en TMDb para ese año.",
        "Sorted by popularity on TMDb for that year.",
    ): (
        "Trié par popularité sur TMDb pour cette année.",
        "Ordinato per popolarità su TMDb per quell'anno.",
        "Nach Popularität auf TMDb für dieses Jahr sortiert.",
    ),
    (
        "slug: {}",
        "slug: {}",
    ): (
        "slug : {}",
        "slug: {}",
        "Slug: {}",
    ),
    (
        "ID {}",
        "ID {}",
    ): ("ID {}", "ID {}", "ID {}"),
    (
        "Discover TMDb (AND de géneros en anime: Animación + elegido).",
        "TMDb discover (AND genres for anime: Animation + selected).",
    ): (
        "Discover TMDb (ET de genres pour anime : Animation + sélectionné).",
        "Discover TMDb (AND generi per anime: Animazione + selezionato).",
        "TMDb Discover (UND-Genres für Anime: Animation + ausgewählt).",
    ),
    (
        "Discover TMDb por género.",
        "TMDb discover by genre.",
    ): (
        "Discover TMDb par genre.",
        "Discover TMDb per genere.",
        "TMDb Discover nach Genre.",
    ),
    (
        "ID proveedor {}",
        "Provider ID {}",
    ): (
        "ID fournisseur {}",
        "ID fornitore {}",
        "Anbieter-ID {}",
    ),
    (
        "Discover TMDb filtrado por plataforma de streaming.",
        "TMDb discover filtered by streaming platform.",
    ): (
        "Discover TMDb filtré par plateforme de streaming.",
        "Discover TMDb filtrato per piattaforma streaming.",
        "TMDb Discover nach Streaming-Plattform gefiltert.",
    ),
    ("Proveedor {}", "Provider {}"): ("Fournisseur {}", "Fornitore {}", "Anbieter {}"),
    (
        "Kraken - Películas - Trakt · año {}",
        "Kraken - Movies - Trakt · year {}",
    ): (
        "Kraken - Films - Trakt · année {}",
        "Kraken - Film - Trakt · anno {}",
        "Kraken - Filme - Trakt · Jahr {}",
    ),
    (
        "Kraken - Anime - Trakt · año {} (anime)",
        "Kraken - Anime - Trakt · year {} (anime)",
    ): (
        "Kraken - Anime - Trakt · année {} (anime)",
        "Kraken - Anime - Trakt · anno {} (anime)",
        "Kraken - Anime - Trakt · Jahr {} (Anime)",
    ),
    (
        "Kraken - Series - Trakt · año {}",
        "Kraken - TV Shows - Trakt · year {}",
    ): (
        "Kraken - Séries - Trakt · année {}",
        "Kraken - Serie TV - Trakt · anno {}",
        "Kraken - Serien - Trakt · Jahr {}",
    ),
    (
        "Kraken - Películas - Trakt · {}",
        "Kraken - Movies - Trakt · {}",
    ): (
        "Kraken - Films - Trakt · {}",
        "Kraken - Film - Trakt · {}",
        "Kraken - Filme - Trakt · {}",
    ),
    (
        "Kraken - Anime - Trakt · {} + anime",
        "Kraken - Anime - Trakt · {} + anime",
    ): (
        "Kraken - Anime - Trakt · {} + anime",
        "Kraken - Anime - Trakt · {} + anime",
        "Kraken - Anime - Trakt · {} + Anime",
    ),
    (
        "Kraken - Series - Trakt · {}",
        "Kraken - TV Shows - Trakt · {}",
    ): (
        "Kraken - Séries - Trakt · {}",
        "Kraken - Serie TV - Trakt · {}",
        "Kraken - Serien - Trakt · {}",
    ),
    (
        "Kraken - Películas - TMDb · año {}",
        "Kraken - Movies - TMDb · year {}",
    ): (
        "Kraken - Films - TMDb · année {}",
        "Kraken - Film - TMDb · anno {}",
        "Kraken - Filme - TMDb · Jahr {}",
    ),
    (
        "Kraken - {} - TMDb · año {}",
        "Kraken - {} - TMDb · year {}",
    ): (
        "Kraken - {} - TMDb · année {}",
        "Kraken - {} - TMDb · anno {}",
        "Kraken - {} - TMDb · Jahr {}",
    ),
    (
        "Kraken - Películas - TMDb · género {}",
        "Kraken - Movies - TMDb · genre {}",
    ): (
        "Kraken - Films - TMDb · genre {}",
        "Kraken - Film - TMDb · genere {}",
        "Kraken - Filme - TMDb · Genre {}",
    ),
    (
        "Kraken - {} - TMDb · género {}",
        "Kraken - {} - TMDb · genre {}",
    ): (
        "Kraken - {} - TMDb · genre {}",
        "Kraken - {} - TMDb · genere {}",
        "Kraken - {} - TMDb · Genre {}",
    ),
    (
        "Kraken - Películas - TMDb · {}",
        "Kraken - Movies - TMDb · {}",
    ): (
        "Kraken - Films - TMDb · {}",
        "Kraken - Film - TMDb · {}",
        "Kraken - Filme - TMDb · {}",
    ),
    (
        "Kraken - {} - TMDb · {}",
        "Kraken - {} - TMDb · {}",
    ): (
        "Kraken - {} - TMDb · {}",
        "Kraken - {} - TMDb · {}",
        "Kraken - {} - TMDb · {}",
    ),
}

_BROWSE_YG_PHRASE_MAP = {**_BROWSE_GENRE_PHRASE_MAP, **_BROWSE_MENU_PHRASE_MAP}
_t = make_mapped_t(_BROWSE_YG_PHRASE_MAP)

TRAKT_SLUG_TO_ES_EN = {
    "action": ("Acción", "Action"),
    "adventure": ("Aventura", "Adventure"),
    "animation": ("Animación", "Animation"),
    "anime": ("Anime", "Anime"),
    "comedy": ("Comedia", "Comedy"),
    "crime": ("Crimen", "Crime"),
    "documentary": ("Documental", "Documentary"),
    "drama": ("Drama", "Drama"),
    "family": ("Familia", "Family"),
    "fantasy": ("Fantasía", "Fantasy"),
    "history": ("Historia", "History"),
    "horror": ("Terror", "Horror"),
    "music": ("Música", "Music"),
    "mystery": ("Misterio", "Mystery"),
    "romance": ("Romance", "Romance"),
    "science-fiction": ("Ciencia ficción", "Science fiction"),
    "thriller": ("Suspense", "Thriller"),
    "war": ("Bélica", "War"),
    "western": ("Western", "Western"),
}

TMDB_MOVIE_GENRE_ID_TO_ES_EN = {
    28: ("Acción", "Action"),
    12: ("Aventura", "Adventure"),
    16: ("Animación", "Animation"),
    35: ("Comedia", "Comedy"),
    80: ("Crimen", "Crime"),
    99: ("Documental", "Documentary"),
    18: ("Drama", "Drama"),
    10751: ("Familia", "Family"),
    14: ("Fantasía", "Fantasy"),
    36: ("Historia", "History"),
    27: ("Terror", "Horror"),
    10402: ("Música", "Music"),
    9648: ("Misterio", "Mystery"),
    10749: ("Romance", "Romance"),
    878: ("Ciencia ficción", "Science fiction"),
    53: ("Suspense", "Thriller"),
    10752: ("Bélica", "War"),
    37: ("Western", "Western"),
}

TMDB_TV_GENRE_ID_TO_ES_EN = {
    10759: ("Acción y aventura", "Action & Adventure"),
    16: ("Animación", "Animation"),
    35: ("Comedia", "Comedy"),
    80: ("Crimen", "Crime"),
    99: ("Documental", "Documentary"),
    18: ("Drama", "Drama"),
    10751: ("Familia", "Family"),
    9648: ("Misterio", "Mystery"),
    10765: ("Ciencia ficción y fantasía", "Sci-Fi & Fantasy"),
    37: ("Western", "Western"),
}


def _trakt_genre_menu_label(slug):
    s = (slug or "").strip().lower()
    pair = TRAKT_SLUG_TO_ES_EN.get(s)
    if pair:
        return _t(pair[0], pair[1])
    return slug


def _tmdb_movie_genre_label(gid):
    try:
        k = int(gid)
    except (TypeError, ValueError):
        return str(gid)
    pair = TMDB_MOVIE_GENRE_ID_TO_ES_EN.get(k)
    if pair:
        return _t(pair[0], pair[1])
    return str(k)


def _tmdb_tv_genre_label(gid):
    try:
        k = int(gid)
    except (TypeError, ValueError):
        return str(gid)
    pair = TMDB_TV_GENRE_ID_TO_ES_EN.get(k)
    if pair:
        return _t(pair[0], pair[1])
    return str(k)

TMDB_PLATFORM_CHOICES = [
    (8, "Netflix"),
    (9, "Prime Video"),
    (337, "Disney+"),
    (384, "HBO Max"),
    (350, "Apple TV+"),
    (2, "Apple TV"),
    (531, "Paramount+"),
    (283, "Crunchyroll"),
    (29, "Movistar Plus+"),
    (149, "Atres Player"),
]


def _tmdb_platform_label(provider_id):
    try:
        p = int(provider_id)
    except (TypeError, ValueError):
        return ""
    for pid, plabel in TMDB_PLATFORM_CHOICES:
        if pid == p:
            return plabel
    return _t("Proveedor {}", "Provider {}").format(p)


def _scope_kind(scope):
    s = (scope or "").strip().lower()
    if s in ("peliculas", "películas", "movie", "movies"):
        return "movie"
    if s in ("series", "serie", "show", "shows"):
        return "series"
    if s in ("anime",):
        return "anime"
    return None


def _parse_year(yraw):
    try:
        y = int(str(yraw).strip())
    except (TypeError, ValueError):
        return None
    if 1888 <= y <= datetime.datetime.now().year + 2:
        return y
    return None


def _parse_genre_id(gid):
    try:
        return int(str(gid).strip())
    except (TypeError, ValueError):
        return None


def _slug_ok(slug):
    s = (slug or "").strip().lower()
    if not s or len(s) > 40:
        return False
    for ch in s:
        if ch not in "abcdefghijklmnopqrstuvwxyz0123456789-":
            return False
    return True


def _min_year_for_scope(sk):
    if sk == "movie":
        return 1888
    if sk == "series":
        return 1938
    if sk == "anime":
        return 1963
    return 1888


def _scope_section_label(sk):
    if sk == "movie":
        return _t("Películas", "Movies")
    if sk == "anime":
        return "Anime"
    return _t("Series", "TV Shows")


def _begin_browse_menu(plugin_handle, category_title):
    xbmcplugin.setPluginCategory(plugin_handle, category_title)
    xbmcplugin.setContent(plugin_handle, "files")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_NONE)


def _tmdb_tv_scope_heading(sk):
    return "Anime" if sk == "anime" else _t("Series", "TV Shows")


def _trakt_common_movie_kwargs(
    plugin_handle,
    trakt_public_get,
    default_list_art,
    tmdb_id_details,
    trakt_parse_year,
    trakt_float_or_none,
    trakt_progress_translator,
    trakt_list_label1_with_year_rating,
    trakt_listitem_set_info_and_videotag,
    url_for_play,
    url_for_noop,
):
    return {
        "plugin_handle": plugin_handle,
        "trakt_public_get": trakt_public_get,
        "default_list_art": default_list_art,
        "tmdb_id_details": tmdb_id_details,
        "trakt_parse_year": trakt_parse_year,
        "trakt_float_or_none": trakt_float_or_none,
        "trakt_progress_translator": trakt_progress_translator,
        "trakt_list_label1_with_year_rating": trakt_list_label1_with_year_rating,
        "trakt_listitem_set_info_and_videotag": trakt_listitem_set_info_and_videotag,
        "url_for_play": url_for_play,
        "url_for_noop": url_for_noop,
    }


def _trakt_common_show_kwargs(
    plugin_handle,
    trakt_public_get,
    default_list_art,
    tmdb_id_details,
    trakt_parse_year,
    trakt_float_or_none,
    trakt_progress_translator,
    trakt_list_label1_with_year_rating,
    trakt_listitem_set_info_and_videotag,
    url_for_show_seasons,
    url_for_noop,
):
    return {
        "plugin_handle": plugin_handle,
        "trakt_public_get": trakt_public_get,
        "default_list_art": default_list_art,
        "tmdb_id_details": tmdb_id_details,
        "trakt_parse_year": trakt_parse_year,
        "trakt_float_or_none": trakt_float_or_none,
        "trakt_progress_translator": trakt_progress_translator,
        "trakt_list_label1_with_year_rating": trakt_list_label1_with_year_rating,
        "trakt_listitem_set_info_and_videotag": trakt_listitem_set_info_and_videotag,
        "url_for_show_seasons": url_for_show_seasons,
        "url_for_noop": url_for_noop,
    }


def _tmdb_discover_base_kwargs(
    plugin_handle,
    tmdb_enabled,
    tmdb_api_key,
    json_get,
    metadata_timeout,
    trakt_public_get,
    default_list_art,
    tmdb_id_details,
    trakt_list_label1_with_year_rating,
    trakt_listitem_set_info_and_videotag,
    url_for_noop,
):
    return {
        "plugin_handle": plugin_handle,
        "tmdb_enabled": tmdb_enabled,
        "tmdb_api_key": tmdb_api_key,
        "json_get": json_get,
        "metadata_timeout": metadata_timeout,
        "trakt_public_get": trakt_public_get,
        "default_list_art": default_list_art,
        "tmdb_id_details": tmdb_id_details,
        "trakt_list_label1_with_year_rating": trakt_list_label1_with_year_rating,
        "trakt_listitem_set_info_and_videotag": trakt_listitem_set_info_and_videotag,
        "url_for_noop": url_for_noop,
    }


def run_browse_trakt_years_menu(
    *, plugin_handle, scope, default_list_art, url_for_year
):
    sk = _scope_kind(scope)
    if not sk:
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    label = _scope_section_label(sk)
    _begin_browse_menu(
        plugin_handle,
        _t(
            "Kraken - {} - Trakt por año",
            "Kraken - {} - Trakt by year",
        ).format(label),
    )
    base_art = default_list_art()
    y0 = datetime.datetime.now().year
    y_min = _min_year_for_scope(sk)
    directory = []
    for y in range(y0, y_min - 1, -1):
        li = xbmcgui.ListItem(
            label=str(y),
            label2=_t("Popular en Trakt · {}", "Popular on Trakt · {}").format(y),
        )
        apply_video_info(
            li,
            {
                "title": str(y),
                "plot": _t(
                    "Películas o series populares filtradas por año en Trakt.",
                    "Popular movies or TV shows filtered by year on Trakt.",
                ),
            },
        )
        li.setArt(base_art)
        directory.append((url_for_year(y), li, True))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)


def run_browse_trakt_genres_menu(
    *, plugin_handle, scope, default_list_art, url_for_genre
):
    sk = _scope_kind(scope)
    if not sk:
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    label = _scope_section_label(sk)
    _begin_browse_menu(
        plugin_handle,
        _t(
            "Kraken - {} - Trakt por género",
            "Kraken - {} - Trakt by genre",
        ).format(label),
    )
    base_art = default_list_art()
    directory = []
    for slug in TRAKT_GENRE_SLUGS:
        if sk == "anime" and slug == "anime":
            continue
        glabel = _trakt_genre_menu_label(slug)
        li = xbmcgui.ListItem(
            label=glabel,
            label2=_t("slug: {}", "slug: {}").format(slug),
        )
        plot = _t(
            "Listado popular Trakt con filtro de género.",
            "Popular Trakt list filtered by genre.",
        )
        if sk == "anime":
            plot += _t(
                " Solo títulos que Trakt marque también como anime.",
                " Only titles that Trakt also marks as anime.",
            )
        apply_video_info(li, {"title": glabel, "plot": plot})
        li.setArt(base_art)
        directory.append((url_for_genre(slug), li, True))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)


def run_browse_tmdb_years_menu(*, plugin_handle, scope, default_list_art, url_for_year):
    sk = _scope_kind(scope)
    if not sk:
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    label = _scope_section_label(sk)
    _begin_browse_menu(
        plugin_handle,
        _t(
            "Kraken - {} - TMDb por año",
            "Kraken - {} - TMDb by year",
        ).format(label),
    )
    base_art = default_list_art()
    y0 = datetime.datetime.now().year
    y_min = _min_year_for_scope(sk)
    directory = []
    for y in range(y0, y_min - 1, -1):
        li = xbmcgui.ListItem(
            label=str(y),
            label2=_t("TMDb discover · {}", "TMDb discover · {}").format(y),
        )
        apply_video_info(
            li,
            {
                "title": str(y),
                "plot": _t(
                    "Orden por popularidad en TMDb para ese año.",
                    "Sorted by popularity on TMDb for that year.",
                ),
            },
        )
        li.setArt(base_art)
        directory.append((url_for_year(y), li, True))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)


def run_browse_tmdb_genres_menu(
    *, plugin_handle, scope, default_list_art, url_for_genre
):
    sk = _scope_kind(scope)
    if not sk:
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    label = _scope_section_label(sk)
    _begin_browse_menu(
        plugin_handle,
        _t(
            "Kraken - {} - TMDb por género",
            "Kraken - {} - TMDb by genre",
        ).format(label),
    )
    base_art = default_list_art()
    pairs = TMDB_MOVIE_GENRES if sk == "movie" else TMDB_TV_GENRES
    directory = []
    for (gid,) in pairs:
        glabel = (
            _tmdb_movie_genre_label(gid)
            if sk == "movie"
            else _tmdb_tv_genre_label(gid)
        )
        li = xbmcgui.ListItem(
            label=glabel,
            label2=_t("ID {}", "ID {}").format(gid),
        )
        plot = _t(
            "Discover TMDb (AND de géneros en anime: Animación + elegido).",
            "TMDb discover (AND genres for anime: Animation + selected).",
        )
        if sk != "anime":
            plot = _t("Discover TMDb por género.", "TMDb discover by genre.")
        apply_video_info(li, {"title": glabel, "plot": plot})
        li.setArt(base_art)
        directory.append((url_for_genre(gid), li, True))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)


def run_browse_tmdb_platforms_menu(
    *, plugin_handle, scope, default_list_art, url_for_platform
):
    sk = _scope_kind(scope)
    if not sk:
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    label = _scope_section_label(sk)
    _begin_browse_menu(
        plugin_handle,
        _t(
            "Kraken - {} - TMDb por plataforma",
            "Kraken - {} - TMDb by platform",
        ).format(label),
    )
    base_art = default_list_art()
    directory = []
    for pid, plabel in TMDB_PLATFORM_CHOICES:
        li = xbmcgui.ListItem(
            label=plabel,
            label2=_t("ID proveedor {}", "Provider ID {}").format(pid),
        )
        apply_video_info(
            li,
            {
                "title": plabel,
                "plot": _t(
                    "Discover TMDb filtrado por plataforma de streaming.",
                    "TMDb discover filtered by streaming platform.",
                ),
            },
        )
        li.setArt(base_art)
        directory.append((url_for_platform(pid), li, True))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)


def run_browse_trakt_year_list(
    *,
    plugin_handle,
    scope,
    year_raw,
    trakt_public_get,
    default_list_art,
    tmdb_id_details,
    trakt_parse_year,
    trakt_float_or_none,
    trakt_progress_translator,
    trakt_list_label1_with_year_rating,
    trakt_listitem_set_info_and_videotag,
    url_for_play,
    url_for_show_seasons,
    url_for_noop,
):
    sk = _scope_kind(scope)
    y = _parse_year(year_raw)
    if sk not in ("movie", "series", "anime") or y is None:
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    ys = str(y)
    if sk == "movie":
        run_trakt_filtered_movie_list(
            years=ys,
            genres_slug=None,
            category_title=_t(
                "Kraken - Películas - Trakt · año {}",
                "Kraken - Movies - Trakt · year {}",
            ).format(ys),
            **_trakt_common_movie_kwargs(
                plugin_handle,
                trakt_public_get,
                default_list_art,
                tmdb_id_details,
                trakt_parse_year,
                trakt_float_or_none,
                trakt_progress_translator,
                trakt_list_label1_with_year_rating,
                trakt_listitem_set_info_and_videotag,
                url_for_play,
                url_for_noop,
            ),
        )
        return
    if sk == "anime":
        run_trakt_filtered_show_list(
            years=ys,
            genres_slug="anime",
            require_genre_lc=None,
            category_title=_t(
                "Kraken - Anime - Trakt · año {} (anime)",
                "Kraken - Anime - Trakt · year {} (anime)",
            ).format(ys),
            **_trakt_common_show_kwargs(
                plugin_handle,
                trakt_public_get,
                default_list_art,
                tmdb_id_details,
                trakt_parse_year,
                trakt_float_or_none,
                trakt_progress_translator,
                trakt_list_label1_with_year_rating,
                trakt_listitem_set_info_and_videotag,
                url_for_show_seasons,
                url_for_noop,
            ),
        )
        return
    run_trakt_filtered_show_list(
        years=ys,
        genres_slug=None,
        require_genre_lc=None,
        category_title=_t(
            "Kraken - Series - Trakt · año {}",
            "Kraken - TV Shows - Trakt · year {}",
        ).format(ys),
        **_trakt_common_show_kwargs(
            plugin_handle,
            trakt_public_get,
            default_list_art,
            tmdb_id_details,
            trakt_parse_year,
            trakt_float_or_none,
            trakt_progress_translator,
            trakt_list_label1_with_year_rating,
            trakt_listitem_set_info_and_videotag,
            url_for_show_seasons,
            url_for_noop,
        ),
    )


def run_browse_trakt_genre_list(
    *,
    plugin_handle,
    scope,
    slug_raw,
    trakt_public_get,
    default_list_art,
    tmdb_id_details,
    trakt_parse_year,
    trakt_float_or_none,
    trakt_progress_translator,
    trakt_list_label1_with_year_rating,
    trakt_listitem_set_info_and_videotag,
    url_for_play,
    url_for_show_seasons,
    url_for_noop,
):
    sk = _scope_kind(scope)
    slug = (slug_raw or "").strip().lower()
    if sk not in ("movie", "series", "anime") or not _slug_ok(slug):
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    if sk == "movie":
        run_trakt_filtered_movie_list(
            years=None,
            genres_slug=slug,
            category_title=_t(
                "Kraken - Películas - Trakt · {}",
                "Kraken - Movies - Trakt · {}",
            ).format(slug),
            **_trakt_common_movie_kwargs(
                plugin_handle,
                trakt_public_get,
                default_list_art,
                tmdb_id_details,
                trakt_parse_year,
                trakt_float_or_none,
                trakt_progress_translator,
                trakt_list_label1_with_year_rating,
                trakt_listitem_set_info_and_videotag,
                url_for_play,
                url_for_noop,
            ),
        )
        return
    if sk == "anime":
        run_trakt_filtered_show_list(
            years=None,
            genres_slug=slug,
            require_genre_lc="anime",
            category_title=_t(
                "Kraken - Anime - Trakt · {} + anime",
                "Kraken - Anime - Trakt · {} + anime",
            ).format(slug),
            **_trakt_common_show_kwargs(
                plugin_handle,
                trakt_public_get,
                default_list_art,
                tmdb_id_details,
                trakt_parse_year,
                trakt_float_or_none,
                trakt_progress_translator,
                trakt_list_label1_with_year_rating,
                trakt_listitem_set_info_and_videotag,
                url_for_show_seasons,
                url_for_noop,
            ),
        )
        return
    run_trakt_filtered_show_list(
        years=None,
        genres_slug=slug,
        require_genre_lc=None,
        category_title=_t(
            "Kraken - Series - Trakt · {}",
            "Kraken - TV Shows - Trakt · {}",
        ).format(slug),
        **_trakt_common_show_kwargs(
            plugin_handle,
            trakt_public_get,
            default_list_art,
            tmdb_id_details,
            trakt_parse_year,
            trakt_float_or_none,
            trakt_progress_translator,
            trakt_list_label1_with_year_rating,
            trakt_listitem_set_info_and_videotag,
            url_for_show_seasons,
            url_for_noop,
        ),
    )


def run_browse_tmdb_year_list(
    *,
    plugin_handle,
    scope,
    year_raw,
    tmdb_enabled,
    tmdb_api_key,
    json_get,
    metadata_timeout,
    trakt_public_get,
    default_list_art,
    tmdb_id_details,
    trakt_list_label1_with_year_rating,
    trakt_listitem_set_info_and_videotag,
    url_for_play,
    url_for_show_seasons,
    url_for_noop,
):
    sk = _scope_kind(scope)
    y = _parse_year(year_raw)
    if sk not in ("movie", "series", "anime") or y is None:
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    if sk == "movie":
        run_tmdb_discover_movies_list(
            year=y,
            genre_id=None,
            watch_provider_id=None,
            watch_region="ES",
            category_title=_t(
                "Kraken - Películas - TMDb · año {}",
                "Kraken - Movies - TMDb · year {}",
            ).format(y),
            **_tmdb_discover_base_kwargs(
                plugin_handle,
                tmdb_enabled,
                tmdb_api_key,
                json_get,
                metadata_timeout,
                trakt_public_get,
                default_list_art,
                tmdb_id_details,
                trakt_list_label1_with_year_rating,
                trakt_listitem_set_info_and_videotag,
                url_for_noop,
            ),
            url_for_play=url_for_play,
        )
        return
    extra = 16 if sk == "anime" else None
    run_tmdb_discover_tv_list(
        year=y,
        genre_id=None,
        with_genres_extra=extra,
        watch_provider_id=None,
        watch_region="ES",
        category_title=_t(
            "Kraken - {} - TMDb · año {}",
            "Kraken - {} - TMDb · year {}",
        ).format(_tmdb_tv_scope_heading(sk), y),
        **_tmdb_discover_base_kwargs(
            plugin_handle,
            tmdb_enabled,
            tmdb_api_key,
            json_get,
            metadata_timeout,
            trakt_public_get,
            default_list_art,
            tmdb_id_details,
            trakt_list_label1_with_year_rating,
            trakt_listitem_set_info_and_videotag,
            url_for_noop,
        ),
        url_for_show_seasons=url_for_show_seasons,
    )


def run_browse_tmdb_genre_list(
    *,
    plugin_handle,
    scope,
    gid_raw,
    tmdb_enabled,
    tmdb_api_key,
    json_get,
    metadata_timeout,
    trakt_public_get,
    default_list_art,
    tmdb_id_details,
    trakt_list_label1_with_year_rating,
    trakt_listitem_set_info_and_videotag,
    url_for_play,
    url_for_show_seasons,
    url_for_noop,
):
    sk = _scope_kind(scope)
    gid = _parse_genre_id(gid_raw)
    if sk not in ("movie", "series", "anime") or gid is None:
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    if sk == "movie":
        run_tmdb_discover_movies_list(
            year=None,
            genre_id=gid,
            watch_provider_id=None,
            watch_region="ES",
            category_title=_t(
                "Kraken - Películas - TMDb · género {}",
                "Kraken - Movies - TMDb · genre {}",
            ).format(gid),
            **_tmdb_discover_base_kwargs(
                plugin_handle,
                tmdb_enabled,
                tmdb_api_key,
                json_get,
                metadata_timeout,
                trakt_public_get,
                default_list_art,
                tmdb_id_details,
                trakt_list_label1_with_year_rating,
                trakt_listitem_set_info_and_videotag,
                url_for_noop,
            ),
            url_for_play=url_for_play,
        )
        return
    extra = 16 if sk == "anime" else None
    run_tmdb_discover_tv_list(
        year=None,
        genre_id=gid,
        with_genres_extra=extra,
        watch_provider_id=None,
        watch_region="ES",
        category_title=_t(
            "Kraken - {} - TMDb · género {}",
            "Kraken - {} - TMDb · genre {}",
        ).format(_tmdb_tv_scope_heading(sk), gid),
        **_tmdb_discover_base_kwargs(
            plugin_handle,
            tmdb_enabled,
            tmdb_api_key,
            json_get,
            metadata_timeout,
            trakt_public_get,
            default_list_art,
            tmdb_id_details,
            trakt_list_label1_with_year_rating,
            trakt_listitem_set_info_and_videotag,
            url_for_noop,
        ),
        url_for_show_seasons=url_for_show_seasons,
    )


def run_browse_tmdb_platform_list(
    *,
    plugin_handle,
    scope,
    provider_id_raw,
    tmdb_enabled,
    tmdb_api_key,
    json_get,
    metadata_timeout,
    trakt_public_get,
    default_list_art,
    tmdb_id_details,
    trakt_list_label1_with_year_rating,
    trakt_listitem_set_info_and_videotag,
    url_for_play,
    url_for_show_seasons,
    url_for_noop,
):
    sk = _scope_kind(scope)
    pid = _parse_genre_id(provider_id_raw)
    if sk not in ("movie", "series", "anime") or pid is None:
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    pname = _tmdb_platform_label(pid)
    if sk == "movie":
        run_tmdb_discover_movies_list(
            year=None,
            genre_id=None,
            watch_provider_id=pid,
            watch_region="ES",
            category_title=_t(
                "Kraken - Películas - TMDb · {}",
                "Kraken - Movies - TMDb · {}",
            ).format(pname),
            **_tmdb_discover_base_kwargs(
                plugin_handle,
                tmdb_enabled,
                tmdb_api_key,
                json_get,
                metadata_timeout,
                trakt_public_get,
                default_list_art,
                tmdb_id_details,
                trakt_list_label1_with_year_rating,
                trakt_listitem_set_info_and_videotag,
                url_for_noop,
            ),
            url_for_play=url_for_play,
        )
        return
    extra = 16 if sk == "anime" else None
    run_tmdb_discover_tv_list(
        year=None,
        genre_id=None,
        with_genres_extra=extra,
        watch_provider_id=pid,
        watch_region="ES",
        category_title=_t(
            "Kraken - {} - TMDb · {}",
            "Kraken - {} - TMDb · {}",
        ).format(_tmdb_tv_scope_heading(sk), pname),
        **_tmdb_discover_base_kwargs(
            plugin_handle,
            tmdb_enabled,
            tmdb_api_key,
            json_get,
            metadata_timeout,
            trakt_public_get,
            default_list_art,
            tmdb_id_details,
            trakt_list_label1_with_year_rating,
            trakt_listitem_set_info_and_videotag,
            url_for_noop,
        ),
        url_for_show_seasons=url_for_show_seasons,
    )
