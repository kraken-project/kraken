"""Fábricas _t reutilizables para rutas con mapas FR/IT/DE opcionales."""

from resources.lib.ui.ui_helpers import _t_mapped


def make_mapped_t(phrase_map):
    """
    Devuelve una función _t(es, en, fr=None, it=None, de=None) que delega en
    ui_helpers._t_mapped con el mapa dado.

    phrase_map: dict con claves (str_es, str_en) y valores (fr, it, de).
    """

    def _t(es_text, en_text, fr_text=None, it_text=None, de_text=None):
        return _t_mapped(phrase_map, es_text, en_text, fr_text, it_text, de_text)

    return _t
