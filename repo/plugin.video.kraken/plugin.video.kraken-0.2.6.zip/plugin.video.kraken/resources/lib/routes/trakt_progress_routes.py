import random
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import quote

import xbmcgui
import xbmcplugin

from resources.lib.core.metadata_tmdb import prefetch_tmdb_details_parallel
from resources.lib.ui.context_menu import (
    add_movie_download_context,
    add_show_download_context,
)
from resources.lib.routes.i18n_routes import make_mapped_t


_TRAKT_PROGRESS_PHRASE_MAP = {
    ("Kraken · Seguimiento Trakt", "Kraken · Trakt Progress"): (
        "Kraken · Suivi Trakt",
        "Kraken · Progresso Trakt",
        "Kraken · Trakt-Fortschritt",
    ),
    ("Ver temporadas y lista de capítulos", "View seasons and episodes list"): (
        "Voir saisons et liste d'épisodes",
        "Vedi stagioni e lista episodi",
        "Staffeln und Episodenliste anzeigen",
    ),
    ("No hay series en seguimiento", "No TV shows in progress"): (
        "Aucune série en cours",
        "Nessuna serie TV in corso",
        "Keine Serien in Bearbeitung",
    ),
    ("Activa Trakt en Ajustes.", "Enable Trakt in Settings."): (
        "Active Trakt dans les paramètres.",
        "Attiva Trakt nelle impostazioni.",
        "Aktiviere Trakt in den Einstellungen.",
    ),
    ("Autoriza tu cuenta para ver progreso.", "Authorize your account to view progress."): (
        "Autorise ton compte pour voir la progression.",
        "Autorizza il tuo account per vedere i progressi.",
        "Autorisiere dein Konto, um den Fortschritt zu sehen.",
    ),
    ("No se pudo cargar series en seguimiento.", "Could not load TV shows in progress."): (
        "Impossible de charger les séries en cours.",
        "Impossibile caricare le serie TV in corso.",
        "Serien in Bearbeitung konnten nicht geladen werden.",
    ),
    ("Serie", "TV Show"): ("Série", "Serie TV", "Serie"),
    ("N/D", "N/A"): ("N/D", "N/D", "k.A."),
    ("Visto: {}", "Watched: {}"): ("Vu : {}", "Visto: {}", "Gesehen: {}"),
    ("No se pudo cargar películas sin finalizar.", "Could not load unfinished movies."): (
        "Impossible de charger les films non terminés.",
        "Impossibile caricare i film non completati.",
        "Unfertige Filme konnten nicht geladen werden.",
    ),
    ("Kraken - Trakt - Películas sin finalizar", "Kraken - Trakt - Unfinished movies"): (
        "Kraken - Trakt - Films non terminés",
        "Kraken - Trakt - Film non completati",
        "Kraken - Trakt - Unfertige Filme",
    ),
    ("Película", "Movie"): ("Film", "Film", "Film"),
    ("Año", "Year"): ("Année", "Anno", "Jahr"),
    ("No hay películas sin finalizar", "No unfinished movies"): (
        "Aucun film non terminé",
        "Nessun film non completato",
        "Keine unfertigen Filme",
    ),
    ("No se pudo cargar historial de películas.", "Could not load movie history."): (
        "Impossible de charger l'historique des films.",
        "Impossibile caricare la cronologia film.",
        "Filmverlauf konnte nicht geladen werden.",
    ),
    ("Kraken - Trakt - Películas relacionadas", "Kraken - Trakt - Related movies"): (
        "Kraken - Trakt - Films liés",
        "Kraken - Trakt - Film correlati",
        "Kraken - Trakt - Ähnliche Filme",
    ),
    ("Sin recomendaciones relacionadas de películas", "No related movie recommendations"): (
        "Aucune recommandation de films liés",
        "Nessun consiglio di film correlati",
        "Keine ähnlichen Filmempfehlungen",
    ),
    ("No se pudo cargar historial de series.", "Could not load TV shows history."): (
        "Impossible de charger l'historique des séries.",
        "Impossibile caricare la cronologia serie TV.",
        "Serienverlauf konnte nicht geladen werden.",
    ),
    ("Autoriza tu cuenta para elegir película aleatoria.", "Authorize your account to choose a random movie."): (
        "Autorise ton compte pour choisir un film aléatoire.",
        "Autorizza il tuo account per scegliere un film casuale.",
        "Autorisiere dein Konto, um einen Zufallsfilm zu wählen.",
    ),
    ("Sin película aleatoria disponible", "No random movie available"): (
        "Aucun film aléatoire disponible",
        "Nessun film casuale disponibile",
        "Kein Zufallsfilm verfügbar",
    ),
    ("Sin serie aleatoria disponible", "No random TV show available"): (
        "Aucune série aléatoire disponible",
        "Nessuna serie TV casuale disponible",
        "Keine Zufallsserie verfügbar",
    ),
    ("Abrir serie aleatoria", "Open random TV show"): (
        "Ouvrir une série aléatoire",
        "Apri serie TV casuale",
        "Zufallsserie öffnen",
    ),
    ("Autoriza tu cuenta para elegir serie aleatoria.", "Authorize your account to choose a random TV show."): (
        "Autorise ton compte pour choisir une série aléatoire.",
        "Autorizza il tuo account per scegliere una serie TV casuale.",
        "Autorisiere dein Konto, um eine Zufallsserie zu wählen.",
    ),
}


_t = make_mapped_t(_TRAKT_PROGRESS_PHRASE_MAP)


def _https_trakt_media_url(maybe):
    u = (maybe or "").strip()
    if not u:
        return ""
    if u.startswith("http://") or u.startswith("https://"):
        return u
    return "https://{}".format(u.lstrip("/"))


def _first_trakt_image_url(img_field):
    """Trakt images: str, list[str], list[dict full/medium/thumb], dict."""
    if not img_field:
        return ""
    if isinstance(img_field, str):
        return _https_trakt_media_url(img_field)
    if isinstance(img_field, list) and img_field:
        first = img_field[0]
        if isinstance(first, dict):
            u = first.get("full") or first.get("medium") or first.get("thumb") or ""
            return _https_trakt_media_url(u)
        return _https_trakt_media_url(first)
    if isinstance(img_field, dict):
        u = (
            img_field.get("full")
            or img_field.get("medium")
            or img_field.get("thumb")
            or ""
        )
        return _https_trakt_media_url(u)
    return ""


def _trakt_show_poster_fanart(show):
    """Arte del objeto show en sync/playback?extended=full (evita TMDb si basta)."""
    if not isinstance(show, dict):
        return "", ""
    imgs = show.get("images") or {}
    if not isinstance(imgs, dict):
        return "", ""
    return (
        _first_trakt_image_url(imgs.get("poster")),
        _first_trakt_image_url(imgs.get("fanart")),
    )


def _tmdb_ids_needing_fetch_for_series_rows(
    rows_unique, trakt_parse_year, trakt_float_or_none
):
    """TMDb solo si falta arte o año/nota en el objeto show de Trakt (menos red)."""
    out = []
    seen = set()
    for row in rows_unique or []:
        show = (row or {}).get("show") or {}
        ids = (show.get("ids") or {}) if isinstance(show, dict) else {}
        tid = ids.get("tmdb")
        if not tid:
            continue
        try:
            n = int(str(tid).strip())
        except (TypeError, ValueError):
            continue
        if n in seen:
            continue
        tr_p, tr_f = _trakt_show_poster_fanart(show)
        sy, shy = trakt_parse_year(show.get("year"))
        sr = trakt_float_or_none(show.get("rating"))
        need = (
            (not tr_p)
            or (not tr_f)
            or (not shy or sy is None)
            or (sr is None or sr <= 0.0)
        )
        if need:
            seen.add(n)
            out.append(n)
    return out


def _unique_show_trakt_ids_from_series_rows(rows_unique):
    out = []
    seen = set()
    for row in rows_unique or []:
        show = (row or {}).get("show") or {}
        ids = (show.get("ids") or {}) if isinstance(show, dict) else {}
        sid = str(ids.get("trakt") or "").strip()
        if sid and sid not in seen:
            seen.add(sid)
            out.append(sid)
    return out


def _prefetch_tmdb_series_map(tmdb_ids, tmdb_id_details, max_workers=6):
    """Varias peticiones TMDb en paralelo (listas Trakt con muchas series)."""
    inner = prefetch_tmdb_details_parallel(
        tmdb_ids,
        lambda nid: tmdb_id_details(nid, media_type="series") or {},
        max_workers=max_workers,
    )
    return {(nid, "series"): dict(inner.get(nid) or {}) for nid in inner}


def _prefetch_show_translations_map(sids, provider, lang, max_workers=5):
    """Varias /translations/{lang} de Trakt en paralelo."""
    cache = {}
    if not sids or not provider or not lang:
        return cache
    workers = min(max(1, int(max_workers)), max(1, len(sids)))

    def fetch(sid):
        try:
            t_tr, o_tr = provider._translation_title_and_overview("show", sid, lang)
            return sid, {
                "title": str(t_tr or "").strip(),
                "plot": str(o_tr or "").strip(),
            }
        except Exception:
            return sid, {"title": "", "plot": ""}

    try:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futures = {ex.submit(fetch, sid): sid for sid in sids}
            for fut in as_completed(futures):
                try:
                    sid, data = fut.result()
                    cache[sid] = data if isinstance(data, dict) else {}
                except Exception:
                    pass
    except Exception:
        for sid in sids:
            try:
                t_tr, o_tr = provider._translation_title_and_overview("show", sid, lang)
                cache[sid] = {
                    "title": str(t_tr or "").strip(),
                    "plot": str(o_tr or "").strip(),
                }
            except Exception:
                cache[sid] = {"title": "", "plot": ""}
    return cache


def _trakt_movie_poster_fanart(movie):
    if not isinstance(movie, dict):
        return "", ""
    imgs = movie.get("images") or {}
    if not isinstance(imgs, dict):
        return "", ""
    return (
        _first_trakt_image_url(imgs.get("poster")),
        _first_trakt_image_url(imgs.get("fanart")),
    )


def _unique_movie_trakt_ids_from_progress_rows(rows):
    out = []
    seen = set()
    for row in rows or []:
        movie = (row or {}).get("movie") or {}
        ids = (movie.get("ids") or {}) if isinstance(movie, dict) else {}
        tid = str(ids.get("trakt") or "").strip()
        if tid and tid not in seen:
            seen.add(tid)
            out.append(tid)
    return out


def _prefetch_trakt_movie_full_map(trakt_ids, trakt_authed_get, max_workers=5):
    out = {}
    if not trakt_ids:
        return out
    workers = min(max(1, int(max_workers)), max(1, len(trakt_ids)))

    def fetch(tid):
        try:
            return tid, trakt_authed_get(
                f"https://api.trakt.tv/movies/{quote(tid)}?extended=full"
            ) or {}
        except Exception:
            return tid, {}

    try:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(fetch, tid): tid for tid in trakt_ids}
            for fut in as_completed(futs):
                try:
                    tid, data = fut.result()
                    out[tid] = data if isinstance(data, dict) else {}
                except Exception:
                    pass
    except Exception:
        for tid in trakt_ids:
            try:
                out[tid] = (
                    trakt_authed_get(
                        f"https://api.trakt.tv/movies/{quote(tid)}?extended=full"
                    )
                    or {}
                )
            except Exception:
                out[tid] = {}
    return out


def _prefetch_movie_translations_map(mids, provider, lang, max_workers=5):
    cache = {}
    if not mids or not provider or not lang:
        return cache
    workers = min(max(1, int(max_workers)), max(1, len(mids)))

    def fetch(mid):
        try:
            t_tr, o_tr = provider._translation_title_and_overview("movie", mid, lang)
            return mid, {
                "title": str(t_tr or "").strip(),
                "plot": str(o_tr or "").strip(),
            }
        except Exception:
            return mid, {"title": "", "plot": ""}

    try:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(fetch, mid): mid for mid in mids}
            for fut in as_completed(futs):
                try:
                    mid, data = fut.result()
                    cache[mid] = data if isinstance(data, dict) else {}
                except Exception:
                    pass
    except Exception:
        for mid in mids:
            try:
                t_tr, o_tr = provider._translation_title_and_overview(
                    "movie", mid, lang
                )
                cache[mid] = {
                    "title": str(t_tr or "").strip(),
                    "plot": str(o_tr or "").strip(),
                }
            except Exception:
                cache[mid] = {"title": "", "plot": ""}
    return cache


def _prefetch_tmdb_movie_map(tmdb_ids, tmdb_id_details, max_workers=6):
    inner = prefetch_tmdb_details_parallel(
        tmdb_ids,
        lambda nid: tmdb_id_details(nid, media_type="movie") or {},
        max_workers=max_workers,
    )
    return {(nid, "movie"): dict(inner.get(nid) or {}) for nid in inner}


def _tmdb_movie_need_ids_from_progress_rows(
    rows, movie_full_cache, trakt_year_from_movie_dict, trakt_float_or_none
):
    out = []
    seen = set()
    for row in rows or []:
        movie = (row or {}).get("movie") or {}
        ids = (movie.get("ids") or {}) if isinstance(movie, dict) else {}
        trakt_id = str(ids.get("trakt") or "").strip()
        if not trakt_id:
            continue
        full = movie_full_cache.get(trakt_id) or {}
        ids2 = dict(ids)
        ids_full = (full.get("ids") or {}) if isinstance(full, dict) else {}
        if isinstance(ids_full, dict):
            if not ids2.get("tmdb") and ids_full.get("tmdb"):
                ids2["tmdb"] = ids_full.get("tmdb")
        tid = ids2.get("tmdb")
        if not tid:
            continue
        try:
            n = int(str(tid).strip())
        except (TypeError, ValueError):
            continue
        if n in seen:
            continue
        art_src = full if isinstance(full, dict) and full else movie
        tr_p, tr_f = _trakt_movie_poster_fanart(art_src)
        year, has_year = trakt_year_from_movie_dict(full or {})
        if not has_year:
            y2, hy2 = trakt_year_from_movie_dict(movie or {})
            if hy2:
                year, has_year = y2, True
        rating = trakt_float_or_none((full or {}).get("rating"))
        if rating is None or rating <= 0.0:
            rating = trakt_float_or_none((movie or {}).get("rating"))
        need = (
            (not tr_p)
            or (not tr_f)
            or (not has_year or year is None)
            or (rating is None or rating <= 0.0)
        )
        if need:
            seen.add(n)
            out.append(n)
    return out


def _unique_trakt_ids_from_movie_dicts(movies):
    out = []
    seen = set()
    for movie in movies or []:
        if not isinstance(movie, dict):
            continue
        ids = movie.get("ids") or {}
        rid = str(ids.get("trakt") or "").strip()
        if rid and rid not in seen:
            seen.add(rid)
            out.append(rid)
    return out


def _tmdb_ids_needing_fetch_for_movie_dicts(
    movies, trakt_parse_year, trakt_float_or_none
):
    out = []
    seen = set()
    for movie in movies or []:
        if not isinstance(movie, dict):
            continue
        ids = movie.get("ids") or {}
        tid = ids.get("tmdb")
        if not tid:
            continue
        try:
            n = int(str(tid).strip())
        except (TypeError, ValueError):
            continue
        if n in seen:
            continue
        tr_p, tr_f = _trakt_movie_poster_fanart(movie)
        year, has_year = trakt_parse_year(movie.get("year"))
        rating = trakt_float_or_none(movie.get("rating"))
        need = (
            (not tr_p)
            or (not tr_f)
            or (not has_year or year is None)
            or (rating is None or rating <= 0.0)
        )
        if need:
            seen.add(n)
            out.append(n)
    return out


def _unique_trakt_ids_from_show_dicts(shows):
    out = []
    seen = set()
    for show in shows or []:
        if not isinstance(show, dict):
            continue
        ids = show.get("ids") or {}
        rid = str(ids.get("trakt") or "").strip()
        if rid and rid not in seen:
            seen.add(rid)
            out.append(rid)
    return out


def _tmdb_ids_needing_fetch_for_show_dicts(
    shows, trakt_parse_year, trakt_float_or_none
):
    out = []
    seen = set()
    for show in shows or []:
        if not isinstance(show, dict):
            continue
        ids = show.get("ids") or {}
        tid = ids.get("tmdb")
        if not tid:
            continue
        try:
            n = int(str(tid).strip())
        except (TypeError, ValueError):
            continue
        if n in seen:
            continue
        tr_p, tr_f = _trakt_show_poster_fanart(show)
        sy, shy = trakt_parse_year(show.get("year"))
        sr = trakt_float_or_none(show.get("rating"))
        need = (
            (not tr_p)
            or (not tr_f)
            or (not shy or sy is None)
            or (sr is None or sr <= 0.0)
        )
        if need:
            seen.add(n)
            out.append(n)
    return out


def _parallel_trakt_get_indexed(urls, trakt_get_fn, max_workers=4):
    """Varias URLs autenticadas/publicas con la misma firma trakt_get_fn(url)."""
    n = len(urls or [])
    if n == 0:
        return []
    out = [[] for _ in range(n)]
    if n == 1:
        try:
            r = trakt_get_fn(urls[0]) or []
            out[0] = r if isinstance(r, list) else []
        except Exception:
            pass
        return out
    workers = min(max(1, int(max_workers)), n)

    def job(ix):
        try:
            r = trakt_get_fn(urls[ix]) or []
            return ix, r if isinstance(r, list) else []
        except Exception:
            return ix, []

    try:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(job, i): i for i in range(n)}
            for fut in as_completed(futs):
                try:
                    ix, data = fut.result()
                    out[ix] = data
                except Exception:
                    pass
    except Exception:
        for i in range(n):
            try:
                r = trakt_get_fn(urls[i]) or []
                out[i] = r if isinstance(r, list) else []
            except Exception:
                out[i] = []
    return out


def _trakt_authed_get_all_pages(
    trakt_authed_get,
    *,
    base_url,
    page_size=100,
    max_pages=20,
):
    """
    Recorre páginas de endpoints de Trakt que pueden venir limitados por defecto.
    Evita perder filas en cuentas con mucho progreso acumulado.
    """
    items = []
    seen_blob = set()
    try:
        size = max(1, int(page_size))
    except (TypeError, ValueError):
        size = 100
    try:
        pages = max(1, int(max_pages))
    except (TypeError, ValueError):
        pages = 20

    for page in range(1, pages + 1):
        sep = "&" if "?" in base_url else "?"
        url = f"{base_url}{sep}limit={size}&page={page}"
        try:
            rows = trakt_authed_get(url) or []
        except Exception:
            rows = []
        if not isinstance(rows, list) or not rows:
            break
        before = len(items)
        for row in rows:
            try:
                # Deduplicado defensivo por contenido serializado.
                blob = str(row)
            except Exception:
                blob = ""
            if blob and blob in seen_blob:
                continue
            if blob:
                seen_blob.add(blob)
            items.append(row)
        # Si la página trae menos del límite, no hay más resultados.
        if len(rows) < size:
            break
        # Guardia extra: si no añadió nada nuevo, cortar bucle.
        if len(items) == before:
            break
    return items


def _show_is_anime(show, show_trakt_id, trakt_authed_get, cache):
    sid = str(show_trakt_id or "").strip()
    if not sid:
        return False
    if sid in cache:
        return bool(cache[sid])
    genres = []
    if isinstance(show, dict):
        genres = show.get("genres") or []
    gset = {str(x or "").strip().lower() for x in genres if str(x or "").strip()}
    if "anime" in gset:
        cache[sid] = True
        return True
    try:
        full = (
            trakt_authed_get(f"https://api.trakt.tv/shows/{quote(sid)}?extended=full")
            or {}
        )
    except Exception:
        full = {}
    genres_full = (full.get("genres") or []) if isinstance(full, dict) else []
    gfull = {str(x or "").strip().lower() for x in genres_full if str(x or "").strip()}
    is_anime = "anime" in gfull
    cache[sid] = is_anime
    return is_anime


def _trakt_row_activity_iso(row):
    """ISO Trakt (`paused_at` en playback o `watched_at` / `paused_at` en historial)."""
    return str((row or {}).get("paused_at") or (row or {}).get("watched_at") or "").strip()


def run_series_in_progress_choice(
    *,
    plugin_handle,
    show_trakt_id,
    season_str,
    episode_str,
    url_for_play_episode,
    url_for_show_seasons,
    default_list_art,
):
    """
    Submenú con dos filas: reproducir el episodio en progreso o abrir temporadas.
    Usa el listado del plugin (navegación nativa) en lugar de diálogo + builtins,
    que en muchas skins no actualizan bien el contenedor.
    """
    sid = str(show_trakt_id or "").strip()
    try:
        sn = int(str(season_str).strip())
        en = int(str(episode_str).strip())
    except (TypeError, ValueError):
        xbmcplugin.endOfDirectory(plugin_handle, succeeded=False)
        return
    if not sid or sn < 0 or en < 1:
        xbmcplugin.endOfDirectory(plugin_handle, succeeded=False)
        return
    play_u = url_for_play_episode(sid, sn, en)
    fold_u = url_for_show_seasons(sid)
    if not play_u or not fold_u:
        xbmcplugin.endOfDirectory(plugin_handle, succeeded=False)
        return

    xbmcplugin.setPluginCategory(
        plugin_handle,
        _t(
            "Kraken · Seguimiento Trakt",
            "Kraken · Trakt Progress",
            "Kraken · Suivi Trakt",
            "Kraken · Progresso Trakt",
            "Kraken · Trakt-Fortschritt",
        )
    )
    xbmcplugin.setContent(plugin_handle, "videos")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_UNSORTED)
    base_art = (
        default_list_art() if callable(default_list_art) else (default_list_art or {})
    )

    label_play = _t(
        f"Reproducir desde el capítulo guardado (T{sn} E{en})",
        f"Play from saved episode (S{sn} E{en})",
        f"Lire depuis l'épisode enregistré (S{sn} E{en})",
        f"Riproduci dall'episodio salvato (S{sn} E{en})",
        f"Ab gespeicherter Folge wiedergeben (S{sn} E{en})",
    )
    li_play = xbmcgui.ListItem(label=label_play)
    li_play.setArt(dict(base_art))
    li_play.setProperty("IsPlayable", "true")
    li_play.setInfo(
        "video",
        {
            "title": label_play,
            "tvshowtitle": label_play,
            "season": sn,
            "episode": en,
            "mediatype": "episode",
        },
    )

    label_fold = _t(
        "Ver temporadas y lista de capítulos",
        "View seasons and episodes list",
        "Voir saisons et liste d'épisodes",
        "Vedi stagioni e lista episodi",
        "Staffeln und Episodenliste anzeigen",
    )
    li_fold = xbmcgui.ListItem(label=label_fold)
    li_fold.setArt(dict(base_art))
    li_fold.setProperty("IsPlayable", "false")
    li_fold.setInfo(
        "video",
        {
            "title": label_fold,
            "tvshowtitle": label_fold,
            "mediatype": "tvshow",
        },
    )

    # Carpeta primero: temporadas y capítulos con metadatos; luego reproducir (buscar fuentes).
    xbmcplugin.addDirectoryItems(
        plugin_handle,
        [(fold_u, li_fold, True), (play_u, li_play, False)],
        2,
    )
    xbmcplugin.endOfDirectory(plugin_handle, True)


def run_series_in_progress(
    *,
    plugin_handle,
    get_bool_setting,
    trakt_is_ready,
    trakt_authed_get,
    trakt_progress_translator,
    default_list_art,
    trakt_parse_year,
    trakt_float_or_none,
    tmdb_id_details,
    progress_percent_text,
    trakt_list_label1_with_year_rating,
    trakt_title_with_year_rating_plain,
    url_for_in_progress_pick,
    url_for_noop,
    anime_only=False,
    category_title=None,
    empty_label=None,
):
    if category_title is None:
        category_title = _t(
            "Kraken - Trakt - Series en seguimiento",
            "Kraken - Trakt - TV shows in progress",
            "Kraken - Trakt - Series en cours",
            "Kraken - Trakt - Serie in corso",
            "Kraken - Trakt - Serien in Bearbeitung",
        )
    if empty_label is None:
        empty_label = _t(
            "No hay series en seguimiento",
            "No TV shows in progress",
            "Aucune série en cours",
            "Nessuna serie TV in corso",
            "Keine Serien in Bearbeitung",
        )
    if not get_bool_setting("trakt_enabled"):
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t(
                "Activa Trakt en Ajustes.",
                "Enable Trakt in Settings.",
                "Active Trakt dans les paramètres.",
                "Attiva Trakt nelle impostazioni.",
                "Aktiviere Trakt in den Einstellungen.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    if not trakt_is_ready():
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t(
                "Autoriza tu cuenta para ver progreso.",
                "Authorize your account to view progress.",
                "Autorise ton compte pour voir la progression.",
                "Autorizza il tuo account per vedere i progressi.",
                "Autorisiere dein Konto, um den Fortschritt zu sehen.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    try:
        rows = _trakt_authed_get_all_pages(
            trakt_authed_get,
            base_url="https://api.trakt.tv/sync/playback/episodes?extended=full",
            page_size=100,
            max_pages=20,
        )
    except Exception:
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t(
                "No se pudo cargar series en seguimiento.",
                "Could not load TV shows in progress.",
                "Impossible de charger les séries en cours.",
                "Impossibile caricare le serie TV in corso.",
                "Serien in Bearbeitung konnten nicht geladen werden.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return

    provider, lang = trakt_progress_translator()

    xbmcplugin.setPluginCategory(plugin_handle, category_title)
    xbmcplugin.setContent(plugin_handle, "episodes")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_UNSORTED)
    base_art = default_list_art()
    directory = []
    anime_cache = {}

    # Agrupar por serie para mostrar una sola fila por show (no por episodio).
    # Si hay varias filas de la misma serie, elegimos la mas reciente por paused_at
    # y como desempate la de mayor progreso.
    rows_by_show = {}
    for row in rows or []:
        show = (row or {}).get("show") or {}
        ep = (row or {}).get("episode") or {}
        ids = (show.get("ids") or {}) if isinstance(show, dict) else {}
        show_trakt_id = str(ids.get("trakt") or "").strip()
        if not show_trakt_id:
            continue
        if anime_only and not _show_is_anime(
            show, show_trakt_id, trakt_authed_get, anime_cache
        ):
            continue
        season = int(ep.get("season") or 0)
        number = int(ep.get("number") or 0)
        if season < 0 or number < 1:
            continue
        prev = rows_by_show.get(show_trakt_id)
        if not prev:
            rows_by_show[show_trakt_id] = row
            continue
        prev_paused = _trakt_row_activity_iso(prev)
        cur_paused = _trakt_row_activity_iso(row)
        if cur_paused > prev_paused:
            rows_by_show[show_trakt_id] = row
            continue
        if cur_paused == prev_paused:
            prev_prog = float((prev or {}).get("progress") or 0.0)
            cur_prog = float((row or {}).get("progress") or 0.0)
            if cur_prog > prev_prog:
                rows_by_show[show_trakt_id] = row

    playback_show_ids = set(rows_by_show.keys())

    # Episodios terminados dejan de estar en /sync/playback pero siguen en historial.
    try:
        hist_rows = _trakt_authed_get_all_pages(
            trakt_authed_get,
            base_url="https://api.trakt.tv/sync/history/episodes?extended=full",
            page_size=100,
            max_pages=5,
        )
    except Exception:
        hist_rows = []

    for hrow in hist_rows or []:
        if str((hrow or {}).get("type") or "").strip().lower() != "episode":
            continue
        show = (hrow or {}).get("show") or {}
        ep = (hrow or {}).get("episode") or {}
        ids = (show.get("ids") or {}) if isinstance(show, dict) else {}
        show_trakt_id = str(ids.get("trakt") or "").strip()
        if not show_trakt_id or show_trakt_id in playback_show_ids:
            continue
        try:
            season = int(ep.get("season") or 0)
            number = int(ep.get("number") or 0)
        except (TypeError, ValueError):
            continue
        if season < 0 or number < 1:
            continue
        if anime_only and not _show_is_anime(
            show, show_trakt_id, trakt_authed_get, anime_cache
        ):
            continue
        if show_trakt_id in rows_by_show:
            continue
        watched_at = str((hrow or {}).get("watched_at") or "").strip()
        synth_ep = dict(ep) if isinstance(ep, dict) else {}
        # Historial = episodio dado por visto; no hay /playback → usar 100% como en el resto de filas
        rows_by_show[show_trakt_id] = {
            "show": show,
            "episode": synth_ep,
            "progress": 100.0,
            "paused_at": watched_at,
        }

    rows_unique = list(rows_by_show.values())
    rows_unique.sort(key=_trakt_row_activity_iso, reverse=True)
    show_tr_cache = _prefetch_show_translations_map(
        _unique_show_trakt_ids_from_series_rows(rows_unique),
        provider,
        lang,
    )
    tmdb_cache = _prefetch_tmdb_series_map(
        _tmdb_ids_needing_fetch_for_series_rows(
            rows_unique, trakt_parse_year, trakt_float_or_none
        ),
        tmdb_id_details,
    )

    for row in rows_unique:
        show = (row or {}).get("show") or {}
        ep = (row or {}).get("episode") or {}
        ids = (show.get("ids") or {}) if isinstance(show, dict) else {}
        show_trakt_id = str(ids.get("trakt") or "").strip()
        if not show_trakt_id:
            continue
        season = int(ep.get("season") or 0)
        number = int(ep.get("number") or 0)
        if season < 0 or number < 1:
            continue
        tmdb_id = ids.get("tmdb")
        imdb_id = str(ids.get("imdb") or "").strip()
        show_year = show.get("year")
        show_year, show_has_year = trakt_parse_year(show_year)
        show_rating = trakt_float_or_none(show.get("rating"))
        show_votes = show.get("votes")
        show_title = str(show.get("title") or _t("Serie", "TV Show", "Série", "Serie TV", "Serie")).strip()
        show_plot = str(show.get("overview") or "").strip()
        if provider and lang:
            sid = str(show_trakt_id)
            if sid not in show_tr_cache:
                try:
                    t_tr, o_tr = provider._translation_title_and_overview(
                        "show", sid, lang
                    )
                except Exception:
                    t_tr, o_tr = "", ""
                show_tr_cache[sid] = {
                    "title": str(t_tr or "").strip(),
                    "plot": str(o_tr or "").strip(),
                }
            trn = show_tr_cache.get(sid) or {}
            if trn.get("title"):
                show_title = trn.get("title")
            if trn.get("plot"):
                show_plot = trn.get("plot")

        tr_p, tr_f = _trakt_show_poster_fanart(show)
        tmdb = {}
        if tmdb_id:
            try:
                kn = int(str(tmdb_id).strip())
            except (TypeError, ValueError):
                kn = None
            if kn is not None and (kn, "series") in tmdb_cache:
                tmdb = dict(tmdb_cache.get((kn, "series")) or {})
            elif kn is not None:
                sy0, shy0 = trakt_parse_year(show.get("year"))
                sr0 = trakt_float_or_none(show.get("rating"))
                trakt_meta_ok = (
                    tr_p
                    and tr_f
                    and shy0
                    and sy0 is not None
                    and sr0 is not None
                    and sr0 > 0.0
                )
                if not trakt_meta_ok:
                    tmdb = tmdb_id_details(tmdb_id, media_type="series") or {}
        if (
            (not show_has_year or show_year is None)
            and tmdb.get("has_year")
            and tmdb.get("year") is not None
        ):
            show_year, show_has_year = tmdb.get("year"), True
        if (
            (show_rating is None or show_rating <= 0.0)
            and tmdb.get("rating") is not None
            and tmdb.get("rating") > 0.0
        ):
            show_rating = tmdb.get("rating")

        ptxt = progress_percent_text((row or {}).get("progress"))
        ptxt_color = f"[COLOR chartreuse][{ptxt}][/COLOR]"
        rating_txt = (
            f" · {show_rating:.1f}/10"
            if (show_rating is not None and show_rating > 0.0)
            else ""
        )
        year_txt = f" · {show_year}" if str(show_year or "").isdigit() else ""
        sub = "{}{}{}".format(
            _t("Visto: {}", "Watched: {}", "Vu : {}", "Visto: {}", "Gesehen: {}").format(
                ptxt
            ),
            year_txt,
            rating_txt,
        )
        year_color = (
            f"[COLOR deepskyblue]{show_year}[/COLOR]"
            if (show_has_year and show_year is not None)
            else "[COLOR gray]{}[/COLOR]".format(_t("N/D", "N/A", "N/D", "N/D", "k.A."))
        )
        rating_color = (
            f"[COLOR gold]{show_rating:.1f}/10[/COLOR]"
            if (show_rating is not None and show_rating > 0.0)
            else "[COLOR gray]{}[/COLOR]".format(_t("N/D", "N/A", "N/D", "N/D", "k.A."))
        )
        label = f"{ptxt_color} [B]{show_title}[/B]  [COLOR gray]·[/COLOR]  {year_color}  [COLOR gray]·[/COLOR]  {rating_color}"
        plot = show_plot or sub
        li = xbmcgui.ListItem(label=label, label2=sub)
        li.setInfo(
            "video",
            {
                "title": label,
                "tvshowtitle": label,
                "mediatype": "tvshow",
                "plot": plot,
                "year": int(show_year) if str(show_year or "").isdigit() else 0,
                "rating": show_rating
                if (show_rating is not None and show_rating > 0.0)
                else 0,
                "votes": str(int(show_votes))
                if str(show_votes or "").isdigit()
                else "",
                "imdbnumber": imdb_id,
            },
        )
        art = dict(base_art)
        poster = (tr_p or str((tmdb or {}).get("poster") or "")).strip()
        fanart = (tr_f or str((tmdb or {}).get("fanart") or "")).strip()
        if poster:
            art.update({"poster": poster, "thumb": poster, "icon": poster})
        if fanart:
            art.update({"fanart": fanart, "landscape": fanart, "banner": fanart})
        li.setArt(art)
        li.setProperty("IsPlayable", "false")
        # Forzar label con color para skins que ignoran title/tag.
        li.setLabel(label)
        directory.append(
            (url_for_in_progress_pick(show_trakt_id, season, number), li, True)
        )

    if not directory:
        li = xbmcgui.ListItem(label=empty_label)
        li.setArt(base_art)
        li.setProperty("IsPlayable", "false")
        directory.append((url_for_noop(), li, False))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle, True)


def run_movies_in_progress(
    *,
    plugin_handle,
    get_bool_setting,
    trakt_is_ready,
    trakt_authed_get,
    trakt_progress_translator,
    default_list_art,
    trakt_year_from_movie_dict,
    trakt_float_or_none,
    tmdb_id_details,
    progress_percent_text,
    trakt_list_label1_with_year_rating,
    trakt_title_with_year_rating_plain,
    safe_votes_str,
    trakt_listitem_set_info_and_videotag,
    url_for_play,
    url_for_noop,
):
    if not get_bool_setting("trakt_enabled"):
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t("Activa Trakt en Ajustes.", "Enable Trakt in Settings.", "Active Trakt dans les paramètres.", "Attiva Trakt nelle impostazioni.", "Aktiviere Trakt in den Einstellungen."),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    if not trakt_is_ready():
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t("Autoriza tu cuenta para ver progreso.", "Authorize your account to view progress.", "Autorise ton compte pour voir la progression.", "Autorizza il tuo account per vedere i progressi.", "Autorisiere dein Konto, um den Fortschritt zu sehen."),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    try:
        rows = _trakt_authed_get_all_pages(
            trakt_authed_get,
            base_url="https://api.trakt.tv/sync/playback/movies?extended=full",
            page_size=100,
            max_pages=20,
        )
    except Exception:
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t(
                "No se pudo cargar películas sin finalizar.",
                "Could not load unfinished movies.",
                "Impossible de charger les films non terminés.",
                "Impossibile caricare i film non completati.",
                "Unfertige Filme konnten nicht geladen werden.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return

    provider, lang = trakt_progress_translator()
    movie_ids_ordered = _unique_movie_trakt_ids_from_progress_rows(rows)
    movie_full_cache = _prefetch_trakt_movie_full_map(
        movie_ids_ordered, trakt_authed_get
    )
    movie_tr_cache = _prefetch_movie_translations_map(movie_ids_ordered, provider, lang)
    tmdb_cache = _prefetch_tmdb_movie_map(
        _tmdb_movie_need_ids_from_progress_rows(
            rows, movie_full_cache, trakt_year_from_movie_dict, trakt_float_or_none
        ),
        tmdb_id_details,
    )

    xbmcplugin.setPluginCategory(
        plugin_handle,
        _t(
            "Kraken - Trakt - Películas sin finalizar",
            "Kraken - Trakt - Unfinished movies",
            "Kraken - Trakt - Films non terminés",
            "Kraken - Trakt - Film non completati",
            "Kraken - Trakt - Unfertige Filme",
        )
    )
    xbmcplugin.setContent(plugin_handle, "movies")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_UNSORTED)
    base_art = default_list_art()
    directory = []

    for row in rows:
        movie = (row or {}).get("movie") or {}
        ids = (movie.get("ids") or {}) if isinstance(movie, dict) else {}
        trakt_id = str(ids.get("trakt") or "").strip()
        if not trakt_id:
            continue
        full_movie = movie_full_cache.get(trakt_id) or {}
        ids_full = (full_movie.get("ids") or {}) if isinstance(full_movie, dict) else {}
        if isinstance(ids_full, dict):
            if not ids.get("tmdb") and ids_full.get("tmdb"):
                ids["tmdb"] = ids_full.get("tmdb")
            if not ids.get("imdb") and ids_full.get("imdb"):
                ids["imdb"] = ids_full.get("imdb")
        tmdb_id = ids.get("tmdb")
        imdb_id = str(ids.get("imdb") or "").strip()
        title = str(full_movie.get("title") or movie.get("title") or _t("Película", "Movie", "Film", "Film", "Film")).strip()
        plot = str(full_movie.get("overview") or movie.get("overview") or "").strip()
        if provider and lang:
            if trakt_id not in movie_tr_cache:
                try:
                    t_tr, o_tr = provider._translation_title_and_overview(
                        "movie", trakt_id, lang
                    )
                except Exception:
                    t_tr, o_tr = "", ""
                movie_tr_cache[trakt_id] = {
                    "title": str(t_tr or "").strip(),
                    "plot": str(o_tr or "").strip(),
                }
            trn = movie_tr_cache.get(trakt_id) or {}
            if trn.get("title"):
                title = trn.get("title")
            if trn.get("plot"):
                plot = trn.get("plot")
        year, has_year = trakt_year_from_movie_dict(full_movie or {})
        if not has_year:
            y2, hy2 = trakt_year_from_movie_dict(movie or {})
            if hy2:
                year, has_year = y2, True
        rating = trakt_float_or_none((full_movie or {}).get("rating"))
        if rating is None or rating <= 0.0:
            rating = trakt_float_or_none((movie or {}).get("rating"))
        votes = (full_movie or {}).get("votes")
        if votes is None:
            votes = (movie or {}).get("votes")
        art_src = full_movie if isinstance(full_movie, dict) and full_movie else movie
        tr_p, tr_f = _trakt_movie_poster_fanart(art_src)
        tmdb = {}
        if tmdb_id:
            try:
                kn = int(str(tmdb_id).strip())
            except (TypeError, ValueError):
                kn = None
            if kn is not None and (kn, "movie") in tmdb_cache:
                tmdb = dict(tmdb_cache.get((kn, "movie")) or {})
            elif kn is not None:
                sy0, shy0 = trakt_year_from_movie_dict(full_movie or {})
                if not shy0:
                    sy0, shy0 = trakt_year_from_movie_dict(movie or {})
                sr0 = trakt_float_or_none((full_movie or {}).get("rating"))
                if sr0 is None or sr0 <= 0.0:
                    sr0 = trakt_float_or_none((movie or {}).get("rating"))
                trakt_meta_ok = (
                    tr_p
                    and tr_f
                    and shy0
                    and sy0 is not None
                    and sr0 is not None
                    and sr0 > 0.0
                )
                if not trakt_meta_ok:
                    tmdb = tmdb_id_details(tmdb_id, media_type="movie") or {}
        if (
            (not has_year or year is None)
            and tmdb.get("has_year")
            and tmdb.get("year") is not None
        ):
            year, has_year = tmdb.get("year"), True
        if (
            (rating is None or rating <= 0.0)
            and tmdb.get("rating") is not None
            and tmdb.get("rating") > 0.0
        ):
            rating = tmdb.get("rating")
        if (
            votes is None or str(votes) == "0" or not str(votes or "").isdigit()
        ) and tmdb.get("votes"):
            votes = tmdb.get("votes")

        ptxt = progress_percent_text((row or {}).get("progress"))
        ptxt_color = f"[COLOR chartreuse][{ptxt}][/COLOR]"
        year_color = (
            f"[COLOR deepskyblue]{year}[/COLOR]"
            if (has_year and year is not None)
            else "[COLOR gray]{}[/COLOR]".format(_t("N/D", "N/A", "N/D", "N/D", "k.A."))
        )
        rating_color = (
            f"[COLOR gold]{rating:.1f}/10[/COLOR]"
            if (rating is not None and rating > 0.0)
            else "[COLOR gray]{}[/COLOR]".format(_t("N/D", "N/A", "N/D", "N/D", "k.A."))
        )
        # Titulo principal forzado con metadatos en colores para skins que
        # no muestran bien rating/año fuera del label.
        label = f"{ptxt_color} [B]{title}[/B]  [COLOR gray]·[/COLOR]  {year_color}  [COLOR gray]·[/COLOR]  {rating_color}"
        sub = "{}{}{}".format(
            _t("Visto: {}", "Watched: {}", "Vu : {}", "Visto: {}", "Gesehen: {}").format(ptxt),
            f" · {year}" if (has_year and year is not None) else "",
            f" · {rating:.1f}/10" if (rating is not None and rating > 0.0) else "",
        )
        plot = plot or sub
        li = xbmcgui.ListItem(label=label, label2=sub)
        r_for_info = rating
        y_for_info = int(year) if (has_year and year is not None) else 0
        v_for_info = safe_votes_str(votes, (tmdb or {}).get("votes"))
        info = {
            "title": label,
            "year": y_for_info,
            "plot": plot,
            "mediatype": "movie",
            "rating": r_for_info
            if (r_for_info is not None and r_for_info > 0.0)
            else 0,
            "votes": v_for_info,
            "imdbnumber": imdb_id,
            "tagline": "{}: {}  |  {}: {}".format(
                _t("Año", "Year", "Année", "Anno", "Jahr"),
                str(year) if (has_year and year is not None) else _t("N/D", "N/A", "N/D", "N/D", "k.A."),
                _t("Valoración", "Rating", "Note", "Voto", "Bewertung"),
                f"{r_for_info:.1f}/10"
                if (r_for_info is not None and r_for_info > 0.0)
                else _t("N/D", "N/A", "N/D", "N/D", "k.A."),
            ),
        }
        trakt_listitem_set_info_and_videotag(
            li,
            label,
            plot,
            False,
            has_year,
            year,
            r_for_info,
            votes,
            info,
        )
        # Algunas skins ignoran setInfo/title y leen Label; forzamos ambos.
        li.setLabel(label)
        art = dict(base_art)
        poster = (tr_p or str((tmdb or {}).get("poster") or "")).strip()
        fanart = (tr_f or str((tmdb or {}).get("fanart") or "")).strip()
        if poster:
            art.update({"poster": poster, "thumb": poster, "icon": poster})
        if fanart:
            art.update({"fanart": fanart, "landscape": fanart, "banner": fanart})
        li.setArt(art)
        li.setProperty("IsPlayable", "true")
        add_movie_download_context(li, f"trakt::movie::{trakt_id}")
        directory.append((url_for_play(trakt_id), li, False))

    if not directory:
        li = xbmcgui.ListItem(
            label=_t(
                "No hay películas sin finalizar",
                "No unfinished movies",
                "Aucun film non terminé",
                "Nessun film non completato",
                "Keine unfertigen Filme",
            )
        )
        li.setArt(base_art)
        li.setProperty("IsPlayable", "false")
        directory.append((url_for_noop(), li, False))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle, True)


def run_movies_related_recent(
    *,
    plugin_handle,
    get_bool_setting,
    trakt_is_ready,
    trakt_authed_get,
    trakt_progress_translator,
    default_list_art,
    trakt_parse_year,
    trakt_float_or_none,
    tmdb_id_details,
    trakt_list_label1_with_year_rating,
    url_for_play,
    url_for_noop,
):
    if not get_bool_setting("trakt_enabled"):
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t("Activa Trakt en Ajustes.", "Enable Trakt in Settings.", "Active Trakt dans les paramètres.", "Attiva Trakt nelle impostazioni.", "Aktiviere Trakt in den Einstellungen."),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    if not trakt_is_ready():
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t(
                "Autoriza tu cuenta para ver recomendaciones relacionadas.",
                "Authorize your account to view related recommendations.",
                "Autorise ton compte pour voir les recommandations liées.",
                "Autorizza il tuo account per le raccomandazioni correlate.",
                "Autorisiere dein Konto, um verwandte Empfehlungen zu sehen.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    try:
        history = (
            trakt_authed_get("https://api.trakt.tv/sync/history/movies?limit=20") or []
        )
    except Exception:
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t(
                "No se pudo cargar historial de películas.",
                "Could not load movie history.",
                "Impossible de charger l'historique des films.",
                "Impossibile caricare la cronologia film.",
                "Filmverlauf konnte nicht geladen werden.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return

    provider, lang = trakt_progress_translator()
    seed_ids = []
    for row in history:
        movie = (row or {}).get("movie") or {}
        ids = (movie.get("ids") or {}) if isinstance(movie, dict) else {}
        sid = str(ids.get("trakt") or "").strip()
        if sid and sid not in seed_ids:
            seed_ids.append(sid)
        if len(seed_ids) >= 6:
            break

    related = []
    seen_rel = set()
    if seed_ids:
        rel_urls = [
            f"https://api.trakt.tv/movies/{quote(sid)}/related?limit=12"
            for sid in seed_ids
        ]
        batches = _parallel_trakt_get_indexed(rel_urls, trakt_authed_get, max_workers=4)
        for _sid, rows in zip(seed_ids, batches):
            for mv in rows or []:
                movie = (
                    mv
                    if isinstance(mv, dict) and "ids" in mv
                    else (mv.get("movie") or {})
                )
                ids = (movie.get("ids") or {}) if isinstance(movie, dict) else {}
                rid = str(ids.get("trakt") or "").strip()
                if not rid or rid in seen_rel or rid in seed_ids:
                    continue
                seen_rel.add(rid)
                related.append(movie)
                if len(related) >= 60:
                    break
            if len(related) >= 60:
                break

    xbmcplugin.setPluginCategory(
        plugin_handle,
        _t(
            "Kraken - Trakt - Películas relacionadas",
            "Kraken - Trakt - Related movies",
            "Kraken - Trakt - Films liés",
            "Kraken - Trakt - Film correlati",
            "Kraken - Trakt - Ähnliche Filme",
        )
    )
    xbmcplugin.setContent(plugin_handle, "movies")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_UNSORTED)
    base_art = default_list_art()
    directory = []
    tr_cache = _prefetch_movie_translations_map(
        _unique_trakt_ids_from_movie_dicts(related),
        provider,
        lang,
    )
    tmdb_cache = _prefetch_tmdb_movie_map(
        _tmdb_ids_needing_fetch_for_movie_dicts(
            related, trakt_parse_year, trakt_float_or_none
        ),
        tmdb_id_details,
    )
    for movie in related:
        ids = (movie.get("ids") or {}) if isinstance(movie, dict) else {}
        rid = str(ids.get("trakt") or "").strip()
        if not rid:
            continue
        tmdb_id = ids.get("tmdb")
        imdb_id = str(ids.get("imdb") or "").strip()
        title = str(movie.get("title") or _t("Película", "Movie", "Film", "Film", "Film")).strip()
        plot = str(movie.get("overview") or "").strip()
        if provider and lang:
            if rid not in tr_cache:
                try:
                    t_tr, o_tr = provider._translation_title_and_overview(
                        "movie", rid, lang
                    )
                except Exception:
                    t_tr, o_tr = "", ""
                tr_cache[rid] = {
                    "title": str(t_tr or "").strip(),
                    "plot": str(o_tr or "").strip(),
                }
            trn = tr_cache.get(rid) or {}
            if trn.get("title"):
                title = trn.get("title")
            if trn.get("plot"):
                plot = trn.get("plot")
        year, has_year = trakt_parse_year(movie.get("year"))
        rating = trakt_float_or_none(movie.get("rating"))
        tr_p, tr_f = _trakt_movie_poster_fanart(movie)
        tmdb = {}
        if tmdb_id:
            try:
                kn = int(str(tmdb_id).strip())
            except (TypeError, ValueError):
                kn = None
            if kn is not None and (kn, "movie") in tmdb_cache:
                tmdb = dict(tmdb_cache.get((kn, "movie")) or {})
            elif kn is not None:
                sy0, shy0 = trakt_parse_year(movie.get("year"))
                sr0 = trakt_float_or_none(movie.get("rating"))
                trakt_meta_ok = (
                    tr_p
                    and tr_f
                    and shy0
                    and sy0 is not None
                    and sr0 is not None
                    and sr0 > 0.0
                )
                if not trakt_meta_ok:
                    tmdb = tmdb_id_details(tmdb_id, media_type="movie") or {}
        if (
            (not has_year or year is None)
            and tmdb.get("has_year")
            and tmdb.get("year") is not None
        ):
            year, has_year = tmdb.get("year"), True
        if (
            (rating is None or rating <= 0.0)
            and tmdb.get("rating") is not None
            and tmdb.get("rating") > 0.0
        ):
            rating = tmdb.get("rating")
        line1 = trakt_list_label1_with_year_rating(
            title,
            has_year,
            year,
            (rating if (rating is not None and rating > 0.0) else None),
        )
        li = xbmcgui.ListItem(label=line1)
        li.setInfo(
            "video",
            {
                "title": line1,
                "plot": plot,
                "mediatype": "movie",
                "year": int(year) if (has_year and year is not None) else 0,
                "rating": rating if (rating is not None and rating > 0.0) else 0,
                "imdbnumber": imdb_id,
            },
        )
        art = dict(base_art)
        poster = (tr_p or str((tmdb or {}).get("poster") or "")).strip()
        fanart = (tr_f or str((tmdb or {}).get("fanart") or "")).strip()
        if poster:
            art.update({"poster": poster, "thumb": poster, "icon": poster})
        if fanart:
            art.update({"fanart": fanart, "landscape": fanart, "banner": fanart})
        li.setArt(art)
        li.setProperty("IsPlayable", "true")
        add_movie_download_context(li, f"trakt::movie::{rid}")
        directory.append((url_for_play(rid), li, False))

    if not directory:
        li = xbmcgui.ListItem(
            label=_t(
                "Sin recomendaciones relacionadas de películas",
                "No related movie recommendations",
                "Aucune recommandation de films liés",
                "Nessun consiglio di film correlati",
                "Keine ähnlichen Filmempfehlungen",
            )
        )
        li.setArt(base_art)
        li.setProperty("IsPlayable", "false")
        directory.append((url_for_noop(), li, False))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle, True)


def run_series_related_recent(
    *,
    plugin_handle,
    get_bool_setting,
    trakt_is_ready,
    trakt_authed_get,
    trakt_progress_translator,
    default_list_art,
    trakt_parse_year,
    trakt_float_or_none,
    tmdb_id_details,
    trakt_list_label1_with_year_rating,
    url_for_show_seasons,
    url_for_noop,
    anime_only=False,
    category_title=None,
    empty_label=None,
):
    if category_title is None:
        category_title = _t(
            "Kraken - Trakt - Series relacionadas",
            "Kraken - Trakt - Related TV shows",
            "Kraken - Trakt - Séries connexes",
            "Kraken - Trakt - Serie correlate",
            "Kraken - Trakt - Aehnliche Serien",
        )
    if empty_label is None:
        empty_label = _t(
            "Sin recomendaciones relacionadas de series",
            "No related TV show recommendations",
            "Aucune recommandation de séries connexes",
            "Nessun consiglio di serie correlate",
            "Keine aehnlichen Serienempfehlungen",
        )
    if not get_bool_setting("trakt_enabled"):
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t("Activa Trakt en Ajustes.", "Enable Trakt in Settings.", "Active Trakt dans les paramètres.", "Attiva Trakt nelle impostazioni.", "Aktiviere Trakt in den Einstellungen."),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    if not trakt_is_ready():
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t(
                "Autoriza tu cuenta para ver recomendaciones relacionadas.",
                "Authorize your account to view related recommendations.",
                "Autorise ton compte pour voir les recommandations liées.",
                "Autorizza il tuo account per le raccomandazioni correlate.",
                "Autorisiere dein Konto, um verwandte Empfehlungen zu sehen.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    try:
        history = (
            trakt_authed_get("https://api.trakt.tv/sync/history/episodes?limit=30")
            or []
        )
    except Exception:
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t(
                "No se pudo cargar historial de series.",
                "Could not load TV shows history.",
                "Impossible de charger l'historique des séries.",
                "Impossibile caricare la cronologia serie TV.",
                "Serienverlauf konnte nicht geladen werden.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return

    provider, lang = trakt_progress_translator()
    seed_ids = []
    anime_cache = {}
    for row in history:
        show = (row or {}).get("show") or {}
        ids = (show.get("ids") or {}) if isinstance(show, dict) else {}
        sid = str(ids.get("trakt") or "").strip()
        if (
            sid
            and anime_only
            and not _show_is_anime(show, sid, trakt_authed_get, anime_cache)
        ):
            continue
        if sid and sid not in seed_ids:
            seed_ids.append(sid)
        if len(seed_ids) >= 6:
            break

    related = []
    seen_rel = set()
    if seed_ids:
        rel_urls = [
            f"https://api.trakt.tv/shows/{quote(sid)}/related?limit=12"
            for sid in seed_ids
        ]
        batches = _parallel_trakt_get_indexed(rel_urls, trakt_authed_get, max_workers=4)
        for _sid, rows in zip(seed_ids, batches):
            for sh in rows or []:
                show = (
                    sh
                    if isinstance(sh, dict) and "ids" in sh
                    else (sh.get("show") or {})
                )
                ids = (show.get("ids") or {}) if isinstance(show, dict) else {}
                rid = str(ids.get("trakt") or "").strip()
                if not rid or rid in seen_rel or rid in seed_ids:
                    continue
                if anime_only and not _show_is_anime(
                    show, rid, trakt_authed_get, anime_cache
                ):
                    continue
                seen_rel.add(rid)
                related.append(show)
                if len(related) >= 60:
                    break
            if len(related) >= 60:
                break

    xbmcplugin.setPluginCategory(plugin_handle, category_title)
    xbmcplugin.setContent(plugin_handle, "tvshows")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_UNSORTED)
    base_art = default_list_art()
    directory = []
    tr_cache = _prefetch_show_translations_map(
        _unique_trakt_ids_from_show_dicts(related),
        provider,
        lang,
    )
    tmdb_cache = _prefetch_tmdb_series_map(
        _tmdb_ids_needing_fetch_for_show_dicts(
            related, trakt_parse_year, trakt_float_or_none
        ),
        tmdb_id_details,
    )
    for show in related:
        ids = (show.get("ids") or {}) if isinstance(show, dict) else {}
        rid = str(ids.get("trakt") or "").strip()
        if not rid:
            continue
        tmdb_id = ids.get("tmdb")
        imdb_id = str(ids.get("imdb") or "").strip()
        title = str(show.get("title") or _t("Serie", "TV Show", "Série", "Serie TV", "Serie")).strip()
        plot = str(show.get("overview") or "").strip()
        if provider and lang:
            if rid not in tr_cache:
                try:
                    t_tr, o_tr = provider._translation_title_and_overview(
                        "show", rid, lang
                    )
                except Exception:
                    t_tr, o_tr = "", ""
                tr_cache[rid] = {
                    "title": str(t_tr or "").strip(),
                    "plot": str(o_tr or "").strip(),
                }
            trn = tr_cache.get(rid) or {}
            if trn.get("title"):
                title = trn.get("title")
            if trn.get("plot"):
                plot = trn.get("plot")
        year, has_year = trakt_parse_year(show.get("year"))
        rating = trakt_float_or_none(show.get("rating"))
        tr_p, tr_f = _trakt_show_poster_fanart(show)
        tmdb = {}
        if tmdb_id:
            try:
                kn = int(str(tmdb_id).strip())
            except (TypeError, ValueError):
                kn = None
            if kn is not None and (kn, "series") in tmdb_cache:
                tmdb = dict(tmdb_cache.get((kn, "series")) or {})
            elif kn is not None:
                sy0, shy0 = trakt_parse_year(show.get("year"))
                sr0 = trakt_float_or_none(show.get("rating"))
                trakt_meta_ok = (
                    tr_p
                    and tr_f
                    and shy0
                    and sy0 is not None
                    and sr0 is not None
                    and sr0 > 0.0
                )
                if not trakt_meta_ok:
                    tmdb = tmdb_id_details(tmdb_id, media_type="series") or {}
        if (
            (not has_year or year is None)
            and tmdb.get("has_year")
            and tmdb.get("year") is not None
        ):
            year, has_year = tmdb.get("year"), True
        if (
            (rating is None or rating <= 0.0)
            and tmdb.get("rating") is not None
            and tmdb.get("rating") > 0.0
        ):
            rating = tmdb.get("rating")
        line1 = trakt_list_label1_with_year_rating(
            title,
            has_year,
            year,
            (rating if (rating is not None and rating > 0.0) else None),
        )
        li = xbmcgui.ListItem(label=line1)
        li.setInfo(
            "video",
            {
                "title": line1,
                "tvshowtitle": line1,
                "plot": plot,
                "mediatype": "tvshow",
                "year": int(year) if (has_year and year is not None) else 0,
                "rating": rating if (rating is not None and rating > 0.0) else 0,
                "imdbnumber": imdb_id,
            },
        )
        art = dict(base_art)
        poster = (tr_p or str((tmdb or {}).get("poster") or "")).strip()
        fanart = (tr_f or str((tmdb or {}).get("fanart") or "")).strip()
        if poster:
            art.update({"poster": poster, "thumb": poster, "icon": poster})
        if fanart:
            art.update({"fanart": fanart, "landscape": fanart, "banner": fanart})
        li.setArt(art)
        li.setProperty("IsPlayable", "false")
        add_show_download_context(li, rid)
        directory.append((url_for_show_seasons(rid), li, True))

    if not directory:
        li = xbmcgui.ListItem(label=empty_label)
        li.setArt(base_art)
        li.setProperty("IsPlayable", "false")
        directory.append((url_for_noop(), li, False))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle, True)


def run_movies_random_recent(
    *,
    plugin_handle,
    get_bool_setting,
    trakt_is_ready,
    trakt_authed_get,
    trakt_progress_translator,
    default_list_art,
    trakt_parse_year,
    trakt_float_or_none,
    tmdb_id_details,
    url_for_play,
    url_for_noop,
):
    if not get_bool_setting("trakt_enabled"):
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t("Activa Trakt en Ajustes.", "Enable Trakt in Settings.", "Active Trakt dans les paramètres.", "Attiva Trakt nelle impostazioni.", "Aktiviere Trakt in den Einstellungen."),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    if not trakt_is_ready():
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t(
                "Autoriza tu cuenta para elegir película aleatoria.",
                "Authorize your account to choose a random movie.",
                "Autorise ton compte pour choisir un film aléatoire.",
                "Autorizza il tuo account per scegliere un film casuale.",
                "Autorisiere dein Konto, um einen Zufallsfilm zu wählen.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    try:
        history = (
            trakt_authed_get("https://api.trakt.tv/sync/history/movies?limit=20") or []
        )
    except Exception:
        history = []
    provider, lang = trakt_progress_translator()
    seed_ids = []
    for row in history:
        movie = (row or {}).get("movie") or {}
        ids = (movie.get("ids") or {}) if isinstance(movie, dict) else {}
        sid = str(ids.get("trakt") or "").strip()
        if sid and sid not in seed_ids:
            seed_ids.append(sid)
        if len(seed_ids) >= 6:
            break
    pending = []
    seen = set()
    if seed_ids:
        rel_urls = [
            f"https://api.trakt.tv/movies/{quote(sid)}/related?limit=20"
            for sid in seed_ids
        ]
        batches = _parallel_trakt_get_indexed(rel_urls, trakt_authed_get, max_workers=4)
        for _sid, rows in zip(seed_ids, batches):
            for mv in rows or []:
                movie = (
                    mv
                    if isinstance(mv, dict) and "ids" in mv
                    else (mv.get("movie") or {})
                )
                ids = (movie.get("ids") or {}) if isinstance(movie, dict) else {}
                rid = str(ids.get("trakt") or "").strip()
                if not rid or rid in seen or rid in seed_ids:
                    continue
                seen.add(rid)
                pending.append({"rid": rid, "movie": movie})
                if len(pending) >= 120:
                    break
            if len(pending) >= 120:
                break

    movie_tr_cache = _prefetch_movie_translations_map(
        [p["rid"] for p in pending], provider, lang
    )
    tmdb_cache = _prefetch_tmdb_movie_map(
        _tmdb_ids_needing_fetch_for_movie_dicts(
            [p["movie"] for p in pending], trakt_parse_year, trakt_float_or_none
        ),
        tmdb_id_details,
    )

    candidates = []
    for p in pending:
        rid = p["rid"]
        movie = p["movie"]
        ids = (movie.get("ids") or {}) if isinstance(movie, dict) else {}
        title = str((movie or {}).get("title") or "").strip()
        year = (movie or {}).get("year")
        if provider and lang:
            trn = movie_tr_cache.get(rid) or {}
            if trn.get("title"):
                title = trn.get("title")
            if trn.get("plot"):
                movie["overview"] = trn.get("plot")
        candidates.append(
            {
                "trakt_id": rid,
                "title": title or _t("Película", "Movie", "Film", "Film", "Film"),
                "year": year,
                "rating": (movie or {}).get("rating"),
                "plot": str((movie or {}).get("overview") or "").strip(),
                "tmdb_id": ids.get("tmdb"),
                "imdb_id": str(ids.get("imdb") or "").strip(),
                "_movie": movie,
            }
        )
    if not candidates:
        li = xbmcgui.ListItem(
            label=_t(
                "Sin película aleatoria disponible",
                "No random movie available",
                "Aucun film aléatoire disponible",
                "Nessun film casuale disponibile",
                "Kein Zufallsfilm verfügbar",
            )
        )
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(plugin_handle, url_for_noop(), li, False)
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    picked = random.choice(candidates)
    picked_id = str((picked or {}).get("trakt_id") or "").strip()
    picked_title = str((picked or {}).get("title") or _t("Película", "Movie", "Film", "Film", "Film")).strip()
    picked_year = (picked or {}).get("year")
    picked_plot = str((picked or {}).get("plot") or "").strip()
    picked_tmdb_id = (picked or {}).get("tmdb_id")
    picked_imdb_id = str((picked or {}).get("imdb_id") or "").strip()
    try:
        picked_rating = float((picked or {}).get("rating") or 0.0)
    except (TypeError, ValueError):
        picked_rating = 0.0
    year_color = (
        f"[COLOR deepskyblue]{picked_year}[/COLOR]"
        if str(picked_year or "").isdigit()
        else "[COLOR gray]{}[/COLOR]".format(_t("N/D", "N/A", "N/D", "N/D", "k.A."))
    )
    rating_color = (
        f"[COLOR gold]{picked_rating:.1f}/10[/COLOR]"
        if picked_rating > 0.0
        else "[COLOR gray]{}[/COLOR]".format(_t("N/D", "N/A", "N/D", "N/D", "k.A."))
    )
    line1 = f"[B]{picked_title}[/B]  [COLOR gray]·[/COLOR]  {year_color}  [COLOR gray]·[/COLOR]  {rating_color}"
    plot_plain_fallback = "{} · {} · {}".format(
        picked_title,
        str(picked_year) if str(picked_year or "").isdigit() else _t("N/D", "N/A", "N/D", "N/D", "k.A."),
        f"{picked_rating:.1f}/10" if picked_rating > 0.0 else _t("N/D", "N/A", "N/D", "N/D", "k.A."),
    )
    li = xbmcgui.ListItem(label=line1)
    li.setProperty("IsPlayable", "true")
    li.setLabel(line1)
    base_art = default_list_art()
    picked_movie = (picked or {}).get("_movie") or {}
    tr_p, tr_f = _trakt_movie_poster_fanart(picked_movie)
    tmdb = {}
    if picked_tmdb_id:
        try:
            kn = int(str(picked_tmdb_id).strip())
        except (TypeError, ValueError):
            kn = None
        if kn is not None and (kn, "movie") in tmdb_cache:
            tmdb = dict(tmdb_cache.get((kn, "movie")) or {})
        elif kn is not None:
            sy0, shy0 = trakt_parse_year((picked_movie or {}).get("year"))
            sr0 = trakt_float_or_none((picked_movie or {}).get("rating"))
            trakt_meta_ok = (
                tr_p
                and tr_f
                and shy0
                and sy0 is not None
                and sr0 is not None
                and sr0 > 0.0
            )
            if not trakt_meta_ok:
                tmdb = tmdb_id_details(picked_tmdb_id, media_type="movie") or {}
    plot_for_info = picked_plot or plot_plain_fallback
    li.setInfo(
        "video",
        {
            "title": picked_title,
            "mediatype": "movie",
            "year": int(picked_year) if str(picked_year or "").isdigit() else 0,
            "rating": picked_rating if picked_rating > 0.0 else 0,
            "plot": plot_for_info,
            "imdbnumber": picked_imdb_id,
        },
    )
    art = dict(base_art)
    poster = (tr_p or str((tmdb or {}).get("poster") or "")).strip()
    fanart = (tr_f or str((tmdb or {}).get("fanart") or "")).strip()
    if poster:
        art.update({"poster": poster, "thumb": poster, "icon": poster})
    if fanart:
        art.update({"fanart": fanart, "landscape": fanart, "banner": fanart})
    li.setArt(art)
    add_movie_download_context(li, f"trakt::movie::{picked_id}")
    xbmcplugin.addDirectoryItem(plugin_handle, url_for_play(picked_id), li, False)
    xbmcplugin.endOfDirectory(plugin_handle, True)


def run_series_random_recent(
    *,
    plugin_handle,
    get_bool_setting,
    trakt_is_ready,
    trakt_authed_get,
    trakt_progress_translator,
    default_list_art,
    trakt_parse_year,
    trakt_float_or_none,
    tmdb_id_details,
    url_for_show_seasons,
    url_for_noop,
    anime_only=False,
    empty_label=None,
    item_label=None,
):
    if empty_label is None:
        empty_label = _t(
            "Sin serie aleatoria disponible",
            "No random TV show available",
            "Aucune série aléatoire disponible",
            "Nessuna serie TV casuale disponibile",
            "Keine Zufallsserie verfügbar",
        )
    if item_label is None:
        item_label = _t(
            "Abrir serie aleatoria",
            "Open random TV show",
            "Ouvrir une série aléatoire",
            "Apri serie TV casuale",
            "Zufallsserie öffnen",
        )
    if not get_bool_setting("trakt_enabled"):
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t("Activa Trakt en Ajustes.", "Enable Trakt in Settings.", "Active Trakt dans les paramètres.", "Attiva Trakt nelle impostazioni.", "Aktiviere Trakt in den Einstellungen."),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    if not trakt_is_ready():
        xbmcgui.Dialog().ok(
            "Kraken - Trakt",
            _t(
                "Autoriza tu cuenta para elegir serie aleatoria.",
                "Authorize your account to choose a random TV show.",
                "Autorise ton compte pour choisir une série aléatoire.",
                "Autorizza il tuo account per scegliere una serie TV casuale.",
                "Autorisiere dein Konto, um eine Zufallsserie zu wählen.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    try:
        history = (
            trakt_authed_get("https://api.trakt.tv/sync/history/episodes?limit=30")
            or []
        )
    except Exception:
        history = []
    provider, lang = trakt_progress_translator()
    seed_ids = []
    anime_cache = {}
    for row in history:
        show = (row or {}).get("show") or {}
        ids = (show.get("ids") or {}) if isinstance(show, dict) else {}
        sid = str(ids.get("trakt") or "").strip()
        if (
            sid
            and anime_only
            and not _show_is_anime(show, sid, trakt_authed_get, anime_cache)
        ):
            continue
        if sid and sid not in seed_ids:
            seed_ids.append(sid)
        if len(seed_ids) >= 6:
            break
    pending = []
    seen = set()
    if seed_ids:
        rel_urls = [
            f"https://api.trakt.tv/shows/{quote(sid)}/related?limit=20"
            for sid in seed_ids
        ]
        batches = _parallel_trakt_get_indexed(rel_urls, trakt_authed_get, max_workers=4)
        for _sid, rows in zip(seed_ids, batches):
            for sh in rows or []:
                show = (
                    sh
                    if isinstance(sh, dict) and "ids" in sh
                    else (sh.get("show") or {})
                )
                ids = (show.get("ids") or {}) if isinstance(show, dict) else {}
                rid = str(ids.get("trakt") or "").strip()
                if not rid or rid in seen or rid in seed_ids:
                    continue
                if anime_only and not _show_is_anime(
                    show, rid, trakt_authed_get, anime_cache
                ):
                    continue
                seen.add(rid)
                pending.append({"rid": rid, "show": show})
                if len(pending) >= 120:
                    break
            if len(pending) >= 120:
                break

    show_tr_cache = _prefetch_show_translations_map(
        [p["rid"] for p in pending], provider, lang
    )
    tmdb_cache = _prefetch_tmdb_series_map(
        _tmdb_ids_needing_fetch_for_show_dicts(
            [p["show"] for p in pending], trakt_parse_year, trakt_float_or_none
        ),
        tmdb_id_details,
    )

    candidates = []
    for p in pending:
        rid = p["rid"]
        show = p["show"]
        ids = (show.get("ids") or {}) if isinstance(show, dict) else {}
        title = str((show or {}).get("title") or "").strip()
        year = (show or {}).get("year")
        if provider and lang:
            trn = show_tr_cache.get(rid) or {}
            if trn.get("title"):
                title = trn.get("title")
            if trn.get("plot"):
                show["overview"] = trn.get("plot")
        candidates.append(
            {
                "trakt_id": rid,
                "title": title or _t("Serie", "TV Show", "Série", "Serie TV", "Serie"),
                "year": year,
                "rating": (show or {}).get("rating"),
                "plot": str((show or {}).get("overview") or "").strip(),
                "tmdb_id": ids.get("tmdb"),
                "imdb_id": str(ids.get("imdb") or "").strip(),
                "_show": show,
            }
        )
    if not candidates:
        li = xbmcgui.ListItem(label=empty_label)
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(plugin_handle, url_for_noop(), li, False)
        xbmcplugin.endOfDirectory(plugin_handle, True)
        return
    picked = random.choice(candidates)
    picked_id = str((picked or {}).get("trakt_id") or "").strip()
    picked_title = str(
        (picked or {}).get("title")
        or ("Anime" if anime_only else _t("Serie", "TV Show", "Série", "Serie TV", "Serie"))
    ).strip()
    picked_year = (picked or {}).get("year")
    picked_plot = str((picked or {}).get("plot") or "").strip()
    picked_tmdb_id = (picked or {}).get("tmdb_id")
    picked_imdb_id = str((picked or {}).get("imdb_id") or "").strip()
    try:
        picked_rating = float((picked or {}).get("rating") or 0.0)
    except (TypeError, ValueError):
        picked_rating = 0.0
    year_color = (
        f"[COLOR deepskyblue]{picked_year}[/COLOR]"
        if str(picked_year or "").isdigit()
        else "[COLOR gray]{}[/COLOR]".format(_t("N/D", "N/A", "N/D", "N/D", "k.A."))
    )
    rating_color = (
        f"[COLOR gold]{picked_rating:.1f}/10[/COLOR]"
        if picked_rating > 0.0
        else "[COLOR gray]{}[/COLOR]".format(_t("N/D", "N/A", "N/D", "N/D", "k.A."))
    )
    line1 = f"[B]{picked_title}[/B]  [COLOR gray]·[/COLOR]  {year_color}  [COLOR gray]·[/COLOR]  {rating_color}"
    plot_plain_fallback = "{} · {} · {}".format(
        picked_title,
        str(picked_year) if str(picked_year or "").isdigit() else _t("N/D", "N/A", "N/D", "N/D", "k.A."),
        f"{picked_rating:.1f}/10" if picked_rating > 0.0 else _t("N/D", "N/A", "N/D", "N/D", "k.A."),
    )
    li = xbmcgui.ListItem(label=line1)
    li.setProperty("IsPlayable", "false")
    li.setLabel(line1)
    base_art = default_list_art()
    picked_show = (picked or {}).get("_show") or {}
    tr_p, tr_f = _trakt_show_poster_fanart(picked_show)
    tmdb = {}
    if picked_tmdb_id:
        try:
            kn = int(str(picked_tmdb_id).strip())
        except (TypeError, ValueError):
            kn = None
        if kn is not None and (kn, "series") in tmdb_cache:
            tmdb = dict(tmdb_cache.get((kn, "series")) or {})
        elif kn is not None:
            sy0, shy0 = trakt_parse_year((picked_show or {}).get("year"))
            sr0 = trakt_float_or_none((picked_show or {}).get("rating"))
            trakt_meta_ok = (
                tr_p
                and tr_f
                and shy0
                and sy0 is not None
                and sr0 is not None
                and sr0 > 0.0
            )
            if not trakt_meta_ok:
                tmdb = tmdb_id_details(picked_tmdb_id, media_type="series") or {}
    plot_for_info = picked_plot or plot_plain_fallback
    li.setInfo(
        "video",
        {
            "title": picked_title,
            "tvshowtitle": picked_title,
            "mediatype": "tvshow",
            "year": int(picked_year) if str(picked_year or "").isdigit() else 0,
            "rating": picked_rating if picked_rating > 0.0 else 0,
            "plot": plot_for_info,
            "imdbnumber": picked_imdb_id,
        },
    )
    art = dict(base_art)
    poster = (tr_p or str((tmdb or {}).get("poster") or "")).strip()
    fanart = (tr_f or str((tmdb or {}).get("fanart") or "")).strip()
    if poster:
        art.update({"poster": poster, "thumb": poster, "icon": poster})
    if fanart:
        art.update({"fanart": fanart, "landscape": fanart, "banner": fanart})
    li.setArt(art)
    add_show_download_context(li, picked_id)
    xbmcplugin.addDirectoryItem(
        plugin_handle, url_for_show_seasons(picked_id), li, True
    )
    xbmcplugin.endOfDirectory(plugin_handle, True)
