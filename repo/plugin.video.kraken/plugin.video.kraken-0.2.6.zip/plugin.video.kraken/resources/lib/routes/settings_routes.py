import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.ui.video_info import apply_video_info
from resources.lib.ui.ui_helpers import _t


def run_settings(
    *,
    plugin_handle,
    addon,
    default_list_art,
    url_for_views_menu,
    url_for_maintenance_menu,
    url_for_open_kodi_addon_settings,
):
    """Menú reducido: vistas de lista, mantenimiento de cachés y ajustes nativos de Kodi."""
    xbmcplugin.setPluginCategory(
        plugin_handle,
        _t("Ajustes", "Settings", "Parametres", "Impostazioni", "Einstellungen"),
    )
    xbmcplugin.setContent(plugin_handle, "files")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_NONE)
    base_art = default_list_art()
    directory = []

    def _add(url, title_id: int, plot_id: int):
        title = addon.getLocalizedString(title_id)
        plot = addon.getLocalizedString(plot_id)
        li = xbmcgui.ListItem(title, plot)
        apply_video_info(li, {"title": title, "plot": plot, "mediatype": "video"})
        li.setArt(dict(base_art or {}))
        li.setProperty("IsPlayable", "false")
        directory.append((url, li, True))

    _add(url_for_views_menu(), 30443, 30444)
    _add(url_for_maintenance_menu(), 30460, 30461)
    _add(url_for_open_kodi_addon_settings(), 30517, 30518)

    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)
