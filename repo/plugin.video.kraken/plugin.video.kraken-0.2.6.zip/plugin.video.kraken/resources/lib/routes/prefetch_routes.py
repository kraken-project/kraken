import json
import time
from urllib.parse import quote

import xbmc
import xbmcgui

from resources.lib.core.kodi_run_plugin import escape_for_quoted_builtin
from resources.lib.core.playback_listitem import configure_listitem_stream_properties
from resources.lib.core.playback_source_stash import stash_source_candidates
from resources.lib.ui.video_info import apply_video_info
from resources.lib.ui.ui_helpers import _t


def _play_prefetched_next_from_addon(win, stream_url, sid, ns, ne, label, ep_t, show_t):
    """Abre el siguiente capítulo ya resuelto."""
    pl = xbmc.Player()
    info = {
        "title": ep_t,
        "tvshowtitle": show_t,
        "season": int(ns),
        "episode": int(ne),
        "mediatype": "episode",
    }
    win.clearProperty("Kraken.PrefetchStreamUrl")
    win.clearProperty("Kraken.PrefetchMeta")
    win.setProperty(
        "Kraken.Playing",
        json.dumps(
            {"kind": "episode", "show_id": sid, "season": int(ns), "episode": int(ne)},
        ),
    )
    for p in (
        "Kraken.30sDialogShown",
        "Kraken.30sUserCancelled",
        "Kraken.EofSoon",
        "Kraken.LastProgressPct",
        "Kraken.TraktSynced",
        "Kraken.TraktCollectionSent",
        "Kraken.TraktScrobbleLast.start",
        "Kraken.TraktScrobbleLast.pause",
        "Kraken.TraktScrobbleLast.stop",
    ):
        try:
            win.clearProperty(p)
        except Exception:
            pass
    li = xbmcgui.ListItem(path=str(stream_url), label=label)
    apply_video_info(li, info)
    li.setProperty("IsPlayable", "true")
    try:
        li.setContentLookup(False)
    except Exception:
        pass
    configure_listitem_stream_properties(li, stream_url)
    xbmc.sleep(400)
    ok = False
    try:
        pl.play(str(stream_url), li, False)
        ok = True
    except Exception as ex:
        xbmc.log(f"[Kraken] prefetch: Player.play error: {ex}", xbmc.LOGWARNING)
    if not ok:
        try:
            plv = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            plv.clear()
            plv.add(str(stream_url), li)
            pl.play(plv, li, False)
            ok = True
        except Exception as ex:
            xbmc.log(f"[Kraken] prefetch: PlayList error: {ex}", xbmc.LOGWARNING)
    if not ok:
        try:
            xbmc.executebuiltin(f'PlayMedia("{escape_for_quoted_builtin(stream_url)}")')
            ok = True
        except Exception as ex:
            xbmc.log(f"[Kraken] prefetch: PlayMedia error: {ex}", xbmc.LOGWARNING)
    return ok


def run_trakt_prefetch_next(
    *,
    show_id,
    season_num,
    ep_num,
    get_bool_setting,
    trakt_next_episode_pair,
    kraken_progress,
    resolve_trakt_episode_stream,
    pick_stream_url_silent,
    finalize_playback_stream_url,
    trakt_public_get,
):
    try:
        s = int(str(season_num))
        e = int(str(ep_num))
    except (TypeError, ValueError):
        return
    sid = (show_id or "").strip()
    if not sid or not get_bool_setting("next_episode_30s_dialog"):
        return
    ns, ne = trakt_next_episode_pair(sid, s, e)
    if ns is None or ne is None:
        xbmcgui.Dialog().notification(
            "Kraken",
            _t(
                "No hay mas episodios",
                "No more episodes",
                "Plus d'episodes",
                "Nessun altro episodio",
                "Keine weiteren Episoden",
            ),
            xbmcgui.NOTIFICATION_INFO,
            4000,
        )
        return
    win = xbmcgui.Window(10000)
    win.setProperty("Kraken.PrefetchInProgress", "1")
    try:
        ep_ctx = f"{int(ns):02d}x{int(ne):02d}"
        dprog = xbmcgui.DialogProgressBG()
        dprog.create(
            _t("Kraken - Siguiente", "Kraken - Next", "Kraken - Suivant", "Kraken - Successivo", "Kraken - Nächste"),
            _t("Buscando fuentes...", "Searching sources...", "Recherche de sources...", "Ricerca fonti...", "Suche Quellen..."),
        )
        started = time.time()

        def _cb(percent, phase, detail):
            kraken_progress(dprog, percent, phase, detail)

        try:
            cands = (
                resolve_trakt_episode_stream(
                    sid,
                    int(ns),
                    int(ne),
                    collect_sources=True,
                    progress_cb=_cb,
                    progress_started_at=started,
                    context_label=ep_ctx,
                )
                or []
            )
        except Exception:
            cands = []
        finally:
            dprog.close()
        stash_source_candidates(
            cands,
            _t("Siguiente", "Next", "Suivant", "Successivo", "Nächste")
            + f" {int(ns):02d}x{int(ne):02d}",
        )
        u = pick_stream_url_silent(cands, playback_kind="episode")
        if not u:
            xbmcgui.Dialog().notification(
                "Kraken",
                _t(
                    f"No hay fuente para T{int(ns)}E{int(ne)}",
                    f"No source found for S{int(ns)}E{int(ne)}",
                    f"Aucune source pour S{int(ns)}E{int(ne)}",
                    f"Nessuna fonte per S{int(ns)}E{int(ne)}",
                    f"Keine Quelle für S{int(ns)}E{int(ne)}",
                ),
                xbmcgui.NOTIFICATION_WARNING,
                5000,
            )
            return
        u = finalize_playback_stream_url(u, {"season": int(ns), "episode": int(ne)})
        show_t = _t("Serie", "TV Show", "Serie", "Serie TV", "Serie")
        try:
            sh = trakt_public_get(
                f"https://api.trakt.tv/shows/{quote(sid)}?extended=full"
            )
            show_t = str((sh or {}).get("title") or _t("Serie", "TV Show", "Serie", "Serie TV", "Serie")).strip()
        except Exception:
            pass
        ep_t = _t("Ep.", "Ep.", "Ep.", "Ep.", "Ep.") + f" {int(ne)}"
        try:
            one = trakt_public_get(
                f"https://api.trakt.tv/shows/{quote(sid)}/seasons/{int(ns)}/episodes/{int(ne)}?extended=full"
            )
            if isinstance(one, dict):
                ep_t = str(one.get("title") or ep_t).strip() or ep_t
        except Exception:
            pass
        label = f"{int(ns):02d}x{int(ne):02d} - {ep_t}"
        payload = {
            "label": label,
            "show_id": sid,
            "next_season": int(ns),
            "next_ep": int(ne),
            "info": {
                "title": ep_t,
                "tvshowtitle": show_t,
                "season": int(ns),
                "episode": int(ne),
                "mediatype": "episode",
            },
        }
        win.setProperty("Kraken.PrefetchStreamUrl", u)
        win.setProperty("Kraken.PrefetchMeta", json.dumps(payload))
        xbmc.sleep(200)
        pl = xbmc.Player()
        try:
            idle = not pl.isPlaying()
        except Exception:
            idle = True
        if idle:
            xbmc.log(
                "[Kraken] prefetch: reproductor inactivo al terminar búsqueda, abriendo siguiente",
                xbmc.LOGINFO,
            )
            if _play_prefetched_next_from_addon(
                win, u, sid, ns, ne, label, ep_t, show_t
            ):
                xbmcgui.Dialog().notification(
                    "Kraken",
                    _t(
                        "Reproduciendo siguiente capítulo.",
                        "Playing next episode.",
                        "Lecture de l'episode suivant.",
                        "Riproduzione episodio successivo.",
                        "Nächste Episode wird abgespielt.",
                    ),
                    xbmcgui.NOTIFICATION_INFO,
                    4000,
                )
            else:
                win.setProperty("Kraken.PrefetchStreamUrl", u)
                win.setProperty("Kraken.PrefetchMeta", json.dumps(payload))
                xbmcgui.Dialog().notification(
                    "Kraken",
                    _t(
                        "Siguiente listo pero no se pudo abrir. Reproduce desde Trakt.",
                        "Next episode is ready but could not be opened. Play it from Trakt.",
                        "Episode suivant prêt mais impossible à ouvrir. Lance-le depuis Trakt.",
                        "Episodio successivo pronto ma non apribile. Avvialo da Trakt.",
                        "Nächste Episode bereit, konnte aber nicht geöffnet werden. Starte sie über Trakt.",
                    ),
                    xbmcgui.NOTIFICATION_WARNING,
                    6000,
                )
        else:
            xbmcgui.Dialog().notification(
                "Kraken",
                _t(
                    "Siguiente listo. Se abre al acabar el actual.",
                    "Next episode ready. It will open when current playback ends.",
                    "Episode suivant prêt. Il s'ouvrira à la fin de la lecture actuelle.",
                    "Episodio successivo pronto. Si aprirà al termine della riproduzione corrente.",
                    "Nächste Episode bereit. Sie öffnet sich nach Ende der aktuellen Wiedergabe.",
                ),
                xbmcgui.NOTIFICATION_INFO,
                5000,
            )
    finally:
        try:
            win.clearProperty("Kraken.PrefetchInProgress")
        except Exception:
            pass
