import xbmcaddon


def tr(msgid, fallback=""):
    """Devuelve cadena localizada del addon o fallback."""
    try:
        addon = xbmcaddon.Addon("plugin.video.kraken")
    except Exception:
        addon = None
    if addon is not None:
        try:
            s = str(addon.getLocalizedString(int(msgid)) or "").strip()
            if s:
                return s
        except Exception:
            pass
    return str(fallback or "")
