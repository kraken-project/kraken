def normalize_language_label_bridge(
    *,
    language,
    provider_name,
    label,
    title,
    info,
    stream_url="",
    normalize_language_label_impl,
):
    return normalize_language_label_impl(
        language,
        provider_name=provider_name,
        label=label,
        title=title,
        info=info,
        stream_url=stream_url or "",
    )


def language_bucket_for_item_bridge(
    *, item, language_normalizer, language_bucket_for_item_impl
):
    return language_bucket_for_item_impl(item, language_normalizer)


def pick_stream_url_silent_bridge(
    *,
    candidates,
    playback_kind=None,
    pick_stream_url_silent_impl,
    source_sort_key_with_language_fn,
    get_bool_setting_fn,
    get_setting_fn,
    autoplay_url_by_language_priority_fn,
    rotation=None,
):
    return pick_stream_url_silent_impl(
        candidates,
        playback_kind=playback_kind,
        source_sort_key_with_language_fn=source_sort_key_with_language_fn,
        get_bool_setting_fn=get_bool_setting_fn,
        get_setting_fn=get_setting_fn,
        autoplay_url_by_language_priority_fn=autoplay_url_by_language_priority_fn,
        rotation=rotation,
    )


def pick_stream_dialog_bridge(
    *,
    title,
    candidates,
    playback_kind=None,
    rotation=None,
    pick_stream_dialog_impl,
    candidates_deduped_for_picker,
    source_sort_key_with_language,
    get_bool_setting,
    get_setting,
    autoplay_url_by_language_priority,
    language_bucket_for_item,
    language_section_title,
    compact_origin,
    normalize_language_label,
    language_flag,
    pretty_source_line,
    quality_counts_colored,
    kraken_sources_dialog_cls,
    addon_path,
):
    return pick_stream_dialog_impl(
        title,
        candidates,
        playback_kind=playback_kind,
        rotation=rotation,
        candidates_deduped_for_picker=candidates_deduped_for_picker,
        source_sort_key_with_language=source_sort_key_with_language,
        get_bool_setting=get_bool_setting,
        get_setting=get_setting,
        autoplay_url_by_language_priority=autoplay_url_by_language_priority,
        language_bucket_for_item=language_bucket_for_item,
        language_section_title=language_section_title,
        compact_origin=compact_origin,
        normalize_language_label=normalize_language_label,
        language_flag=language_flag,
        pretty_source_line=pretty_source_line,
        quality_counts_colored=quality_counts_colored,
        kraken_sources_dialog_cls=kraken_sources_dialog_cls,
        addon_path=addon_path,
    )
