import re
from urllib.parse import quote_plus
from urllib.request import Request, urlopen

import xbmc

from resources.lib.core.kraken_torrent_lite import (
    LINK_PROVIDER_URL_SETTINGS,
    enabled_link_providers,
)

_MAGNET_RE = re.compile(r"magnet:\?[^'\"\s<>]+", re.IGNORECASE)
_HTTP_RE = re.compile(r"https?://[^'\"\s<>]+", re.IGNORECASE)
_VIDEO_HINTS = (".mkv", ".mp4", ".avi", ".m3u8", ".torrent")
_DEFAULT_BASE_URLS = {
    "2ddl": "https://2ddl.ag",
    "300mbfilms": "https://300mbfilms.io",
    "allmoviesforyou": "https://allmoviesforyou.net",
    "anymovies": "https://anymovies.xyz",
    "cmovieshd": "https://cmovieshd.bz",
    "databasegdriveplayer": "https://databasegdriveplayer.co",
    "dbgo": "https://dbgo.fun",
    "easynews": "https://members.easynews.com",
    "filmxy": "https://www.filmxy.vip",
    "furk": "https://www.furk.net",
    "gowatchseries": "https://gowatchseries.ac",
    "maxrls": "https://maxrls.com",
    "myvideolinks": "https://myvideolinks.net",
    "onlineseries": "https://onlineseries.co",
    "ororo": "https://ororo.tv",
    "rapidmoviez": "https://rapidmoviez.com",
    "rlsbb": "https://rlsbb.ru",
    "scenerls": "https://www.scenerls.com",
}


def _fetch_text(url, timeout=6):
    req = Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0 (KrakenKodi)",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        },
    )
    with urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8", errors="ignore")


def _search_url(base_url, query, title, year, season=None, episode=None):
    u = str(base_url or "").strip()
    if not u:
        return ""
    q = quote_plus(str(query or "").strip())
    t = quote_plus(str(title or "").strip())
    y = quote_plus(str(year or "").strip())
    s = quote_plus(str(season or "").strip())
    e = quote_plus(str(episode or "").strip())
    if any(k in u for k in ("{query}", "{title}", "{year}", "{season}", "{episode}")):
        return (
            u.replace("{query}", q)
            .replace("{title}", t)
            .replace("{year}", y)
            .replace("{season}", s)
            .replace("{episode}", e)
        )
    sep = "&" if "?" in u else "?"
    return "{}{}s={}".format(u.rstrip("/"), sep, q)


def _looks_playable_http(u):
    low = str(u or "").lower()
    if any(
        h in low
        for h in (
            "/manifest.json",
            "/configure",
            "/settings",
            ".css",
            ".js",
            ".png",
            ".jpg",
        )
    ):
        return False
    return any(h in low for h in _VIDEO_HINTS) or "download" in low


def web_link_provider_candidates(
    *,
    title,
    year,
    media_type,
    season=None,
    episode=None,
    get_bool_setting,
    get_setting,
    is_playable_stream_url,
):
    query = "{} {}".format(str(title or "").strip(), str(year or "").strip()).strip()
    selected = enabled_link_providers(get_bool_setting)
    out = []
    seen = set()
    for name in selected[:8]:
        sid = LINK_PROVIDER_URL_SETTINGS.get(name, "")
        base = (get_setting(sid) or "").strip() if sid else ""
        if not base:
            base = _DEFAULT_BASE_URLS.get(name, "")
        if not base:
            continue
        surl = _search_url(base, query, title, year, season=season, episode=episode)
        if not surl:
            continue
        try:
            html = _fetch_text(surl, timeout=6)
        except Exception as ex:
            xbmc.log(f"[Kraken] WebLinks {name} fetch: {ex}", xbmc.LOGDEBUG)
            continue
        found = []
        found.extend(_MAGNET_RE.findall(html))
        for u in _HTTP_RE.findall(html):
            if _looks_playable_http(u):
                found.append(u)
        for url in found:
            u = str(url or "").strip()
            if not u or u in seen or not is_playable_stream_url(u):
                continue
            seen.add(u)
            out.append(
                {
                    "url": u,
                    "label": f"{name} web",
                    "title": str(title or "").strip(),
                    "quality": "Auto",
                    "language": "N/D",
                    "origin": f"WebLinks {name}",
                }
            )
    return out
