from resources.lib.core.addon_runtime import (
    finalize_playback_stream_url as _finalize_playback_stream_url_impl,
)
from resources.lib.core.debrid_stream_resolve import (
    DEBRID_MAGNET_QUICK_POLL_MOVIE_SEC,
    DEBRID_MAGNET_QUICK_POLL_SEC,
    maybe_resolve_torrent_via_debrid,
)


def build_runtime_context(
    *,
    addon,
    trakt_client_id,
    trakt_client_secret,
    stremio_open_all_peerflix,
    get_bool_setting_impl,
    get_setting_impl,
    get_int_setting_impl,
    set_setting_impl,
    get_enabled_providers_impl,
    get_trakt_search_provider_impl,
    get_stremio_provider_impl,
    get_stremio_toggle_names_impl,
    stremio_addons_config_impl,
    metadata_timeout_impl,
    metadata_priority_impl,
    trakt_results_limit_impl,
    trakt_title_with_year_impl,
    metadata_fallback_fanart_impl,
    external_scrapers_timeout_impl,
    addon_installed_impl,
    torrent_player_route_impl,
    json_get_impl,
    json_post_impl,
    trakt_post_impl,
    trakt_get_impl,
    trakt_public_get_impl,
    trakt_is_ready_impl,
    trakt_authed_get_impl,
    trakt_authed_get_with_refresh_impl,
    trakt_progress_translator_impl,
    omdb_enabled_impl,
    omdb_external_ratings_enabled_impl,
    tmdb_enabled_impl,
    tmdb_api_key_impl,
    omdb_api_key_impl,
):
    def get_bool_setting(setting_id):
        return get_bool_setting_impl(addon, setting_id)

    def get_setting(setting_id):
        return get_setting_impl(addon, setting_id)

    def get_int_setting(setting_id, default_value):
        return get_int_setting_impl(addon, setting_id, default_value)

    def debrid_torrent_resolve(
        url,
        magnet_quick=False,
        magnet_max_wait_seconds=None,
        playback=None,
    ):
        mag_max = None
        if magnet_max_wait_seconds is not None:
            try:
                mag_max = int(magnet_max_wait_seconds)
            except (TypeError, ValueError):
                mag_max = None
        elif magnet_quick:
            mag_max = DEBRID_MAGNET_QUICK_POLL_SEC
            if isinstance(playback, dict):
                k = str(playback.get("kind") or "").strip().lower()
                if k == "movie":
                    mag_max = int(DEBRID_MAGNET_QUICK_POLL_MOVIE_SEC)
        return maybe_resolve_torrent_via_debrid(
            url,
            get_bool_setting,
            get_setting,
            json_get_impl,
            json_post_impl,
            magnet_max_wait_seconds=mag_max,
            playback=playback,
        )

    return {
        "get_bool_setting": get_bool_setting,
        "get_setting": get_setting,
        "get_int_setting": get_int_setting,
        "get_enabled_providers": lambda: get_enabled_providers_impl(addon),
        "get_trakt_search_provider": lambda: get_trakt_search_provider_impl(addon),
        "get_stremio_provider": lambda: get_stremio_provider_impl(
            addon, get_bool_setting
        ),
        "get_stremio_toggle_names": lambda: get_stremio_toggle_names_impl(
            get_bool_setting=get_bool_setting,
            get_setting=get_setting,
        ),
        "stremio_addons_config": lambda: stremio_addons_config_impl(
            stremio_open_all_peerflix
        ),
        "metadata_timeout": lambda: metadata_timeout_impl(get_int_setting),
        "metadata_priority": lambda: metadata_priority_impl(get_setting),
        "trakt_results_limit": lambda: trakt_results_limit_impl(get_int_setting),
        "trakt_title_with_year": lambda: trakt_title_with_year_impl(get_bool_setting),
        "metadata_fallback_fanart": lambda: metadata_fallback_fanart_impl(
            get_bool_setting
        ),
        "external_scrapers_timeout": lambda: external_scrapers_timeout_impl(
            get_int_setting
        ),
        "addon_installed": lambda addon_id: addon_installed_impl(addon_id),
        "torrent_player_route": lambda stream_url: torrent_player_route_impl(
            stream_url,
            get_setting,
            lambda addon_id: addon_installed_impl(addon_id),
        ),
        "finalize_playback_stream_url": lambda stream_url, playback_context=None: (
            _finalize_playback_stream_url_impl(
                stream_url,
                get_setting,
                lambda addon_id: addon_installed_impl(addon_id),
                debrid_torrent_resolve,
                playback_context=playback_context,
            )
        ),
        "set_setting": lambda setting_id, value: set_setting_impl(
            addon, setting_id, value
        ),
        "trakt_post": lambda url, payload: trakt_post_impl(url, payload),
        "trakt_get": lambda url, client_id, access_token: trakt_get_impl(
            url, client_id, access_token
        ),
        "trakt_public_get": lambda url: trakt_public_get_impl(url, trakt_client_id),
        "trakt_is_ready": lambda: trakt_is_ready_impl(get_bool_setting, get_setting),
        "trakt_authed_get": lambda url: trakt_authed_get_with_refresh_impl(
            url=url,
            get_setting=get_setting,
            set_setting=lambda setting_id, value: set_setting_impl(addon, setting_id, value),
            trakt_client_id=trakt_client_id,
            trakt_client_secret=trakt_client_secret,
            trakt_get_fn=lambda u, cid, tok: trakt_get_impl(u, cid, tok),
            trakt_post_fn=lambda u, p: trakt_post_impl(u, p),
        ),
        "trakt_progress_translator": lambda: trakt_progress_translator_impl(
            lambda: get_trakt_search_provider_impl(addon)
        ),
        "omdb_enabled": lambda: omdb_enabled_impl(get_bool_setting, get_setting),
        "omdb_external_ratings_enabled": lambda: omdb_external_ratings_enabled_impl(
            addon,
            lambda: omdb_enabled_impl(get_bool_setting, get_setting),
        ),
        "tmdb_enabled": lambda: tmdb_enabled_impl(get_bool_setting, get_setting),
        "tmdb_api_key": lambda: tmdb_api_key_impl(get_setting),
        "omdb_api_key": lambda: omdb_api_key_impl(get_setting),
    }
