"""Utilidades de transporte HTTP para complementos estilo Stremio (Kraken)."""

from urllib.parse import urlsplit, urlunsplit


def normalize_stremio_addon_url(raw):
    """
    Normaliza URLs pegadas desde clientes Stremio u otros:
    - stremio:// y strem:// -> https://
    - esquema forzado a http/https; host en minusculas (sin tocar credenciales).
    """
    u = (raw or "").strip()
    if not u:
        return ""
    low = u.lower()
    if low.startswith("stremio://"):
        u = "https://" + u[len("stremio://") :]
    elif low.startswith("strem://"):
        u = "https://" + u[len("strem://") :].lstrip("/")
    parts = urlsplit(u)
    scheme = (parts.scheme or "https").lower()
    if scheme not in ("http", "https"):
        scheme = "https"
    netloc = parts.netloc or ""
    if "@" in netloc:
        i = netloc.rfind("@")
        netloc = netloc[: i + 1] + netloc[i + 1 :].lower()
    else:
        netloc = netloc.lower()
    return urlunsplit(
        (scheme, netloc, parts.path or "", parts.query or "", parts.fragment or "")
    )
