"""Claves de ajustes por proveedor Debrid y migracion desde esquema global antiguo."""

PROVIDERS = (
    {
        "slug": "alldebrid",
        "title": "AllDebrid",
        "enabled_key": "debrid_ad_enabled",
        "token_key": "debrid_ad_token",
        "refresh_key": None,
        "info_key": "debrid_ad_info",
        "legacy_name": "AllDebrid",
        "has_oauth_refresh": False,
    },
    {
        "slug": "rapidgator",
        "title": "Rapidgator",
        "enabled_key": "debrid_rg_enabled",
        "token_key": None,
        "refresh_key": None,
        "info_key": "debrid_rg_info",
        "legacy_name": "Rapidgator",
        "has_oauth_refresh": False,
    },
)

_BY_SLUG = {p["slug"]: p for p in PROVIDERS}


def provider_by_slug(slug):
    return _BY_SLUG.get(str(slug or "").strip().lower())


def migrate_legacy_debrid_settings(get_setting, set_setting, get_bool_setting):
    """Una vez: copia debrid_* global a claves por proveedor si las nuevas estan vacias."""
    if (get_setting("debrid_legacy_migrated") or "").strip().lower() == "true":
        return
    legacy_token = (get_setting("debrid_api_key") or "").strip()
    legacy_refresh = (get_setting("debrid_refresh_token") or "").strip()
    legacy_provider = (get_setting("debrid_provider") or "").strip()
    legacy_info = (get_setting("debrid_account_info") or "").strip()
    legacy_on = get_bool_setting("debrid_enabled")

    for p in PROVIDERS:
        if p["legacy_name"] and legacy_provider == p["legacy_name"] and legacy_token:
            if p["token_key"] and not (get_setting(p["token_key"]) or "").strip():
                set_setting(p["token_key"], legacy_token)
            if (
                p["refresh_key"]
                and legacy_refresh
                and not (get_setting(p["refresh_key"]) or "").strip()
            ):
                set_setting(p["refresh_key"], legacy_refresh)
            if legacy_on:
                set_setting(p["enabled_key"], "true")
            if legacy_info and p["info_key"]:
                cur = (get_setting(p["info_key"]) or "").strip()
                if not cur or cur == "No conectada":
                    set_setting(p["info_key"], legacy_info)

    set_setting("debrid_legacy_migrated", "true")
