"""
QR codificado y PNG escritos solo con biblioteca estandar + Nayuki (MIT).
Sin peticiones HTTP a servicios externos.
"""

from __future__ import annotations

import os
import struct
import zlib

from resources.lib.core.nayuki_qrcodegen import QrCode


def _png_pack_chunk(chunk_type: bytes, data: bytes) -> bytes:
    crc = zlib.crc32(chunk_type + data) & 0xFFFFFFFF
    return struct.pack(">I", len(data)) + chunk_type + data + struct.pack(">I", crc)


def write_qr_matrix_png(
    qr: QrCode, out_path: str, scale: int = 6, border: int = 4
) -> str:
    """
    Escribe PNG RGB 8-bit (tipo 2): mejor compatibilidad con Image de Kodi que grayscale.
    Limita lado maximo (~720 px) para evitar fallos de textura con URLs muy largas (QR v40).
    """
    if scale < 1:
        scale = 1
    if border < 0:
        border = 0

    sz = qr.get_size()
    mod_edge = sz + 2 * border
    # Kodi / GPU suelen rechazar texturas enormes o mostrarlas en blanco (> ~1024 px lado).
    max_dim = 720
    need_dim = mod_edge * scale
    if need_dim > max_dim:
        scale = max(1, max_dim // mod_edge)

    dim = mod_edge * scale

    pixels = bytearray(dim * dim)
    for y in range(dim):
        my = y // scale - border
        for x in range(dim):
            mx = x // scale - border
            dark = False
            if 0 <= mx < sz and 0 <= my < sz:
                dark = qr.get_module(mx, my)
            pixels[y * dim + x] = 0 if dark else 255

    # PNG RGB (tipo 2): 3 bytes por pixel; fila = 0x00 + R*dim + G*dim + B*dim
    raw_parts = []
    pos = 0
    for _y in range(dim):
        row = bytearray(1 + dim * 3)
        row[0] = 0  # filter None
        off = 1
        for _x in range(dim):
            v = pixels[pos]
            row[off] = row[off + 1] = row[off + 2] = v
            off += 3
            pos += 1
        raw_parts.append(bytes(row))

    compressed = zlib.compress(b"".join(raw_parts), 9)

    signature = b"\x89PNG\r\n\x1a\n"
    # 8 bpp, tipo 2 = RGB truecolor
    ihdr_data = struct.pack(">IIBBBBB", dim, dim, 8, 2, 0, 0, 0)
    png_blob = (
        signature
        + _png_pack_chunk(b"IHDR", ihdr_data)
        + _png_pack_chunk(b"IDAT", compressed)
        + _png_pack_chunk(b"IEND", b"")
    )

    directory = os.path.dirname(out_path)
    if directory and not os.path.isdir(directory):
        try:
            os.makedirs(directory)
        except OSError:
            pass
    with open(out_path, "wb") as handle:
        handle.write(png_blob)
    return out_path


def save_qr_png_for_text(
    text: str, out_path: str, scale: int = 6, border: int = 4
) -> str:
    """Codifica texto en QR y guarda PNG. Usa ECC medio (adecuado para URLs largas)."""
    qr = QrCode.encode_text(text, QrCode.Ecc.MEDIUM)
    return write_qr_matrix_png(qr, out_path, scale=scale, border=border)
