import sys

import xbmc
import xbmcvfs


def load_scraper_module(package_name, addon_id):
    """Importa paquete scraper externo desde su carpeta lib en Kodi."""
    lib_path = xbmcvfs.translatePath(f"special://home/addons/{addon_id}/lib")
    if lib_path and lib_path not in sys.path:
        sys.path.append(lib_path)
    try:
        return __import__(package_name, fromlist=["sources"])
    except Exception as err:
        xbmc.log(
            f"[Kraken] No se pudo importar {package_name}: {err}",
            xbmc.LOGWARNING,
        )
        return None
