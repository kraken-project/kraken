# Etiquetas multiidioma para /api/json-bundle (panel web móvil).
# ES se obtiene de MOBILE_EDITABLE_FIELDS si falta entrada dedicada.

from __future__ import annotations

from urllib.parse import parse_qs

_SUPPORTED = frozenset({"es", "en", "fr", "de", "it"})

_EN: dict[str, str] = {
    "kraken_mobile_web_port": "Mobile web server port (1024–65535)",
    "sources_order_priority": "Source order (same enum as Kodi)",
    "stremio_manifest_catalog_pick": "Stremio — manifest catalog filter (JSON)",
    "stremio_catalog_named": "Stremio — named catalogs (semicolon-separated)",
    "stremio_catalog_urls": "Stremio — extra catalog URLs (comma-separated)",
    "stremio_catalog_url": "Stremio — default catalog URL",
    "stremio_torrentio_enabled": "Stremio — Torrentio enabled (true/false)",
    "stremio_torrentio_url": "Stremio — Torrentio catalog manifest JSON URL",
    "stremio_preeflix_enabled": "Stremio — Preeflix enabled (true/false)",
    "stremio_preeflix_url": "Stremio — Preeflix catalog manifest JSON URL",
    "stremio_comet_enabled": "Stremio — Comet enabled (true/false)",
    "stremio_comet_url": "Stremio — Comet catalog manifest JSON URL",
    "stremio_mediafusion_enabled": "Stremio — MediaFusion enabled (true/false)",
    "stremio_mediafusion_url": "Stremio — MediaFusion catalog manifest JSON URL",
    "stremio_aiostreams_enabled": "Stremio — AIOStreams enabled (true/false)",
    "stremio_aiostreams_url": "Stremio — AIOStreams catalog manifest JSON URL",
    "lite_link_url_2ddl": "KrakenLite — 2ddl URL",
    "lite_link_url_300mbfilms": "KrakenLite — 300mbfilms URL",
    "lite_link_url_allmoviesforyou": "KrakenLite — allmoviesforyou URL",
    "lite_link_url_anymovies": "KrakenLite — anymovies URL",
    "lite_link_url_cmovieshd": "KrakenLite — cmovieshd URL",
    "lite_link_url_databasegdriveplayer": "KrakenLite — databasegdriveplayer URL",
    "lite_link_url_dbgo": "KrakenLite — dbgo URL",
    "lite_link_url_easynews": "KrakenLite — easynews URL",
    "lite_link_url_filmxy": "KrakenLite — filmxy URL",
    "lite_link_url_furk": "KrakenLite — furk URL",
    "lite_link_url_gowatchseries": "KrakenLite — gowatchseries URL",
    "lite_link_url_maxrls": "KrakenLite — maxrls URL",
    "lite_link_url_myvideolinks": "KrakenLite — myvideolinks URL",
    "lite_link_url_onlineseries": "KrakenLite — onlineseries URL",
    "lite_link_url_ororo": "KrakenLite — ororo URL",
    "lite_link_url_rapidmoviez": "KrakenLite — rapidmoviez URL",
    "lite_link_url_rlsbb": "KrakenLite — rlsbb URL",
    "lite_link_url_scenerls": "KrakenLite — scenerls URL",
    "external_scrapers_timeout": "External scrapers timeout (enum seconds)",
    "stremio_http_timeout": "Stremio — HTTP timeout seconds (15|20|25|30|45|60)",
    "tmdb_api_key": "TMDB — API key v3",
    "omdb_api_key": "OMDb — API key",
    "metadata_priority": "Metadata priority (TMDB first | OMDb first)",
    "metadata_timeout": "Metadata timeout seconds (5|8|10|15)",
    "trakt_plot_language": "Trakt — plot/title language (Auto (Kodi)|…)",
    "trakt_results_limit": "Trakt — max results (10|20|30|50|75|100)",
    "trakt_access_token": "Trakt — access token",
    "trakt_refresh_token": "Trakt — refresh token",
    "trakt_token_expires": "Trakt — token expiry (epoch or text)",
    "trakt_account_info": "Trakt — account info (read-only backup)",
    "debrid_ad_token": "AllDebrid — token",
    "debrid_provider": "Legacy Debrid — provider name",
    "debrid_api_key": "Legacy Debrid — API key / token",
    "debrid_refresh_token": "Legacy Debrid — refresh token",
    "debrid_account_info": "Legacy Debrid — account info",
    "debrid_ad_info": "AllDebrid — account status text (backup)",
    "debrid_rg_info": "Rapidgator — status / notes",
    "provider_elementum_burst": "Torrent Burst (Elementum Burst): true/false",
    "torrent_player": "Torrent handler (same enum text as Kodi)",
    "download_movies_path": "Downloads — movies folder path",
    "download_series_path": "Downloads — TV folder path",
    "download_last_mode": "Downloads — last mode (internal)",
    "source_selector_style": "Source picker layout (Compact|Detailed|…)",
    "kraken_quality_filter_enabled": "Video quality — resolution filter on",
    "kraken_quality_allow_4k": "Quality — include 4K",
    "kraken_quality_allow_1080p": "Quality — include 1080p",
    "kraken_quality_allow_720p": "Quality — include 720p",
    "kraken_quality_allow_sd": "Quality — include SD",
    "kraken_quality_filter_allow_auto": "Quality — include Auto / unknown quality",
    "autoplay_movies_enabled": "Autoplay — movies (true/false)",
    "autoplay_series_enabled": "Autoplay — episodes (true/false)",
    "autoplay_lang_primary": "Autoplay — primary audio language",
    "autoplay_lang_secondary": "Autoplay — secondary audio language",
    "next_episode_warn_seconds": "Next episode — warning seconds",
    "opensubtitles_preferred_lang": "OpenSubtitles — preferred language",
    "opensubtitles_fallback_lang": "OpenSubtitles — fallback language",
    "debrid_expiration_notify_days": "Debrid — expiry notify days before",
    "kraken_rotate_sources_enabled": "Prefer another server on each play when multiple sources exist",
}


def _overlay(base: dict[str, str], overrides: dict[str, str]) -> dict[str, str]:
    m = dict(base)
    m.update(overrides)
    return m


# Panel web: etiquetas alineadas a _EN (sin huecos en FR/DE/IT).
_FR_OVERRIDES: dict[str, str] = {
    "kraken_mobile_web_port": "Port du serveur web mobile (1024–65535)",
    "sources_order_priority": "Ordre des sources (identique à Kodi)",
    "stremio_manifest_catalog_pick": "Stremio — filtre catalogues manifest (JSON)",
    "stremio_catalog_named": "Stremio — catalogues nommés (point-virgule)",
    "stremio_catalog_urls": "Stremio — URLs catalogues supplémentaires (virgules)",
    "stremio_catalog_url": "Stremio — URL catalogue par défaut",
    "stremio_torrentio_enabled": "Stremio — Torrentio activé (true/false)",
    "stremio_torrentio_url": "Stremio — URL manifest JSON Torrentio",
    "stremio_preeflix_enabled": "Stremio — Preeflix activé (true/false)",
    "stremio_preeflix_url": "Stremio — URL manifest JSON Preeflix",
    "stremio_comet_enabled": "Stremio — Comet activé (true/false)",
    "stremio_comet_url": "Stremio — URL manifest JSON Comet",
    "stremio_mediafusion_enabled": "Stremio — MediaFusion activé (true/false)",
    "stremio_mediafusion_url": "Stremio — URL manifest JSON MediaFusion",
    "stremio_aiostreams_enabled": "Stremio — AIOStreams activé (true/false)",
    "stremio_aiostreams_url": "Stremio — URL manifest JSON AIOStreams",
    "lite_link_url_2ddl": "KrakenLite — URL 2ddl",
    "lite_link_url_300mbfilms": "KrakenLite — URL 300mbfilms",
    "lite_link_url_allmoviesforyou": "KrakenLite — URL allmoviesforyou",
    "lite_link_url_anymovies": "KrakenLite — URL anymovies",
    "lite_link_url_cmovieshd": "KrakenLite — URL cmovieshd",
    "lite_link_url_databasegdriveplayer": "KrakenLite — URL databasegdriveplayer",
    "lite_link_url_dbgo": "KrakenLite — URL dbgo",
    "lite_link_url_easynews": "KrakenLite — URL easynews",
    "lite_link_url_filmxy": "KrakenLite — URL filmxy",
    "lite_link_url_furk": "KrakenLite — URL furk",
    "lite_link_url_gowatchseries": "KrakenLite — URL gowatchseries",
    "lite_link_url_maxrls": "KrakenLite — URL maxrls",
    "lite_link_url_myvideolinks": "KrakenLite — URL myvideolinks",
    "lite_link_url_onlineseries": "KrakenLite — URL onlineseries",
    "lite_link_url_ororo": "KrakenLite — URL ororo",
    "lite_link_url_rapidmoviez": "KrakenLite — URL rapidmoviez",
    "lite_link_url_rlsbb": "KrakenLite — URL rlsbb",
    "lite_link_url_scenerls": "KrakenLite — URL scenerls",
    "external_scrapers_timeout": "Timeout scrapers externes (secondes, énumération)",
    "stremio_http_timeout": "Stremio — timeout HTTP en secondes (15|20|25|30|45|60)",
    "tmdb_api_key": "TMDB — clé API v3",
    "omdb_api_key": "OMDb — clé API",
    "metadata_priority": "Priorité métadonnées (TMDB d'abord | OMDb d'abord)",
    "metadata_timeout": "Timeout métadonnées en secondes (5|8|10|15)",
    "trakt_plot_language": "Trakt — langue titre/synopsis (Auto (Kodi)|…)",
    "trakt_results_limit": "Trakt — résultats max (10|20|30|50|75|100)",
    "trakt_access_token": "Trakt — jeton d'accès",
    "trakt_refresh_token": "Trakt — jeton d'actualisation",
    "trakt_token_expires": "Trakt — expiration du jeton (epoch ou texte)",
    "trakt_account_info": "Trakt — infos compte (sauvegarde lecture seule)",
    "debrid_ad_token": "AllDebrid — jeton",
    "debrid_provider": "Debrid hérité — nom du fournisseur",
    "debrid_api_key": "Debrid hérité — clé API / jeton",
    "debrid_refresh_token": "Debrid hérité — jeton d'actualisation",
    "debrid_account_info": "Debrid hérité — infos compte",
    "debrid_ad_info": "AllDebrid — texte d'état du compte (sauvegarde)",
    "debrid_rg_info": "Rapidgator — état / notes",
    "provider_elementum_burst": "Torrent Burst (Elementum Burst) : true/false",
    "torrent_player": "Gestionnaire torrent (même libellé enum que Kodi)",
    "download_movies_path": "Téléchargements — dossier films",
    "download_series_path": "Téléchargements — dossier séries",
    "download_last_mode": "Téléchargements — dernier mode (interne)",
    "source_selector_style": "Présentation sélecteur de sources (Compact|Détaillé|…)",
    "kraken_quality_filter_enabled": "Vidéo — filtre de résolution actif",
    "kraken_quality_allow_4k": "Qualité — inclure 4K",
    "kraken_quality_allow_1080p": "Qualité — inclure 1080p",
    "kraken_quality_allow_720p": "Qualité — inclure 720p",
    "kraken_quality_allow_sd": "Qualité — inclure SD",
    "kraken_quality_filter_allow_auto": "Qualité — inclure Auto / qualité inconnue",
    "autoplay_movies_enabled": "Lecture auto — films (true/false)",
    "autoplay_series_enabled": "Lecture auto — épisodes (true/false)",
    "autoplay_lang_primary": "Lecture auto — langue audio principale",
    "autoplay_lang_secondary": "Lecture auto — langue audio secondaire",
    "next_episode_warn_seconds": "Épisode suivant — secondes d'avertissement",
    "opensubtitles_preferred_lang": "OpenSubtitles — langue préférée",
    "opensubtitles_fallback_lang": "OpenSubtitles — langue de secours",
    "debrid_expiration_notify_days": "Debrid — jours d'avertissement avant expiration",
    "kraken_rotate_sources_enabled": "Préférer un autre serveur à chaque lecture si plusieurs sources",
}

_DE_OVERRIDES: dict[str, str] = {
    "kraken_mobile_web_port": "Port des mobilen Webservers (1024–65535)",
    "sources_order_priority": "Quellenreihenfolge (wie in Kodi)",
    "stremio_manifest_catalog_pick": "Stremio — Manifest-Katalogfilter (JSON)",
    "stremio_catalog_named": "Stremio — benannte Kataloge (Semikolon)",
    "stremio_catalog_urls": "Stremio — zusätzliche Katalog-URLs (Komma)",
    "stremio_catalog_url": "Stremio — Standard-Katalog-URL",
    "stremio_torrentio_enabled": "Stremio — Torrentio aktiv (true/false)",
    "stremio_torrentio_url": "Stremio — Torrentio-Manifest-JSON-URL",
    "stremio_preeflix_enabled": "Stremio — Preeflix aktiv (true/false)",
    "stremio_preeflix_url": "Stremio — Preeflix-Manifest-JSON-URL",
    "stremio_comet_enabled": "Stremio — Comet aktiv (true/false)",
    "stremio_comet_url": "Stremio — Comet-Manifest-JSON-URL",
    "stremio_mediafusion_enabled": "Stremio — MediaFusion aktiv (true/false)",
    "stremio_mediafusion_url": "Stremio — MediaFusion-Manifest-JSON-URL",
    "stremio_aiostreams_enabled": "Stremio — AIOStreams aktiv (true/false)",
    "stremio_aiostreams_url": "Stremio — AIOStreams-Manifest-JSON-URL",
    "lite_link_url_2ddl": "KrakenLite — URL 2ddl",
    "lite_link_url_300mbfilms": "KrakenLite — URL 300mbfilms",
    "lite_link_url_allmoviesforyou": "KrakenLite — URL allmoviesforyou",
    "lite_link_url_anymovies": "KrakenLite — URL anymovies",
    "lite_link_url_cmovieshd": "KrakenLite — URL cmovieshd",
    "lite_link_url_databasegdriveplayer": "KrakenLite — URL databasegdriveplayer",
    "lite_link_url_dbgo": "KrakenLite — URL dbgo",
    "lite_link_url_easynews": "KrakenLite — URL easynews",
    "lite_link_url_filmxy": "KrakenLite — URL filmxy",
    "lite_link_url_furk": "KrakenLite — URL furk",
    "lite_link_url_gowatchseries": "KrakenLite — URL gowatchseries",
    "lite_link_url_maxrls": "KrakenLite — URL maxrls",
    "lite_link_url_myvideolinks": "KrakenLite — URL myvideolinks",
    "lite_link_url_onlineseries": "KrakenLite — URL onlineseries",
    "lite_link_url_ororo": "KrakenLite — URL ororo",
    "lite_link_url_rapidmoviez": "KrakenLite — URL rapidmoviez",
    "lite_link_url_rlsbb": "KrakenLite — URL rlsbb",
    "lite_link_url_scenerls": "KrakenLite — URL scenerls",
    "external_scrapers_timeout": "Timeout externe Scraper (Sekunden, Aufzählung)",
    "stremio_http_timeout": "Stremio — HTTP-Timeout in Sekunden (15|20|25|30|45|60)",
    "tmdb_api_key": "TMDB — API-Schlüssel v3",
    "omdb_api_key": "OMDb — API-Schlüssel",
    "metadata_priority": "Metadaten-Priorität (TMDB zuerst | OMDb zuerst)",
    "metadata_timeout": "Metadaten-Timeout in Sekunden (5|8|10|15)",
    "trakt_plot_language": "Trakt — Sprache Titel/Plot (Auto (Kodi)|…)",
    "trakt_results_limit": "Trakt — max. Ergebnisse (10|20|30|50|75|100)",
    "trakt_access_token": "Trakt — Zugriffstoken",
    "trakt_refresh_token": "Trakt — Aktualisierungstoken",
    "trakt_token_expires": "Trakt — Token-Ablauf (Epoch oder Text)",
    "trakt_account_info": "Trakt — Kontoinfo (Nur-Lesen-Backup)",
    "debrid_ad_token": "AllDebrid — Token",
    "debrid_provider": "Legacy Debrid — Anbietername",
    "debrid_api_key": "Legacy Debrid — API-Schlüssel / Token",
    "debrid_refresh_token": "Legacy Debrid — Aktualisierungstoken",
    "debrid_account_info": "Legacy Debrid — Kontoinfo",
    "debrid_ad_info": "AllDebrid — Kontostatus-Text (Backup)",
    "debrid_rg_info": "Rapidgator — Status / Notizen",
    "provider_elementum_burst": "Torrent Burst (Elementum Burst): true/false",
    "torrent_player": "Torrent-Handler (gleicher Enum-Text wie Kodi)",
    "download_movies_path": "Downloads — Ordner Filme",
    "download_series_path": "Downloads — Ordner Serien",
    "download_last_mode": "Downloads — letzter Modus (intern)",
    "source_selector_style": "Quellenwahl-Layout (Kompakt|Detailliert|…)",
    "kraken_quality_filter_enabled": "Video — Auflösungsfilter aktiv",
    "kraken_quality_allow_4k": "Qualität — 4K einschließen",
    "kraken_quality_allow_1080p": "Qualität — 1080p einschließen",
    "kraken_quality_allow_720p": "Qualität — 720p einschließen",
    "kraken_quality_allow_sd": "Qualität — SD einschließen",
    "kraken_quality_filter_allow_auto": "Qualität — Auto / unbekannte Qualität einschließen",
    "autoplay_movies_enabled": "Autoplay — Filme (true/false)",
    "autoplay_series_enabled": "Autoplay — Episoden (true/false)",
    "autoplay_lang_primary": "Autoplay — primäre Audiospur",
    "autoplay_lang_secondary": "Autoplay — sekundäre Audiospur",
    "next_episode_warn_seconds": "Nächste Folge — Warnsekunden",
    "opensubtitles_preferred_lang": "OpenSubtitles — bevorzugte Sprache",
    "opensubtitles_fallback_lang": "OpenSubtitles — Ersatzsprache",
    "debrid_expiration_notify_days": "Debrid — Tage vor Ablaufwarnung",
    "kraken_rotate_sources_enabled": "Bei mehreren Quellen anderen Server pro Wiedergabe bevorzugen",
}

_IT_OVERRIDES: dict[str, str] = {
    "kraken_mobile_web_port": "Porta server web mobile (1024–65535)",
    "sources_order_priority": "Ordine fonti (come in Kodi)",
    "stremio_manifest_catalog_pick": "Stremio — filtro cataloghi manifest (JSON)",
    "stremio_catalog_named": "Stremio — cataloghi nominati (punto e virgola)",
    "stremio_catalog_urls": "Stremio — URL cataloghi extra (virgole)",
    "stremio_catalog_url": "Stremio — URL catalogo predefinito",
    "stremio_torrentio_enabled": "Stremio — Torrentio attivo (true/false)",
    "stremio_torrentio_url": "Stremio — URL manifest JSON Torrentio",
    "stremio_preeflix_enabled": "Stremio — Preeflix attivo (true/false)",
    "stremio_preeflix_url": "Stremio — URL manifest JSON Preeflix",
    "stremio_comet_enabled": "Stremio — Comet attivo (true/false)",
    "stremio_comet_url": "Stremio — URL manifest JSON Comet",
    "stremio_mediafusion_enabled": "Stremio — MediaFusion attivo (true/false)",
    "stremio_mediafusion_url": "Stremio — URL manifest JSON MediaFusion",
    "stremio_aiostreams_enabled": "Stremio — AIOStreams attivo (true/false)",
    "stremio_aiostreams_url": "Stremio — URL manifest JSON AIOStreams",
    "lite_link_url_2ddl": "KrakenLite — URL 2ddl",
    "lite_link_url_300mbfilms": "KrakenLite — URL 300mbfilms",
    "lite_link_url_allmoviesforyou": "KrakenLite — URL allmoviesforyou",
    "lite_link_url_anymovies": "KrakenLite — URL anymovies",
    "lite_link_url_cmovieshd": "KrakenLite — URL cmovieshd",
    "lite_link_url_databasegdriveplayer": "KrakenLite — URL databasegdriveplayer",
    "lite_link_url_dbgo": "KrakenLite — URL dbgo",
    "lite_link_url_easynews": "KrakenLite — URL easynews",
    "lite_link_url_filmxy": "KrakenLite — URL filmxy",
    "lite_link_url_furk": "KrakenLite — URL furk",
    "lite_link_url_gowatchseries": "KrakenLite — URL gowatchseries",
    "lite_link_url_maxrls": "KrakenLite — URL maxrls",
    "lite_link_url_myvideolinks": "KrakenLite — URL myvideolinks",
    "lite_link_url_onlineseries": "KrakenLite — URL onlineseries",
    "lite_link_url_ororo": "KrakenLite — URL ororo",
    "lite_link_url_rapidmoviez": "KrakenLite — URL rapidmoviez",
    "lite_link_url_rlsbb": "KrakenLite — URL rlsbb",
    "lite_link_url_scenerls": "KrakenLite — URL scenerls",
    "external_scrapers_timeout": "Timeout scraper esterni (secondi, enum)",
    "stremio_http_timeout": "Stremio — timeout HTTP in secondi (15|20|25|30|45|60)",
    "tmdb_api_key": "TMDB — chiave API v3",
    "omdb_api_key": "OMDb — chiave API",
    "metadata_priority": "Priorità metadati (TMDB prima | OMDb prima)",
    "metadata_timeout": "Timeout metadati in secondi (5|8|10|15)",
    "trakt_plot_language": "Trakt — lingua titolo/trama (Auto (Kodi)|…)",
    "trakt_results_limit": "Trakt — risultati massimi (10|20|30|50|75|100)",
    "trakt_access_token": "Trakt — token di accesso",
    "trakt_refresh_token": "Trakt — token di aggiornamento",
    "trakt_token_expires": "Trakt — scadenza token (epoch o testo)",
    "trakt_account_info": "Trakt — info account (backup sola lettura)",
    "debrid_ad_token": "AllDebrid — token",
    "debrid_provider": "Debrid legacy — nome provider",
    "debrid_api_key": "Debrid legacy — chiave API / token",
    "debrid_refresh_token": "Debrid legacy — token di aggiornamento",
    "debrid_account_info": "Debrid legacy — info account",
    "debrid_ad_info": "AllDebrid — testo stato account (backup)",
    "debrid_rg_info": "Rapidgator — stato / note",
    "provider_elementum_burst": "Torrent Burst (Elementum Burst): true/false",
    "torrent_player": "Gestore torrent (stesso testo enum di Kodi)",
    "download_movies_path": "Download — cartella film",
    "download_series_path": "Download — cartella serie TV",
    "download_last_mode": "Download — ultima modalità (interno)",
    "source_selector_style": "Layout selettore fonti (Compatto|Dettagliato|…)",
    "kraken_quality_filter_enabled": "Video — filtro risoluzione attivo",
    "kraken_quality_allow_4k": "Qualità — includi 4K",
    "kraken_quality_allow_1080p": "Qualità — includi 1080p",
    "kraken_quality_allow_720p": "Qualità — includi 720p",
    "kraken_quality_allow_sd": "Qualità — includi SD",
    "kraken_quality_filter_allow_auto": "Qualità — includi Auto / qualità sconosciuta",
    "autoplay_movies_enabled": "Riproduzione automatica — film (true/false)",
    "autoplay_series_enabled": "Riproduzione automatica — episodi (true/false)",
    "autoplay_lang_primary": "Riproduzione automatica — lingua audio principale",
    "autoplay_lang_secondary": "Riproduzione automatica — lingua audio secondaria",
    "next_episode_warn_seconds": "Prossimo episodio — secondi di avviso",
    "opensubtitles_preferred_lang": "OpenSubtitles — lingua preferita",
    "opensubtitles_fallback_lang": "OpenSubtitles — lingua di riserva",
    "debrid_expiration_notify_days": "Debrid — giorni di preavviso scadenza",
    "kraken_rotate_sources_enabled": "Preferire un altro server a ogni riproduzione se ci sono più fonti",
}

_FR = _overlay(_EN, _FR_OVERRIDES)
_DE = _overlay(_EN, _DE_OVERRIDES)
_IT = _overlay(_EN, _IT_OVERRIDES)


def _spanish_from_server(sid: str) -> str:
    from resources.lib.core.kraken_mobile_config_server import MOBILE_EDITABLE_FIELDS

    for a, b in MOBILE_EDITABLE_FIELDS:
        if a == sid:
            return str(b)
    return sid


def mobile_field_label(sid: str, lang: str | None) -> str:
    lc = (lang or "en").strip().lower()[:2]
    if lc not in _SUPPORTED:
        lc = "en"
    en = _EN.get(sid) or _spanish_from_server(sid)
    if lc == "en":
        return en
    if lc == "es":
        return _spanish_from_server(sid)
    if lc == "fr":
        return _FR.get(sid) or en
    if lc == "de":
        return _DE.get(sid) or en
    if lc == "it":
        return _IT.get(sid) or en
    return en


def normalize_request_lang(query_string: str, header_accept_language: str | None) -> str:
    """?lang=xx tiene prioridad; si no, primera etiqueta Accept-Language."""
    if query_string:
        try:
            q = parse_qs(query_string, keep_blank_values=False)
            langs = q.get("lang") or []
            if langs:
                return str(langs[0]).strip().lower()[:2]
        except Exception:
            pass
    if header_accept_language:
        part = header_accept_language.split(",")[0].strip().split(";")[0].strip()
        if len(part) >= 2:
            return part[:2].lower()
    return "en"
