"""Heuristica Kraken para elegir el archivo dentro de torrents tipo pack (serie)."""

import os
import re
from urllib.parse import unquote

_VIDEO_SUFFIXES = (".mkv", ".mp4", ".avi", ".webm", ".m4v", ".mov", ".mpg", ".mpeg", ".wmv")

_EXTRA_SUBSTRINGS = (
    ".sample.",
    "sample.mp4",
    "sample.mkv",
    "/sample/",
    " trailer",
    ".trailer.",
    "/extras/",
    "deleted.scenes",
    "behind.the.scenes",
    "making.of",
    "featurette",
    "bloopers",
)


def _basename_lower(path):
    raw = unquote(str(path or "")).strip()
    raw = raw.replace("\\", "/").rsplit("/", 1)[-1]
    return raw.lower()


def torrent_path_extra_like(path):
    b = _basename_lower(path)
    return any(tok in b for tok in _EXTRA_SUBSTRINGS)


def _looks_video_path(path):
    return any(_basename_lower(path).endswith(ext) for ext in _VIDEO_SUFFIXES)


def torrent_paths_match_series_episode(season, episode, path):
    """
    Comprueba si el nombre encaja en patrones habituales (SxxEyy, Variante, etc.).
    """
    try:
        s_num = int(season)
        e_num = int(episode)
    except (TypeError, ValueError):
        return False
    hay = _basename_lower(path)
    hay = hay.replace("&", ".and.")
    hay = os.path.basename(hay)

    ef2 = "{:02d}".format(e_num)
    ef3 = "{:03d}".format(e_num)
    variants_s = sorted(
        {"{:d}".format(s_num), "{:02d}".format(s_num)},
        key=len,
        reverse=True,
    )
    needles = []

    def _add(pat):
        if pat not in needles:
            needles.append(pat)

    for sv in variants_s:
        sf2 = str(sv).zfill(2)
        _add(
            r"s{}(\.|_|-| )?e(?:0*{}|{})\b".format(
                re.escape(sf2),
                int(e_num),
                re.escape(ef2),
            )
        )
        _add(r"s{}(\.|_|-| )?e{:s}\b".format(re.escape(sf2), re.escape(ef3)))

    ex = ef2.lstrip("0") or "0"
    _add(r"\b{:d}(\.|x|_){}\b".format(s_num, re.escape(ex)))
    _add(r"\bseason\.?{:d}(\.|_|-).*episode\.?{}\b".format(s_num, re.escape(ex)))
    _add(r"\bseason\.{:d}(\.|_|-).*ep\.{:d}\b".format(s_num, int(ex)))
    low = hay
    try:
        for pat in needles:
            if re.search(pat, low, re.IGNORECASE):
                return True
    except re.error:
        return False
    return False


def _norm_slug_title(title):
    t = unquote(str(title or "")).lower()
    t = re.sub(r"[^a-z0-9\-]+", ".", t.strip().replace("&", ".and."), flags=re.UNICODE).strip(".")
    if len(t) < 3:
        return ""
    return t


def _remainder_after_episode_match(season, episode, path):
    """Quita desde SxxExx en adelante (slug) para filtrar extras colgando del mismo nombre."""
    try:
        s_num = int(season)
        e_num = int(episode)
    except (TypeError, ValueError):
        return ""
    b = _basename_lower(path).replace("&", ".and.")
    variants_s = sorted(
        {"{:d}".format(s_num), "{:02d}".format(s_num)},
        key=len,
        reverse=True,
    )
    ef = "{:02d}".format(e_num)
    for sv in variants_s:
        sf2 = sv.zfill(2)
        rx = r"(?i)s{:s}(\.|_|-| )?e({:s}|{:s})\b".format(
            re.escape(sf2),
            re.escape(ef),
            str(e_num),
        )
        m = re.search(rx, b)
        if m:
            return b[m.end() :]

    mx = r"(?i)\b{:d}(\.|x|_){}\b".format(s_num, re.escape(ef))
    m = re.search(mx, b)
    if m:
        return b[m.end() :]
    return ""


def remainder_suggests_extras_fragment(season, episode, ep_title_slug, path):
    """Igual espiritu Umbrella extras_filter tras quitar temporada/ep."""
    slug = ep_title_slug or ""
    remainder = _remainder_after_episode_match(season, episode, path)
    if slug and remainder.startswith("." + slug[: min(80, len(slug))]):
        remainder = remainder[len(slug) + 1 :]
        if len(remainder) < 6:
            return False

    lowered = remainder
    suspects = ("sample", "trailer", "extra", "featurette")
    return any(x in lowered for x in suspects)


def pick_ordered_video_selection(files):
    """
    Lista de dicts archivo torrent (solo selected=1 y extension video),
    mismo orden estable que espera paralelo ``links``.
    """
    out = []
    for f in files or []:
        if not isinstance(f, dict):
            continue
        try:
            if int(f.get("selected") or 0) != 1:
                continue
        except (TypeError, ValueError):
            continue
        path = str(f.get("path") or f.get("filename") or "")
        if not _looks_video_path(path):
            continue
        out.append(f)
    return out


def choose_pack_video_file_for_playback(video_files, playback):
    """
    video_files: lista ordenada igual que enlaces disponibles para desrestringir.

    playback: dict con season (int/str), episode, ep_title (opcional para series).
    """
    pb = playback or {}
    seas = pb.get("season")
    eps = pb.get("episode")

    prefer_episode = seas is not None and eps is not None
    try:
        s_i = int(seas)
        e_i = int(eps)
    except (TypeError, ValueError):
        prefer_episode = False

    ep_slug = _norm_slug_title(pb.get("ep_title"))

    weighted = []
    for f in video_files:
        path = str(f.get("path") or f.get("filename") or "")
        try:
            size = int(f.get("bytes") or f.get("s") or 0)
        except (TypeError, ValueError):
            size = 0
        weighted.append((size, path, f))

    if not weighted:
        return None

    if prefer_episode:
        matches = []
        for sz, path, f in weighted:
            if torrent_path_extra_like(path):
                continue
            if not torrent_paths_match_series_episode(s_i, e_i, path):
                continue
            if remainder_suggests_extras_fragment(s_i, e_i, ep_slug, path):
                continue
            matches.append((sz, path, f))
        matches.sort(key=lambda x: x[0], reverse=True)
        if matches:
            return matches[0][2]

    weighted.sort(key=lambda x: x[0], reverse=True)
    return weighted[0][2]


def index_of_file_in_ordered_list(chosen_file, ordered):
    """Indice dentro de lista de archivos reproducibles (solo si identidad objeto/camino coincide)."""
    if not chosen_file:
        return -1
    want = chosen_file.get("path") or chosen_file.get("filename")
    want_s = str(want or "").strip()
    if not want_s:
        return -1
    for idx, item in enumerate(ordered):
        cand = item.get("path") or item.get("filename") or ""
        if str(cand or "").strip() == want_s:
            return idx
    return -1


def choose_alldebrid_leaf_for_playback(flat_entries, playback):
    """
    flat_entries: resultado _ad_flatten_file_tree [{n,l,s,...}, ...]
    playback: dict season / episode opcional.

    Sin season/episode: mayor tamaño entre enlaces ``l`` parecidos a video.
    """
    cand = []
    for node in flat_entries or []:
        if not isinstance(node, dict):
            continue
        name = str(node.get("n") or "")
        link = str(node.get("l") or "").strip()
        if not link or not name:
            continue
        if not any(name.lower().endswith(ext) for ext in _VIDEO_SUFFIXES):
            continue
        try:
            sz = int(node.get("s") or 0)
        except (TypeError, ValueError):
            sz = 0
        cand.append((sz, name, node))

    if not cand:
        return None

    pb = playback or {}
    seas = pb.get("season")
    eps = pb.get("episode")
    prefer_episode = seas is not None and eps is not None
    try:
        s_i = int(seas)
        e_i = int(eps)
    except (TypeError, ValueError):
        prefer_episode = False

    ep_slug = _norm_slug_title(pb.get("ep_title"))

    if prefer_episode:
        good = []
        for sz, name, node in cand:
            if torrent_path_extra_like(name):
                continue
            if not torrent_paths_match_series_episode(s_i, e_i, name):
                continue
            if remainder_suggests_extras_fragment(s_i, e_i, ep_slug, name):
                continue
            good.append((sz, node))
        good.sort(key=lambda x: x[0], reverse=True)
        if good:
            return good[0][1]

    cand.sort(key=lambda x: x[0], reverse=True)
    return cand[0][2]
