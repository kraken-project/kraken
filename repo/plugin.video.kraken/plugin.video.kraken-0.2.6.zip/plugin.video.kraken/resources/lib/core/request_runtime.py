def play_result_id_from_request_bridge(
    *, result_id_path, route_play_result_id_from_request, plugin_args
):
    return route_play_result_id_from_request(result_id_path, plugin_args or {})


def query_arg_first_str_bridge(*, route_query_arg_first_str, plugin_args, candidates):
    return route_query_arg_first_str(plugin_args or {}, *candidates)
