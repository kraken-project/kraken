"""Invoca Torrent Burst (script.elementum.burst) desde Kraken.

Burst depende del paquete Python de plugin.video.elementum; hay que ajustar
elementum.addon.ADDON al addon de Burst antes de importar burst.burst.
"""

import os
import re
import sys

import xbmc
import xbmcaddon
import xbmcvfs

BURST_ADDON_ID = "script.elementum.burst"
ELEMENTUM_ADDON_ID = "plugin.video.elementum"
KODI_SIX_ADDON_ID = "script.module.kodi-six"
FUTURE_ADDON_ID = "script.module.future"

_COLOR_TAG = re.compile(r"\[/?COLOR(?:\s+[^\]]*)?\]", re.IGNORECASE)


def _strip_kodi_color(text):
    return _COLOR_TAG.sub("", str(text or "")).strip()


def _ensure_sys_path():
    burst_root = xbmcvfs.translatePath(f"special://home/addons/{BURST_ADDON_ID}")
    elem_root = xbmcvfs.translatePath(f"special://home/addons/{ELEMENTUM_ADDON_ID}")
    kodi_six_libs = os.path.join(
        xbmcvfs.translatePath(f"special://home/addons/{KODI_SIX_ADDON_ID}"),
        "libs",
    )
    future_lib = xbmcvfs.translatePath(f"special://home/addons/{FUTURE_ADDON_ID}/lib")
    for rel in (
        kodi_six_libs,
        future_lib,
        os.path.join(elem_root, "resources", "site-packages"),
        os.path.join(burst_root, "resources", "site-packages"),
        burst_root,
    ):
        p = os.path.normpath(rel)
        if os.path.isdir(p) and p not in sys.path:
            sys.path.insert(0, p)


def _patch_elementum_addon_to_burst():
    import elementum.addon as ea

    addon = xbmcaddon.Addon(BURST_ADDON_ID)
    ea.ADDON = addon
    ea.ADDON_ID = addon.getAddonInfo("id")
    ea.ADDON_NAME = addon.getAddonInfo("name")
    ea.ADDON_ICON = addon.getAddonInfo("icon")
    ea.ADDON_VERSION = addon.getAddonInfo("version")


def elementum_burst_import_ok():
    try:
        _ensure_sys_path()
        _patch_elementum_addon_to_burst()
        from burst.burst import search  # noqa: F401
    except Exception as err:
        xbmc.log(f"[Kraken] Torrent Burst import: {err}", xbmc.LOGDEBUG)
        return False
    return True


def _burst_payload_movie(title, year, imdb_id):
    t = str(title or "").strip()
    y = str(year or "").strip()
    imdb = str(imdb_id or "").strip()
    return {
        "title": t,
        "titles": {"source": t, "original": t},
        "year": y,
        "imdb_id": imdb,
        "silent": True,
        "skip_auth": False,
    }


def _burst_payload_episode(tvshowtitle, year, imdb_id, season, episode):
    show = str(tvshowtitle or "").strip()
    y = str(year or "").strip()
    imdb = str(imdb_id or "").strip()
    return {
        "title": "Episodio",
        "titles": {"source": show, "original": show},
        "year": y,
        "season": int(season or 1),
        "episode": int(episode or 1),
        "imdb_id": imdb,
        "silent": True,
        "skip_auth": False,
    }


def run_burst_search(
    *, media_type, title, year, imdb_id, season=None, episode=None, tvshowtitle=None
):
    """Devuelve la lista de dicts que devuelve burst.burst.search (formato Burst estándar)."""
    _ensure_sys_path()
    _patch_elementum_addon_to_burst()
    from burst.burst import search

    if media_type == "series":
        payload = _burst_payload_episode(
            tvshowtitle or title, year, imdb_id, season, episode
        )
        return search(payload, "episode") or []
    payload = _burst_payload_movie(title, year, imdb_id)
    return search(payload, "movie") or []


def elementum_burst_to_kraken_candidates(
    raw_results, *, normalize_language_label, is_playable_stream_url, seen
):
    out = []
    for raw in raw_results or []:
        if not isinstance(raw, dict):
            continue
        uri = str(raw.get("uri") or "").strip().split("|")[0].strip()
        if not uri or uri in seen or not is_playable_stream_url(uri):
            continue
        seen.add(uri)
        name = _strip_kodi_color(raw.get("name") or "Torrent")
        prov = _strip_kodi_color(raw.get("provider") or "Burst")
        qual = str(raw.get("size") or "Auto").strip() or "Auto"
        lang_code = str(raw.get("language") or "").strip() or None
        out.append(
            {
                "url": uri,
                "label": name,
                "title": name,
                "quality": qual,
                "language": normalize_language_label(
                    lang_code,
                    provider_name=prov,
                    label=name,
                    title=name,
                    info="",
                    stream_url=uri,
                ),
                "origin": f"Burst {prov}",
            }
        )
    return out
