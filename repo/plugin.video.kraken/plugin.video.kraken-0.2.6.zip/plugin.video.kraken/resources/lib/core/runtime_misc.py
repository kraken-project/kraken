import xbmcgui

from resources.lib.ui.ui_helpers import _t


def omdb_external_ratings_label2_extra(
    *, rotten, metacritic, imdb_omdb, omdb_external_ratings_enabled
):
    """OMDb: Rotten / Metacritic / IMDb (si la plan API y el ajuste lo permiten)."""
    if not omdb_external_ratings_enabled():
        return ""
    parts = []
    if rotten:
        parts.append(f"[COLOR FFEB3B]RT: {str(rotten).strip()}[/COLOR]")
    if metacritic:
        parts.append(f"[COLOR 80CBC4]MC: {str(metacritic).strip()}[/COLOR]")
    if imdb_omdb:
        parts.append(f"[COLOR B0BEC5]IMDb: {str(imdb_omdb).strip()}[/COLOR]")
    if not parts:
        return ""
    return "  " + "  ".join(parts)


def resolve_trakt_result_bridge(
    *,
    result_id,
    collect_sources,
    progress_cb,
    progress_started_at,
    resolve_trakt_result_impl,
    search_result_cache,
    trakt_public_get,
    get_enabled_providers,
    clean_title,
    resolver_progress_phase,
    resolver_progress_detail,
    stremio_source_is_tv_only,
    is_playable_stream_url,
    get_bool_setting,
    get_setting,
    external_scraper_candidates,
    web_link_provider_candidates,
    source_label,
):
    return resolve_trakt_result_impl(
        result_id,
        collect_sources=collect_sources,
        progress_cb=progress_cb,
        progress_started_at=progress_started_at,
        search_result_cache=search_result_cache,
        trakt_public_get=trakt_public_get,
        get_enabled_providers=get_enabled_providers,
        clean_title=clean_title,
        resolver_progress_phase=resolver_progress_phase,
        resolver_progress_detail=resolver_progress_detail,
        stremio_source_is_tv_only=stremio_source_is_tv_only,
        is_playable_stream_url=is_playable_stream_url,
        get_bool_setting=get_bool_setting,
        get_setting=get_setting,
        external_scraper_candidates=external_scraper_candidates,
        web_link_provider_candidates=web_link_provider_candidates,
        source_label=source_label,
    )


def resolve_trakt_episode_stream_bridge(
    *,
    show_trakt_id,
    season,
    episode,
    collect_sources,
    progress_cb,
    progress_started_at,
    context_label,
    resolve_trakt_episode_stream_impl,
    trakt_public_get,
    get_enabled_providers,
    resolver_progress_phase,
    resolver_progress_detail,
    stremio_source_is_tv_only,
    is_playable_stream_url,
    get_bool_setting,
    get_setting,
    external_scraper_candidates,
    web_link_provider_candidates,
):
    return resolve_trakt_episode_stream_impl(
        show_trakt_id,
        season,
        episode,
        collect_sources=collect_sources,
        progress_cb=progress_cb,
        progress_started_at=progress_started_at,
        context_label=context_label,
        trakt_public_get=trakt_public_get,
        get_enabled_providers=get_enabled_providers,
        resolver_progress_phase=resolver_progress_phase,
        resolver_progress_detail=resolver_progress_detail,
        stremio_source_is_tv_only=stremio_source_is_tv_only,
        is_playable_stream_url=is_playable_stream_url,
        get_bool_setting=get_bool_setting,
        get_setting=get_setting,
        external_scraper_candidates=external_scraper_candidates,
        web_link_provider_candidates=web_link_provider_candidates,
    )


def show_debrid_activation_help(provider_name):
    help_urls = {
        "AllDebrid": "https://alldebrid.com/pin",
    }
    url = help_urls.get(provider_name, "")
    if url:
        xbmcgui.Dialog().ok(
            "Kraken - Debrid",
            _t(
                "Para {p} abre:\n{u}\n\nDespues pega el token/API key.",
                "For {p} open:\n{u}\n\nThen paste the token/API key.",
                "Pour {p} ouvre :\n{u}\n\nColle ensuite le jeton / cle API.",
                "Per {p} apri:\n{u}\n\nPoi incolla token/API key.",
                "Fuer {p} oeffnen:\n{u}\n\nDann Token/API-Key einfuegen.",
            ).format(p=provider_name, u=url),
        )
    else:
        xbmcgui.Dialog().ok(
            "Kraken - Debrid",
            _t(
                "Selecciona un proveedor Debrid primero.",
                "Select a Debrid provider first.",
                "Choisis d'abord un fournisseur Debrid.",
                "Seleziona prima un provider Debrid.",
                "Waehle zuerst einen Debrid-Anbieter.",
            ),
        )


def external_scraper_candidates_bridge(
    *,
    title,
    year,
    imdb_id,
    media_type,
    season,
    episode,
    tvshowtitle,
    preferred_engine,
    progress_cb,
    external_scraper_candidates_impl,
    external_scrapers_timeout,
    get_bool_setting,
    addon_installed,
    load_scraper_module,
    is_playable_stream_url,
    normalize_language_label,
):
    return external_scraper_candidates_impl(
        title,
        year,
        imdb_id,
        media_type=media_type,
        season=season,
        episode=episode,
        tvshowtitle=tvshowtitle,
        preferred_engine=preferred_engine,
        progress_cb=progress_cb,
        external_scrapers_timeout=external_scrapers_timeout,
        get_bool_setting=get_bool_setting,
        addon_installed=addon_installed,
        load_scraper_module=load_scraper_module,
        is_playable_stream_url=is_playable_stream_url,
        normalize_language_label=normalize_language_label,
    )
