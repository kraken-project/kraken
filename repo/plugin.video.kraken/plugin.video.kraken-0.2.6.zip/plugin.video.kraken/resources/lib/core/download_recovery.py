"""Cola persistente: reintentar descargas HTTP si Kodi se cerro antes de terminar."""

import hashlib
import json
import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.kraken"
_QUEUE_NAME = "downloads_recovery_queue.json"
_VERSION = 1
_MAX_ITEMS = 40
_MAX_ATTEMPTS = 6
_MAX_AGE_SEC = 72 * 3600
_MIN_DONE_BYTES = 2048


def _profile_dir():
    try:
        add = xbmcaddon.Addon(ADDON_ID)
        prof = add.getAddonInfo("profile")
        base = xbmcvfs.translatePath(prof) if prof else ""
    except Exception:
        base = ""
    if base and not os.path.isdir(base):
        try:
            os.makedirs(base, exist_ok=True)
        except OSError:
            return ""
    return base


def _queue_path():
    base = _profile_dir()
    return os.path.join(base, _QUEUE_NAME) if base else ""


def recovery_enabled():
    try:
        return bool(
            xbmcaddon.Addon(ADDON_ID).getSettingBool("download_recovery_on_startup")
        )
    except Exception:
        pass
    try:
        return (
            xbmcaddon.Addon(ADDON_ID).getSetting("download_recovery_on_startup")
            or "true"
        ).lower() == "true"
    except Exception:
        return True


def _load():
    path = _queue_path()
    if not path or not os.path.isfile(path):
        return {"version": _VERSION, "items": []}
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict) and isinstance(data.get("items"), list):
            return data
    except Exception as err:
        xbmc.log(f"[Kraken][recovery] read: {err}", xbmc.LOGDEBUG)
    return {"version": _VERSION, "items": []}


def _save(data):
    path = _queue_path()
    if not path:
        return False
    try:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=True, indent=0)
        try:
            if os.path.isfile(path):
                os.remove(path)
        except OSError:
            pass
        os.replace(tmp, path)
        return True
    except Exception as err:
        xbmc.log(f"[Kraken][recovery] save: {err}", xbmc.LOGWARNING)
        return False


def _item_id(url, target):
    raw = "{}|{}".format(str(url or "").strip(), str(target or "").strip())
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]


def _target_already_complete(target_special):
    try:
        p = xbmcvfs.translatePath(str(target_special or "").strip())
    except Exception:
        p = str(target_special or "").strip()
    if not p:
        return False
    try:
        return os.path.isfile(p) and os.path.getsize(p) >= _MIN_DONE_BYTES
    except OSError:
        return False


def register_pending_http_download(
    url, target, heading, message, journal_title, journal_kind
):
    """Guarda la descarga para reintentarla al arrancar Kodi. Devuelve id o ''."""
    if not recovery_enabled():
        return ""
    base = str(url or "").strip().split("|", 1)[0].strip()
    if not base.startswith(("http://", "https://")):
        return ""
    tid = _item_id(url, target)
    k = str(journal_kind or "series").strip().lower()
    if k not in ("movie", "series", "anime"):
        k = "series"
    entry = {
        "id": tid,
        "url": str(url or "").strip(),
        "target": str(target or "").strip(),
        "heading": str(heading or "Kraken")[:120],
        "message": str(message or "")[:200],
        "journal_title": str(journal_title or "").strip(),
        "journal_kind": k,
        "attempts": 0,
        "ts": time.time(),
    }
    if not entry["url"] or not entry["target"]:
        return ""
    data = _load()
    items = [
        x
        for x in (data.get("items") or [])
        if isinstance(x, dict) and x.get("id") != tid
    ]
    items.insert(0, entry)
    data["items"] = items[:_MAX_ITEMS]
    data["version"] = _VERSION
    if _save(data):
        return tid
    return ""


def discard_pending(download_id):
    if not download_id:
        return
    data = _load()
    items = [
        x
        for x in (data.get("items") or [])
        if str((x or {}).get("id") or "") != str(download_id)
    ]
    if len(items) != len(data.get("items") or []):
        data["items"] = items
        _save(data)


def _prune_loaded(data):
    now = time.time()
    kept = []
    for x in data.get("items") or []:
        if not isinstance(x, dict):
            continue
        try:
            ts = float(x.get("ts") or 0)
        except (TypeError, ValueError):
            ts = 0.0
        if ts and (now - ts) > _MAX_AGE_SEC:
            continue
        kept.append(x)
    data["items"] = kept


def _persist_attempts_update(data):
    _save(data)


def run_pending_downloads_recovery():
    """Ejecutar desde service.py (hilo aparte): reintenta HTTP pendientes."""
    if not recovery_enabled():
        return
    data = _load()
    _prune_loaded(data)
    _save(data)
    items = list(data.get("items") or [])
    for it in items:
        if isinstance(it, dict) and _target_already_complete(it.get("target")):
            discard_pending(str(it.get("id") or ""))
    data = _load()
    items = list(data.get("items") or [])
    if not items:
        return

    try:
        from resources.lib.core.download_journal import append_entry
        from resources.lib.routes.download_routes import _save_stream_url_to_local
    except Exception as ex:
        xbmc.log(f"[Kraken][recovery] import: {ex}", xbmc.LOGWARNING)
        return

    try:
        xbmcgui.Dialog().notification(
            "Kraken",
            f"Reanudando {len(items)} descarga(s) HTTP…",
            xbmcgui.NOTIFICATION_INFO,
            6500,
        )
    except Exception:
        pass

    bg = None
    try:
        bg = xbmcgui.DialogProgressBG()
        bg.create("Kraken — Reanudar descargas", "")
    except Exception:
        bg = None

    total = len(items)
    for i, it in enumerate(items):
        tid = str((it or {}).get("id") or "").strip()
        url = str((it or {}).get("url") or "").strip()
        target = str((it or {}).get("target") or "").strip()
        heading = str((it or {}).get("heading") or "Kraken")
        message = str((it or {}).get("message") or "")
        jt = str((it or {}).get("journal_title") or "").strip()
        jk = str((it or {}).get("journal_kind") or "series").strip().lower()
        if jk not in ("movie", "series", "anime"):
            jk = "series"
        try:
            att = int((it or {}).get("attempts") or 0) + 1
        except (TypeError, ValueError):
            att = 1

        if not tid or not url or not target:
            discard_pending(tid)
            continue
        if att > _MAX_ATTEMPTS:
            xbmc.log(
                f"[Kraken][recovery] omitido (max intentos): {message[:60]}",
                xbmc.LOGINFO,
            )
            discard_pending(tid)
            continue

        pct = int(i * 100 / max(total, 1))
        if bg:
            try:
                bg.update(
                    pct,
                    heading,
                    f"{message[:90]} · intento {att}/{_MAX_ATTEMPTS}",
                )
            except Exception:
                pass

        if _target_already_complete(target):
            discard_pending(tid)
            continue

        _data = _load()
        _items = _data.get("items") or []
        for row in _items:
            if str(row.get("id")) == tid:
                row["attempts"] = att
                row["ts"] = time.time()
                break
        _persist_attempts_update(_data)

        try:
            ok, full_path, nbytes = _save_stream_url_to_local(
                url,
                target,
                heading=heading,
                message=message,
                notify=False,
            )
        except Exception as ex:
            xbmc.log(f"[Kraken][recovery] error: {ex}", xbmc.LOGWARNING)
            ok = False
            full_path, nbytes = "", 0

        if ok and full_path:
            discard_pending(tid)
            if jt:
                try:
                    append_entry(
                        path_fs=full_path, title=jt, kind=jk, bytes_size=nbytes
                    )
                except Exception:
                    pass
        else:
            xbmc.log(
                f"[Kraken][recovery] fallo, queda en cola: {message[:80]}",
                xbmc.LOGINFO,
            )

    if bg:
        try:
            bg.update(100, "Kraken", "Listo")
        except Exception:
            pass
        try:
            bg.close()
        except Exception:
            pass
