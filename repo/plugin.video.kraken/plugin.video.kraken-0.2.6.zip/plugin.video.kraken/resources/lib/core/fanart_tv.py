import json
import os
import time


def _addon_profile_dir(addon):
    try:
        profile = addon.getAddonInfo("profile")
    except Exception:
        profile = ""
    if profile.startswith("special://"):
        try:
            import xbmcvfs

            profile = xbmcvfs.translatePath(profile)
        except Exception:
            pass
    if profile and not os.path.isdir(profile):
        try:
            os.makedirs(profile, exist_ok=True)
        except Exception:
            return ""
    return profile or ""


def fanart_cache_path(addon):
    base = _addon_profile_dir(addon)
    return os.path.join(base, "fanart_tv_cache.json") if base else ""


def _cache_load(addon):
    path = fanart_cache_path(addon)
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _cache_save(addon, cache):
    path = fanart_cache_path(addon)
    if not path:
        return
    try:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(cache, fh, ensure_ascii=True)
    except Exception:
        pass


def _best_image(rows):
    if not isinstance(rows, list):
        return ""
    best = ""
    best_likes = -1
    for row in rows:
        if not isinstance(row, dict):
            continue
        url = str(row.get("url") or "").strip()
        if not url:
            continue
        try:
            likes = int(row.get("likes") or 0)
        except Exception:
            likes = 0
        if likes > best_likes:
            best = url
            best_likes = likes
    return best


def fanart_tv_search_art(
    *,
    addon,
    media_type,
    tmdb_id="",
    tvdb_id="",
    imdb_id="",
    enabled_fn,
    api_key_fn,
    json_get,
    metadata_timeout,
):
    if not enabled_fn():
        return {"poster": "", "fanart": ""}
    api_key = str(api_key_fn() or "").strip()
    if not api_key:
        return {"poster": "", "fanart": ""}
    kind = "tv" if str(media_type or "").lower() in ("series", "show", "tv") else "movies"
    ident = str(tvdb_id or "").strip() if kind == "tv" else str(tmdb_id or imdb_id or "").strip()
    if not ident:
        return {"poster": "", "fanart": ""}
    key = f"{kind}|{ident}"
    cache = _cache_load(addon)
    node = cache.get(key) if isinstance(cache, dict) else None
    if isinstance(node, dict) and time.time() - int(node.get("saved_at") or 0) < 7 * 24 * 60 * 60:
        return node.get("art") if isinstance(node.get("art"), dict) else {"poster": "", "fanart": ""}
    url = f"https://webservice.fanart.tv/v3/{kind}/{ident}?api_key={api_key}"
    try:
        payload = json_get(url, timeout=metadata_timeout())
    except Exception:
        return {"poster": "", "fanart": ""}
    if not isinstance(payload, dict):
        return {"poster": "", "fanart": ""}
    if kind == "tv":
        poster = _best_image(payload.get("tvposter"))
        fanart = _best_image(payload.get("showbackground") or payload.get("hdclearart"))
    else:
        poster = _best_image(payload.get("movieposter"))
        fanart = _best_image(payload.get("moviebackground") or payload.get("hdmovieclearart"))
    art = {"poster": poster or "", "fanart": fanart or ""}
    cache[key] = {"saved_at": int(time.time()), "art": art}
    _cache_save(addon, cache)
    return art
