def get_enabled_providers(addon):
    """Import diferido: evita cargar proveedores al abrir menú principal."""
    from resources.lib.providers import (
        get_enabled_providers as _get_enabled_providers_impl,
    )

    return _get_enabled_providers_impl(addon)


def get_trakt_search_provider(addon):
    from resources.lib.providers.trakt_search import TraktSearchProvider

    return TraktSearchProvider(addon)


def get_stremio_provider(addon, get_bool_setting):
    if not get_bool_setting("provider_stremio_catalog"):
        return None
    from resources.lib.providers.stremio_catalog import StremioCatalogProvider

    return StremioCatalogProvider(addon)
