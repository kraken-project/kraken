from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlencode

from resources.lib.core.language_prefs import tmdb_language_param


def tmdb_effective_language(value=None):
    v = str(value or "").strip()
    if not v or v.lower() == "auto":
        return tmdb_language_param()
    return v


def tmdb_image_bases(quality="high"):
    q = str(quality or "high").strip().lower()
    if q == "original":
        return "https://image.tmdb.org/t/p/original", "https://image.tmdb.org/t/p/original"
    if q == "medium":
        return "https://image.tmdb.org/t/p/w342", "https://image.tmdb.org/t/p/w780"
    return "https://image.tmdb.org/t/p/w500", "https://image.tmdb.org/t/p/w1280"


def prefetch_tmdb_details_parallel(tmdb_ids, fetch_detail, max_workers=8):
    """Varias llamadas fetch_detail(id) en paralelo (IDs TMDb normalizadas a entero).

    deduplica entrada y garantiza clave por cada ID único válido."""
    uniq = []
    seen = set()
    for tid in tmdb_ids or []:
        try:
            nid = int(str(tid).strip())
        except (TypeError, ValueError):
            continue
        if nid in seen:
            continue
        seen.add(nid)
        uniq.append(nid)
    if not uniq:
        return {}
    workers = min(max(1, int(max_workers)), max(1, len(uniq)))
    out = {}

    def worker(nid):
        try:
            raw = fetch_detail(nid)
        except Exception:
            raw = {}
        return nid, raw if isinstance(raw, dict) else {}

    try:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futures = [ex.submit(worker, nid) for nid in uniq]
            for fut in as_completed(futures):
                try:
                    nid, data = fut.result()
                    out[nid] = data
                except Exception:
                    pass
    except Exception:
        for nid in uniq:
            try:
                raw = fetch_detail(nid)
                out[nid] = raw if isinstance(raw, dict) else {}
            except Exception:
                out[nid] = {}

    for nid in uniq:
        out.setdefault(nid, {})
    return out


def tmdb_id_details(
    tmdb_id,
    media_type="movie",
    *,
    tmdb_enabled,
    tmdb_api_key,
    json_get,
    metadata_timeout,
    tmdb_image_base,
    tmdb_backdrop_base,
    trakt_parse_year,
    trakt_float_or_none,
    tmdb_language=None,
    tmdb_country=None,
):
    """
    Un solo GET a TMDb: caratulas + año + nota (0-10) y votos para rellenar listas
    cuando Trakt no rellena year/rating o la piel ignora setInfo.
    """
    out = {
        "poster": "",
        "fanart": "",
        "year": None,
        "has_year": False,
        "rating": None,
        "votes": None,
        "imdb_id": "",
        "tvdb_id": "",
    }
    if not tmdb_enabled():
        return out
    try:
        numeric_id = int(str(tmdb_id).strip())
    except Exception:
        return out
    endpoint = "tv" if media_type == "series" else "movie"
    params = {
        "api_key": tmdb_api_key(),
        "language": tmdb_effective_language(tmdb_language),
        "append_to_response": "external_ids",
    }
    if tmdb_country:
        params["region"] = tmdb_country
    url = f"https://api.themoviedb.org/3/{endpoint}/{numeric_id}?{urlencode(params)}"
    try:
        payload = json_get(url, timeout=metadata_timeout())
    except Exception:
        return out
    if not isinstance(payload, dict):
        return out
    poster_path = str(payload.get("poster_path") or "").strip()
    backdrop_path = str(payload.get("backdrop_path") or "").strip()
    if poster_path:
        out["poster"] = f"{tmdb_image_base}{poster_path}"
    if backdrop_path:
        out["fanart"] = f"{tmdb_backdrop_base}{backdrop_path}"
    date_s = str(
        (payload.get("first_air_date") if media_type == "series" else None)
        or payload.get("release_date")
        or ""
    ).strip()
    if len(date_s) >= 4 and date_s[:4].isdigit():
        y, hy = trakt_parse_year(int(date_s[:4]))
        if hy and y is not None:
            out["year"], out["has_year"] = y, True
    va = trakt_float_or_none(payload.get("vote_average"))
    if va is not None and va > 0.0:
        out["rating"] = va
    vc = payload.get("vote_count")
    if vc is not None and str(vc).isdigit():
        out["votes"] = int(vc)
    ext = payload.get("external_ids") if isinstance(payload.get("external_ids"), dict) else {}
    out["imdb_id"] = str(ext.get("imdb_id") or payload.get("imdb_id") or "")
    out["tvdb_id"] = str(ext.get("tvdb_id") or "")
    return out


def tmdb_search_art_by_id(tmdb_id, media_type, tmdb_id_details_fn):
    """Pide carteles/backdrops TMDB usando un ID estable (p.ej. vinculado desde Trakt)."""
    d = tmdb_id_details_fn(tmdb_id, media_type)
    return {"poster": d.get("poster") or "", "fanart": d.get("fanart") or ""}
