"""Preferencias de visualización (ajustes addon)."""


def setting_bool_true(get_setting, setting_id: str, *, default: bool = True) -> bool:
    if not get_setting:
        return default
    try:
        raw = str(get_setting(setting_id) or "").strip().lower()
    except Exception:
        return default
    if raw == "":
        return default
    return raw == "true"


def home_is_hub(get_setting):
    v = str((get_setting("kraken_home_layout") if get_setting else "") or "").strip().lower()
    return v in ("", "hub")


def hub_movie_trending_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_hub_movie_trending", default=True)


def hub_movie_trakt_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_hub_movie_trakt", default=True)


def hub_series_trending_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_hub_series_trending", default=True)


def hub_series_trakt_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_hub_series_trakt", default=True)


def hub_anime_trending_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_hub_anime_trending", default=True)


def hub_anime_trakt_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_hub_anime_trakt", default=True)


# Submenús Películas / Series / Anime (filas bajo cada hub, sin contar trending ni bloque personal Trakt)
def submenu_movie_trakt_lists_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_submenu_movie_trakt_lists", default=True)


def submenu_movie_actor_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_submenu_movie_actor", default=True)


def submenu_movie_trakt_browse_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_submenu_movie_trakt_browse", default=True)


def submenu_movie_tmdb_browse_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_submenu_movie_tmdb_browse", default=True)


def submenu_movie_search_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_submenu_movie_search", default=True)


def submenu_series_trakt_lists_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_submenu_series_trakt_lists", default=True)


def submenu_series_actor_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_submenu_series_actor", default=True)


def submenu_series_trakt_browse_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_submenu_series_trakt_browse", default=True)


def submenu_series_tmdb_browse_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_submenu_series_tmdb_browse", default=True)


def submenu_series_search_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_submenu_series_search", default=True)


def submenu_anime_trakt_lists_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_submenu_anime_trakt_lists", default=True)


def submenu_anime_actor_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_submenu_anime_actor", default=True)


def submenu_anime_trakt_browse_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_submenu_anime_trakt_browse", default=True)


def submenu_anime_tmdb_browse_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_submenu_anime_tmdb_browse", default=True)


def submenu_anime_search_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_submenu_anime_search", default=True)


def simple_list_art_enabled(get_setting):
    try:
        return str((get_setting("kraken_simple_list_art") or "").strip().lower()) == "true"
    except Exception:
        return False


def list_extra_sort_enabled(get_setting):
    try:
        return str((get_setting("kraken_list_extra_sort") or "").strip().lower()) != "false"
    except Exception:
        return True


def skin_content_hint(get_setting):
    """
    auto | movies | shows — sugerencia global para setContent (pocas rutas la consumen).
    """
    v = str((get_setting("kraken_skin_list_hint") if get_setting else "") or "").strip().lower()
    if v in ("movies", "movie", "film", "films"):
        return "movie"
    if v in ("shows", "show", "series", "tv"):
        return "show"
    return ""


def home_show_movies_menu_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_home_show_movies_menu", default=True)


def home_show_series_menu_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_home_show_series_menu", default=True)


def home_show_anime_menu_enabled(get_setting):
    return setting_bool_true(get_setting, "kraken_home_show_anime_menu", default=True)


def settings_pin_enabled(get_setting):
    try:
        return str((get_setting("kraken_settings_pin_enable") or "").strip().lower()) == "true"
    except Exception:
        return False


def settings_pin_value(get_setting):
    try:
        return str(get_setting("kraken_settings_pin") or "").strip()
    except Exception:
        return ""


def schedule_saved_skin_view_slug(get_setting, slug):
    """
    Programa Container.SetViewMode retrasado (IDs orientativos skins tipo Estuary).
    """
    if not get_setting or not slug:
        return
    from resources.lib.ui.view_schedule import schedule_container_set_view_mode

    pairs = (
        ("home", "kraken_view_mode_home"),
        ("movies", "kraken_view_mode_movies"),
        ("movie", "kraken_view_mode_movies"),
        ("tvshows", "kraken_view_mode_tvshows"),
        ("series", "kraken_view_mode_tvshows"),
        ("show", "kraken_view_mode_tvshows"),
        ("mixed", "kraken_view_mode_mixed"),
    )
    sid_key = ""
    slug = str(slug).strip().lower()
    for s, ky in pairs:
        if s == slug:
            sid_key = ky
            break
    if not sid_key:
        return
    try:
        vid = int(str(get_setting(sid_key) or "0").strip())
    except Exception:
        vid = 0
    schedule_container_set_view_mode(vid)


def schedule_saved_skin_view_media_filter(media_filter, get_setting):
    if not get_setting:
        return
    if (media_filter or "").strip().lower() == "movie":
        schedule_saved_skin_view_slug(get_setting, "movies")
        return
    if (media_filter or "").strip().lower() == "show":
        schedule_saved_skin_view_slug(get_setting, "tvshows")
        return
    h = skin_content_hint(get_setting)
    if h == "movie":
        schedule_saved_skin_view_slug(get_setting, "movies")
    elif h == "show":
        schedule_saved_skin_view_slug(get_setting, "tvshows")
    else:
        schedule_saved_skin_view_slug(get_setting, "mixed")


