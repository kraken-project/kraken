def tmdb_api_key(get_setting):
    return (get_setting("tmdb_api_key") or "").strip()


def omdb_api_key(get_setting):
    key = (get_setting("omdb_api_key") or "").strip()
    if key:
        return key
    # Compatibilidad con versiones previas que usaban tmdb_api_key.
    return (get_setting("tmdb_api_key") or "").strip()


def tmdb_enabled(get_bool_setting, get_setting):
    return get_bool_setting("tmdb_enabled") and bool(
        (get_setting("tmdb_api_key") or "").strip()
    )


def omdb_enabled(get_bool_setting, get_setting):
    enabled = get_bool_setting("omdb_enabled")
    if not enabled:
        # Compatibilidad con versiones previas que usaban tmdb_enabled.
        enabled = get_bool_setting("tmdb_enabled")
    return enabled and bool(omdb_api_key(get_setting))


def omdb_external_ratings_enabled(addon, omdb_enabled_fn):
    """RT / Metacritic / IMDb en lista Trakt (requiere API OMDb)."""
    if not omdb_enabled_fn():
        return False
    try:
        return addon.getSettingBool("omdb_show_external_ratings")
    except Exception:
        return (
            addon.getSetting("omdb_show_external_ratings") or "true"
        ).lower() == "true"
