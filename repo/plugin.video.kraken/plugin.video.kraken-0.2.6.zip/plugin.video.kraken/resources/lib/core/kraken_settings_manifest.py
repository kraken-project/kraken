"""Lista de pestañas y filas de settings.xml sin depender de xbmc.

Orden de <category label> (indices 0..12), inspirado en Umbrella:

0 General · 1 Navigation & appearance · 2–4 Hubs Movies / Series / Anime ·
5 Playback · 6 Video quality · 7 Stremio · 8 Torrent scrapers · 9 Debrid ·
10 Trakt (+ search prefs) · 11 Metadata TMDB/OMDb · 12 Internal.
"""

from __future__ import annotations

import os
import xml.etree.ElementTree as ET
from typing import Any


def _visible_always_false(visible_attr: str | None) -> bool:
    if visible_attr is None:
        return False
    return visible_attr.strip().lower() == "false"


def categories_from_addon_settings_xml(settings_xml_abs_path: str) -> list[dict[str, Any]]:
    """
    Orden igual que <category> en settings.xml; focus_idx cuenta filas enfocables
    (excluye solo visible=\"false\"; condicionales como eq(...) se cuentan).
    """
    if not settings_xml_abs_path or not os.path.isfile(settings_xml_abs_path):
        return []
    tree = ET.parse(settings_xml_abs_path)
    root = tree.getroot()
    out: list[dict[str, Any]] = []
    for cat in root.findall("category"):
        lb = cat.get("label") or ""
        rows: list[dict[str, Any]] = []
        fi = 0
        for st in cat.findall("setting"):
            if _visible_always_false(st.get("visible")):
                continue
            rows.append(
                {
                    "focus_idx": fi,
                    "label_id": str(st.get("label") or "").strip(),
                    "sid": str(st.get("id") or "").strip(),
                    "stype": str(st.get("type") or "").strip(),
                    "action": str(st.get("action") or "").strip(),
                }
            )
            fi += 1
        out.append({"category_label_id": lb, "rows": rows})
    return out
