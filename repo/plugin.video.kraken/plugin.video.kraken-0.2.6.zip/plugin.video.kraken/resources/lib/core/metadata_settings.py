def metadata_timeout(get_int_setting):
    return max(3, min(20, get_int_setting("metadata_timeout", 10)))


def metadata_priority(get_setting):
    value = (get_setting("metadata_priority") or "TMDB first").strip().lower()
    if "omdb" in value:
        return "omdb_first"
    return "tmdb_first"


def trakt_results_limit(get_int_setting):
    return max(5, min(100, get_int_setting("trakt_results_limit", 20)))


def trakt_title_with_year(get_bool_setting):
    return get_bool_setting("trakt_title_with_year")


def metadata_fallback_fanart(get_bool_setting):
    return get_bool_setting("metadata_fallback_fanart")


def _setting_text(get_setting, setting_id, default=""):
    try:
        value = str(get_setting(setting_id) or "").strip()
    except Exception:
        value = ""
    return value or default


def tmdb_language(get_setting):
    value = _setting_text(get_setting, "tmdb_language", "Auto (Kodi)")
    low = value.lower()
    aliases = {
        "auto": "auto",
        "auto (kodi)": "auto",
        "spanish": "es-ES",
        "español": "es-ES",
        "castellano": "es-ES",
        "english": "en-US",
        "inglés": "en-US",
        "français": "fr-FR",
        "french": "fr-FR",
        "italiano": "it-IT",
        "italian": "it-IT",
        "deutsch": "de-DE",
        "german": "de-DE",
    }
    if low in aliases:
        return aliases[low]
    if len(value) >= 5 and value[2] == "-":
        return value
    return "auto"


def tmdb_country(get_setting):
    value = _setting_text(get_setting, "tmdb_country", "España")
    low = value.lower()
    aliases = {
        "españa": "ES",
        "spain": "ES",
        "es": "ES",
        "estados unidos": "US",
        "united states": "US",
        "usa": "US",
        "us": "US",
        "méxico": "MX",
        "mexico": "MX",
        "mx": "MX",
        "argentina": "AR",
        "ar": "AR",
        "chile": "CL",
        "cl": "CL",
        "colombia": "CO",
        "co": "CO",
        "perú": "PE",
        "peru": "PE",
        "pe": "PE",
        "reino unido": "GB",
        "united kingdom": "GB",
        "uk": "GB",
        "gb": "GB",
        "francia": "FR",
        "france": "FR",
        "fr": "FR",
        "alemania": "DE",
        "germany": "DE",
        "de": "DE",
        "italia": "IT",
        "italy": "IT",
        "it": "IT",
        "portugal": "PT",
        "pt": "PT",
        "brasil": "BR",
        "brazil": "BR",
        "br": "BR",
    }
    return aliases.get(low, "ES")


def tmdb_image_quality(get_setting):
    value = _setting_text(get_setting, "tmdb_image_quality", "High").lower()
    if "original" in value:
        return "original"
    if "medium" in value or "medio" in value:
        return "medium"
    return "high"


def omdb_image_quality(get_setting):
    value = _setting_text(get_setting, "omdb_image_quality", "High").lower()
    if "original" in value:
        return "original"
    if "medium" in value or "medio" in value:
        return "medium"
    return "high"


def fanart_tv_enabled(get_bool_setting):
    return get_bool_setting("fanart_tv_enabled")


def fanart_tv_api_key(get_setting):
    return _setting_text(get_setting, "fanart_tv_api_key", "")


def external_scrapers_timeout(get_int_setting):
    return max(3, min(20, get_int_setting("external_scrapers_timeout", 8)))
