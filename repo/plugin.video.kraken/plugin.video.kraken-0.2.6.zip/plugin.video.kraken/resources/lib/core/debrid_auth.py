import time
from urllib.error import URLError
from urllib.parse import urlencode

import xbmc
import xbmcgui

from resources.lib.core.kraken_qr_ui import (
    oauth_device_flow_qr_url,
    open_kraken_qr_modal,
    pin_challenge_qr_url,
    write_qr_png_to_special_temp,
)
from resources.lib.ui.ui_helpers import _t


def _kraken_debrid_show_activation_qr(
    *,
    png_filename: str,
    qr_payload: str,
    dialog_title: str,
    body_text: str,
    qr_dialog_cls,
    addon_path,
    poll_kw,
    text_if_no_png: str,
    text_if_no_window: str,
) -> dict:
    """Mismo flujo QR para AllDebrid (PNG + modal o fallback)."""
    if qr_dialog_cls and (addon_path or "").strip():
        qr_path = write_qr_png_to_special_temp(
            png_filename, qr_payload, scale=6, border=4
        )
        if qr_path:
            result = open_kraken_qr_modal(
                qr_dialog_cls,
                addon_path,
                dialog_title=dialog_title,
                body_text=body_text,
                qr_special_path=qr_path,
                **poll_kw,
            )
            return result if isinstance(result, dict) else {"success": False, "timeout": False}
        xbmcgui.Dialog().ok("Kraken - Debrid", text_if_no_png)
        return {"success": False, "timeout": False, "fallback": True}
    xbmcgui.Dialog().ok("Kraken - Debrid", text_if_no_window)
    return {"success": False, "timeout": False, "fallback": True}


def _alldebrid_user_label(json_get, base_url, apikey):
    if not apikey:
        return ""
    try:
        info = json_get("{}{}?{}".format(base_url, "/user", urlencode({"agent": "KrakenKodi", "apikey": apikey})))
    except Exception:
        return ""
    data = info.get("data", {}) if isinstance(info, dict) else {}
    user = data.get("user", {}) if isinstance(data, dict) else {}
    for key in ("username", "email"):
        value = str(user.get(key) or "").strip() if isinstance(user, dict) else ""
        if value:
            return value
    return ""


def _manual_alldebrid_token_fallback(
    *, set_setting, token_setting_id, info_setting_id, reason_text=""
):
    msg = _t(
        "No se pudo obtener el PIN automático de AllDebrid.",
        "Could not fetch automatic AllDebrid PIN.",
        "Impossible d'obtenir le PIN automatique AllDebrid.",
        "Impossibile ottenere il PIN automatico di AllDebrid.",
        "Automatische AllDebrid-PIN konnte nicht abgerufen werden.",
    )
    if reason_text:
        msg += _t(
            f"\n\nDetalle: {reason_text}",
            f"\n\nDetail: {reason_text}",
            f"\n\nDétail : {reason_text}",
            f"\n\nDettaglio: {reason_text}",
            f"\n\nDetails: {reason_text}",
        )
    msg += (
        _t(
            "\n\n¿Quieres introducir tu API key manualmente?"
            "\n\nPuedes verla en: https://alldebrid.com/account/",
            "\n\nDo you want to enter your API key manually?"
            "\n\nYou can find it at: https://alldebrid.com/account/",
            "\n\nVoulez-vous saisir votre clé API manuellement ?"
            "\n\nVous pouvez la trouver ici : https://alldebrid.com/account/",
            "\n\nVuoi inserire manualmente la tua API key?"
            "\n\nPuoi trovarla qui: https://alldebrid.com/account/",
            "\n\nMöchtest du deinen API-Schlüssel manuell eingeben?"
            "\n\nDu findest ihn unter: https://alldebrid.com/account/",
        )
    )
    if not xbmcgui.Dialog().yesno(
        "Kraken - Debrid",
        msg,
        yeslabel=_t("Introducir API key", "Enter API key", "Saisir clé API", "Inserisci API key", "API-Schlüssel eingeben"),
        nolabel=_t("Cancelar", "Cancel", "Annuler", "Annulla", "Abbrechen"),
    ):
        return False
    token = xbmcgui.Dialog().input(
        _t(
            "Pega aquí tu API key de AllDebrid",
            "Paste your AllDebrid API key here",
            "Collez ici votre clé API AllDebrid",
            "Incolla qui la tua API key AllDebrid",
            "Füge hier deinen AllDebrid API-Schlüssel ein",
        ),
        defaultt="",
        type=xbmcgui.INPUT_ALPHANUM,
    )
    token = str(token or "").strip()
    if len(token) < 12:
        xbmcgui.Dialog().ok(
            "Kraken - Debrid",
            _t(
                "API key inválida o vacía.",
                "Invalid or empty API key.",
                "Clé API invalide ou vide.",
                "API key non valida o vuota.",
                "Ungültiger oder leerer API-Schlüssel.",
            ),
        )
        return False
    set_setting(token_setting_id, token)
    set_setting(
        info_setting_id,
        _t(
            "Conectada: AllDebrid (manual)",
            "Connected: AllDebrid (manual)",
            "Connecté : AllDebrid (manuel)",
            "Connesso: AllDebrid (manuale)",
            "Verbunden: AllDebrid (manuell)",
        ),
    )
    xbmcgui.Dialog().ok(
        "Kraken - Debrid",
        _t(
            "AllDebrid guardado correctamente (modo manual).",
            "AllDebrid saved successfully (manual mode).",
            "AllDebrid enregistré avec succès (mode manuel).",
            "AllDebrid salvato correttamente (modalità manuale).",
            "AllDebrid erfolgreich gespeichert (manueller Modus).",
        ),
    )
    return True


def alldebrid_pin_authorize(
    *,
    json_get,
    set_setting,
    token_setting_id,
    info_setting_id,
    addon_path=None,
    qr_dialog_cls=None,
):
    agent_name = "KrakenKodi"
    api_bases = ("https://api.alldebrid.com/v4", "https://api.alldebrid.com/v4.1")
    pin_data = None
    base_url = ""
    last_error = ""
    for one_base in api_bases:
        get_url = "{}{}?{}".format(
            one_base, "/pin/get", urlencode({"agent": agent_name})
        )
        try:
            pin_data = json_get(get_url)
            base_url = one_base
            break
        except (URLError, ValueError) as ex:
            last_error = str(ex)
            pin_data = None
    if not pin_data:
        return _manual_alldebrid_token_fallback(
            set_setting=set_setting,
            token_setting_id=token_setting_id,
            info_setting_id=info_setting_id,
            reason_text=last_error or "pin/get sin respuesta",
        )

    if pin_data.get("status") != "success":
        return _manual_alldebrid_token_fallback(
            set_setting=set_setting,
            token_setting_id=token_setting_id,
            info_setting_id=info_setting_id,
            reason_text="respuesta inválida en pin/get",
        )

    data = pin_data.get("data", {})
    pin = data.get("pin", "")
    check = data.get("check", "")
    user_url = data.get("user_url", "https://alldebrid.com/pin/")
    if not pin or not check:
        return _manual_alldebrid_token_fallback(
            set_setting=set_setting,
            token_setting_id=token_setting_id,
            info_setting_id=info_setting_id,
            reason_text="PIN/CHECK ausente en respuesta",
        )

    check_params = {"agent": agent_name, "pin": pin, "check": check}
    deadline = time.time() + 600
    outcome: dict = {}

    def try_pin_activate():
        if outcome.get("_pin_error"):
            return True
        if outcome.get("_apikey"):
            return True
        check_url = "{}{}?{}".format(base_url, "/pin/check", urlencode(check_params))
        try:
            check_data = json_get(check_url)
        except (URLError, ValueError):
            return False

        if check_data.get("status") == "error":
            outcome["_pin_error"] = True
            return True

        check_payload = check_data.get("data", {})
        if check_payload.get("activated") and check_payload.get("apikey"):
            outcome["_apikey"] = check_payload.get("apikey", "")
            return True
        return False

    poll_kw = dict(
        poll_interval_sec=5.0,
        poll_deadline_epoch=deadline,
        poll_fn=try_pin_activate,
    )

    ad_qr_target = pin_challenge_qr_url(user_url, pin, query_param="pin") or user_url

    body_ad = _t(
        f"{user_url}  PIN: {pin}",
        f"{user_url}  PIN: {pin}",
        f"{user_url}  PIN : {pin}",
        f"{user_url}  PIN: {pin}",
        f"{user_url}  PIN: {pin}",
    )
    modal_result = _kraken_debrid_show_activation_qr(
        png_filename="kraken_alldebrid_activate_qr.png",
        qr_payload=ad_qr_target,
        dialog_title=f"Kraken - AllDebrid (PIN: {pin})",
        body_text=body_ad,
        qr_dialog_cls=qr_dialog_cls,
        addon_path=addon_path,
        poll_kw=poll_kw,
        text_if_no_png=_t(
            f"Abre:\n{user_url}\n\nPIN: {pin}\n\n(No se pudo crear el PNG del QR.)",
            f"Open:\n{user_url}\n\nPIN: {pin}\n\n(Could not generate QR PNG.)",
            f"Ouvre :\n{user_url}\n\nPIN : {pin}\n\n(Impossible de générer le PNG du QR.)",
            f"Apri:\n{user_url}\n\nPIN: {pin}\n\n(Impossibile generare il PNG del QR.)",
            f"Öffne:\n{user_url}\n\nPIN: {pin}\n\n(QR-PNG konnte nicht erstellt werden.)",
        ),
        text_if_no_window=_t(
            f"Abre:\n{user_url}\n\nPIN: {pin}\n\nIntroduce el PIN y pulsa OK para continuar.",
            f"Open:\n{user_url}\n\nPIN: {pin}\n\nEnter the PIN and press OK to continue.",
            f"Ouvre :\n{user_url}\n\nPIN : {pin}\n\nSaisis le PIN puis appuie sur OK pour continuer.",
            f"Apri:\n{user_url}\n\nPIN: {pin}\n\nInserisci il PIN e premi OK per continuare.",
            f"Öffne:\n{user_url}\n\nPIN: {pin}\n\nPIN eingeben und mit OK fortfahren.",
        ),
    )
    if isinstance(modal_result, dict) and modal_result.get("timeout"):
        xbmcgui.Dialog().notification(
            "Kraken - Debrid",
            _t(
                "Tiempo agotado para sincronizar AllDebrid.",
                "Timed out waiting for AllDebrid sync.",
                "Délai dépassé pour synchroniser AllDebrid.",
                "Tempo scaduto per sincronizzare AllDebrid.",
                "Zeitüberschreitung beim Synchronisieren von AllDebrid.",
            ),
            xbmcgui.NOTIFICATION_WARNING,
            6500,
        )
        return False

    while (
        not outcome.get("_apikey")
        and not outcome.get("_pin_error")
        and time.time() < deadline
    ):
        if try_pin_activate():
            break
        xbmc.sleep(5000)

    if outcome.get("_pin_error"):
        xbmcgui.Dialog().ok(
            "Kraken - Debrid",
            _t(
                "PIN expirado o invalido en AllDebrid.",
                "PIN expired or invalid on AllDebrid.",
                "PIN expiré ou invalide sur AllDebrid.",
                "PIN scaduto o non valido su AllDebrid.",
                "PIN bei AllDebrid abgelaufen oder ungültig.",
            ),
        )
        return False

    apikey = (outcome.get("_apikey") or "").strip()
    if apikey:
        user_label = _alldebrid_user_label(json_get, base_url, apikey)
        set_setting(token_setting_id, apikey)
        set_setting(
            info_setting_id,
            _t(
                "Conectada: AllDebrid{}",
                "Connected: AllDebrid{}",
                "Connecté : AllDebrid{}",
                "Connesso: AllDebrid{}",
                "Verbunden: AllDebrid{}",
            ).format(f" ({user_label})" if user_label else ""),
        )
        xbmcgui.Dialog().notification(
            "Kraken - Debrid",
            _t(
                "AllDebrid conectado correctamente.",
                "AllDebrid connected successfully.",
                "AllDebrid connecté avec succès.",
                "AllDebrid connesso correttamente.",
                "AllDebrid erfolgreich verbunden.",
            ),
            xbmcgui.NOTIFICATION_INFO,
            6500,
        )
        return True

    xbmcgui.Dialog().ok(
        "Kraken - Debrid",
        _t(
            "Tiempo de espera agotado para PIN de AllDebrid.",
            "Timeout waiting for AllDebrid PIN.",
            "Délai d'attente dépassé pour le PIN AllDebrid.",
            "Tempo scaduto in attesa del PIN AllDebrid.",
            "Zeitüberschreitung beim Warten auf AllDebrid-PIN.",
        ),
    )
    return False

