# Proveedores web de enlaces (sitios de listados HTTP) para comprobador y ajustes.

LINK_PROVIDER_SETTINGS = [
    ("2ddl", "lite_link_2ddl"),
    ("300mbfilms", "lite_link_300mbfilms"),
    ("allmoviesforyou", "lite_link_allmoviesforyou"),
    ("anymovies", "lite_link_anymovies"),
    ("cmovieshd", "lite_link_cmovieshd"),
    ("databasegdriveplayer", "lite_link_databasegdriveplayer"),
    ("dbgo", "lite_link_dbgo"),
    ("easynews", "lite_link_easynews"),
    ("filmxy", "lite_link_filmxy"),
    ("furk", "lite_link_furk"),
    ("gowatchseries", "lite_link_gowatchseries"),
    ("maxrls", "lite_link_maxrls"),
    ("myvideolinks", "lite_link_myvideolinks"),
    ("onlineseries", "lite_link_onlineseries"),
    ("ororo", "lite_link_ororo"),
    ("rapidmoviez", "lite_link_rapidmoviez"),
    ("rlsbb", "lite_link_rlsbb"),
    ("scenerls", "lite_link_scenerls"),
]

LINK_PROVIDER_URL_SETTINGS = {
    "2ddl": "lite_link_url_2ddl",
    "300mbfilms": "lite_link_url_300mbfilms",
    "allmoviesforyou": "lite_link_url_allmoviesforyou",
    "anymovies": "lite_link_url_anymovies",
    "cmovieshd": "lite_link_url_cmovieshd",
    "databasegdriveplayer": "lite_link_url_databasegdriveplayer",
    "dbgo": "lite_link_url_dbgo",
    "easynews": "lite_link_url_easynews",
    "filmxy": "lite_link_url_filmxy",
    "furk": "lite_link_url_furk",
    "gowatchseries": "lite_link_url_gowatchseries",
    "maxrls": "lite_link_url_maxrls",
    "myvideolinks": "lite_link_url_myvideolinks",
    "onlineseries": "lite_link_url_onlineseries",
    "ororo": "lite_link_url_ororo",
    "rapidmoviez": "lite_link_url_rapidmoviez",
    "rlsbb": "lite_link_url_rlsbb",
    "scenerls": "lite_link_url_scenerls",
}


def enabled_link_providers(get_bool_setting):
    selected = []
    for name, setting_id in LINK_PROVIDER_SETTINGS:
        try:
            if get_bool_setting(setting_id):
                selected.append(name)
        except Exception:
            selected.append(name)
    return selected or [name for name, _sid in LINK_PROVIDER_SETTINGS]
