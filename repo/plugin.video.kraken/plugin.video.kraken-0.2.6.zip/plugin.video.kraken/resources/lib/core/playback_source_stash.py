"""Guarda la última lista de fuentes resueltas para poder reabrirla sin volver a buscar."""

import json

import xbmcgui

WID = 10000
_PROP_CANDIDATES = "Kraken.SourceCandidates"
_PROP_CONTEXT = "Kraken.SourceContext"
_MAX_ITEMS = 42
_MAX_BYTES = 30000


def stash_source_candidates(candidates, context_label=""):
    """Serializa candidatos (misma forma que el selector) en propiedades de ventana."""
    from resources.lib.sources.source_picker import candidates_deduped_for_picker

    clean = candidates_deduped_for_picker(candidates or [])
    if not clean:
        return
    clean = clean[:_MAX_ITEMS]
    win = xbmcgui.Window(WID)
    win.clearProperty("Kraken.RepickLastOfferTs")
    payload = json.dumps(clean, ensure_ascii=True)
    while len(payload) > _MAX_BYTES and len(clean) > 3:
        clean = clean[: max(3, len(clean) // 2)]
        payload = json.dumps(clean, ensure_ascii=True)
    win.setProperty(_PROP_CANDIDATES, payload)
    win.setProperty(_PROP_CONTEXT, str(context_label or "")[:400])


def load_stashed_candidates():
    raw = (xbmcgui.Window(WID).getProperty(_PROP_CANDIDATES) or "").strip()
    if not raw:
        return []
    try:
        data = json.loads(raw)
    except (TypeError, ValueError):
        return []
    return data if isinstance(data, list) else []


def get_stash_context():
    return (xbmcgui.Window(WID).getProperty(_PROP_CONTEXT) or "").strip()
