"""Normalización unificada de URLs manifest/catalog para complementos Stremio."""

from resources.lib.core.stremio_transport import normalize_stremio_addon_url
from resources.lib.stremio.domain import normalize_manifest_url


def normalize_manifest_or_catalog_url(raw_url):
    """
    Pipeline compartido por el menú Stremio, autostart y pegado de URLs:
    esquema stremio://, sufijo manifest/catalog y sustitución torrentlinks→streamlinks.
    """
    u = normalize_stremio_addon_url(raw_url)
    if not u:
        return ""
    if "debridoptions=torrentlinks" in u.lower():
        u = u.replace("debridoptions=torrentlinks", "debridoptions=streamlinks")
    return normalize_manifest_url(u)
