import base64
import json
import os
import time

import xbmcaddon
import xbmcvfs

ADDON_ID = "plugin.video.kraken"
SEARCH_HISTORY_FILE = "search_history.json"
VALID_MEDIA = ("movie", "show", "all", "actor_movie", "actor_show")


def _addon():
    return xbmcaddon.Addon(ADDON_ID)


def search_history_enabled():
    try:
        return _addon().getSettingBool("search_history_enabled")
    except Exception:
        return (
            _addon().getSetting("search_history_enabled") or "true"
        ).lower() == "true"


def search_history_path():
    profile = xbmcvfs.translatePath(_addon().getAddonInfo("profile"))
    if not xbmcvfs.exists(profile):
        xbmcvfs.mkdirs(profile)
    return os.path.join(profile, SEARCH_HISTORY_FILE)


def search_history_load():
    if not search_history_enabled():
        return []
    p = search_history_path()
    if not xbmcvfs.exists(p):
        return []
    try:
        f = xbmcvfs.File(p)
        raw = f.read()
        f.close()
        data = json.loads(raw) if raw else []
        if not isinstance(data, list):
            return []
        out = []
        for it in data:
            if not isinstance(it, dict):
                continue
            q = str(it.get("q") or "").strip()
            if not q:
                continue
            out.append(
                {
                    "q": q,
                    "media": str(it.get("media") or "all").strip().lower(),
                    "ts": int(it.get("ts") or 0),
                }
            )
        return out
    except Exception:
        return []


def search_history_save(items):
    if not search_history_enabled():
        return
    clean = []
    for it in items or []:
        if not isinstance(it, dict):
            continue
        q = str(it.get("q") or "").strip()
        if not q:
            continue
        clean.append(
            {
                "q": q,
                "media": str(it.get("media") or "all").strip().lower(),
                "ts": int(it.get("ts") or 0),
            }
        )
    p = search_history_path()
    try:
        f = xbmcvfs.File(p, "w")
        f.write(json.dumps(clean[:50], ensure_ascii=False))
        f.close()
    except Exception:
        pass


def search_history_add(query, media_filter):
    q = str(query or "").strip()
    if not q or not search_history_enabled():
        return
    m = str(media_filter or "all").strip().lower()
    if m not in VALID_MEDIA:
        m = "all"
    items = search_history_load()
    now = int(time.time())
    new_items = [{"q": q, "media": m, "ts": now}]
    for it in items:
        if it.get("q", "").strip().lower() == q.lower() and it.get("media", "all") == m:
            continue
        new_items.append(it)
    search_history_save(new_items[:50])


def search_history_last(media_filter):
    m = str(media_filter or "all").strip().lower()
    for it in search_history_load():
        im = str(it.get("media") or "all").strip().lower()
        if m == "all":
            return it.get("q", "")
        if m == "actor_movie" and im in ("actor_movie", "movie", "all"):
            return it.get("q", "")
        if m == "actor_show" and im in ("actor_show", "show", "all"):
            return it.get("q", "")
        if im in (m, "all"):
            return it.get("q", "")
    return ""


def search_history_token_read(token):
    raw = (token or "").strip()
    if not raw:
        return "", "all"
    try:
        pad = "=" * (-(len(raw)) % 4)
        data = json.loads(base64.urlsafe_b64decode(raw + pad).decode("utf-8"))
    except Exception:
        return "", "all"
    q = str((data or {}).get("q") or "").strip()
    m = str((data or {}).get("m") or "all").strip().lower()
    if m not in VALID_MEDIA:
        m = "all"
    return q, m
