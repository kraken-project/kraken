from urllib.parse import unquote


def query_arg_first_str(args, *candidates):
    """Devuelve el primer query arg encontrado, decodificado y sin espacios."""
    if not candidates:
        return ""
    for key in candidates:
        if key not in args:
            continue
        vals = args.get(key) or []
        if not vals:
            continue
        v0 = vals[0]
        if isinstance(v0, bytes):
            v0 = v0.decode("utf-8", "replace")
        t = str(v0 or "").strip()
        if t:
            return unquote(t).strip()
    return ""


def play_result_id_from_request(result_id_path, args):
    """
    id en ?result_id=... (ruta /play) evita poner '::' en el path plugin://.
    Sigue aceptando /play/<id> legado.
    """
    if result_id_path is not None and str(result_id_path or "").strip():
        return unquote(str(result_id_path).strip()).strip()
    return query_arg_first_str(args or {}, "result_id", "r", b"result_id", b"r")
