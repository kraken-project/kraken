"""
Selección de credenciales Debrid para inyección en URLs Stremio (Torrentio, etc.).
Solo AllDebrid.
"""


def best_debrid_pipe_for_stremio(get_bool_setting, get_setting):
    """
    Primer proveedor con toggle activo y token no vacío.

    Returns:
        dict con keys token, pipe_key, display; o None.
    """
    enabled_key, token_key, pipe_key, display = (
        "debrid_ad_enabled",
        "debrid_ad_token",
        "alldebrid",
        "AllDebrid",
    )
    try:
        enabled = bool(get_bool_setting(enabled_key))
    except Exception:
        enabled = str(get_setting(enabled_key) or "").strip().lower() == "true"
    token = str(get_setting(token_key) or "").strip()
    if enabled and token:
        return {"pipe_key": pipe_key, "token": token, "display": display}
    return None
