"""Convierte magnet / .torrent en URL HTTP reproducible via AllDebrid."""

import time
from urllib.parse import quote

import xbmc

from resources.lib.core.debrid_torrent_pick import choose_alldebrid_leaf_for_playback

_AD_AGENT = "KrakenKodi"
_AD_V4 = "https://api.alldebrid.com/v4"
_AD_V41 = "https://api.alldebrid.com/v4.1"
# Docs AllDebrid: magnets[] en upload; tiempo de espera corto rompía igual que sin Debrid en JSON Stremio.
_AD_MAGNET_MAX_WAIT = 120
# Paso «Debrid primero» desde el plugin de vídeo: no bloquear minutos (Kodi corta scripts / playlist).
DEBRID_MAGNET_QUICK_POLL_SEC = 15
# Los magnet de película suelen estar más tiempo en «In queue» en AllDebrid que episodios ligeros;
# si cortamos demasiado pronto pasamos al segundo intento (>200s), el script del plugin puede cortarse
# antes de obtener HTTP y Kodi marca la película como no reproducible.
DEBRID_MAGNET_QUICK_POLL_MOVIE_SEC = 75
# Magnetes 4K grandes suelen superar 150s en AllDebrid en estado Downloading (code 1).
DEBRID_PLAYBACK_SECOND_PASS_SEC = 210
_STREAM_HINTS = (".m3u8", ".mpd")


def _torrent_like(url):
    raw = str(url or "").strip()
    if not raw:
        return False
    low = raw.lower()
    if raw.startswith("magnet:"):
        return True
    if low.endswith(".torrent") or ".torrent?" in low:
        return True
    return False


def _normalize_magnet_uri(uri):
    """
    Limpia saltos de linea en el magnet (p. ej. dn=Torrentio%0A4k) que a veces
    vienen de metadatos Stremio y pueden retrasar o fallar en APIs Debrid.
    """
    u = str(uri or "").strip()
    if not u.startswith("magnet:"):
        return u
    u = u.replace("\r", " ").replace("\n", " ")
    u = u.replace("%0D", "").replace("%0d", "")
    u = u.replace("%0A", "%20").replace("%0a", "%20")
    return u


def _looks_direct_stream_http(url):
    low = str(url or "").strip().lower()
    if not low.startswith(("http://", "https://")):
        return False
    if any(h in low for h in _STREAM_HINTS):
        return True
    # Algunos streamers usan query params sin extensión.
    return any(
        k in low
        for k in ("mime=video", "contenttype=video", "playlist.m3u8", "format=mpd")
    )


def _ad_headers(token):
    return {"Authorization": "Bearer {}".format((token or "").strip())}


def _ad_url_v4(path, apikey=None):
    """
    AllDebrid documenta Authorization: Bearer; en la práctica muchos endpoints
    responden correctamente solo si además va apikey= en la query (como pin/check).
    """
    q = ["agent={}".format(quote(_AD_AGENT, safe=""))]
    ak = (apikey or "").strip()
    if ak:
        q.append("apikey={}".format(quote(ak, safe="")))
    return "{}?{}".format(f"{_AD_V4}{path}", "&".join(q))


def _ad_url_v41(path, apikey=None):
    q = ["agent={}".format(quote(_AD_AGENT, safe=""))]
    ak = (apikey or "").strip()
    if ak:
        q.append("apikey={}".format(quote(ak, safe="")))
    return "{}?{}".format(f"{_AD_V41}{path}", "&".join(q))


def _ad_flatten_file_tree(nodes, out=None):
    if out is None:
        out = []
    for node in nodes or []:
        if not isinstance(node, dict):
            continue
        if "l" in node and "n" in node:
            out.append(node)
        if "e" in node:
            _ad_flatten_file_tree(node.get("e"), out)
    return out


def _ad_first_magnet_entry(data):
    magnets = (data.get("data") or {}).get("magnets")
    if isinstance(magnets, list):
        return magnets[0] if magnets else None
    if isinstance(magnets, dict):
        return magnets
    return None


def _ad_magnet_status_code(sm):
    """Interpreta magnet/status v4.1; tolera APIs que solo mandan texto en status."""
    if not isinstance(sm, dict):
        return -1
    v = sm.get("statusCode")
    if v is not None:
        try:
            return int(v)
        except (TypeError, ValueError):
            pass
    st = str(sm.get("status") or "").strip().lower()
    if st == "ready":
        return 4
    if any(
        x in st
        for x in ("fail", "error", "deleted", "too big", "not available", "no peer")
    ):
        return 99
    return -1


def _ad_link_unlock(link, token, json_post, timeout_delayed=180):
    try:
        data = json_post(
            _ad_url_v4("/link/unlock", apikey=token),
            payload={"link": link},
            headers=_ad_headers(token),
            timeout=90,
        )
    except Exception as ex:
        xbmc.log(f"[Kraken] AD link/unlock: {ex}", xbmc.LOGWARNING)
        return None
    if not isinstance(data, dict) or data.get("status") != "success":
        return None
    d = data.get("data") or {}
    direct = str(d.get("link") or "").strip()
    if direct.startswith(("http://", "https://")):
        return direct
    delayed = d.get("delayed")
    if delayed is None:
        return None
    deadline = time.time() + timeout_delayed
    while time.time() < deadline:
        time.sleep(5)
        try:
            dresp = json_post(
                _ad_url_v4("/link/delayed", apikey=token),
                payload={"id": str(delayed)},
                headers=_ad_headers(token),
                timeout=45,
            )
        except Exception as ex:
            xbmc.log(f"[Kraken] AD link/delayed: {ex}", xbmc.LOGWARNING)
            continue
        if not isinstance(dresp, dict) or dresp.get("status") != "success":
            continue
        dd = dresp.get("data") or {}
        st = int(dd.get("status") or 0)
        if st == 2:
            got = str(dd.get("link") or "").strip()
            if got.startswith(("http://", "https://")):
                return got
            return None
        if st == 3:
            return None
    return None


def _alldebrid_resolve_magnet(
    magnet_uri, token, json_post, max_wait_seconds=None, playback=None
):
    if max_wait_seconds is None:
        max_wait_seconds = _AD_MAGNET_MAX_WAIT
    try:
        data = json_post(
            _ad_url_v4("/magnet/upload", apikey=token),
            payload=[("magnets[]", magnet_uri)],
            headers=_ad_headers(token),
            timeout=90,
        )
    except Exception as ex:
        xbmc.log(f"[Kraken] AD magnet/upload: {ex}", xbmc.LOGWARNING)
        return None
    if not isinstance(data, dict) or data.get("status") != "success":
        xbmc.log(
            "[Kraken] AD magnet/upload invalid response: {}".format(data),
            xbmc.LOGWARNING,
        )
        return None
    m0 = _ad_first_magnet_entry(data)
    if not m0:
        return None
    if m0.get("error"):
        xbmc.log(
            "[Kraken] AD magnet/upload error: {}".format(m0.get("error")),
            xbmc.LOGWARNING,
        )
        return None
    mid = m0.get("id")
    if mid is None:
        return None
    mid = int(mid)
    deadline = time.time() + max(5, int(max_wait_seconds or _AD_MAGNET_MAX_WAIT))
    last_slow_log = [0.0]
    while time.time() < deadline:
        try:
            st = json_post(
                _ad_url_v41("/magnet/status", apikey=token),
                payload={"id": str(mid)},
                headers=_ad_headers(token),
                timeout=45,
            )
        except Exception as ex:
            xbmc.log(f"[Kraken] AD magnet/status: {ex}", xbmc.LOGWARNING)
            time.sleep(3)
            continue
        if not isinstance(st, dict) or st.get("status") != "success":
            time.sleep(3)
            continue
        sm = _ad_first_magnet_entry(st)
        if not sm:
            time.sleep(3)
            continue
        code = _ad_magnet_status_code(sm)
        if code == 4:
            break
        if code >= 5:
            try:
                xbmc.log(
                    "[Kraken] AD magnet terminó con error "
                    "(statusCode={} status={})".format(code, sm.get("status")),
                    xbmc.LOGWARNING,
                )
            except Exception:
                pass
            return None
        now = time.time()
        if now - last_slow_log[0] >= 30.0 and code >= 0:
            last_slow_log[0] = now
            try:
                pct = ""
                sz = sm.get("size")
                dn = sm.get("downloaded")
                if dn is not None and sz:
                    try:
                        pct = " {:d}%".format(
                            min(
                                100,
                                int(100 * int(dn) / max(1, int(sz))),
                            )
                        )
                    except Exception:
                        pct = ""
                xbmc.log(
                    "[Kraken] AD magnet id={} en cola/descarga: "
                    "{} (code {}){}".format(mid, sm.get("status"), code, pct),
                    xbmc.LOGINFO,
                )
            except Exception:
                pass
        time.sleep(3)
    else:
        cap = int(max_wait_seconds or _AD_MAGNET_MAX_WAIT)
        if cap < int(_AD_MAGNET_MAX_WAIT):
            if cap <= int(DEBRID_MAGNET_QUICK_POLL_SEC) + 2:
                xbmc.log(
                    "[Kraken] AllDebrid magnet: not ready in {}s (quick attempt), using local torrent".format(
                        cap
                    ),
                    xbmc.LOGINFO,
                )
            else:
                xbmc.log(
                    "[Kraken] AllDebrid magnet: not ready in {}s (wait limit), no direct HTTP yet".format(
                        cap
                    ),
                    xbmc.LOGINFO,
                )
        else:
            xbmc.log(
                "[Kraken] AllDebrid magnet: sin listo tras {}s de espera, sin HTTP directo".format(
                    cap
                ),
                xbmc.LOGINFO,
            )
        return None

    try:
        finfo = json_post(
            _ad_url_v4("/magnet/files", apikey=token),
            payload=[("id[]", str(mid))],
            headers=_ad_headers(token),
            timeout=60,
        )
    except Exception as ex:
        xbmc.log(f"[Kraken] AD magnet/files: {ex}", xbmc.LOGWARNING)
        return None
    if not isinstance(finfo, dict) or finfo.get("status") != "success":
        return None
    mags = (finfo.get("data") or {}).get("magnets") or []
    if not mags or mags[0].get("error"):
        return None
    flat = _ad_flatten_file_tree(mags[0].get("files") or [])
    leaf = choose_alldebrid_leaf_for_playback(flat, playback)
    picked = str((leaf or {}).get("l") or "").strip()
    if not picked:
        return None
    return _ad_link_unlock(picked, token, json_post)


def _alldebrid_resolve(url, token, json_post, magnet_max_wait_seconds=None, playback=None):
    if url.startswith("magnet:"):
        return _alldebrid_resolve_magnet(
            url,
            token,
            json_post,
            max_wait_seconds=magnet_max_wait_seconds,
            playback=playback,
        )
    xbmc.log(
        "[Kraken] AD: solo magnet soportado (no URL .torrent directa)", xbmc.LOGDEBUG
    )
    return None


def maybe_resolve_torrent_via_debrid(
    url,
    get_bool_setting,
    get_setting,
    json_get,
    json_post,
    magnet_max_wait_seconds=None,
    playback=None,
):
    raw = str(url or "").strip()
    if not raw:
        return raw
    if raw.startswith("plugin://"):
        return raw
    if _torrent_like(raw):
        raw = _normalize_magnet_uri(raw)
    is_torrentish = _torrent_like(raw)
    is_http = raw.startswith(("http://", "https://"))
    # Para reproducción normal priorizamos stream directo.
    # Si no parece stream, permitimos unlock AllDebrid para enlaces hoster/puente.
    ad_on = False
    try:
        ad_on = get_bool_setting("debrid_ad_enabled")
    except Exception:
        pass
    token_ad = (get_setting("debrid_ad_token") or "").strip() if ad_on else ""

    pb = playback or {}

    if ad_on and token_ad:
        try:
            if is_torrentish:
                resolved = _alldebrid_resolve(
                    raw,
                    token_ad,
                    json_post,
                    magnet_max_wait_seconds=magnet_max_wait_seconds,
                    playback=pb,
                )
            elif is_http and not _looks_direct_stream_http(raw):
                resolved = _ad_link_unlock(raw, token_ad, json_post, timeout_delayed=45)
            else:
                resolved = None
            if resolved and resolved.startswith(("http://", "https://")):
                xbmc.log(
                    "[Kraken] Debrid: magnet/torrent resuelto a HTTP (AllDebrid)",
                    xbmc.LOGINFO,
                )
                return resolved
        except Exception as ex:
            xbmc.log(f"[Kraken] AllDebrid stream resolve: {ex}", xbmc.LOGWARNING)

    return raw
