from resources.lib.sources.stremio_sources_config import (
    SETTING_PER_ADDON_TOGGLE,
    STREMIO_CATALOG_NAMED_ADDONS,
)


def _stremio_named_filter_prefixes():
    return frozenset(prefix for _, prefix in STREMIO_CATALOG_NAMED_ADDONS)


def get_stremio_toggle_names(*, get_bool_setting, get_setting):
    """Nombres de complementos con URL (respeta multicheck si filtro nombrados activo)."""
    toggles = [
        ("Torrentio", "stremio_torrentio"),
        ("Preeflix", "stremio_preeflix"),
        ("Comet", "stremio_comet"),
        ("MediaFusion", "stremio_mediafusion"),
        ("AIOStreams", "stremio_aiostreams"),
        ("Jackettio", "stremio_jackettio"),
        ("KnightCrawler", "stremio_knightcrawler"),
        ("Annatar", "stremio_annatar"),
        ("Tvvoo", "stremio_tvvoo"),
    ]
    master = get_bool_setting("provider_stremio_catalog")
    try:
        use_named_toggle = bool(get_bool_setting(SETTING_PER_ADDON_TOGGLE))
    except Exception:
        use_named_toggle = False
    filter_prefixes = _stremio_named_filter_prefixes()
    active = []
    for name, prefix in toggles:
        url = (get_setting(f"{prefix}_url") or "").strip()
        if not url:
            continue
        if master:
            if use_named_toggle and prefix in filter_prefixes:
                if not get_bool_setting(f"{prefix}_enabled"):
                    continue
            active.append(name)
        elif get_bool_setting(f"{prefix}_enabled"):
            active.append(name)
    return active


def stremio_addons_config(stremio_open_all_peerflix):
    return [
        ("Torrentio", "stremio_torrentio_enabled", "stremio_torrentio_web_url"),
        ("Preeflix", "stremio_preeflix_enabled", "stremio_preeflix_web_url"),
        ("Comet", "stremio_comet_enabled", "stremio_comet_web_url"),
        ("MediaFusion", "stremio_mediafusion_enabled", "stremio_mediafusion_web_url"),
        ("AIOStreams", "stremio_aiostreams_enabled", "stremio_aiostreams_web_url"),
        ("Jackettio", "stremio_jackettio_enabled", "stremio_jackettio_web_url"),
        (
            "KnightCrawler",
            "stremio_knightcrawler_enabled",
            "stremio_knightcrawler_web_url",
        ),
        ("Annatar", "stremio_annatar_enabled", "stremio_annatar_web_url"),
        ("Tvvoo", "stremio_tvvoo_enabled", "stremio_tvvoo_web_url"),
    ]
