"""Registro local de descargas completadas (peliculas / series / anime)."""

import json
import os
import time

import xbmc
import xbmcaddon
import xbmcvfs

_JOURNAL_NAME = "downloads_journal.json"
_MAX_ITEMS = 400


def _profile_journal_path():
    try:
        add = xbmcaddon.Addon()
        prof = add.getAddonInfo("profile")
        base = xbmcvfs.translatePath(prof) if prof else ""
    except Exception:
        base = ""
    if not base:
        return ""
    if not os.path.isdir(base):
        try:
            os.makedirs(base, exist_ok=True)
        except OSError:
            return ""
    return os.path.join(base, _JOURNAL_NAME)


def journal_resolved_isfile(path_fs):
    """True si path_fs apunta a un fichero que sigue existiendo en disco."""
    p = str(path_fs or "").strip()
    if not p:
        return False
    try:
        local = xbmcvfs.translatePath(p)
    except Exception:
        local = p
    local = str(local or "").strip()
    if not local:
        return False
    try:
        return os.path.isfile(local)
    except OSError:
        return False


def prune_missing_download_entries():
    """Quita del journal las entradas cuyo archivo fue borrado o movido; guarda si hubo cambios."""
    data = load_journal()
    items = list(data.get("items") or [])
    kept = [x for x in items if journal_resolved_isfile((x or {}).get("path"))]
    if len(kept) != len(items):
        data["items"] = kept
        save_journal(data)
    return data


def load_journal():
    path = _profile_journal_path()
    if not path or not os.path.isfile(path):
        return {"version": 1, "items": []}
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict) and isinstance(data.get("items"), list):
            return data
    except Exception as err:
        xbmc.log(f"[Kraken][journal] read: {err}", xbmc.LOGDEBUG)
    return {"version": 1, "items": []}


def save_journal(data):
    path = _profile_journal_path()
    if not path:
        return False
    try:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=True, indent=0)
        try:
            if os.path.isfile(path):
                os.remove(path)
        except OSError:
            pass
        os.replace(tmp, path)
        return True
    except Exception as err:
        xbmc.log(f"[Kraken][journal] save: {err}", xbmc.LOGWARNING)
        return False


def append_entry(*, path_fs, title, kind, bytes_size):
    """path_fs: ruta absoluta traducida (local). kind: movie | series | anime"""
    k = str(kind or "").strip().lower()
    if k not in ("movie", "series", "anime"):
        k = "series"
    entry = {
        "path": str(path_fs or "").strip(),
        "title": str(title or "").strip() or os.path.basename(str(path_fs or "")),
        "kind": k,
        "bytes": int(bytes_size or 0),
        "added": time.time(),
    }
    if not entry["path"]:
        return False
    data = load_journal()
    items = data.get("items") or []
    items.insert(0, entry)
    data["items"] = items[:_MAX_ITEMS]
    return save_journal(data)


def filter_items(kind_filter):
    """kind_filter: movie | series | anime | all"""
    data = prune_missing_download_entries()
    items = data.get("items") or []
    kf = str(kind_filter or "all").strip().lower()
    if kf == "all":
        return items
    return [x for x in items if str((x or {}).get("kind") or "").lower() == kf]
