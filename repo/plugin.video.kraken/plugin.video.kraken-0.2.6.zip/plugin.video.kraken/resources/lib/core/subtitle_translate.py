import hashlib
import json
import os
from urllib.parse import quote
from urllib.request import Request, urlopen


def _profile_path(profile_dir):
    path = str(profile_dir or "").strip()
    if path.startswith("special://"):
        try:
            import xbmcvfs

            path = xbmcvfs.translatePath(path)
        except Exception:
            pass
    if path and not os.path.isdir(path):
        try:
            os.makedirs(path, exist_ok=True)
        except Exception:
            return ""
    return path


def _parse_srt(text):
    blocks = []
    chunk = []
    for line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        if line.strip():
            chunk.append(line)
            continue
        if chunk:
            blocks.append(chunk)
            chunk = []
    if chunk:
        blocks.append(chunk)
    return blocks


def _render_srt(blocks):
    return "\n\n".join("\n".join(block) for block in blocks) + "\n"


def _lingva_translate(text, *, endpoint, source_lang, target_lang, timeout=20):
    base = str(endpoint or "https://lingva.ml").strip().rstrip("/")
    src = quote(str(source_lang or "auto").strip() or "auto", safe="")
    dst = quote(str(target_lang or "en").strip() or "en", safe="")
    q = quote(str(text or ""), safe="")
    req = Request(f"{base}/api/v1/{src}/{dst}/{q}", headers={"User-Agent": "KrakenKodi/1.0"})
    with urlopen(req, timeout=timeout) as resp:
        payload = json.loads(resp.read().decode("utf-8"))
    return str(payload.get("translation") or payload.get("translatedText") or text)


def translate_srt_file(src_path, *, profile_dir, source_lang, target_lang, endpoint, max_chars=1200):
    if not src_path or not os.path.isfile(src_path):
        return ""
    base = _profile_path(profile_dir)
    if not base:
        return ""
    cache_dir = os.path.join(base, "translated_subtitles")
    os.makedirs(cache_dir, exist_ok=True)
    digest = hashlib.sha1((src_path + "|" + str(os.path.getmtime(src_path)) + "|" + target_lang).encode("utf-8")).hexdigest()
    out_path = os.path.join(cache_dir, f"{digest}.{target_lang}.srt")
    if os.path.isfile(out_path):
        return out_path
    with open(src_path, "r", encoding="utf-8-sig", errors="replace") as fh:
        text = fh.read()
    blocks = _parse_srt(text)
    limit = max(200, int(max_chars or 1200))
    for block in blocks:
        if len(block) <= 2:
            continue
        subtitle_lines = block[2:]
        buf = []
        size = 0
        translated = []
        for line in subtitle_lines:
            if size + len(line) > limit and buf:
                translated.extend(_lingva_translate("\n".join(buf), endpoint=endpoint, source_lang=source_lang, target_lang=target_lang).split("\n"))
                buf = []
                size = 0
            buf.append(line)
            size += len(line)
        if buf:
            translated.extend(_lingva_translate("\n".join(buf), endpoint=endpoint, source_lang=source_lang, target_lang=target_lang).split("\n"))
        block[2:] = translated or subtitle_lines
    with open(out_path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(_render_srt(blocks))
    return out_path


def clear_translated_subtitles(profile_dir):
    base = _profile_path(profile_dir)
    cache_dir = os.path.join(base, "translated_subtitles") if base else ""
    if not cache_dir or not os.path.isdir(cache_dir):
        return 0
    removed = 0
    for root, _dirs, files in os.walk(cache_dir):
        for name in files:
            if not name.lower().endswith((".srt", ".sub", ".vtt", ".ass", ".ssa")):
                continue
            try:
                os.remove(os.path.join(root, name))
                removed += 1
            except OSError:
                pass
    return removed
