"""
Propiedades de ListItem para reproduccion: HLS/DASH suelen necesitar InputStream.Adaptive.
Sin esto Kodi a veces devuelve «Error creating demuxer» en .m3u8 (p. ej. canales Tvvoo).
"""

import json
from urllib.parse import quote, urlparse

import xbmc
import xbmcgui

# UA de navegador habitual; muchas CDNs de IPTV rechazan el UA por defecto de Kodi.
_DEFAULT_STREAM_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)


def inputstream_adaptive_installed():
    try:
        return xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)") == 1
    except Exception:
        return False


def inputstream_ffmpegdirect_installed():
    try:
        return xbmc.getCondVisibility("System.HasAddon(inputstream.ffmpegdirect)") == 1
    except Exception:
        return False


def _kodi_major_version():
    try:
        ver = (xbmc.getInfoLabel("System.BuildVersion") or "").strip()
        return int(str(ver).split(".", 1)[0])
    except Exception:
        return 21


def _sunshine_style_cdn(url):
    low = str(url or "").lower()
    return "ngolpdkyoctjcddxshli469r.org" in low or "/sunshine/" in low


def _headers_dict_to_isa_param(headers_dict):
    """Convierte dict de cabeceras a cadena ISA (clave=valor&…, valores URL-encoded)."""
    if not isinstance(headers_dict, dict) or not headers_dict:
        return ""
    parts = []
    for k, v in headers_dict.items():
        kk = str(k).strip()
        if not kk or v is None:
            continue
        parts.append("{}={}".format(kk, quote(str(v), safe="")))
    return "&".join(parts)


def _merged_stream_headers_dict(stream_url, extra_headers=None):
    """
    Cabeceras efectivas: primero `streams[].headers` de Stremio si hay;
    si no, CDN sunshine/Tvvoo (Referer tvvoo.hayd.uk); si no, Referer/Origin del host de la URL.
    """
    u = str(stream_url or "").strip()
    if isinstance(extra_headers, dict) and extra_headers:
        out = {}
        for k, v in extra_headers.items():
            kk = str(k).strip()
            if not kk or v is None:
                continue
            out[kk] = str(v)
        if out:
            return out
    if _sunshine_style_cdn(u):
        return {
            "User-Agent": _DEFAULT_STREAM_UA,
            "Referer": "https://tvvoo.hayd.uk/",
            "Origin": "https://tvvoo.hayd.uk",
        }
    try:
        p = urlparse(u)
        if not p.netloc:
            return {}
        scheme = (p.scheme or "https").lower()
        origin = f"{scheme}://{p.netloc}"
        referer = "{}/".format(origin.rstrip("/"))
        return {
            "User-Agent": _DEFAULT_STREAM_UA,
            "Referer": referer,
            "Origin": origin,
        }
    except Exception:
        return {}


def _headers_dict_to_ffmpegdirect_pipe_suffix(headers_dict):
    """Sufijo tras | para inputstream.ffmpegdirect (mismo esquema clave=valor que ISA)."""
    return _headers_dict_to_isa_param(headers_dict)


def _isa_http_headers_param(stream_url, extra_headers=None):
    """
    Cabeceras HTTP para ISA (valores entre & URL-encoded, ver wiki inputstream.adaptive).

    Desde Kodi 21, stream_headers solo aplica a segmentos; la descarga del .m3u8 usa
    manifest_headers.
    """
    return _headers_dict_to_isa_param(
        _merged_stream_headers_dict(stream_url, extra_headers)
    )


def configure_listitem_stream_properties(listitem, stream_url, http_headers_extra=None):
    """
    Ajusta MIME + inputstream.adaptive para URLs manifest (HLS/MPEG-DASH).

    http_headers_extra: dict del campo `headers` de Stremio /stream (si existe).
    """
    u = str(stream_url or "").strip()
    if not u.startswith(("http://", "https://")):
        return

    low = u.lower()
    is_hls = ".m3u8" in low or "/hls/" in low
    is_dash = ".mpd" in low or "format=mpd" in low or "/dash/" in low
    if not is_hls and not is_dash:
        return

    try:
        listitem.setContentLookup(False)
    except Exception:
        pass

    if is_hls:
        try:
            listitem.setMimeType("application/vnd.apple.mpegurl")
        except Exception:
            pass

    # Sunshine/Tvvoo: ISA suele ir por cURL de Kodi y agotar timeout (28) en el manifiesto;
    # ffmpegdirect + open_mode=ffmpeg usa libavformat y |User-Agent=…&Referer=… en la URL.
    if is_hls and _sunshine_style_cdn(u) and inputstream_ffmpegdirect_installed():
        hdr_dict = _merged_stream_headers_dict(u, http_headers_extra)
        play_u = u
        pipe = _headers_dict_to_ffmpegdirect_pipe_suffix(hdr_dict)
        if pipe:
            play_u = f"{u}|{pipe}"
        try:
            listitem.setPath(play_u)
        except Exception:
            pass
        try:
            listitem.setProperty("inputstream", "inputstream.ffmpegdirect")
            listitem.setProperty("inputstream.ffmpegdirect.manifest_type", "hls")
            listitem.setProperty("inputstream.ffmpegdirect.open_mode", "ffmpeg")
            if "/hls/" in low and "index.m3u8" in low:
                listitem.setProperty(
                    "inputstream.ffmpegdirect.is_realtime_stream", "true"
                )
        except Exception:
            pass
        try:
            xbmc.log(
                "[Kraken] HLS sunshine: inputstream.ffmpegdirect (ffmpeg), no ISA.",
                xbmc.LOGINFO,
            )
        except Exception:
            pass
        return

    if is_hls and _sunshine_style_cdn(u) and not inputstream_ffmpegdirect_installed():
        try:
            xbmc.log(
                "[Kraken] HLS sunshine: opcional «InputStream FFmpeg Direct» puede evitar timeouts de ISA.",
                xbmc.LOGINFO,
            )
        except Exception:
            pass

    if is_dash:
        try:
            listitem.setMimeType("application/dash+xml")
        except Exception:
            pass

    if not inputstream_adaptive_installed():
        try:
            xbmc.log(
                "[Kraken] HLS/DASH: instala el addon «InputStream Adaptive» (repositorio oficial de Kodi). "
                "Sin el, la reproduccion de .m3u8 suele fallar (Error creating demuxer).",
                xbmc.LOGWARNING,
            )
        except Exception:
            pass
        try:
            xbmcgui.Dialog().notification(
                "Kraken",
                "Instala InputStream Adaptive desde complementos (repositorio Kodi) para canales HLS.",
                xbmcgui.NOTIFICATION_WARNING,
                12000,
            )
        except Exception:
            pass
        return

    hdrs = _isa_http_headers_param(u, http_headers_extra)
    try:
        if is_hls:
            listitem.setProperty("inputstream", "inputstream.adaptive")
            if _kodi_major_version() <= 20:
                listitem.setProperty("inputstream.adaptive.manifest_type", "hls")
            if hdrs:
                listitem.setProperty("inputstream.adaptive.manifest_headers", hdrs)
                listitem.setProperty("inputstream.adaptive.stream_headers", hdrs)
            try:
                listitem.setProperty(
                    "inputstream.adaptive.manifest_config",
                    json.dumps({"hls_ignore_endlist": True}),
                )
            except Exception:
                pass
            try:
                listitem.setProperty(
                    "inputstream.adaptive.config",
                    json.dumps({"internal_cookies": True}),
                )
            except Exception:
                pass
            if "/hls/" in low and "index.m3u8" in low:
                listitem.setProperty("inputstream.adaptive.is_live", "true")
            return
        if is_dash:
            listitem.setProperty("inputstream", "inputstream.adaptive")
            if _kodi_major_version() <= 20:
                listitem.setProperty("inputstream.adaptive.manifest_type", "mpd")
            if hdrs:
                listitem.setProperty("inputstream.adaptive.manifest_headers", hdrs)
                listitem.setProperty("inputstream.adaptive.stream_headers", hdrs)
            try:
                listitem.setProperty(
                    "inputstream.adaptive.config",
                    json.dumps({"internal_cookies": True}),
                )
            except Exception:
                pass
    except Exception:
        pass
