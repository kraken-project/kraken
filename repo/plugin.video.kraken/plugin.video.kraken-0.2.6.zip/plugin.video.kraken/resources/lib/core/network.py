import json
from urllib.parse import urlencode
from urllib.request import Request, urlopen


def json_get(url, headers=None, timeout=15):
    req = Request(url, headers=headers or {})
    with urlopen(req, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def json_post(url, payload=None, headers=None, timeout=15):
    raw = {} if payload is None else payload
    body = urlencode(raw).encode("utf-8")
    hdrs = dict(headers or {})
    hdrs.setdefault(
        "Content-Type", "application/x-www-form-urlencoded; charset=UTF-8"
    )
    req = Request(url, data=body, headers=hdrs)
    with urlopen(req, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))
