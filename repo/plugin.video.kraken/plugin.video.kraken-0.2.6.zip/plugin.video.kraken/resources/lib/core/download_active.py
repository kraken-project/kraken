"""Estado global de descargas HTTP en curso (titulo + porcentaje) para Mis descargas > En curso."""

import threading
import time

_LOCK = threading.Lock()
_ENTRIES = []
_MAX = 24


def _now():
    return time.time()


def begin(title, subtitle=""):
    """Registra una descarga nueva; devuelve id o None."""
    tid = f"{int(_now() * 1000)}-{threading.get_ident() & 0xFFFF:x}"
    title = str(title or "").strip() or "Descarga"
    subtitle = str(subtitle or "").strip()
    row = {
        "id": tid,
        "title": title,
        "subtitle": subtitle,
        "pct": 0,
        "detail": subtitle,
        "t": _now(),
    }
    try:
        with _LOCK:
            _ENTRIES.insert(0, row)
            del _ENTRIES[_MAX:]
    except Exception:
        return None
    return tid


def update(download_id, pct, detail=None):
    if not download_id:
        return
    try:
        p = max(0, min(100, int(pct)))
    except (TypeError, ValueError):
        p = 0
    with _LOCK:
        for row in _ENTRIES:
            if row.get("id") == download_id:
                row["pct"] = p
                row["t"] = _now()
                if detail is not None:
                    row["detail"] = str(detail or "").strip()
                break


def finish(download_id):
    if not download_id:
        return
    try:
        with _LOCK:
            for i, row in enumerate(_ENTRIES):
                if row.get("id") == download_id:
                    _ENTRIES.pop(i)
                    break
    except Exception:
        pass


def snapshot():
    """Copia actual para pintar listas Kodi (orden: mas recientes primero)."""
    try:
        with _LOCK:
            return [dict(x) for x in _ENTRIES]
    except Exception:
        return []
