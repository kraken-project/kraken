import json

import xbmc
import xbmcaddon


def _normalize_code2(value):
    raw = str(value or "").strip()
    if not raw:
        return ""
    # labelenum + lvalues: algunas versiones de Kodi guardan el id de strings.po (30169–30174).
    if raw.isdigit():
        try:
            nid = int(raw)
        except (TypeError, ValueError):
            nid = -1
        by_po_id = {
            30169: "",  # Auto (Kodi) → vacío, preferred_text_lang_code usa lógica Kodi
            30170: "es",
            30171: "en",
            30172: "fr",
            30173: "it",
            30174: "de",
        }
        if nid in by_po_id:
            return by_po_id[nid]
    v = raw.lower()
    if v in ("en", "en_gb", "en-us", "english", "ingles", "inglés"):
        return "en"
    if v in ("es", "es_es", "es-es", "spanish", "espanol", "español", "castellano"):
        return "es"
    if v in ("fr", "fr_fr", "fr-fr", "french", "frances", "francés"):
        return "fr"
    if v in ("it", "it_it", "it-it", "italian", "italiano"):
        return "it"
    if v in ("de", "de_de", "de-de", "german", "aleman", "alemán", "deutsch"):
        return "de"
    if v.startswith("en"):
        return "en"
    if v.startswith("es"):
        return "es"
    if v.startswith("fr"):
        return "fr"
    if v.startswith("it"):
        return "it"
    if v.startswith("de"):
        return "de"
    if "english" in v:
        return "en"
    if "spanish" in v or "espanol" in v or "español" in v:
        return "es"
    if "french" in v or "francais" in v or "français" in v:
        return "fr"
    if "italian" in v or "italiano" in v:
        return "it"
    if "german" in v or "deutsch" in v:
        return "de"
    return ""


def _kodi_language_code2():
    try:
        raw = xbmc.executeJSONRPC(
            '{"jsonrpc":"2.0","id":1,"method":"Settings.GetSettingValue","params":{"setting":"locale.language"}}'
        )
        data = json.loads(raw or "{}")
        val = str(((data or {}).get("result") or {}).get("value") or "").strip().lower()
    except Exception:
        val = ""
    if (
        val.startswith("resource.language.spanish")
        or val.startswith("es")
        or "spanish" in val
        or "espanol" in val
    ):
        return "es"
    if val.startswith("resource.language.english") or val.startswith("en") or "english" in val:
        return "en"
    if val.startswith("resource.language.french") or val.startswith("fr") or "french" in val:
        return "fr"
    if val.startswith("resource.language.italian") or val.startswith("it") or "italian" in val:
        return "it"
    if (
        val.startswith("resource.language.german")
        or val.startswith("resource.language.de_de")
        or val.startswith("de")
        or "german" in val
        or "deutsch" in val
    ):
        return "de"
    # Fallback alternativo por si locale.language devuelve formatos no esperados.
    try:
        gui_lang = str(xbmc.getLanguage(xbmc.ISO_639_1) or "").strip().lower()
        if gui_lang.startswith("es"):
            return "es"
        if gui_lang.startswith("en"):
            return "en"
        if gui_lang.startswith("fr"):
            return "fr"
        if gui_lang.startswith("it"):
            return "it"
        if gui_lang.startswith("de"):
            return "de"
    except Exception:
        pass
    # Para no forzar castellano cuando no podemos detectar el idioma.
    return "en"


def preferred_text_lang_code():
    """
    Idioma efectivo de textos/metadatos.
    Prioridad: ajuste explícito UI -> ajuste Trakt -> idioma Kodi.
    """
    try:
        addon = xbmcaddon.Addon("plugin.video.kraken")
    except Exception:
        addon = None
    ui = ""
    tp = ""
    if addon is not None:
        try:
            ui = str(addon.getSetting("kraken_ui_language") or "").strip().lower()
        except Exception:
            ui = ""
        try:
            tp = str(addon.getSetting("trakt_plot_language") or "").strip().lower()
        except Exception:
            tp = ""
    ui_n = _normalize_code2(ui)
    if ui_n:
        return ui_n
    tp_n = _normalize_code2(tp)
    if tp_n:
        return tp_n
    return _kodi_language_code2()


def tmdb_language_param():
    code2 = preferred_text_lang_code()
    mapping = {
        "en": "en-US",
        "es": "es-ES",
        "fr": "fr-FR",
        "it": "it-IT",
        "de": "de-DE",
    }
    return mapping.get(code2, "es-ES")


def tmdb_theatrical_region_code():
    """
    ISO 3166-1 alpha-2 para TMDb /movie/now_playing (cartelera por país).
    Prioridad: ajuste regional de Kodi; si no, idioma de interfaz.
    """
    try:
        raw = xbmc.executeJSONRPC(
            '{"jsonrpc":"2.0","id":1,"method":"Settings.GetSettingValue","params":{"setting":"locale.country"}}'
        )
        data = json.loads(raw or "{}")
        val = str(((data or {}).get("result") or {}).get("value") or "").strip()
        if len(val) == 2 and val.isalpha():
            return val.upper()
    except Exception:
        pass
    lc = preferred_text_lang_code()
    return {
        "es": "ES",
        "en": "US",
        "fr": "FR",
        "it": "IT",
        "de": "DE",
        "pt": "BR",
    }.get(lc, "US")
