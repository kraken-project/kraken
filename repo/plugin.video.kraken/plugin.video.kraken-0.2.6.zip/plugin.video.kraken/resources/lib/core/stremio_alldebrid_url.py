"""Inyeccion opcional de token Debrid en URLs de complementos Stremio compatibles."""

from urllib.parse import quote, urlparse

# Hosts donde suele funcionar el mismo esquema que Torrentio: ...|alldebrid=KEY/manifest.json
# (ELF hosted Jackettio/MediaFusion/Comet; Peerflix; Tvvoo). Si un addon cambia formato, desactiva la opcion.
_ALLDEBRID_PIPE_HOST_SUFFIXES = (
    "torrentio.strem.fun",
    "torrentio.elfhosted.com",
    "annatar.elfhosted.com",
    "jackettio.elfhosted.com",
    "knightcrawler.elfhosted.com",
    "stremio-jackett.elfhosted.com",
    "mediafusion.elfhosted.com",
    "comet.elfhosted.com",
    "aiostreams.elfhosted.com",
    "shluflix.elfhosted.com",
    "thepiratebay-plus.strem.fun",
    "torrent-catalogs.strem.fun",
    "yggstremio.fun",
    "addon.peerflix.mov",
    "config.peerflix.mov",
    "peerflix.mov",
    "peerflix-235ac-default-rtdb.europe-west1.firebasedatabase.app",
    "tvvoo.hayd.uk",
    "68d69db7dc40-debrid-search.baby-beamup.club",
)


def _manifest_host_allowed(netloc):
    h = (netloc or "").strip().lower()
    if not h:
        return False
    h = h.split("@")[-1].split(":")[0]
    return any(h == s or h.endswith(s) for s in _ALLDEBRID_PIPE_HOST_SUFFIXES)


def augment_stremio_debrid_pipe_url(url, token, pipe_key):
    """
    Inserta |<pipe_key>=APIKEY antes de /manifest.json si el host esta permitido (estilo Torrentio).
    Ver p. ej. https://github.com/TheBeastLT/torrentio-scraper
    """
    u = (url or "").strip()
    t = (token or "").strip()
    key = str(pipe_key or "").strip().lower()
    if not u or not t or not key:
        return u
    if f"{key}=" in u.lower():
        return u
    try:
        host = urlparse(u).netloc
    except Exception:
        return u
    if not _manifest_host_allowed(host):
        return u
    enc = quote(t, safe="")
    marker = "/manifest.json"
    if marker not in u:
        return u
    return u.replace(marker, f"|{key}={enc}{marker}", 1)


def augment_stremio_alldebrid_pipe_url(url, token):
    """Compatibilidad hacia atrás: inserta |alldebrid=APIKEY."""
    return augment_stremio_debrid_pipe_url(url, token, "alldebrid")


def augment_stremio_catalog_url(url, addon):
    """
    URLs de catálogo/manifest para descubrimiento y búsqueda.
    No se inyecta Debrid aquí: varios addons dejan de responder catálogos si se altera
    transport/manifest con el pipe (|alldebrid=...).
    """
    return (url or "").strip()
