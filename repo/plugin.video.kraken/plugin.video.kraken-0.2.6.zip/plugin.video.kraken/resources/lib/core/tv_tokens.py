import base64
import json

import xbmc


def tv_catalog_token_dict(meta_type, catalog_id, genre=None, catalog_name=None):
    data = {"m": str(meta_type or "tv"), "c": str(catalog_id or "")}
    g = (genre or "").strip() if genre is not None else ""
    if g:
        data["g"] = g
    cn = str(catalog_name or "").strip() if catalog_name is not None else ""
    if cn:
        data["n"] = cn
    s = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return base64.urlsafe_b64encode(s.encode("utf-8")).decode("ascii").rstrip("=")


def tv_catalog_token_read(token):
    raw = (token or "").strip()
    if not raw:
        return "tv", "", None, ""
    try:
        pad = "=" * (-(len(raw)) % 4)
        s = base64.urlsafe_b64decode(raw + pad).decode("utf-8")
        o = json.loads(s) if s else {}
    except Exception as e:
        xbmc.log(
            "[Kraken] token catalogo TV no valido: {} ({})".format(
                (token or "")[:48], e
            ),
            xbmc.LOGINFO,
        )
        return "tv", "", None, ""
    if not isinstance(o, dict):
        return "tv", "", None, ""
    g0 = o.get("g")
    g = str(g0).strip() if g0 is not None else ""
    g = g if g else None
    n = str(o.get("n") or "").strip()
    return str(o.get("m", "tv") or "tv"), str(o.get("c", "") or "").strip(), g, n
