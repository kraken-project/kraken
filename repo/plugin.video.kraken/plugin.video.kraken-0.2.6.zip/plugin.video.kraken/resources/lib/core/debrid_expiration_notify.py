# Avisos de caducidad de suscripcion AllDebrid.
# Implementacion propia sobre el endpoint REST usado ya en Kraken para validar cuenta.
from __future__ import annotations

import datetime as _dt
from collections.abc import Callable
from urllib.parse import urlencode


def days_remaining_alldebrid(token: str, json_get: Callable) -> int | None:
    token = (token or "").strip()
    if not token:
        return None
    try:
        q = urlencode({"apikey": token, "agent": "KrakenKodi"})
        data = json_get(f"https://api.alldebrid.com/v4/user?{q}", timeout=20)
        if data.get("status") != "success":
            return None
        payload = data.get("data") or {}
        sub = payload.get("subscription") or {}
        until = sub.get("premium_until")
        if until is None:
            nested = payload.get("user") or {}
            if isinstance(nested, dict):
                ns = nested.get("subscription")
                if isinstance(ns, dict):
                    until = ns.get("premium_until")
        if until is None:
            return None
        try:
            ts = float(until)
        except (TypeError, ValueError):
            return None
        expires = _dt.datetime.fromtimestamp(ts)
        return int((expires - _dt.datetime.now()).days)
    except Exception:
        return None


def _threshold_days(get_setting_str: Callable[[str, str], str]) -> int:
    raw = get_setting_str("debrid_expiration_notify_days", "3").strip()
    try:
        v = int(raw)
    except ValueError:
        v = 3
    return max(1, min(30, v))


def _already_notified_today(key_suffix: str) -> bool:
    try:
        import xbmcgui
    except Exception:
        return False
    day = _dt.date.today().isoformat()
    prop = f"Kraken.DebridExpNotify.{day}.{key_suffix}"
    return (xbmcgui.Window(10000).getProperty(prop) or "").strip() == "1"


def _mark_notified_today(key_suffix: str) -> None:
    try:
        import xbmcgui
    except Exception:
        return
    day = _dt.date.today().isoformat()
    prop = f"Kraken.DebridExpNotify.{day}.{key_suffix}"
    xbmcgui.Window(10000).setProperty(prop, "1")


def run_debrid_expiration_notifications(
    *,
    get_bool_setting: Callable[[str, str], bool],
    get_setting_str: Callable[[str, str], str],
    json_get: Callable,
    dialog_notification: Callable[[str, str, int], None],
) -> None:
    """Comprueba cuenta AllDebrid habilitada y muestra como mucho una notificacion por dia."""
    if not get_bool_setting("debrid_expiration_notify_enabled", "true"):
        return
    threshold = _threshold_days(get_setting_str)

    def maybe(
        name: str,
        suffix: str,
        enabled_key: str,
        token_key: str,
        days_fn: Callable[[], int | None],
    ) -> None:
        if not get_bool_setting(enabled_key, "false"):
            return
        tok = get_setting_str(token_key, "")
        if not tok.strip():
            return
        days = days_fn()
        if days is None or days > threshold:
            return
        if _already_notified_today(suffix):
            return
        _mark_notified_today(suffix)
        if days <= 0:
            msg = f"Kraken: {name} — suscripcion caducada o sin dias restantes."
        else:
            msg = f"Kraken: {name} caduca en {days} dias."
        dialog_notification("Kraken — Debrid", msg, 6500)

    maybe(
        "AllDebrid",
        "ad",
        "debrid_ad_enabled",
        "debrid_ad_token",
        lambda: days_remaining_alldebrid(
            get_setting_str("debrid_ad_token", ""), json_get
        ),
    )
