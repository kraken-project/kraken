def get_bool_setting(addon, setting_id):
    try:
        return addon.getSettingBool(setting_id)
    except Exception:
        pass
    raw = get_setting(addon, setting_id)
    return str(raw or "").strip().lower() in ("true", "1", "yes")


def get_setting(addon, setting_id):
    """
    Kodi tipa los ajustes (bool, string, labelenum, etc.). getSettingString en labelenum/bool
    dispara «Invalid setting type» (a veces logueado aunque se capture); getSetting() suele
    devolver el valor como texto para la mayoría de tipos.
    """
    sid = setting_id
    try:
        v = addon.getSetting(sid)
        if v is not None:
            return str(v)
    except Exception:
        pass
    return ""


def get_int_setting(addon, setting_id, default_value):
    try:
        raw = (get_setting(addon, setting_id) or "").strip()
        return int(raw) if raw else int(default_value)
    except Exception:
        return int(default_value)


def set_setting(addon, setting_id, value):
    if value is None:
        value = ""
    text_value = str(value)
    try:
        addon.setSetting(setting_id, text_value)
        return
    except Exception:
        pass
