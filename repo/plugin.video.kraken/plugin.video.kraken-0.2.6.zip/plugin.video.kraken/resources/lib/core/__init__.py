"""Utilidades centrales del add-on (red, Stremio, Debrid, runtime)."""
