"""Escapado de rutas para builtins Kodi entre comillas (RunPlugin, PlayMedia, …)."""


def escape_for_quoted_builtin(path):
    """Escapa barras invertidas y comillas para RunPlugin/PlayMedia entre comillas."""
    return (path or "").strip().replace("\\", "\\\\").replace('"', '\\"')
