from resources.lib.trakt.trakt_meta import trakt_float_or_none, trakt_parse_year
from resources.lib.ui.video_info import apply_video_info


def trakt_year_from_movie_dict(data):
    """
    Año de un objeto movie de Trakt: a veces solo llega 'released' (AAAA-MM-DD).
    """
    if not isinstance(data, dict):
        return None, False
    year, ok = trakt_parse_year(data.get("year"))
    if ok and year is not None:
        return year, True
    for key in ("released", "release_date", "first_released"):
        s = str(data.get(key) or "").strip()
        if len(s) >= 4 and s[:4].isdigit():
            y2, ok2 = trakt_parse_year(int(s[:4]))
            if ok2 and y2 is not None:
                return y2, True
    return None, False


def trakt_listitem_set_info_and_videotag(
    li, title, plot, is_show, has_year, year, rating, votes, info
):
    """
    En Kodi 20+ setInfo('video', ...) a veces no aplica todo en listas de plugin.
    InfoTagVideo repone año, rating y plot para más skins.
    """
    try:
        tag = li.getVideoInfoTag()
    except (AttributeError, TypeError, SystemError, RuntimeError):
        tag = None

    if tag is not None:
        try:
            tag.setTitle(title)
            tag.setMediaType("tvshow" if is_show else "movie")
            tag.setPlot(plot or "")
        except (TypeError, ValueError, AttributeError):
            pass

        if has_year and year is not None:
            try:
                tag.setYear(int(year))
            except (TypeError, ValueError):
                pass

        rating_num = trakt_float_or_none(rating)
        votes_num = 0
        if votes is not None and votes != "":
            try:
                votes_num = int(votes)
            except (TypeError, ValueError):
                votes_num = 0
        if rating_num is not None and (rating_num > 0.0 or votes_num > 0):
            try:
                tag.setRating(rating_num, votes_num, "trakt", True)
            except (TypeError, ValueError, AttributeError):
                pass

    apply_video_info(li, info)
