def run_actor_people_listing_and_open(
    *,
    kind,
    forced_query,
    search_actor_people_listing_impl,
    plugin_handle,
    search_history_last,
    search_history_add,
    get_trakt_search_provider,
    default_list_art,
    url_for_movie_person,
    url_for_show_person,
    search_actor_credits,
):
    person_id = search_actor_people_listing_impl(
        kind,
        forced_query=forced_query,
        plugin_handle=plugin_handle,
        search_history_last=search_history_last,
        search_history_add=search_history_add,
        get_trakt_search_provider=get_trakt_search_provider,
        default_list_art=default_list_art,
        url_for_movie_person=url_for_movie_person,
        url_for_show_person=url_for_show_person,
    )
    if person_id is not None:
        search_actor_credits(
            "movie" if (kind or "movie").lower() == "movie" else "show", person_id
        )


def run_actor_credits_search(
    *,
    kind,
    person_id,
    search_actor_credits_impl,
    get_trakt_search_provider,
    kraken_progress,
    trakt_results_limit,
    tmdb_enabled,
    omdb_enabled,
    enrich_trakt_result_items_with_metadata,
    add_trakt_search_listing_to_directory,
    trakt_parse_year,
):
    search_actor_credits_impl(
        kind,
        person_id,
        get_trakt_search_provider=get_trakt_search_provider,
        kraken_progress=kraken_progress,
        trakt_results_limit=trakt_results_limit,
        tmdb_enabled=tmdb_enabled,
        omdb_enabled=omdb_enabled,
        enrich_trakt_result_items_with_metadata=enrich_trakt_result_items_with_metadata,
        add_trakt_search_listing_to_directory=add_trakt_search_listing_to_directory,
        trakt_parse_year=trakt_parse_year,
    )
