import json
import time
from urllib.error import HTTPError
from urllib.request import Request, urlopen


def trakt_post(url, payload):
    headers = {
        "Content-Type": "application/json",
        "trakt-api-version": "2",
        "User-Agent": "Kraken Kodi Addon/0.1",
    }
    req = Request(url, data=json.dumps(payload).encode("utf-8"), headers=headers)
    with urlopen(req, timeout=15) as response:
        return json.loads(response.read().decode("utf-8"))


def trakt_get(url, client_id, access_token):
    headers = {
        "Content-Type": "application/json",
        "trakt-api-version": "2",
        "trakt-api-key": client_id,
        "Authorization": f"Bearer {access_token}",
        "User-Agent": "Kraken Kodi Addon/0.1",
    }
    req = Request(url, headers=headers)
    with urlopen(req, timeout=15) as response:
        return json.loads(response.read().decode("utf-8"))


def trakt_public_get(url, trakt_client_id):
    headers = {
        "Content-Type": "application/json",
        "trakt-api-version": "2",
        "trakt-api-key": trakt_client_id,
        "User-Agent": "Kraken Kodi Addon/0.1",
    }
    req = Request(url, headers=headers)
    with urlopen(req, timeout=15) as response:
        return json.loads(response.read().decode("utf-8"))


def trakt_is_ready(get_bool_setting, get_setting):
    if not get_bool_setting("trakt_enabled"):
        return False
    return bool((get_setting("trakt_access_token") or "").strip())


def trakt_authed_get(url, get_setting, trakt_client_id, trakt_get_fn):
    token = (get_setting("trakt_access_token") or "").strip()
    if not token:
        raise ValueError("Trakt sin token")
    return trakt_get_fn(url, trakt_client_id, token)


def trakt_refresh_access_token(
    *,
    get_setting,
    set_setting,
    trakt_client_id,
    trakt_client_secret,
    trakt_post_fn,
):
    refresh_token = (get_setting("trakt_refresh_token") or "").strip()
    if not refresh_token:
        raise ValueError("Trakt sin refresh token")

    payload = trakt_post_fn(
        "https://api.trakt.tv/oauth/token",
        {
            "refresh_token": refresh_token,
            "client_id": trakt_client_id,
            "client_secret": trakt_client_secret,
            "redirect_uri": "urn:ietf:wg:oauth:2.0:oob",
            "grant_type": "refresh_token",
        },
    )
    access_token = (payload or {}).get("access_token") or ""
    if not access_token:
        raise ValueError("Respuesta de refresh sin access_token")

    set_setting("trakt_access_token", str(access_token))
    new_refresh = (payload or {}).get("refresh_token")
    if new_refresh is not None:
        set_setting("trakt_refresh_token", str(new_refresh))

    created_at = int((payload or {}).get("created_at") or int(time.time()))
    expires_in = int((payload or {}).get("expires_in") or 0)
    set_setting("trakt_token_expires", str(created_at + max(0, expires_in)))
    return str(access_token)


def trakt_authed_get_with_refresh(
    *,
    url,
    get_setting,
    set_setting,
    trakt_client_id,
    trakt_client_secret,
    trakt_get_fn,
    trakt_post_fn,
):
    token = (get_setting("trakt_access_token") or "").strip()
    if not token:
        raise ValueError("Trakt sin token")
    try:
        return trakt_get_fn(url, trakt_client_id, token)
    except HTTPError as ex:
        if int(getattr(ex, "code", 0) or 0) != 401:
            raise
    token = trakt_refresh_access_token(
        get_setting=get_setting,
        set_setting=set_setting,
        trakt_client_id=trakt_client_id,
        trakt_client_secret=trakt_client_secret,
        trakt_post_fn=trakt_post_fn,
    )
    return trakt_get_fn(url, trakt_client_id, token)
