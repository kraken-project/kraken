"""
Fábrica _t compartida para búsqueda y listados Trakt (FR/IT/DE vía mapa).

Incluye textos de search_flow, actor_search y search_listing en un solo bloque.
"""

from resources.lib.routes.i18n_routes import make_mapped_t

_TRAKT_PHRASE_MAP = {
    # --- search_flow (búsqueda Trakt)
    (
        "Buscar película en Trakt",
        "Search movie on Trakt",
    ): (
        "Rechercher un film sur Trakt",
        "Cerca film su Trakt",
        "Film auf Trakt suchen",
    ),
    (
        "Buscar serie en Trakt",
        "Search TV show on Trakt",
    ): (
        "Rechercher une série sur Trakt",
        "Cerca serie TV su Trakt",
        "Serie auf Trakt suchen",
    ),
    (
        "Buscar en Trakt",
        "Search on Trakt",
    ): (
        "Rechercher sur Trakt",
        "Cerca su Trakt",
        "Auf Trakt suchen",
    ),
    (
        "Kraken - Búsqueda Kraken",
        "Kraken - Kraken Search",
    ): (
        "Kraken - Recherche Kraken",
        "Kraken - Ricerca Kraken",
        "Kraken - Kraken-Suche",
    ),
    (
        "Iniciando búsqueda...",
        "Starting search...",
    ): (
        "Démarrage de la recherche...",
        "Avvio ricerca...",
        "Suche wird gestartet...",
    ),
    (
        "Conectando con Trakt",
        "Connecting to Trakt",
    ): (
        "Connexion à Trakt",
        "Connessione a Trakt",
        "Verbindung mit Trakt",
    ),
    (
        "Analizando consulta",
        "Analyzing query",
    ): (
        "Analyse de la requête",
        "Analisi della query",
        "Suchanfrage wird analysiert",
    ),
    (
        "Catálogo recibido",
        "Catalog received",
    ): (
        "Catalogue reçu",
        "Catalogo ricevuto",
        "Katalog erhalten",
    ),
    (
        "{} resultados iniciales",
        "{} initial results",
    ): (
        "{} résultats initiaux",
        "{} risultati iniziali",
        "{} erste Ergebnisse",
    ),
    (
        "Sin Trakt autorizado",
        "Trakt not authorized",
    ): (
        "Trakt non autorisé",
        "Trakt non autorizzato",
        "Trakt nicht autorisiert",
    ),
    (
        "Usando fallback TMDb",
        "Using TMDb fallback",
    ): (
        "Utilisation du fallback TMDb",
        "Uso del fallback TMDb",
        "TMDb-Fallback wird verwendet",
    ),
    (
        "Fallback recibido",
        "Fallback received",
    ): (
        "Fallback reçu",
        "Fallback ricevuto",
        "Fallback erhalten",
    ),
    (
        "Filtro aplicado",
        "Filter applied",
    ): (
        "Filtre appliqué",
        "Filtro applicato",
        "Filter angewendet",
    ),
    (
        "{} resultados útiles",
        "{} useful results",
    ): (
        "{} résultats utiles",
        "{} risultati utili",
        "{} brauchbare Ergebnisse",
    ),
    (
        "Búsqueda completada",
        "Search completed",
    ): (
        "Recherche terminée",
        "Ricerca completata",
        "Suche abgeschlossen",
    ),
    (
        "Tiempo total: {:.1f}s",
        "Total time: {:.1f}s",
    ): (
        "Temps total : {:.1f}s",
        "Tempo totale: {:.1f}s",
        "Gesamtzeit: {:.1f}s",
    ),
    (
        "Sin resultados",
        "No results",
    ): (
        "Aucun résultat",
        "Nessun risultato",
        "Keine Ergebnisse",
    ),
    # --- actor_search
    (
        "Búsqueda Trakt: actor o actriz (nombre)",
        "Trakt search: actor or actress (name)",
    ): (
        "Recherche Trakt : acteur ou actrice (nom)",
        "Ricerca Trakt: attore o attrice (nome)",
        "Trakt-Suche: Schauspieler oder Schauspielerin (Name)",
    ),
    (
        "No se encontro esa persona",
        "That person was not found",
    ): (
        "Cette personne est introuvable",
        "Questa persona non e stata trovata",
        "Diese Person wurde nicht gefunden",
    ),
    (
        "Kraken - Persona ({})",
        "Kraken - Person ({})",
    ): (
        "Kraken - Personne ({})",
        "Kraken - Persona ({})",
        "Kraken - Person ({})",
    ),
    (
        "peliculas",
        "movies",
    ): (
        "films",
        "film",
        "filme",
    ),
    (
        "series",
        "shows",
    ): (
        "series",
        "serie",
        "serien",
    ),
    (
        "Persona",
        "Person",
    ): (
        "Personne",
        "Persona",
        "Person",
    ),
    (
        "Elegir para listar su catálogo de {}",
        "Choose to list their {} catalog",
    ): (
        "Choisir pour lister son catalogue de {}",
        "Scegli per elencare il catalogo di {}",
        "Auswaehlen, um den {}-Katalog anzuzeigen",
    ),
    (
        "Películas",
        "Movies",
    ): (
        "Films",
        "Film",
        "Filme",
    ),
    (
        "Series",
        "TV Shows",
    ): (
        "Séries",
        "Serie TV",
        "Serien",
    ),
    (
        "Kraken - Trakt",
        "Kraken - Trakt",
    ): (
        "Kraken - Trakt",
        "Kraken - Trakt",
        "Kraken - Trakt",
    ),
    (
        "Cargando créditos de {}...",
        "Loading {} credits...",
    ): (
        "Chargement des crédits de {}...",
        "Caricamento crediti di {}...",
        "Lade Credits für {}...",
    ),
    (
        "ID persona {}",
        "Person ID {}",
    ): (
        "ID personne {}",
        "ID persona {}",
        "Personen-ID {}",
    ),
    (
        "Crédits Trakt",
        "Trakt credits",
    ): (
        "Crédits Trakt",
        "Crediti Trakt",
        "Trakt-Credits",
    ),
    (
        "{} títulos en catálogo",
        "{} titles in catalog",
    ): (
        "{} titres dans le catalogue",
        "{} titoli nel catalogo",
        "{} Titel im Katalog",
    ),
    (
        "Listo",
        "Done",
    ): (
        "Terminé",
        "Fatto",
        "Fertig",
    ),
    (
        "Sin créditos de {} en Trakt",
        "No {} credits on Trakt",
    ): (
        "Aucun crédit {} sur Trakt",
        "Nessun credito {} su Trakt",
        "Keine {}-Credits auf Trakt",
    ),
    (
        "película",
        "movie",
    ): (
        "film",
        "film",
        "Film",
    ),
    (
        "serie",
        "show",
    ): (
        "série",
        "serie",
        "Serie",
    ),
    # --- search_listing (banner + aviso temporadas)
    (
        "[B][COLOR FF88CCFF]Películas[/COLOR][/B]  ·  resultados",
        "[B][COLOR FF88CCFF]Movies[/COLOR][/B]  ·  results",
    ): (
        "[B][COLOR FF88CCFF]Films[/COLOR][/B]  ·  resultats",
        "[B][COLOR FF88CCFF]Film[/COLOR][/B]  ·  risultati",
        "[B][COLOR FF88CCFF]Filme[/COLOR][/B]  ·  Ergebnisse",
    ),
    (
        "Películas — resultados de búsqueda",
        "Movies — search results",
    ): (
        "Films — resultats de recherche",
        "Film — risultati di ricerca",
        "Filme — Suchergebnisse",
    ),
    (
        "[B][COLOR FF88CCFF]Series[/COLOR][/B]  ·  resultados",
        "[B][COLOR FF88CCFF]TV shows[/COLOR][/B]  ·  results",
    ): (
        "[B][COLOR FF88CCFF]Séries[/COLOR][/B]  ·  resultats",
        "[B][COLOR FF88CCFF]Serie TV[/COLOR][/B]  ·  risultati",
        "[B][COLOR FF88CCFF]Serien[/COLOR][/B]  ·  Ergebnisse",
    ),
    (
        "Series — resultados de búsqueda",
        "TV shows — search results",
    ): (
        "Séries — resultats de recherche",
        "Serie TV — risultati di ricerca",
        "Serien — Suchergebnisse",
    ),
    (
        "[B][COLOR FF88CCFF]Resultados[/COLOR][/B]  ·  búsqueda",
        "[B][COLOR FF88CCFF]Results[/COLOR][/B]  ·  search",
    ): (
        "[B][COLOR FF88CCFF]Résultats[/COLOR][/B]  ·  recherche",
        "[B][COLOR FF88CCFF]Risultati[/COLOR][/B]  ·  ricerca",
        "[B][COLOR FF88CCFF]Ergebnisse[/COLOR][/B]  ·  Suche",
    ),
    (
        "Resultados — búsqueda Kraken",
        "Results — Kraken search",
    ): (
        "Résultats — recherche Kraken",
        "Risultati — ricerca Kraken",
        "Ergebnisse — Kraken-Suche",
    ),
    (
        "No hay enlace Trakt para abrir temporadas; autoriza Trakt en Ajustes o busca con Trakt activo.",
        "No Trakt link to open seasons; authorize Trakt in Settings or search with Trakt enabled.",
    ): (
        "Pas de lien Trakt pour les saisons; autorise Trakt dans les paramètres ou recherche avec Trakt actif.",
        "Nessun link Trakt per le stagioni; autorizza Trakt nelle impostazioni o cerca con Trakt attivo.",
        "Kein Trakt-Link für Staffeln; autorisiere Trakt in den Einstellungen oder suche mit aktivem Trakt.",
    ),
}

_t = make_mapped_t(_TRAKT_PHRASE_MAP)
