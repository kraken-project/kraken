from resources.lib.sources.stremio_sources_config import is_stremio_tv_live_only_source


def filter_peerflix_magnets_when_alldebrid(candidates, get_bool_setting, get_setting):
    """
    Mantener todas las fuentes visibles.
    Antes se ocultaban magnets de Peerflix con AllDebrid activo, pero eso hacía
    parecer que Kraken "solo busca en Comet".
    """
    return candidates


def _entry_is_peerflix_magnet(item):
    url = str((item or {}).get("url") or "").strip().lower()
    if not url.startswith("magnet:"):
        return False
    blob = "{} {} {}".format(
        str((item or {}).get("label") or ""),
        str((item or {}).get("origin") or ""),
        url,
    ).lower()
    return "peerflix" in blob


def trakt_progress_translator(get_trakt_search_provider):
    """
    Reutiliza la lógica de idioma/traducciones del proveedor Trakt para
    mantener consistencia con 'trakt_plot_language' (es, auto, etc.).
    """
    try:
        provider = get_trakt_search_provider()
    except Exception:
        return None, ""
    lang = ""
    try:
        lang = provider._trakt_effective_translations_code()
    except Exception:
        lang = ""
    return provider, str(lang or "").strip().lower()


def parse_trakt_compound_id(result_id):
    rid = str(result_id or "").strip()
    parts = rid.split("::")
    if len(parts) >= 3 and parts[0] == "trakt":
        media_type = parts[1]
        trakt_id = parts[2]
        if media_type in ("movie", "show") and trakt_id:
            return media_type, trakt_id
    if len(parts) == 2 and parts[0] == "trakt":
        return "movie", parts[1]
    return "", ""


def stremio_source_is_tv_only(source_name):
    return is_stremio_tv_live_only_source(source_name)


def source_origin_group(origin):
    low = str(origin or "").lower()
    if "stremio" in low:
        return "stremio"
    if "coco" in low or "gears" in low or "viper" in low or "burst" in low:
        return "external"
    return "other"


def source_order_rank(item, sources_order_priority, quality_rank_fn, compact_origin_fn):
    priority = sources_order_priority()
    group = source_origin_group((item or {}).get("origin"))
    quality_rank = quality_rank_fn((item or {}).get("quality"))
    label_low = str((item or {}).get("label") or "").lower()
    url_low = str((item or {}).get("url") or "").lower()
    # Prioridad debrid: enlaces HTTP/directos primero, magnet al final.
    magnet_penalty = 1 if url_low.startswith("magnet:") else 0
    # Peerflix magnet suele fallar metadata; lo mandamos al final.
    peerflix_penalty = (
        1 if ("peerflix" in label_low and url_low.startswith("magnet:")) else 0
    )
    if priority == "external_first":
        order = {"external": 0, "stremio": 1, "other": 2}
    elif priority == "mixed_quality":
        order = {"stremio": 0, "external": 1, "other": 2}
        return (
            magnet_penalty,
            peerflix_penalty,
            quality_rank,
            order.get(group, 3),
            compact_origin_fn((item or {}).get("origin")),
            label_low,
        )
    else:
        order = {"stremio": 0, "external": 1, "other": 2}
    return (
        magnet_penalty,
        peerflix_penalty,
        order.get(group, 3),
        quality_rank,
        compact_origin_fn((item or {}).get("origin")),
        label_low,
    )
