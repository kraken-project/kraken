def trakt_parse_year(value):
    """Convierte año (int/float/str) a int válido, o (None, False)."""
    if value is None or value == "":
        return None, False
    try:
        f = float(str(value).strip().replace(",", "."))
    except (TypeError, ValueError):
        return None, False
    if 1800.0 < f < 3000.0:
        return int(f), True
    return None, False


def trakt_float_or_none(value):
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def format_trakt_vote_count(votes):
    """Abrevia recuento de votos para la segunda línea de la lista."""
    try:
        n = int(votes)
    except (TypeError, ValueError):
        return ""
    if n >= 1_000_000:
        return f"{n / 1_000_000.0:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000.0:.1f}k"
    return str(n)


def trakt_list_label1_with_year_rating(title, has_year, year, rating_display):
    """
    Línea 1: título + año + nota; ARGB hex para skins Estuary/Kodi 21 que fallan con nombres (deepskyblue/gold).
    """
    line = "[B]{}[/B]".format((title or "").strip() or "—")
    year_txt = (
        f"[COLOR FF00BFFF]{year}[/COLOR]"
        if (has_year and year is not None)
        else "[COLOR FF909090]N/D[/COLOR]"
    )
    rating_txt = (
        f"[COLOR FFDAA520]{rating_display:.1f}/10[/COLOR]"
        if (rating_display is not None and rating_display > 0.0)
        else "[COLOR FF909090]N/D[/COLOR]"
    )
    sep = "[COLOR 66FFFFFF]·[/COLOR]"
    return f"{line}  {sep}  {year_txt}  {sep}  {rating_txt}"


def trakt_title_with_year_rating_plain(title, has_year, year, rating_display):
    """Título plano para skins que priorizan ListItem.Title sobre label."""
    t = (title or "").strip() or "—"
    year_txt = str(year) if (has_year and year is not None) else "N/D"
    rating_txt = (
        f"{rating_display:.1f}/10"
        if (rating_display is not None and rating_display > 0.0)
        else "N/D"
    )
    return f"{t} · {year_txt} · {rating_txt}"


def trakt_rating_label2_extra(rating, votes):
    """Texto BBCode para rating Trakt en label2."""
    if rating is None:
        return ""
    r = trakt_float_or_none(rating)
    if r is None:
        return ""
    vcount = 0
    if votes is not None and votes != "":
        try:
            vcount = int(votes)
        except (TypeError, ValueError):
            vcount = 0
    if r <= 0.0 and vcount == 0:
        return ""
    extra = f"  [COLOR gold]{r:.1f}/10[/COLOR]"
    vc = format_trakt_vote_count(votes) if votes else ""
    if vc:
        extra += f"  [COLOR gray]({vc} v.)[/COLOR]"
    return extra
