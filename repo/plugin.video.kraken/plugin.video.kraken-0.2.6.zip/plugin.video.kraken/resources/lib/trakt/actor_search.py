import time

import xbmcgui
import xbmcplugin

from resources.lib.trakt.trakt_phrases import _t
from resources.lib.ui.video_info import apply_video_info


def trakt_credits_year_title_sort_key(result, trakt_parse_year):
    y, has_y = (
        trakt_parse_year(result.get("year"))
        if result.get("year") is not None
        else (0, False)
    )
    return (0 if has_y else 1, -y if has_y else 0, (result.get("title") or "").lower())


def search_movies_shows_by_actor_people_listing(
    kind="movie",
    *,
    forced_query=None,
    plugin_handle,
    search_history_last,
    search_history_add,
    get_trakt_search_provider,
    default_list_art,
    url_for_movie_person,
    url_for_show_person,
):
    k = (kind or "movie").lower()
    query = (forced_query or "").strip()
    if not query:
        default_q = search_history_last("actor_movie" if k == "movie" else "actor_show")
        query = xbmcgui.Dialog().input(
            _t(
                "Búsqueda Trakt: actor o actriz (nombre)",
                "Trakt search: actor or actress (name)",
            ),
            default_q,
        )
    if not query or not str(query).strip():
        xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)
        return None
    query = str(query).strip()
    search_history_add(query, "actor_movie" if k == "movie" else "actor_show")
    provider = get_trakt_search_provider()
    people = provider.search_people(query, limit=20)
    if not people:
        xbmcgui.Dialog().notification(
            "Kraken",
            _t(
                "No se encontro esa persona",
                "That person was not found",
            ),
            xbmcgui.NOTIFICATION_INFO,
        )
        xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)
        return None
    if len(people) == 1:
        p = people[0]
        return int(p["person_id"])

    xbmcplugin.setPluginCategory(
        plugin_handle,
        _t(
            "Kraken - Persona ({})",
            "Kraken - Person ({})",
        ).format(
            _t("peliculas", "movies") if k == "movie" else _t("series", "shows")
        ),
    )
    xbmcplugin.setContent(plugin_handle, "files")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_LABEL)
    base_art = default_list_art()
    directory = []
    for p in people:
        label = p.get("name") or _t("Persona", "Person")
        li = xbmcgui.ListItem(
            label=label,
            label2=_t(
                "Elegir para listar su catálogo de {}",
                "Choose to list their {} catalog",
            ).format(
                _t("peliculas", "movies")
                if k == "movie"
                else _t("series", "shows")
            ),
        )
        apply_video_info(
            li, {"title": label, "plot": p.get("plot", ""), "mediatype": "actor"}
        )
        art = dict(base_art)
        h = p.get("headshot") or ""
        f = p.get("fanart") or h
        if h:
            art.update({"thumb": h, "icon": h, "poster": h})
        if f:
            art["fanart"] = f
        li.setArt(art)
        if k == "movie":
            u = url_for_movie_person(p["person_id"])
        else:
            u = url_for_show_person(p["person_id"])
        li.setProperty("IsPlayable", "false")
        directory.append((u, li, True))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)
    return None


def search_movies_shows_by_actor_credits(
    kind,
    person_id,
    *,
    get_trakt_search_provider,
    kraken_progress,
    trakt_results_limit,
    tmdb_enabled,
    omdb_enabled,
    enrich_trakt_result_items_with_metadata,
    add_trakt_search_listing_to_directory,
    trakt_parse_year,
):
    dialog = xbmcgui.DialogProgress()
    started_at = time.time()
    k = (kind or "movie").lower()
    media_f = "movie" if k == "movie" else "show"
    who = _t("Películas", "Movies") if k == "movie" else _t("Series", "TV Shows")
    results = []
    dialog.create(
        _t("Kraken - Trakt", "Kraken - Trakt"),
        _t(
            "Cargando créditos de {}...",
            "Loading {} credits...",
        ).format(who),
    )
    try:
        kraken_progress(
            dialog,
            10,
            _t("Conectando con Trakt", "Connecting to Trakt"),
            _t("ID persona {}", "Person ID {}").format(person_id),
        )
        provider = get_trakt_search_provider()
        if k == "movie":
            results = provider.person_movies(int(person_id))
        else:
            results = provider.person_shows(int(person_id))
        kraken_progress(
            dialog,
            30,
            _t("Crédits Trakt", "Trakt credits"),
            _t("{} títulos en catálogo", "{} titles in catalog").format(len(results or [])),
        )
        results = sorted(
            list(results or []),
            key=lambda r: trakt_credits_year_title_sort_key(r, trakt_parse_year),
        )
        limit = trakt_results_limit()
        if limit and len(results) > limit * 3:
            results = results[: limit * 3]
        if results and (tmdb_enabled() or omdb_enabled()):
            enrich_trakt_result_items_with_metadata(results, dialog)
        elapsed = time.time() - started_at
        kraken_progress(
            dialog,
            100,
            _t("Listo", "Done"),
            _t("Tiempo total: {:.1f}s", "Total time: {:.1f}s").format(elapsed),
        )
    finally:
        dialog.close()
    add_trakt_search_listing_to_directory(
        results,
        media_f,
        empty_message=_t(
            "Sin créditos de {} en Trakt",
            "No {} credits on Trakt",
        ).format(
            _t("película", "movie") if k == "movie" else _t("serie", "show")
        ),
    )
