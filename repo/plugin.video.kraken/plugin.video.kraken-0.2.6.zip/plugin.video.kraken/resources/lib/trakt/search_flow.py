import time

import xbmcgui
import xbmcplugin

from resources.lib.trakt.trakt_phrases import _t
from resources.lib.trakt.search_ranking import rank_search_results


def search_prompt_trakt_query(media_filter, search_history_last=None):
    """Solo muestra el teclado de búsqueda; sin listar."""
    media_filter = (media_filter or "all").strip().lower()
    if media_filter not in ("movie", "show", "all"):
        media_filter = "all"
    prompt = (
        _t("Buscar película en Trakt", "Search movie on Trakt")
        if media_filter == "movie"
        else _t("Buscar serie en Trakt", "Search TV show on Trakt")
    )
    if media_filter == "all":
        prompt = _t("Buscar en Trakt", "Search on Trakt")
    default_q = ""
    if search_history_last:
        default_q = search_history_last(media_filter) or ""
    query = xbmcgui.Dialog().input(prompt, default_q)
    if not query:
        return ""
    return str(query).strip()


def search_trakt_media(
    media_filter,
    *,
    forced_query=None,
    plugin_handle,
    search_history_last,
    search_history_add,
    kraken_progress,
    get_trakt_search_provider,
    trakt_results_limit,
    tmdb_enabled,
    omdb_enabled,
    enrich_trakt_result_items_with_metadata,
    add_trakt_search_listing_to_directory,
    get_bool_setting,
    get_setting,
    fallback_search,
):
    media_filter = (media_filter or "all").strip().lower()
    if media_filter not in ("movie", "show", "all"):
        media_filter = "all"
    prompt = (
        _t("Buscar película en Trakt", "Search movie on Trakt")
        if media_filter == "movie"
        else _t("Buscar serie en Trakt", "Search TV show on Trakt")
    )
    if media_filter == "all":
        prompt = _t("Buscar en Trakt", "Search on Trakt")

    query = (forced_query or "").strip()
    if not query:
        default_q = search_history_last(media_filter)
        query = xbmcgui.Dialog().input(prompt, default_q)
    if not query:
        xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)
        return
    query = str(query).strip()
    if not query:
        xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)
        return
    search_history_add(query, media_filter)

    dialog = xbmcgui.DialogProgress()
    started_at = time.time()
    dialog.create(
        _t("Kraken - Búsqueda Kraken", "Kraken - Kraken Search"),
        _t("Iniciando búsqueda...", "Starting search..."),
    )
    try:
        trakt_enabled = get_bool_setting("trakt_enabled")
        trakt_token = (get_setting("trakt_access_token") or "").strip()
        use_trakt_account = bool(trakt_enabled and trakt_token)
        if use_trakt_account:
            kraken_progress(
                dialog,
                5,
                _t("Conectando con Trakt", "Connecting to Trakt"),
                _t("Analizando consulta", "Analyzing query"),
            )
            provider = get_trakt_search_provider()
            want_lim = max(5, min(100, int(trakt_results_limit() or 20)))
            trakt_media = media_filter if media_filter in ("movie", "show") else None
            results = provider.search(
                query,
                media_kind=trakt_media,
                api_limit=want_lim,
            )
            n0 = len(results or [])
            kraken_progress(
                dialog,
                35,
                _t("Catálogo recibido", "Catalog received"),
                _t("{} resultados iniciales", "{} initial results").format(n0),
            )
        else:
            kraken_progress(
                dialog,
                5,
                _t("Sin Trakt autorizado", "Trakt not authorized"),
                _t("Usando fallback TMDb", "Using TMDb fallback"),
            )
            results = fallback_search(query, media_filter) if fallback_search else []
            n0 = len(results or [])
            kraken_progress(
                dialog,
                35,
                _t("Fallback recibido", "Fallback received"),
                _t("{} resultados iniciales", "{} initial results").format(n0),
            )
        if use_trakt_account:
            if media_filter == "movie":
                results = [
                    r
                    for r in results
                    if str(r.get("id", "")).startswith("trakt::movie::")
                ]
            elif media_filter == "show":
                results = [
                    r
                    for r in results
                    if str(r.get("id", "")).startswith("trakt::show::")
                ]
        else:
            if media_filter == "movie":
                results = [
                    r
                    for r in results
                    if str(r.get("id", "")).startswith("fallback::movie::")
                ]
            elif media_filter == "show":
                results = [
                    r
                    for r in results
                    if str(r.get("id", "")).startswith("fallback::show::")
                ]
            else:
                results = [
                    r
                    for r in results
                    if str(r.get("id", "")).startswith("fallback::")
                ]
        results = rank_search_results(query, results)
        limit = max(5, min(100, int(trakt_results_limit() or 20)))
        if limit and len(results or []) > limit:
            results = results[:limit]
        nf = len(results or [])
        kraken_progress(
            dialog,
            45,
            _t("Filtro aplicado", "Filter applied"),
            _t("{} resultados útiles", "{} useful results").format(nf),
        )
        # En búsqueda priorizamos velocidad: enriquecer sólo con TMDb.
        if results and tmdb_enabled():
            enrich_trakt_result_items_with_metadata(results, dialog)
        elapsed = time.time() - started_at
        kraken_progress(
            dialog,
            100,
            _t("Búsqueda completada", "Search completed"),
            _t("Tiempo total: {:.1f}s", "Total time: {:.1f}s").format(elapsed),
        )
    finally:
        dialog.close()

    add_trakt_search_listing_to_directory(
        results,
        media_filter,
        empty_message=_t("Sin resultados", "No results"),
    )
