"""Token en /buscar/le/<blob>: lista de resultados sin volver a pedir texto al cerrar vídeo."""

import base64
import json

_MEDIA = frozenset({"movie", "show", "all"})


def encode_search_listing_token(media_filter, query):
    m = str(media_filter or "all").strip().lower()
    if m not in _MEDIA:
        m = "all"
    q = str(query or "").strip()
    if not q:
        return ""
    raw = json.dumps({"m": m, "q": q}, ensure_ascii=False, separators=(",", ":"))
    return (
        base64.urlsafe_b64encode(raw.encode("utf-8"))
        .decode("ascii")
        .rstrip("=")
    )


def decode_search_listing_token(blob):
    raw = str(blob or "").strip()
    if not raw:
        return None
    try:
        pad = "=" * (-len(raw) % 4)
        data = json.loads(
            base64.urlsafe_b64decode(raw + pad).decode("utf-8"),
        )
    except Exception:
        return None
    if not isinstance(data, dict):
        return None
    m = str(data.get("m") or "all").strip().lower()
    q = str(data.get("q") or "").strip()
    if not q or m not in _MEDIA:
        return None
    return m, q
