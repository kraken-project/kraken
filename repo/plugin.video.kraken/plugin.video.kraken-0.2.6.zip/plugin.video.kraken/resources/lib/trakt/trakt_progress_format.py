def progress_percent_text(progress_value):
    try:
        p = float(progress_value or 0.0)
    except (TypeError, ValueError):
        p = 0.0
    return f"{max(0.0, min(100.0, p)):.0f}%"


def safe_votes_str(votes, tmdb_votes=None):
    out = ""
    if votes is not None:
        try:
            out = str(int(votes))
        except (TypeError, ValueError):
            try:
                out = str(int(float(votes)))
            except (TypeError, ValueError):
                out = ""
    if not out and tmdb_votes:
        out = str(int(tmdb_votes))
    return out
