"""Reordenar resultados de búsqueda (Trakt/TMDb) por proximidad al texto buscado."""

from __future__ import annotations


def rank_search_results(user_query_raw: str, rows: list | None) -> list:
    """
    Prefiere coincidencias exactas, prefijo del título o que contenga todas las palabras de la consulta,
    con bonus si el año de la entrada coincide con un año «colado» al final («Título 2019»).
    """
    from resources.lib.providers.trakt_search import TraktSearchProvider

    if not rows:
        return []

    qc, yr_hint = TraktSearchProvider._normalize_search_query_parts(
        str(user_query_raw or "").strip()
    )
    qc_fold = qc.casefold()
    qraw_fold = str(user_query_raw or "").strip().casefold()
    toks = [t for t in qc_fold.split() if len(t) > 1]

    def tier_for_strings(*titles):
        best = 9
        for title in titles:
            tl = str(title or "").strip().casefold()
            if not tl:
                continue
            cand = 9
            if qc_fold and tl == qc_fold:
                cand = 0
            elif qraw_fold and tl == qraw_fold:
                cand = 0
            elif qc_fold and tl.startswith(qc_fold):
                cand = min(cand, 1)
            elif qc_fold and toks and all(t in tl for t in toks):
                cand = min(cand, 2)
            elif qc_fold and qc_fold in tl:
                cand = min(cand, 3)
            else:
                cand = min(cand, 4)
            best = min(best, cand)
        return best

    def score_row(r):
        t1 = str((r or {}).get("title") or "")
        t2 = str((r or {}).get("trakt_default_title") or "")
        tier = tier_for_strings(t1, t2)
        ry = (r or {}).get("year")
        try:
            y = int(ry) if ry is not None and str(ry).strip().isdigit() else None
        except (TypeError, ValueError):
            y = None
        if yr_hint is not None and y == yr_hint:
            tier = max(0, tier - 1)
        try:
            votes = int((r or {}).get("votes") or 0)
        except (TypeError, ValueError):
            votes = 0
        canon = (t1 or t2).strip().casefold()
        len_gap = (
            abs(len(canon) - len(qc_fold)) if qc_fold else abs(len(canon) - len(qraw_fold))
        )
        return (tier, len_gap, -min(votes, 10_000_000))

    return sorted(list(rows), key=score_row)
