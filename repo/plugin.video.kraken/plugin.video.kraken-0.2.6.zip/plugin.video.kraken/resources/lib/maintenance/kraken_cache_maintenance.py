"""Limpieza de cachés y metadatos locales de Kraken (sin tocar BD del núcleo de Kodi)."""

import os


def addon_cache_root_bytes(profile_path_hint):
    base = os.path.join(profile_path_hint, "addon_data", "plugin.video.kraken")
    total = 0
    try:
        for root, _dirs, files in os.walk(base):
            for name in files:
                p = os.path.join(root, name)
                try:
                    sz = os.path.getsize(p)
                    total += int(sz)
                except OSError:
                    continue
    except Exception:
        return total
    return total


def clear_omdb_metadata_file(addon, omdb_clear_fn):
    removed = False
    err = ""
    try:
        removed = bool(omdb_clear_fn(addon))
    except Exception as ex:
        err = str(ex)
    return removed, err


def clear_stremio_session_cache(session_clear_fn):
    try:
        session_clear_fn()
        return True, ""
    except Exception as ex:
        return False, str(ex)


def clear_logo_disk_cache(logos_clear_fn):
    removed = 0
    try:
        removed = int(logos_clear_fn() or 0)
    except Exception:
        removed = -1
    return removed >= 0, removed


def clear_search_ram_cache(clear_ram_fn):
    try:
        clear_ram_fn()
        return True, ""
    except Exception as ex:
        return False, str(ex)


def clear_subtitle_disk_cache(profile_dir, clear_translated_fn):
    try:
        removed = int(clear_translated_fn(profile_dir) or 0)
        return True, removed
    except Exception:
        return False, -1
