# Kraken addon maintenance helpers (cache/metadata).
