# Kraken: servicio de fondo (aviso ~30 s antes del final para preparar el siguiente capítulo).
import json
import os
import sys
import threading
import time
from urllib.parse import quote
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui

WID = 10000
ADDON_ID = "plugin.video.kraken"
TRAKT_CLIENT_ID = "1038ef327e86e7f6d39d80d2eb5479bff66dd8394e813c5e0e387af0f84d89fb"
TRAKT_CLIENT_SECRET = "8d27a92e1d17334dae4a0590083a4f26401cb8f721f477a79fd3f218f8534fd1"
# Duración mínima (s) para fiar de tot-pos frente a Player.TimeRemaining.
MIN_DUR = 40
# Si el usuario para el vídeo pero el % guardado alcanza este umbral, igual se envía sync/history.
TRAKT_WATCHED_MIN_PCT = 87.5

# Props de sesión Kraken (siguiente capítulo, prefetch, Trakt) — limpiar si el vídeo no es de Kraken.
_KRAKEN_SESSION_PROPERTY_KEYS = (
    "Kraken.Playing",
    "Kraken.30sDialogShown",
    "Kraken.30sUserCancelled",
    "Kraken.PrefetchStreamUrl",
    "Kraken.PrefetchMeta",
    "Kraken.EofSoon",
    "Kraken.LastProgressPct",
    "Kraken.PrefetchInProgress",
    "Kraken.PendingPlaybackStart",
    "Kraken.PendingPlaybackTs",
    "Kraken.LastPlaybackAttemptUrl",
    "Kraken.FallbackTriedUrls",
    "Kraken.FallbackAutoAttempts",
    "Kraken.TraktSynced",
    "Kraken.TraktCollectionSent",
    "Kraken.TraktScrobbleLast.start",
    "Kraken.TraktScrobbleLast.pause",
    "Kraken.TraktScrobbleLast.stop",
)

# Magnet/torrent enrutado a estos add-ons sigue siendo “sesión Kraken”.
_KRAKEN_TORRENT_DELEGATE_PREFIXES = (
    "plugin://plugin.video.elementum/",
    "plugin://plugin.video.torrest/",
    "plugin://plugin.video.jacktorr/",
)


def _is_kraken_or_delegate_playback(path_lower):
    if not path_lower:
        return False
    if path_lower.startswith("plugin://plugin.video.kraken/"):
        return True
    for prefix in _KRAKEN_TORRENT_DELEGATE_PREFIXES:
        if path_lower.startswith(prefix):
            return True
    return False


def _clear_kraken_session_properties(win):
    for p in _KRAKEN_SESSION_PROPERTY_KEYS:
        try:
            win.clearProperty(p)
        except Exception:
            pass


def _playback_detached_from_kraken(path, win):
    """
    True si hay estado Kraken.Playing pero la fuente actual no corresponde a Kraken
    (otro plugin de vídeo o HTTP distinto al último URL preparado por Kraken).
    """
    try:
        low = str(path or "").strip().lower()
    except Exception:
        return False
    if not str(win.getProperty("Kraken.Playing") or "").strip():
        return False
    if _is_kraken_or_delegate_playback(low):
        return False
    if low.startswith("plugin://"):
        return True
    if low.startswith(("http://", "https://")):
        last = str(win.getProperty("Kraken.LastPlaybackAttemptUrl") or "").strip()
        if not last:
            return True
        llow = last.lower()
        if not llow.startswith(("http://", "https://")):
            return False
        # No comparar netloc: tras redirecciones/CDN el host del reproductor suele
        # diferir del enlace Debrid original; limpiar Kraken.Playing rompía Trakt en series.
        return False
    return False


_ROOT = xbmcaddon.Addon(ADDON_ID).getAddonInfo("path")
_LIB = os.path.join(_ROOT, "resources", "lib")
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)
from core.addon_runtime import (
    finalize_playback_stream_url as _finalize_playback_stream_url,
)
from core.debrid_expiration_notify import (
    run_debrid_expiration_notifications,
)
from core.kodi_run_plugin import escape_for_quoted_builtin
from core.network import json_get as _kraken_json_get
from core.playback_listitem import (
    configure_listitem_stream_properties as _configure_listitem_stream,
)
from core.subtitle_translate import translate_srt_file
from core.playback_source_stash import load_stashed_candidates
from core.settings_helpers import get_setting as _addon_get_setting
from ui.next_episode_corner import NextEpisodeCornerDialog
from ui.ui_helpers import _t


class KrakenSettingsMonitor(xbmc.Monitor):
    """Al guardar ajustes: notificar cambio de idioma UI de Kraken (textos _t en el addon)."""

    def __init__(self):
        super().__init__()
        self._last_ui = None
        try:
            self._last_ui = xbmcaddon.Addon(ADDON_ID).getSetting(
                "kraken_ui_language"
            )
        except Exception:
            pass

    def onSettingsChanged(self):
        try:
            cur = xbmcaddon.Addon(ADDON_ID).getSetting("kraken_ui_language")
        except Exception:
            return
        if cur == self._last_ui:
            return
        self._last_ui = cur
        try:
            msg = _t(
                "Idioma de Kraken aplicado. Los textos de los menus del addon usaran este idioma.",
                "Kraken language applied. Addon menu texts will use this language.",
                "Langue Kraken appliquee : les menus de l'addon utiliseront cette langue.",
                "Lingua Kraken applicata: i menu dell'addon useranno questa lingua.",
                "Kraken-Sprache aktiv: Addon-Menue-Texte nutzen diese Sprache.",
            )
            xbmcgui.Dialog().notification(
                "Kraken", msg, xbmcgui.NOTIFICATION_INFO, 4000
            )
        except Exception:
            pass


def _safe_is_playing_video(player):
    try:
        return bool(player.isPlayingVideo())
    except Exception:
        return False


def _get_bool(sid, default="true"):
    try:
        return xbmcaddon.Addon(ADDON_ID).getSettingBool(sid)
    except Exception:
        return (xbmcaddon.Addon(ADDON_ID).getSetting(sid) or default).lower() == "true"


def _get_warn_seconds():
    """Segundos o menos al final para mostrar el aviso (ajuste next_episode_warn_seconds, por defecto 30)."""
    add = xbmcaddon.Addon(ADDON_ID)
    raw = str(_addon_get_setting(add, "next_episode_warn_seconds") or "").strip()
    if not raw:
        raw = "30"
    try:
        v = int(raw)
    except (TypeError, ValueError):
        v = 30
    return max(5, min(600, v))


def _get_setting_str(sid, default=""):
    add = xbmcaddon.Addon(ADDON_ID)
    s = str(_addon_get_setting(add, sid) or "").strip()
    return s if s else str(default or "")


def _get_setting_raw(sid):
    return _addon_get_setting(xbmcaddon.Addon(ADDON_ID), sid)


def _get_setting_int(sid, default=0, minv=None, maxv=None):
    raw = str(_get_setting_raw(sid) or "").strip()
    try:
        val = int(raw)
    except (TypeError, ValueError):
        val = int(default)
    if minv is not None:
        val = max(int(minv), val)
    if maxv is not None:
        val = min(int(maxv), val)
    return val


def _installed(addon_id):
    try:
        return xbmc.getCondVisibility(f"System.HasAddon({addon_id})") == 1
    except Exception:
        return False


def _opensubtitles_addon_id():
    # Distintas instalaciones usan uno de estos IDs.
    candidates = (
        "service.subtitles.opensubtitles_by_opensubtitles",
        "service.subtitles.opensubtitles",
    )
    for aid in candidates:
        if _installed(aid):
            return aid
    return ""


def _jsonrpc(payload):
    try:
        return xbmc.executeJSONRPC(
            json.dumps(payload) if isinstance(payload, dict) else str(payload)
        )
    except Exception:
        return ""


def _utc_now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime())


def _trakt_authorized():
    if not _get_bool("trakt_enabled", "false"):
        return False
    token = _get_setting_str("trakt_access_token", "")
    return bool(token)


def _trakt_authed_get(url):
    token = _get_setting_str("trakt_access_token", "")
    if not token:
        raise ValueError("Trakt sin token")
    headers = {
        "Content-Type": "application/json",
        "trakt-api-version": "2",
        "trakt-api-key": TRAKT_CLIENT_ID,
        "Authorization": f"Bearer {token}",
        "User-Agent": "Kraken Kodi Addon/0.1",
    }
    req = Request(str(url), headers=headers)
    with urlopen(req, timeout=15) as response:
        body = response.read().decode("utf-8")
    return json.loads(body) if body else {}


def _trakt_authed_post(url, payload):
    token = _get_setting_str("trakt_access_token", "")
    if not token:
        raise ValueError("Trakt sin token")
    headers = {
        "Content-Type": "application/json",
        "trakt-api-version": "2",
        "trakt-api-key": TRAKT_CLIENT_ID,
        "Authorization": f"Bearer {token}",
        "User-Agent": "Kraken Kodi Addon/0.1",
    }
    req = Request(str(url), data=json.dumps(payload).encode("utf-8"), headers=headers)
    with urlopen(req, timeout=15) as response:
        body = response.read().decode("utf-8")
    return json.loads(body) if body else {}


def _trakt_refresh_access_token():
    refresh_token = _get_setting_str("trakt_refresh_token", "")
    if not refresh_token:
        raise ValueError("Trakt sin refresh token")
    headers = {
        "Content-Type": "application/json",
        "trakt-api-version": "2",
        "trakt-api-key": TRAKT_CLIENT_ID,
        "User-Agent": "Kraken Kodi Addon/0.1",
    }
    payload = {
        "refresh_token": refresh_token,
        "client_id": TRAKT_CLIENT_ID,
        "client_secret": TRAKT_CLIENT_SECRET,
        "redirect_uri": "urn:ietf:wg:oauth:2.0:oob",
        "grant_type": "refresh_token",
    }
    req = Request(
        "https://api.trakt.tv/oauth/token",
        data=json.dumps(payload).encode("utf-8"),
        headers=headers,
    )
    with urlopen(req, timeout=15) as response:
        body = response.read().decode("utf-8")
    token_data = json.loads(body) if body else {}
    access_token = str(token_data.get("access_token") or "").strip()
    if not access_token:
        raise ValueError("Respuesta de refresh sin access_token")
    xbmcaddon.Addon(ADDON_ID).setSetting("trakt_access_token", access_token)
    new_refresh = token_data.get("refresh_token")
    if new_refresh is not None:
        xbmcaddon.Addon(ADDON_ID).setSetting("trakt_refresh_token", str(new_refresh))
    try:
        created_at = int(token_data.get("created_at") or int(time.time()))
    except (TypeError, ValueError):
        created_at = int(time.time())
    try:
        expires_in = int(token_data.get("expires_in") or 0)
    except (TypeError, ValueError):
        expires_in = 0
    xbmcaddon.Addon(ADDON_ID).setSetting(
        "trakt_token_expires", str(created_at + max(0, expires_in))
    )
    return access_token


def _trakt_authed_get_retry_refresh(url):
    try:
        return _trakt_authed_get(url)
    except HTTPError as ex:
        if int(getattr(ex, "code", 0) or 0) != 401:
            raise
    _trakt_refresh_access_token()
    return _trakt_authed_get(url)


def _trakt_authed_post_retry_refresh(url, payload):
    try:
        return _trakt_authed_post(url, payload)
    except HTTPError as ex:
        if int(getattr(ex, "code", 0) or 0) != 401:
            raise
    _trakt_refresh_access_token()
    return _trakt_authed_post(url, payload)


def _trakt_mark_watched_from_playing(win):
    if not _trakt_authorized():
        return
    if (win.getProperty("Kraken.TraktSynced") or "").strip() == "1":
        return
    raw = (win.getProperty("Kraken.Playing") or "").strip()
    if not raw:
        return
    try:
        playing = json.loads(raw)
    except Exception:
        return
    if not isinstance(playing, dict):
        return
    watched_at = _utc_now_iso()
    payload = None
    kind = str(playing.get("kind") or "").strip().lower()
    if kind == "movie":
        trakt_id = str(playing.get("trakt_id") or "").strip()
        if trakt_id:
            try:
                tid = int(trakt_id)
            except (TypeError, ValueError):
                tid = trakt_id
            payload = {"movies": [{"watched_at": watched_at, "ids": {"trakt": tid}}]}
    if payload is None:
        show_id = str(playing.get("show_id") or "").strip()
        try:
            season_num = int(playing.get("season") or 0)
            episode_num = int(playing.get("episode") or 0)
        except (TypeError, ValueError):
            season_num = 0
            episode_num = 0
        if show_id and season_num >= 0 and episode_num >= 1:
            try:
                ep = _trakt_authed_get_retry_refresh(
                    f"https://api.trakt.tv/shows/{quote(show_id)}/seasons/{season_num}/episodes/{episode_num}?extended=full"
                )
                ep_ids = (ep or {}).get("ids") or {}
                ep_trakt_id = str(ep_ids.get("trakt") or "").strip()
            except Exception as ex:
                xbmc.log(f"[Kraken] Trakt ids episodio error: {ex}", xbmc.LOGDEBUG)
                ep_trakt_id = ""
            if ep_trakt_id:
                try:
                    eid = int(ep_trakt_id)
                except (TypeError, ValueError):
                    eid = ep_trakt_id
                payload = {
                    "episodes": [{"watched_at": watched_at, "ids": {"trakt": eid}}]
                }
    if not payload:
        return
    try:
        _trakt_authed_post_retry_refresh("https://api.trakt.tv/sync/history", payload)
        win.setProperty("Kraken.TraktSynced", "1")
        xbmc.log("[Kraken] Trakt sync/history enviado", xbmc.LOGINFO)
    except Exception as ex:
        xbmc.log(f"[Kraken] Trakt sync/history error: {ex}", xbmc.LOGWARNING)


def _trakt_sync_collection_from_playing(win):
    """POST /sync/collection — una vez por reproducción (dedupe con Kraken.TraktCollectionSent)."""
    if not _get_bool("trakt_sync_collection_on_play", "true"):
        return
    if not _trakt_authorized():
        return
    raw = (win.getProperty("Kraken.Playing") or "").strip()
    if not raw:
        return
    try:
        playing = json.loads(raw)
    except Exception:
        return
    if not isinstance(playing, dict):
        return

    collected_at = _utc_now_iso()
    payload = None
    marker = ""
    kind = str(playing.get("kind") or "").strip().lower()

    if kind == "movie":
        trakt_id = str(playing.get("trakt_id") or "").strip()
        if trakt_id:
            try:
                tid = int(trakt_id)
            except (TypeError, ValueError):
                tid = trakt_id
            payload = {
                "movies": [{"collected_at": collected_at, "ids": {"trakt": tid}}]
            }
            marker = f"m:{trakt_id}"
    if payload is None:
        ep_trakt_id = _trakt_episode_trakt_id_from_playing(playing)
        try:
            win.setProperty("Kraken.Playing", json.dumps(playing))
        except Exception:
            pass
        if ep_trakt_id:
            try:
                eid = int(ep_trakt_id)
            except (TypeError, ValueError):
                eid = ep_trakt_id
            payload = {
                "episodes": [{"collected_at": collected_at, "ids": {"trakt": eid}}]
            }
            marker = f"e:{ep_trakt_id}"

    if not payload or not marker:
        return
    if (win.getProperty("Kraken.TraktCollectionSent") or "").strip() == marker:
        return
    try:
        _trakt_authed_post_retry_refresh(
            "https://api.trakt.tv/sync/collection", payload
        )
        win.setProperty("Kraken.TraktCollectionSent", marker)
        xbmc.log("[Kraken] Trakt sync/collection enviado", xbmc.LOGINFO)
    except Exception as ex:
        xbmc.log(f"[Kraken] Trakt sync/collection error: {ex}", xbmc.LOGWARNING)


def _trakt_episode_trakt_id_from_playing(playing):
    show_id = str((playing or {}).get("show_id") or "").strip()
    try:
        season_num = int((playing or {}).get("season") or 0)
        episode_num = int((playing or {}).get("episode") or 0)
    except (TypeError, ValueError):
        season_num = 0
        episode_num = 0
    if not show_id or season_num < 0 or episode_num < 1:
        return ""
    cache_key = f"s{season_num}e{episode_num}"
    id_cache = (playing or {}).get("episode_trakt_ids") or {}
    if isinstance(id_cache, dict):
        cached = str(id_cache.get(cache_key) or "").strip()
        if cached:
            return cached
    try:
        ep = _trakt_authed_get_retry_refresh(
            f"https://api.trakt.tv/shows/{quote(show_id)}/seasons/{season_num}/episodes/{episode_num}?extended=full"
        )
    except Exception as ex:
        xbmc.log(f"[Kraken] Trakt ids episodio error: {ex}", xbmc.LOGDEBUG)
        return ""
    ep_ids = (ep or {}).get("ids") or {}
    ep_trakt_id = str(ep_ids.get("trakt") or "").strip()
    if not ep_trakt_id:
        return ""
    if isinstance(id_cache, dict):
        id_cache[cache_key] = ep_trakt_id
        playing["episode_trakt_ids"] = id_cache
    return ep_trakt_id


def _trakt_scrobble_payload(player, win, action=""):
    if not _trakt_authorized():
        return None, None
    raw = (win.getProperty("Kraken.Playing") or "").strip()
    if not raw:
        return None, None
    try:
        playing = json.loads(raw)
    except Exception:
        return None, None
    if not isinstance(playing, dict):
        return None, None
    kind = str(playing.get("kind") or "").strip().lower()
    media_key = ""
    ids = None
    if kind == "movie":
        trakt_id = str(playing.get("trakt_id") or "").strip()
        if not trakt_id:
            return None, None
        media_key = "movie"
        try:
            ids = {"trakt": int(trakt_id)}
        except (TypeError, ValueError):
            ids = {"trakt": trakt_id}
    else:
        ep_trakt_id = _trakt_episode_trakt_id_from_playing(playing)
        if not ep_trakt_id:
            return None, None
        media_key = "episode"
        try:
            ids = {"trakt": int(ep_trakt_id)}
        except (TypeError, ValueError):
            ids = {"trakt": ep_trakt_id}
        try:
            win.setProperty("Kraken.Playing", json.dumps(playing))
        except Exception:
            pass

    tot, pos = _playback_total_and_pos(player)
    progress = 0.0
    if tot and tot > 0:
        progress = max(0.0, min(100.0, (float(pos) * 100.0) / float(tot)))
    elif pos and pos > 0:
        progress = 1.0
    cached_pct = None
    try:
        cr = str(win.getProperty("Kraken.LastProgressPct") or "").strip()
        if cr:
            cached_pct = float(cr)
            cached_pct = max(0.0, min(100.0, cached_pct))
    except (TypeError, ValueError):
        cached_pct = None
    # Al hacer stop Kodi suele tener ya posición 0 → Trakt recibe progress 0 y responde 422.
    act = str(action or "").strip().lower()
    if act == "stop" and cached_pct is not None:
        if progress <= 2.02 or progress + 8.0 < cached_pct:
            progress = cached_pct
    payload = {media_key: {"ids": ids}, "progress": float(round(progress, 2))}
    return payload, media_key


def _trakt_scrobble(action, player, win):
    if str(action or "").strip() not in ("start", "pause", "stop"):
        return
    payload, media_key = _trakt_scrobble_payload(player, win, action=action)
    if not payload or not media_key:
        return
    marker_key = f"Kraken.TraktScrobbleLast.{action}"
    marker_val = "{}:{}:{:.2f}".format(
        media_key, payload[media_key]["ids"].get("trakt"), payload["progress"]
    )
    if (win.getProperty(marker_key) or "").strip() == marker_val:
        return
    try:
        _trakt_authed_post_retry_refresh(f"https://api.trakt.tv/scrobble/{action}", payload)
        win.setProperty(marker_key, marker_val)
        xbmc.log(f"[Kraken] Trakt scrobble/{action} ok ({media_key})", xbmc.LOGINFO)
    except Exception as ex:
        xbmc.log(f"[Kraken] Trakt scrobble/{action} error: {ex}", xbmc.LOGWARNING)


def _kodi_subtitle_language_current():
    """Valor actual de locale.subtitlelanguage (evita Set redundante y avisos de Kodi)."""
    raw = _jsonrpc(
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "Settings.GetSettingValue",
            "params": {"setting": "locale.subtitlelanguage"},
        }
    )
    try:
        data = json.loads(raw) if raw else {}
        val = (data.get("result") or {}).get("value")
        return str(val or "").strip().lower()
    except Exception:
        return ""


def _apply_preferred_subtitle_language():
    pref = _get_setting_str("opensubtitles_preferred_lang", "Auto (Kodi)")
    if pref.startswith("Auto"):
        return
    code = str(pref).strip().lower()
    cur = _kodi_subtitle_language_current()
    if cur and cur == code:
        return
    win = xbmcgui.Window(WID)
    if (win.getProperty("Kraken.LastSubtitleLangApplied") or "").strip().lower() == code:
        return
    # Best-effort: usa el ajuste global de Kodi para idioma de subtítulos.
    _jsonrpc(
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "Settings.SetSettingValue",
            "params": {"setting": "locale.subtitlelanguage", "value": code},
        }
    )
    try:
        win.setProperty("Kraken.LastSubtitleLangApplied", code)
    except Exception:
        pass


def _apply_subtitle_language_code(code):
    c = str(code or "").strip().lower()
    if not c:
        return
    cur = _kodi_subtitle_language_current()
    if cur and cur == c:
        return
    win = xbmcgui.Window(WID)
    if (win.getProperty("Kraken.LastSubtitleLangApplied") or "").strip().lower() == c:
        return
    _jsonrpc(
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "Settings.SetSettingValue",
            "params": {"setting": "locale.subtitlelanguage", "value": c},
        }
    )
    try:
        win.setProperty("Kraken.LastSubtitleLangApplied", c)
    except Exception:
        pass


def _subtitle_active(player):
    try:
        name = str(player.getSubtitles() or "").strip()
    except Exception:
        name = ""
    return bool(name)


def _subtitle_translate_target_code():
    try:
        rpc = xbmc.executeJSONRPC(
            '{"jsonrpc":"2.0","id":0,"method":"Settings.GetSettingValue","params":{"setting":"locale.language"}}'
        )
        payload = json.loads(rpc) if rpc else {}
        val = str(payload.get("result", {}).get("value") or "").lower()
    except Exception:
        val = ""
    if "spanish" in val or val.startswith("es"):
        return "es"
    if "french" in val or val.startswith("fr"):
        return "fr"
    if "italian" in val or val.startswith("it"):
        return "it"
    if "german" in val or val.startswith("de"):
        return "de"
    return "en"


def _maybe_translate_fallback_subtitle(player, fallback_code, target_code):
    if not _get_bool("subtitle_translate_enabled", "true"):
        return
    if not fallback_code or not target_code or str(fallback_code).lower() == str(target_code).lower():
        return
    try:
        sub_path = str(player.getSubtitles() or "").strip()
    except Exception:
        sub_path = ""
    if not sub_path or not os.path.isfile(sub_path):
        return
    try:
        profile = xbmcaddon.Addon(ADDON_ID).getAddonInfo("profile")
        translated = translate_srt_file(
            sub_path,
            profile_dir=profile,
            source_lang=fallback_code,
            target_lang=target_code,
            endpoint=_get_setting_str("subtitle_translate_endpoint", "https://lingva.ml"),
            max_chars=int(_get_setting_str("subtitle_translate_max_chars", "1200") or 1200),
        )
    except Exception as ex:
        xbmc.log(f"[Kraken][SubTranslate] Fallo traduciendo subtítulo: {ex}", xbmc.LOGWARNING)
        return
    if translated and os.path.isfile(translated):
        try:
            player.setSubtitles(translated)
            xbmcgui.Dialog().notification("Kraken", _t("Subtítulos traducidos cargados", "Translated subtitles loaded", "Sous-titres traduits chargés", "Sottotitoli tradotti caricati", "Übersetzte Untertitel geladen"), xbmcgui.NOTIFICATION_INFO, 4500)
        except Exception:
            pass


def _maybe_trigger_opensubtitles(player, win, now_ts):
    if not _get_bool("opensubtitles_enabled", "false"):
        return
    mode = _get_setting_str("opensubtitles_mode", "Automático (intenta descargar)")
    current = ""
    try:
        current = str(player.getPlayingFile() or "").strip()
    except Exception:
        current = ""
    if not current:
        return
    last_file = (win.getProperty("Kraken.SubtitlesLastFile") or "").strip()
    last_ts_raw = (win.getProperty("Kraken.SubtitlesLastTs") or "").strip()
    try:
        last_ts = float(last_ts_raw) if last_ts_raw else 0.0
    except Exception:
        last_ts = 0.0
    if current == last_file and (now_ts - last_ts) < 30.0:
        return
    win.setProperty("Kraken.SubtitlesLastFile", current)
    win.setProperty("Kraken.SubtitlesLastTs", str(now_ts))
    _apply_preferred_subtitle_language()
    if "Manual" in mode:
        xbmc.executebuiltin("ActivateWindow(SubtitleSearch)")
        return
    addon_id = _opensubtitles_addon_id()
    if not addon_id:
        xbmcgui.Dialog().notification(
            "Kraken",
            _t(
                "Instala el addon OpenSubtitles para usar subtítulos automáticos.",
                "Install the OpenSubtitles add-on to use automatic subtitles.",
                "Installez l'extension OpenSubtitles pour les sous-titres automatiques.",
                "Installa l'addon OpenSubtitles per i sottotitoli automatici.",
                "Installiere das OpenSubtitles-Addon für automatische Untertitel.",
            ),
            xbmcgui.NOTIFICATION_WARNING,
            5000,
        )
        return
    xbmc.executebuiltin(f"RunAddon({addon_id})")
    fallback = _get_setting_str("opensubtitles_fallback_lang", "Ninguno")
    fb_code = str(fallback).strip().lower()
    if fb_code in ("ninguno", ""):
        return
    pref = _get_setting_str("opensubtitles_preferred_lang", "Auto (Kodi)")
    pref_code = "" if pref.startswith("Auto") else str(pref).strip().lower()
    if pref_code and pref_code == fb_code:
        return
    # Espera corta para dar tiempo al primer intento; si no hay subtítulo activo, reintenta con fallback.
    xbmc.sleep(3500)
    if not player.isPlaying() or not _safe_is_playing_video(player):
        return
    if _subtitle_active(player):
        return
    _apply_subtitle_language_code(fb_code)
    xbmc.executebuiltin(f"RunAddon({addon_id})")
    xbmc.sleep(3500)
    if player.isPlaying() and _safe_is_playing_video(player) and _subtitle_active(player):
        _maybe_translate_fallback_subtitle(player, fb_code, _subtitle_translate_target_code())


def _build_prefetch_plugin_url(show_id, s, e):
    return "plugin://{}/trakt/prefetch_next/{}/{}/{}".format(
        ADDON_ID, quote(str(show_id).strip(), safe=""), int(s), int(e)
    )


def _playback_total_and_pos(player):
    """
    Duración + posición para el aviso de fin de capítulo (segundos configurables).

    getTotalTime() suele ser 0 en muchos streams (HLS, enlaces directos, etc.);
    se intenta InfoTagVideo y, si hace falta, una estimación con Player.Progress.
    """
    pos = 0.0
    tot = 0.0
    try:
        pos = float(player.getTime())
    except Exception:
        pos = 0.0
    try:
        tot = float(player.getTotalTime())
    except Exception:
        tot = 0.0
    if tot > 0:
        return tot, pos
    if _safe_is_playing_video(player):
        try:
            tag = player.getVideoInfoTag()
            if tag:
                d = tag.getDuration()
                if d is not None:
                    tot = float(d)
        except Exception:
            tot = 0.0
    if tot > 0:
        return tot, pos
    try:
        pr_raw = xbmc.getInfoLabel("Player.Progress") or ""
        pr = float(pr_raw.replace("%", "").strip())
    except Exception:
        pr = 0.0
    # Evitar estimaciones absurdas al inicio (barra de progreso poco fiable).
    if pr >= 5.0 and pr < 99.99 and pos >= 60.0:
        tot = pos * 100.0 / pr
    return tot, pos


def _time_remaining_seconds():
    """Player.TimeRemaining (p. ej. '1:30' o '0:45') cuando no hay duracion total."""
    s = (xbmc.getInfoLabel("Player.TimeRemaining") or "").strip()
    if not s or s in ("--", "-", "00:00:00"):
        return None
    parts = s.replace(".", ":").split(":")
    try:
        nums = [int(p) for p in parts if p != ""]
    except ValueError:
        return None
    if not nums:
        return None
    if len(nums) == 1:
        return float(nums[0])
    if len(nums) == 2:
        return float(nums[0] * 60 + nums[1])
    return float(nums[0] * 3600 + nums[1] * 60 + nums[2])


def _is_within_remaining_window(time_left, max_seconds):
    """True si time_left no es None y 0 <= time_left <= max_seconds (faltan N segundos o menos al final)."""
    if time_left is None or time_left < 0:
        return False
    return time_left <= float(max_seconds)


def _maybe_run_debrid_expiration(sched):
    """Una pasada tras ~2 min al arrancar el servicio; luego como mucho cada ~24 h."""
    t0 = sched.get("t0") or time.time()
    sched.setdefault("t0", t0)
    now = time.time()
    if now - sched["t0"] < 120:
        return
    last = float(sched.get("last") or 0.0)
    if last > 0 and (now - last) < 23.5 * 3600:
        return
    sched["last"] = now
    try:
        run_debrid_expiration_notifications(
            get_bool_setting=_get_bool,
            get_setting_str=_get_setting_str,
            json_get=_kraken_json_get,
            dialog_notification=lambda title, msg, ms: xbmcgui.Dialog().notification(
                title, msg, xbmcgui.NOTIFICATION_WARNING, ms
            ),
        )
    except Exception as ex:
        xbmc.log(f"[Kraken] aviso caducidad Debrid: {ex}", xbmc.LOGDEBUG)


class KrakenPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._skip_stop_clear = False

    def _try_consume_prefetch_play(self):
        win = xbmcgui.Window(WID)
        u = (win.getProperty("Kraken.PrefetchStreamUrl") or "").strip()
        if not u:
            return False
        try:
            meta = json.loads(win.getProperty("Kraken.PrefetchMeta") or "{}")
        except Exception:
            meta = {}
        win.clearProperty("Kraken.PrefetchStreamUrl")
        win.clearProperty("Kraken.PrefetchMeta")
        for p in (
            "Kraken.30sDialogShown",
            "Kraken.30sUserCancelled",
            "Kraken.EofSoon",
            "Kraken.PrefetchInProgress",
            "Kraken.TraktSynced",
            "Kraken.TraktCollectionSent",
            "Kraken.LastProgressPct",
            "Kraken.TraktScrobbleLast.start",
            "Kraken.TraktScrobbleLast.pause",
            "Kraken.TraktScrobbleLast.stop",
        ):
            win.clearProperty(p)
        show_id = (meta or {}).get("show_id", "")
        win.setProperty(
            "Kraken.Playing",
            json.dumps(
                {
                    "kind": "episode",
                    "show_id": show_id,
                    "season": int((meta or {}).get("next_season", 0)),
                    "episode": int((meta or {}).get("next_ep", 0)),
                }
            ),
        )
        self._skip_stop_clear = True
        li = xbmcgui.ListItem(path=str(u), label=(meta or {}).get("label", "Kraken"))
        if (meta or {}).get("info"):
            li.setInfo("video", meta["info"])
        li.setProperty("IsPlayable", "true")
        try:
            li.setContentLookup(False)
        except Exception:
            pass
        _configure_listitem_stream(li, u)
        # Dejar que Kodi cierre el reproductor anterior antes de abrir el siguiente.
        xbmc.sleep(400)
        ok = False
        # Player() global: el callback vive en KrakenPlayer pero la reproducción debe pedirse al player por defecto.
        xplayer = xbmc.Player()
        try:
            xplayer.play(str(u), li, False)
            ok = True
            win.setProperty("Kraken.LastPlaybackAttemptUrl", str(u))
            xbmc.log("[Kraken] service: siguiente vía Player.play", xbmc.LOGINFO)
        except Exception as ex:
            xbmc.log(f"[Kraken] service: Player.play error: {ex}", xbmc.LOGWARNING)
            ok = False
        if not ok:
            try:
                plv = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                plv.clear()
                plv.add(str(u), li)
                xplayer.play(plv, li, False)
                ok = True
                win.setProperty("Kraken.LastPlaybackAttemptUrl", str(u))
                xbmc.log("[Kraken] service: siguiente vía PlayList", xbmc.LOGINFO)
            except Exception as ex:
                xbmc.log(f"[Kraken] service: PlayList error: {ex}", xbmc.LOGWARNING)
                ok = False
        if not ok:
            try:
                xbmc.executebuiltin(f'PlayMedia("{escape_for_quoted_builtin(u)}")')
                ok = True
                win.setProperty("Kraken.LastPlaybackAttemptUrl", str(u))
                xbmc.log("[Kraken] service: siguiente vía PlayMedia", xbmc.LOGINFO)
            except Exception as ex:
                xbmc.log(f"[Kraken] service: PlayMedia error: {ex}", xbmc.LOGWARNING)
                ok = False
        if not ok:
            self._skip_stop_clear = False
            xbmcgui.Dialog().notification(
                "Kraken",
                _t(
                    "No se pudo abrir el siguiente capítulo. Prueba a reproducirlo desde el menú.",
                    "Could not open the next episode. Try playing it from the menu.",
                    "Impossible d'ouvrir l'épisode suivant. Essayez depuis le menu.",
                    "Impossibile aprire il prossimo episodio. Riprodurlo dal menu.",
                    "Nächste Folge konnte nicht geöffnet werden. Versuchen Sie es im Menu.",
                ),
                xbmcgui.NOTIFICATION_WARNING,
                6000,
            )
        return ok

    def _next_fallback_url(self, failed_url):
        failed = str(failed_url or "").strip()
        cands = load_stashed_candidates() or []
        if not cands:
            return ""
        w = xbmcgui.Window(WID)
        tried_blob = (w.getProperty("Kraken.FallbackTriedUrls") or "").strip()
        tried = set()
        if tried_blob:
            for piece in tried_blob.split("\n"):
                p = str(piece or "").strip()
                if p:
                    tried.add(p)
        if failed:
            tried.add(failed)
        for item in cands:
            u = str((item or {}).get("url") or "").strip()
            if not u or u in tried:
                continue
            return u
        return ""

    def _play_fallback_candidate(self, failed_url):
        raw_url = self._next_fallback_url(failed_url)
        if not raw_url:
            return False
        path = _finalize_playback_stream_url(raw_url, _get_setting_raw, _installed)
        if not path:
            return False
        li = xbmcgui.ListItem(path=str(path), label="Kraken")
        li.setProperty("IsPlayable", "true")
        try:
            li.setContentLookup(False)
        except Exception:
            pass
        _configure_listitem_stream(li, path)
        xbmc.sleep(120)
        pl = xbmc.Player()
        ok = False
        try:
            pl.play(str(path), li, False)
            ok = True
        except Exception as ex:
            xbmc.log(f"[Kraken] fallback Player.play: {ex}", xbmc.LOGWARNING)
        if not ok:
            try:
                plv = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                plv.clear()
                plv.add(str(path), li)
                pl.play(plv, li, False)
                ok = True
            except Exception as ex:
                xbmc.log(f"[Kraken] fallback PlayList: {ex}", xbmc.LOGWARNING)
        if not ok:
            try:
                xbmc.executebuiltin(f'PlayMedia("{escape_for_quoted_builtin(path)}")')
                ok = True
            except Exception as ex:
                xbmc.log(f"[Kraken] fallback PlayMedia: {ex}", xbmc.LOGWARNING)
        if ok:
            w = xbmcgui.Window(WID)
            tried_blob = (w.getProperty("Kraken.FallbackTriedUrls") or "").strip()
            tried_list = (
                [x for x in tried_blob.split("\n") if str(x or "").strip()]
                if tried_blob
                else []
            )
            tried_list.append(raw_url)
            w.setProperty("Kraken.FallbackTriedUrls", "\n".join(tried_list[-12:]))
            w.setProperty("Kraken.LastPlaybackAttemptUrl", str(raw_url))
            xbmcgui.Dialog().notification(
                "Kraken",
                _t(
                    "Fuente con error; probando la siguiente automáticamente.",
                    "Source error; trying the next one automatically.",
                    "Erreur de source ; passage a la suivante automatiquement.",
                    "Errore della fonte; si prova la successiva automaticamente.",
                    "Quellenfehler; versuche automatisch die naechste.",
                ),
                xbmcgui.NOTIFICATION_INFO,
                3000,
            )
            xbmc.log(f"[Kraken] fallback auto -> {raw_url}", xbmc.LOGINFO)
        return ok

    def onPlayBackEnded(self):
        win = xbmcgui.Window(WID)
        _trakt_scrobble("stop", self, win)
        _trakt_mark_watched_from_playing(win)
        if self._try_consume_prefetch_play():
            return
        # La resolución del siguiente capítulo puede tardar más que lo que queda de vídeo:
        # no borrar Kraken.Playing mientras Kraken.PrefetchInProgress (addon RunPlugin).
        if win.getProperty("Kraken.PrefetchInProgress") == "1":
            return
        for p in (
            "Kraken.Playing",
            "Kraken.30sDialogShown",
            "Kraken.30sUserCancelled",
            "Kraken.LastProgressPct",
        ):
            win.clearProperty(p)

    def onPlayBackError(self):
        """Si falla la reproducción, probar automáticamente la siguiente fuente guardada."""
        w = xbmcgui.Window(WID)
        raw = (w.getProperty("Kraken.SourceCandidates") or "").strip()
        if not raw:
            return
        try:
            data = json.loads(raw)
        except Exception:
            return
        if not data:
            return
        try:
            last = float(w.getProperty("Kraken.RepickLastOfferTs") or "0")
        except (TypeError, ValueError):
            last = 0.0
        now = time.time()
        if now - last < 25.0:
            return
        w.setProperty("Kraken.RepickLastOfferTs", str(now))
        auto_on = _get_bool("autofallback_on_playback_error", "true")
        max_attempts = _get_setting_int(
            "autofallback_max_attempts", default=2, minv=1, maxv=5
        )
        try:
            used_attempts = int(
                str(w.getProperty("Kraken.FallbackAutoAttempts") or "0").strip()
            )
        except (TypeError, ValueError):
            used_attempts = 0
        used_attempts = max(0, min(99, used_attempts))
        failed_url = (w.getProperty("Kraken.LastPlaybackAttemptUrl") or "").strip()
        if auto_on and used_attempts < max_attempts:
            if self._play_fallback_candidate(failed_url):
                w.setProperty("Kraken.FallbackAutoAttempts", str(used_attempts + 1))
                return
        if not xbmcgui.Dialog().yesno(
            "Kraken",
            _t(
                "La reproducción falló.\n\n¿Ver la lista de fuentes para elegir otra?",
                "Playback failed.\n\nOpen the source list to pick another?",
                "Lecture impossible.\n\nOuvrir la liste des sources pour en choisir une autre ?",
                "Riproduzione non riuscita.\n\nAprire l'elenco delle fonti per sceglierne un'altra?",
                "Wiedergabe fehlgeschlagen.\n\nQuellenliste oeffnen, um eine andere zu waehlen?",
            ),
            nolabel=_t("No", "No", "Non", "No", "Nein"),
            yeslabel=_t("Sí", "Yes", "Oui", "Sì", "Ja"),
        ):
            return
        xbmc.executebuiltin('RunPlugin("plugin://plugin.video.kraken/sources/repick")')

    def onPlayBackStopped(self):
        if getattr(self, "_skip_stop_clear", False):
            self._skip_stop_clear = False
            return
        w = xbmcgui.Window(WID)
        _trakt_scrobble("stop", self, w)
        eof = (w.getProperty("Kraken.EofSoon") or "").strip() == "1"
        pct_hit = False
        try:
            pct_hit = (
                float((w.getProperty("Kraken.LastProgressPct") or "0").strip())
                >= TRAKT_WATCHED_MIN_PCT
            )
        except (TypeError, ValueError):
            pct_hit = False
        if eof or pct_hit:
            _trakt_mark_watched_from_playing(w)
        if (w.getProperty("Kraken.PrefetchStreamUrl") or "").strip() and w.getProperty(
            "Kraken.EofSoon"
        ) == "1":
            if self._try_consume_prefetch_play():
                return
        # Prefetch aún resolviendo: no limpiar Playing (el addon abrirá al terminar o al detectar fin).
        if w.getProperty("Kraken.PrefetchInProgress") == "1":
            return
        _clear_kraken_session_properties(w)

    def onPlayBackStarted(self):
        try:
            w = xbmcgui.Window(WID)
            try:
                path = str(self.getPlayingFile() or "").strip()
            except Exception:
                path = ""
            if _playback_detached_from_kraken(path, w):
                _clear_kraken_session_properties(w)
            _trakt_scrobble("start", self, w)
            _trakt_sync_collection_from_playing(w)
        except Exception:
            pass

    def onPlayBackResumed(self):
        try:
            w = xbmcgui.Window(WID)
            _trakt_scrobble("start", self, w)
        except Exception:
            pass

    def onPlayBackPaused(self):
        try:
            w = xbmcgui.Window(WID)
            _trakt_scrobble("pause", self, w)
        except Exception:
            pass


def run():
    mon = KrakenSettingsMonitor()
    pl = KrakenPlayer()
    addon_path = xbmcaddon.Addon(ADDON_ID).getAddonInfo("path")
    debrid_sched = {"t0": time.time(), "last": 0.0}
    t_boot = time.time()
    recovery_started = False
    while not mon.abortRequested():
        if mon.waitForAbort(1):
            break
        if not recovery_started and (time.time() - t_boot) >= 40:
            recovery_started = True

            def _recovery_job():
                try:
                    from resources.lib.core.download_recovery import (
                        run_pending_downloads_recovery,
                    )

                    run_pending_downloads_recovery()
                except Exception as ex_r:
                    xbmc.log(f"[Kraken] recovery startup: {ex_r}", xbmc.LOGWARNING)

            try:
                threading.Thread(target=_recovery_job, daemon=True).start()
            except Exception as ex_t:
                xbmc.log(f"[Kraken] recovery thread: {ex_t}", xbmc.LOGWARNING)

        _maybe_run_debrid_expiration(debrid_sched)
        w = xbmcgui.Window(WID)
        if pl.isPlaying() and _safe_is_playing_video(pl):
            # Arrancó reproducción: desarma watchdog de repick por fallo de arranque.
            for p in ("Kraken.PendingPlaybackStart", "Kraken.PendingPlaybackTs"):
                w.clearProperty(p)
            w.clearProperty("Kraken.FallbackAutoAttempts")
            _maybe_trigger_opensubtitles(pl, w, time.time())
            tot_prog, pos_prog = _playback_total_and_pos(pl)
            time_left = None
            if tot_prog >= MIN_DUR:
                time_left = tot_prog - pos_prog
            else:
                rem = _time_remaining_seconds()
                if rem is not None and pos_prog >= 45.0:
                    time_left = rem
            if time_left is not None:
                # Ventana amplia: fin natural a veces no pasa por el bucle en los últimos 3 s.
                if time_left <= 15.0:
                    w.setProperty("Kraken.EofSoon", "1")
                elif time_left > 25.0:
                    w.clearProperty("Kraken.EofSoon")
            if tot_prog > 0:
                try:
                    pct = max(
                        0.0, min(100.0, (float(pos_prog) * 100.0) / float(tot_prog))
                    )
                    w.setProperty("Kraken.LastProgressPct", f"{pct:.2f}")
                except Exception:
                    pass
            else:
                # Streams sin duración total confiable (HLS, etc.): infobar Player.Progress%.
                try:
                    pr_raw = (
                        str(xbmc.getInfoLabel("Player.Progress") or "")
                        .replace("%", "")
                        .strip()
                    )
                    if pr_raw:
                        pr_v = float(pr_raw)
                        if 4.0 <= pr_v <= 99.98:
                            w.setProperty("Kraken.LastProgressPct", f"{pr_v:.2f}")
                except Exception:
                    pass
        else:
            # Si tras elegir fuente no arranca vídeo en unos segundos, reabrir lista guardada.
            if (w.getProperty("Kraken.PendingPlaybackStart") or "").strip() == "1":
                try:
                    ts = float(w.getProperty("Kraken.PendingPlaybackTs") or "0")
                except (TypeError, ValueError):
                    ts = 0.0
                # Algunas fuentes (Stremio/Debrid) tardan bastante en abrir InputStream.
                # Si repicamos demasiado pronto, reaparece el selector durante el arranque.
                if ts > 0 and (time.time() - ts) >= 30.0:
                    for p in (
                        "Kraken.PendingPlaybackStart",
                        "Kraken.PendingPlaybackTs",
                    ):
                        w.clearProperty(p)
                    xbmc.executebuiltin(
                        'RunPlugin("plugin://plugin.video.kraken/sources/repick")'
                    )
        if not _get_bool("next_episode_30s_dialog", "true"):
            continue
        if not pl.isPlaying() or not _safe_is_playing_video(pl):
            # No limpiar Kraken.EofSoon aquí: al acabar el capítulo isPlaying pasa a False
            # antes que onPlayBackStopped; si borramos EofSoon, no se reproduce el prefetch.
            continue
        tot, pos = _playback_total_and_pos(pl)
        time_left = None
        if tot >= MIN_DUR:
            time_left = tot - pos
        else:
            rem = _time_remaining_seconds()
            if rem is not None and pos >= 45.0:
                time_left = rem
        if w.getProperty("Kraken.30sUserCancelled") == "1":
            continue
        if w.getProperty("Kraken.30sDialogShown") == "1":
            continue
        try:
            st = w.getProperty("Kraken.Playing")
            if not st:
                continue
            data = json.loads(st)
        except Exception:
            continue
        warn_s = _get_warn_seconds()
        # Evitar umbral mayor que la duracion (p. ej. 120 s en un clip corto): no mostrar al inicio.
        if tot > 0:
            warn_eff = min(warn_s, max(5, int(tot) - 10))
        else:
            warn_eff = warn_s
        if not _is_within_remaining_window(time_left, warn_eff):
            continue
        w.setProperty("Kraken.30sDialogShown", "1")
        _n = int(warn_eff)
        body = _t(
            "Quedan {n} s o menos de reproducción de este capítulo. "
            "Preparar el siguiente ahora (búsqueda de fuentes) para abrirlo al terminar?\n\n"
            "Solo Cancelar detiene el siguiente capítulo; si la cuenta atrás termina, se prepara solo.",
            "Less than {n} s of this episode remain. Prepare the next one now (source search) to open it when this ends?\n\n"
            "Cancel stops only the next-episode preparation; if the countdown ends, it still prepares automatically.",
            "Moins de {n} s pour cet episode. Preparer le suivant maintenant (recherche de sources) pour l'ouvrir a la fin ?\n\n"
            "Annuler n'arrete que la preparation ; si le compte a rebours finit, elle se lance quand meme.",
            "Meno di {n} s di questo episodio. Preparare il prossimo ora (ricerca fonti) per aprirlo alla fine?\n\n"
            "Annulla ferma solo la preparazione; se il countdown finisce, la preparazione parte comunque.",
            "Weniger als {n} s von dieser Folge. Naechste jetzt vorbereiten (Quellensuche), um sie am Ende zu oeffnen?\n\n"
            "Abbrechen stoppt nur die Vorbereitung; endet der Countdown, wird trotzdem vorbereitet.",
        ).format(n=_n)
        corner = NextEpisodeCornerDialog(
            "kraken_next_corner.xml",
            addon_path,
            "default",
            "1080i",
            remain_seconds_cap=warn_eff,
            body_text=body,
            countdown_seconds=10,
        )
        corner.doModal()
        accepted = corner.buscar_selected()
        del corner
        if not accepted:
            w.setProperty("Kraken.30sUserCancelled", "1")
            continue
        show_id = (data or {}).get("show_id", "")
        s = int((data or {}).get("season", 0))
        e = int((data or {}).get("episode", 0))
        if not show_id or e < 1 or s < 0:
            w.clearProperty("Kraken.30sDialogShown")
            continue
        purl = _build_prefetch_plugin_url(show_id, s, e)
        xbmc.log(f"[Kraken] service: RunPlugin {purl}", xbmc.LOGINFO)
        xbmc.executebuiltin(f'RunPlugin("{escape_for_quoted_builtin(purl)}")')


if __name__ == "__main__":
    run()
