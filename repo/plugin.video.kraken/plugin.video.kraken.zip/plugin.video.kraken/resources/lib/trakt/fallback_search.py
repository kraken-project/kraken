from urllib.parse import quote

from resources.lib.core.metadata_tmdb import tmdb_effective_language


def _tmdb_search_movies(
    *,
    query,
    tmdb_api_key,
    json_get,
    metadata_timeout,
    tmdb_image_base,
    tmdb_backdrop_base,
    tmdb_language=None,
    tmdb_country=None,
):
    if not tmdb_api_key:
        return []
    payload = json_get(
        "https://api.themoviedb.org/3/search/movie?api_key={}&query={}&language={}&region={}&include_adult=false".format(
            quote(str(tmdb_api_key), safe=""),
            quote(str(query or "").strip(), safe=""),
            quote(str(tmdb_effective_language(tmdb_language)), safe=""),
            quote(str(tmdb_country() if callable(tmdb_country) else "ES"), safe=""),
        ),
        timeout=metadata_timeout(),
    )
    out = []
    for row in payload.get("results") or []:
        title = str(row.get("title") or "").strip()
        if not title:
            continue
        year = None
        rd = str(row.get("release_date") or "").strip()
        if len(rd) >= 4 and rd[:4].isdigit():
            year = int(rd[:4])
        tmdb_id = row.get("id")
        poster_path = str(row.get("poster_path") or "").strip()
        backdrop_path = str(row.get("backdrop_path") or "").strip()
        out.append(
            {
                "id": "fallback::movie::{}::{}".format(
                    year or 0, quote(title, safe="")
                ),
                "title": title,
                "year": year,
                "rating": row.get("vote_average"),
                "votes": row.get("vote_count"),
                "plot": str(row.get("overview") or ""),
                "poster": f"{tmdb_image_base}{poster_path}" if poster_path else "",
                "fanart": f"{tmdb_backdrop_base}{backdrop_path}"
                if backdrop_path
                else "",
                "tmdb_id": tmdb_id,
                "provider": "TMDb",
            }
        )
    return out


def _tmdb_search_shows(
    *,
    query,
    tmdb_api_key,
    json_get,
    metadata_timeout,
    tmdb_image_base,
    tmdb_backdrop_base,
    tmdb_language=None,
    tmdb_country=None,
):
    if not tmdb_api_key:
        return []
    payload = json_get(
        "https://api.themoviedb.org/3/search/tv?api_key={}&query={}&language={}&region={}&include_adult=false".format(
            quote(str(tmdb_api_key), safe=""),
            quote(str(query or "").strip(), safe=""),
            quote(str(tmdb_effective_language(tmdb_language)), safe=""),
            quote(str(tmdb_country() if callable(tmdb_country) else "ES"), safe=""),
        ),
        timeout=metadata_timeout(),
    )
    out = []
    for row in payload.get("results") or []:
        title = str(row.get("name") or "").strip()
        if not title:
            continue
        year = None
        rd = str(row.get("first_air_date") or "").strip()
        if len(rd) >= 4 and rd[:4].isdigit():
            year = int(rd[:4])
        tmdb_id = row.get("id")
        poster_path = str(row.get("poster_path") or "").strip()
        backdrop_path = str(row.get("backdrop_path") or "").strip()
        out.append(
            {
                "id": "fallback::show::{}::{}".format(
                    year or 0, quote(title, safe="")
                ),
                "title": title,
                "year": year,
                "rating": row.get("vote_average"),
                "votes": row.get("vote_count"),
                "plot": str(row.get("overview") or ""),
                "poster": f"{tmdb_image_base}{poster_path}" if poster_path else "",
                "fanart": f"{tmdb_backdrop_base}{backdrop_path}"
                if backdrop_path
                else "",
                "tmdb_id": tmdb_id,
                "provider": "TMDb",
            }
        )
    return out


def search_fallback_media(
    *,
    query,
    media_filter,
    tmdb_enabled,
    tmdb_api_key,
    json_get,
    metadata_timeout,
    tmdb_image_base,
    tmdb_backdrop_base,
    tmdb_language=None,
    tmdb_country=None,
    omdb_enabled,
    omdb_search_art,
):
    mf = (media_filter or "all").strip().lower()
    if mf not in ("movie", "show", "all"):
        return []
    if not tmdb_enabled():
        return []
    api_key = tmdb_api_key()
    results = []
    if mf in ("movie", "all"):
        results.extend(
            _tmdb_search_movies(
                query=query,
                tmdb_api_key=api_key,
                json_get=json_get,
                metadata_timeout=metadata_timeout,
                tmdb_image_base=tmdb_image_base,
                tmdb_backdrop_base=tmdb_backdrop_base,
                tmdb_language=tmdb_language,
                tmdb_country=tmdb_country,
            )
        )
    if mf in ("show", "all"):
        results.extend(
            _tmdb_search_shows(
                query=query,
                tmdb_api_key=api_key,
                json_get=json_get,
                metadata_timeout=metadata_timeout,
                tmdb_image_base=tmdb_image_base,
                tmdb_backdrop_base=tmdb_backdrop_base,
                tmdb_language=tmdb_language,
                tmdb_country=tmdb_country,
            )
        )
    # Con TMDb activo ya hay poster/fanarte del search; no llamar OMDb.
    return results
