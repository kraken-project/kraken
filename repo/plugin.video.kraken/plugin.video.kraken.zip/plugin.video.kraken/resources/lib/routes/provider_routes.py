from urllib.parse import urlencode
from urllib.request import Request, urlopen

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.core.debrid_provider_config import PROVIDERS
from resources.lib.core.elementum_burst_client import elementum_burst_import_ok
from resources.lib.core.kraken_torrent_lite import (
    LINK_PROVIDER_SETTINGS,
    LINK_PROVIDER_URL_SETTINGS,
    enabled_link_providers,
)
from resources.lib.ui.video_info import apply_video_info
from resources.lib.routes.i18n_routes import make_mapped_t

_PROVIDER_PHRASE_MAP = {
    ("sin proveedor", "no provider"): ("sans fournisseur", "nessun provider", "kein Anbieter"),
    ("sin token", "missing token"): ("sans jeton", "senza token", "kein Token"),
    ("token valido", "valid token"): ("jeton valide", "token valido", "gültiges Token"),
    ("token invalido", "invalid token"): ("jeton invalide", "token non valido", "ungültiges Token"),
    ("proveedor no reconocido", "unrecognized provider"): (
        "fournisseur non reconnu",
        "provider non riconosciuto",
        "unbekannter Anbieter",
    ),
}


_t = make_mapped_t(_PROVIDER_PHRASE_MAP)


def run_providers_view(*, plugin_handle, get_enabled_providers, url_for_noop):
    providers = get_enabled_providers()
    if not providers:
        xbmcgui.Dialog().ok(
            "Kraken",
            _t(
                "No hay proveedores habilitados en ajustes.",
                "No providers enabled in settings.",
                "Aucun fournisseur active dans les parametres.",
                "Nessun provider abilitato nelle impostazioni.",
                "Keine Provider in den Einstellungen aktiviert.",
            ),
        )
        xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)
        return

    directory = []
    for provider in providers:
        li = xbmcgui.ListItem(label=provider.name)
        apply_video_info(li, {"plot": provider.description})
        directory.append((url_for_noop(), li, False))
    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)


_WEB_LINK_PROVIDER_PING_URLS = {
    "2ddl": "https://2ddl.ag",
    "300mbfilms": "https://300mbfilms.io",
    "allmoviesforyou": "https://allmoviesforyou.net",
    "anymovies": "https://anymovies.xyz",
    "cmovieshd": "https://cmovieshd.bz",
    "databasegdriveplayer": "https://databasegdriveplayer.co",
    "dbgo": "https://dbgo.fun",
    "easynews": "https://members.easynews.com",
    "filmxy": "https://www.filmxy.vip",
    "furk": "https://www.furk.net",
    "gowatchseries": "https://gowatchseries.ac",
    "maxrls": "https://maxrls.com",
    "myvideolinks": "https://myvideolinks.net",
    "onlineseries": "https://onlineseries.co",
    "ororo": "https://ororo.tv",
    "rapidmoviez": "https://rapidmoviez.com",
    "rlsbb": "https://rlsbb.ru",
    "scenerls": "https://www.scenerls.com",
}


def _http_ping(url, timeout=4):
    try:
        req = Request(url, headers={"User-Agent": "KrakenProviderCheck/1.0"})
        with urlopen(req, timeout=timeout) as res:
            code = int(getattr(res, "status", 200))
        return (200 <= code < 500), code
    except Exception:
        return False, 0


def _pick_ping_url(provider_name, defaults_map, settings_map, get_setting):
    custom_sid = settings_map.get(provider_name, "")
    custom_url = (get_setting(custom_sid) or "").strip() if custom_sid else ""
    if custom_url:
        return custom_url, True
    return defaults_map.get(provider_name, ""), False


def _normalize_url_value(raw):
    u = str(raw or "").strip()
    if not u:
        return ""
    if not (u.startswith("http://") or u.startswith("https://")):
        u = "https://" + u.lstrip("/")
    while "//" in u.replace("://", "__proto__"):
        u = u.replace("://", "__proto__").replace("//", "/").replace("__proto__", "://")
    return u.rstrip("/")


def _debrid_provider_check(*, provider, token, json_get):
    p = str(provider or "").strip()
    t = str(token or "").strip()
    if not p or p == "Ninguno":
        return "OFF", _t("sin proveedor", "no provider", "sans fournisseur", "nessun provider", "kein Anbieter")
    if p == "Rapidgator":
        return "OK", _t(
            "modo universal (sin token en Kraken)",
            "universal mode (no token in Kraken)",
            "mode universel (sans token dans Kraken)",
            "modalita universale (senza token in Kraken)",
            "universeller Modus (ohne Token in Kraken)",
        )
    if not t:
        return "ERROR", _t("sin token", "missing token", "sans jeton", "senza token", "kein Token")
    try:
        if p == "AllDebrid":
            data = json_get(
                "https://api.alldebrid.com/v4/user?{}".format(
                    urlencode({"apikey": t, "agent": "KrakenKodi"})
                )
            )
            return (
                ("OK", _t("token valido", "valid token", "jeton valide", "token valido", "gültiges Token"))
                if data.get("status") == "success"
                else ("ERROR", _t("token invalido", "invalid token", "jeton invalide", "token non valido", "ungültiges Token"))
            )
    except Exception as err:
        return "ERROR", _t(
            "fallo de red/api ({})",
            "network/api error ({})",
            "erreur réseau/api ({})",
            "errore rete/api ({})",
            "Netzwerk/API-Fehler ({})",
        ).format(err)
    return "WARN", _t("proveedor no reconocido", "unrecognized provider", "fournisseur non reconnu", "provider non riconosciuto", "unbekannter Anbieter")


def run_providers_check(
    *,
    plugin_handle,
    get_enabled_providers,
    get_bool_setting,
    get_setting,
    set_setting,
    addon_installed,
    load_scraper_module,
    json_get,
):
    lines = []
    providers = get_enabled_providers() or []
    if not providers:
        lines.append(
            _t(
                "Ningún proveedor catálogo activo.",
                "No active catalog provider.",
                "Aucun fournisseur de catalogue actif.",
                "Nessun provider catalogo attivo.",
                "Kein aktiver Katalog-Provider.",
            )
        )
    for provider in providers:
        name = str(getattr(provider, "name", _t("Proveedor", "Provider", "Fournisseur", "Provider", "Provider"))).strip() or _t("Proveedor", "Provider", "Fournisseur", "Provider", "Provider")
        try:
            result = provider.search("matrix") if hasattr(provider, "search") else []
            count = len(result or [])
            lines.append(
                _t(
                    "OK: {} ({} resultados prueba)",
                    "OK: {} ({} test results)",
                    "OK : {} ({} résultats test)",
                    "OK: {} ({} risultati test)",
                    "OK: {} ({} Testergebnisse)",
                ).format(name, count)
            )
        except Exception as err:
            lines.append(f"ERROR: {name} ({err})")

    ext_cfg = [
        ("CocoScrapers", "provider_coco_scrapers", "script.module.cocoscrapers"),
        ("Torrent Burst", "provider_elementum_burst", "script.elementum.burst"),
    ]
    for label, setting_id, addon_id in ext_cfg:
        enabled = bool(get_bool_setting(setting_id))
        if not enabled:
            lines.append(f"OFF: {label}")
            continue
        if not addon_installed(addon_id):
            lines.append(
                _t(
                    "ERROR: {} activado pero no instalado",
                    "ERROR: {} enabled but not installed",
                    "ERROR : {} activé mais non installé",
                    "ERROR: {} abilitato ma non installato",
                    "ERROR: {} aktiviert aber nicht installiert",
                ).format(
                    label
                )
            )
            continue
        if addon_id == "script.elementum.burst":
            if not addon_installed("plugin.video.elementum"):
                lines.append(
                    _t(
                        "ERROR: Torrent Burst necesita instalado plugin.video.elementum",
                        "ERROR: Torrent Burst needs plugin.video.elementum installed",
                        "ERROR : Torrent Burst nécessite plugin.video.elementum installé",
                        "ERROR: Torrent Burst richiede plugin.video.elementum installato",
                        "ERROR: Torrent Burst benötigt plugin.video.elementum installiert",
                    )
                )
                continue
            if elementum_burst_import_ok():
                lines.append(f"OK: {label} (modulo Burst)")
            else:
                lines.append(
                    _t(
                        "ERROR: {} no importable (revisa video torrent + Burst)",
                        "ERROR: {} not importable (check video torrent + Burst)",
                        "ERROR : {} non importable (vérifie client torrent vidéo + Burst)",
                        "ERROR: {} non importabile (controlla client torrent video + Burst)",
                        "ERROR: {} nicht importierbar (Video-Torrent-Client + Burst prüfen)",
                    ).format(label)
                )
            continue
        package_name = "cocoscrapers"
        module = load_scraper_module(package_name, addon_id)
        if module and hasattr(module, "sources"):
            try:
                provs = module.sources(ret_all=False) or []
                lines.append(f"OK: {label} ({len(provs)})")
            except Exception as err:
                lines.append(
                    _t(
                        "ERROR: {} fallo sources() ({})",
                        "ERROR: {} sources() failed ({})",
                        "ERROR : {} échec sources() ({})",
                        "ERROR: {} sources() fallita ({})",
                        "ERROR: {} sources() fehlgeschlagen ({})",
                    ).format(label, err)
                )
        else:
            lines.append(
                _t(
                    "ERROR: {} no cargable",
                    "ERROR: {} not loadable",
                    "ERROR : {} non chargeable",
                    "ERROR: {} non caricabile",
                    "ERROR: {} nicht ladbar",
                ).format(label)
            )

    n_link = len(link_enabled)
    n_link_tot = len(LINK_PROVIDER_SETTINGS)
    lines.append(
        _t(
            "Proveedores de enlaces web activos: {} / {}",
            "Active web link providers: {} / {}",
            "Fournisseurs de liens web actifs : {} / {}",
            "Provider link web attivi: {} / {}",
            "Aktive Web-Link-Provider: {} / {}",
        ).format(n_link, n_link_tot)
    )
    for provider_name, setting_id in LINK_PROVIDER_SETTINGS:
        if not get_bool_setting(setting_id):
            continue
        ping_url, is_custom = _pick_ping_url(
            provider_name,
            _WEB_LINK_PROVIDER_PING_URLS,
            LINK_PROVIDER_URL_SETTINGS,
            get_setting,
        )
        if is_custom:
            sid = LINK_PROVIDER_URL_SETTINGS.get(provider_name, "")
            norm = _normalize_url_value(ping_url)
            if sid and norm and norm != ping_url:
                set_setting(sid, norm)
                ping_url = norm
        if not ping_url:
            lines.append(
                _t(
                    "WARN: link {} sin URL de ping",
                    "WARN: link {} has no ping URL",
                    "WARN : lien {} sans URL de ping",
                    "WARN: link {} senza URL di ping",
                    "WARN: Link {} ohne Ping-URL",
                ).format(provider_name)
            )
            continue
        ok, status_code = _http_ping(ping_url, timeout=4)
        suffix = " (custom)" if is_custom else ""
        if ok:
            lines.append(
                f"OK: link {provider_name} responde ping {status_code}{suffix}"
            )
        else:
            lines.append(
                _t(
                    "ERROR: link {} no responde ping{}",
                    "ERROR: link {} ping failed{}",
                    "ERROR : lien {} échec ping{}",
                    "ERROR: link {} ping fallito{}",
                    "ERROR: Link {} Ping fehlgeschlagen{}",
                ).format(provider_name, suffix)
            )

    if get_bool_setting("provider_stremio_catalog"):
        lines.append(
            _t(
                "OK: Stremio catalog activo",
                "OK: Stremio catalog active",
                "OK : catalogue Stremio actif",
                "OK: catalogo Stremio attivo",
                "OK: Stremio-Katalog aktiv",
            )
        )
    else:
        lines.append("OFF: Stremio catalog")
    for p in PROVIDERS:
        if not get_bool_setting(p["enabled_key"]):
            lines.append("OFF: Debrid {}".format(p["title"]))
            continue
        tok_key = p.get("token_key")
        token = (get_setting(tok_key) or "").strip() if tok_key else ""
        debrid_status, debrid_msg = _debrid_provider_check(
            provider=p["legacy_name"],
            token=token,
            json_get=json_get,
        )
        lines.append("{}: Debrid {} ({})".format(debrid_status, p["title"], debrid_msg))

    xbmc.log("[Kraken] provider check:\n{}".format("\n".join(lines)), xbmc.LOGINFO)
    xbmcgui.Dialog().textviewer(
        _t("Kraken - Comprobador de proveedores", "Kraken - Provider checker", "Kraken - Verificateur de fournisseurs", "Kraken - Verifica provider", "Kraken - Provider-Prüfung"),
        "\n".join(lines)
        or _t("Sin datos", "No data", "Aucune donnee", "Nessun dato", "Keine Daten"),
    )
    xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)


def run_lite_link_providers_list(*, plugin_handle, get_bool_setting):
    active = set(enabled_link_providers(get_bool_setting))
    lines = []
    for name, _sid in LINK_PROVIDER_SETTINGS:
        mark = "ON" if name in active else "OFF"
        lines.append(f"[{mark}] {name}")
    xbmcgui.Dialog().textviewer(
        _t(
            "KrakenLite - Proveedores Web Enlaces",
            "KrakenLite - Web Link Providers",
            "KrakenLite - Fournisseurs de liens web",
            "KrakenLite - Provider link web",
            "KrakenLite - Web-Link-Provider",
        ),
        "\n".join(lines),
    )
    xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)


def run_lite_urls_reset(*, plugin_handle, set_setting):
    for _name, sid in LINK_PROVIDER_URL_SETTINGS.items():
        set_setting(sid, "")
    xbmcgui.Dialog().notification(
        "Kraken",
        _t(
            "URLs personalizadas restauradas a valores por defecto.",
            "Custom URLs restored to default values.",
        ),
        xbmcgui.NOTIFICATION_INFO,
        4000,
    )
    xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)
