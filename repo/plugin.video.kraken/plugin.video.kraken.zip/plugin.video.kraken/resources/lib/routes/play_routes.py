import json
import time
from urllib.parse import quote, unquote

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.core.playback_listitem import configure_listitem_stream_properties
from resources.lib.core.playback_source_stash import stash_source_candidates
from resources.lib.ui.ui_helpers import _t


def _build_source_rotation(rid, get_setting, set_setting, get_bool_setting):
    if not (get_setting and set_setting and get_bool_setting):
        return None
    try:
        from resources.lib.sources.source_rotation import (
            rotation_content_key_from_play_rid,
        )

        k = rotation_content_key_from_play_rid(rid)
        if not k:
            return None
        return {
            "content_key": k,
            "get_setting": get_setting,
            "set_setting": set_setting,
            "get_bool_setting": get_bool_setting,
        }
    except Exception:
        return None


def _arm_auto_repick_watchdog():
    """Marca una ventana corta de arranque; si no inicia vídeo, service ofrecerá repick."""
    try:
        w = xbmcgui.Window(10000)
        w.setProperty("Kraken.PendingPlaybackStart", "1")
        w.setProperty("Kraken.PendingPlaybackTs", str(time.time()))
    except Exception:
        pass


def _source_search_background(get_setting):
    try:
        raw = str(get_setting("source_search_style") or "").strip().lower()
    except Exception:
        return False
    return "background" in raw or "segundo" in raw


def _create_source_progress(get_setting, heading, message):
    dialog_cls = xbmcgui.DialogProgressBG if _source_search_background(get_setting) else xbmcgui.DialogProgress
    dialog = dialog_cls()
    dialog.create(heading, message)
    return dialog


def _playable_listitem(path, http_headers_extra=None):
    p = str(path or "").strip()
    li = xbmcgui.ListItem(path=p)
    try:
        li.setContentLookup(False)
    except Exception:
        pass
    configure_listitem_stream_properties(li, p, http_headers_extra=http_headers_extra)
    return li


def _unpack_resolve_stream(resolved):
    """resolve() puede devolver str o dict {url, http_headers} (Stremio)."""
    if isinstance(resolved, dict):
        return (str(resolved.get("url") or "").strip(), resolved.get("http_headers"))
    return (str(resolved or "").strip(), None)


def _is_unrouted_torrent_url(url):
    raw = str(url or "").strip()
    if not raw:
        return False
    low = raw.lower()
    if raw.startswith("plugin://"):
        return False
    if raw.startswith("magnet:"):
        return True
    return low.endswith(".torrent") or ".torrent?" in low


def _set_playback_context_for_trakt_result(result_id):
    rid = str(result_id or "").strip()
    if not rid.startswith("trakt::"):
        return
    parts = rid.split("::")
    if len(parts) < 3:
        return
    media_type = str(parts[1] or "").strip().lower()
    trakt_id = str(parts[2] or "").strip()
    if media_type not in ("movie", "movies") or not trakt_id:
        return
    try:
        w = xbmcgui.Window(10000)
        w.setProperty(
            "Kraken.Playing",
            f'{{"kind":"movie","trakt_id":"{trakt_id}"}}',
        )
        w.clearProperty("Kraken.TraktSynced")
        w.clearProperty("Kraken.TraktCollectionSent")
        w.clearProperty("Kraken.LastProgressPct")
        for p in (
            "Kraken.TraktScrobbleLast.start",
            "Kraken.TraktScrobbleLast.pause",
            "Kraken.TraktScrobbleLast.stop",
        ):
            w.clearProperty(p)
    except Exception:
        pass


def _trakt_movie_id_from_fallback_search(title, year, trakt_public_get):
    """Resuelve id numérico Trakt para película (búsqueda pública por título/año)."""
    if not callable(trakt_public_get):
        return ""
    qt = quote(str(title or "").strip(), safe="")
    if len(qt) < 2:
        return ""
    url = "https://api.trakt.tv/search/movie?query={}&limit=15".format(qt)
    try:
        rows = trakt_public_get(url)
    except Exception:
        return ""
    if not isinstance(rows, list) or not rows:
        return ""
    want_y = None
    try:
        if year is not None and str(year).strip().isdigit():
            want_y = int(year)
    except (TypeError, ValueError):
        want_y = None
    best_tid = ""
    best_score = -999
    first_tid = ""
    for row in rows:
        if str(row.get("type") or "") != "movie":
            continue
        m = row.get("movie") or {}
        mids = (m.get("ids") or {})
        tid = mids.get("trakt")
        if tid is None:
            continue
        stid = str(tid).strip()
        if not stid:
            continue
        if not first_tid:
            first_tid = stid
        try:
            my = int(m.get("year") or 0)
        except (TypeError, ValueError):
            my = 0
        score = 50
        if want_y is not None and my == want_y:
            score += 200
        elif want_y is not None and my:
            score -= min(120, abs(my - want_y) * 40)
        if score > best_score:
            best_score = score
            best_tid = stid
    if best_tid and best_score > 10:
        return best_tid
    return first_tid


def _bind_fallback_movie_to_trakt_playing(title, year, trakt_public_get):
    """Vincula Película respaldo (TMDb) a colección/scrobble Trakt mediante búsqueda."""
    tid = _trakt_movie_id_from_fallback_search(title, year, trakt_public_get)
    if not tid:
        return
    try:
        w = xbmcgui.Window(10000)
        w.setProperty(
            "Kraken.Playing",
            json.dumps({"kind": "movie", "trakt_id": str(tid)}),
        )
        w.clearProperty("Kraken.TraktSynced")
        w.clearProperty("Kraken.TraktCollectionSent")
        w.clearProperty("Kraken.LastProgressPct")
        for p in (
            "Kraken.TraktScrobbleLast.start",
            "Kraken.TraktScrobbleLast.pause",
            "Kraken.TraktScrobbleLast.stop",
        ):
            w.clearProperty(p)
    except Exception:
        pass


def run_play(
    *,
    plugin_handle,
    result_id_path,
    play_result_id_from_request,
    kraken_progress,
    resolver_progress_phase,
    resolver_progress_detail,
    resolve_trakt_result,
    pick_stream_dialog,
    finalize_playback_stream_url,
    get_enabled_providers,
    is_playable_stream_url,
    resolve_fallback_candidates=None,
    trakt_public_get=None,
    get_setting=None,
    set_setting=None,
    get_bool_setting=None,
):
    try:
        rid = play_result_id_from_request(result_id_path)

        if not rid:
            xbmc.log(
                "[Kraken] play: sin result_id (path ni query result_id)", xbmc.LOGWARNING
            )
            xbmcgui.Dialog().ok(
                "Kraken",
                _t(
                    "Falta el id del título. Vuelve a abrirlo desde el listado; si persiste, reporta Tvvoo/Stremio.",
                    "Missing title id. Open it again from listing; if it persists, report Tvvoo/Stremio.",
                    "L'identifiant du titre est manquant. Ouvre-le à nouveau depuis la liste ; si le problème persiste, signale Tvvoo/Stremio.",
                    "Manca l'ID del titolo. Aprilo di nuovo dalla lista; se persiste, segnala Tvvoo/Stremio.",
                    "Titel-ID fehlt. Öffne ihn erneut aus der Liste; wenn es weiter auftritt, melde Tvvoo/Stremio.",
                ),
            )
            xbmcplugin.setResolvedUrl(plugin_handle, False, xbmcgui.ListItem())
            return

        if rid.startswith("trakt::"):
            dialog = _create_source_progress(
                get_setting,
                _t(
                    "Kraken - Resolver",
                    "Kraken - Resolver",
                    "Kraken - Resolution",
                    "Kraken - Risolutore",
                    "Kraken - Auflösung",
                ),
                _t(
                    "Resolviendo fuentes",
                    "Resolving sources",
                    "Resolution des sources",
                    "Risoluzione delle fonti",
                    "Quellen werden aufgelöst",
                ),
            )
            started_at = time.time()

            def _progress_cb(percent, phase, detail):
                kraken_progress(dialog, percent, phase, detail)

            try:
                kraken_progress(
                    dialog,
                    5,
                    resolver_progress_phase,
                    resolver_progress_detail(
                        _t("Inicio", "Start", "Démarrage", "Avvio", "Start"),
                        [],
                        None,
                        started_at,
                    ),
                )
                candidates = (
                    resolve_trakt_result(
                        rid,
                        collect_sources=True,
                        progress_cb=_progress_cb,
                        progress_started_at=started_at,
                    )
                    or []
                )
                xbmc.log(
                    f"[Kraken] Candidatas pelicula: {len(candidates)}", xbmc.LOGINFO
                )
                kraken_progress(
                    dialog,
                    100,
                    resolver_progress_phase,
                    resolver_progress_detail(
                        _t("Listo", "Done", "Terminé", "Fatto", "Fertig"),
                        candidates,
                        None,
                        started_at,
                    ),
                )
            finally:
                dialog.close()
            stash_source_candidates(
                candidates,
                _t("Película (Trakt)", "Movie (Trakt)", "Film (Trakt)", "Film (Trakt)", "Film (Trakt)"),
            )
            play_kind = "movie"
            p = [x.strip() for x in str(rid).split("::") if str(x).strip()]
            if len(p) >= 2 and str(p[1]).lower() in ("show", "series", "tv"):
                play_kind = "episode"
            try:
                w = xbmcgui.Window(10000)
                w.setProperty("Kraken.LastPlaybackKind", play_kind)
                if play_kind != "episode":
                    w.clearProperty("Kraken.PlaybackSeason")
                    w.clearProperty("Kraken.PlaybackEpisode")
                    w.clearProperty("Kraken.PlaybackEpisodeTitle")
            except Exception:
                pass
            stream_url = pick_stream_dialog(
                _t(
                    "Kraken - Selecciona fuente",
                    "Kraken - Select source",
                    "Kraken - Sélectionner une source",
                    "Kraken - Seleziona fonte",
                    "Kraken - Quelle wählen",
                ),
                candidates,
                playback_kind=play_kind,
                rotation=_build_source_rotation(
                    rid, get_setting, set_setting, get_bool_setting
                ),
            )
            if stream_url is None:
                xbmcplugin.setResolvedUrl(plugin_handle, False, xbmcgui.ListItem())
                return
            if stream_url:
                stream_url = finalize_playback_stream_url(
                    stream_url,
                    playback_context={"kind": play_kind},
                )
            if not stream_url:
                xbmcgui.Dialog().ok(
                    "Kraken",
                    _t(
                        "No se encontró stream para este título de Trakt.\n\n"
                        "- Revisa que tengas al menos un complemento Stremio activo.\n"
                        "- Si devuelve magnet/.torrent, configura el cliente torrent en Kraken - Torrent.\n"
                        "- Si usas Debrid, verifica token y proveedor.",
                        "No stream was found for this Trakt title.\n\n"
                        "- Check that at least one Stremio addon is active.\n"
                        "- If it returns magnet/.torrent, set up your torrent client under Kraken - Torrent.\n"
                        "- If you use Debrid, verify token and provider.",
                        "Aucun flux trouvé pour ce titre Trakt.\n\n"
                        "- Vérifie qu'au moins un add-on Stremio est actif.\n"
                        "- S'il renvoie magnet/.torrent, configure ton client torrent (Kraken - Torrent).\n"
                        "- Si tu utilises Debrid, vérifie le jeton et le fournisseur.",
                        "Nessuno stream trovato per questo titolo Trakt.\n\n"
                        "- Controlla che sia attivo almeno un add-on Stremio.\n"
                        "- Se restituisce magnet/.torrent, configura il client torrent (Kraken - Torrent).\n"
                        "- Se usi Debrid, verifica token e provider.",
                        "Kein Stream für diesen Trakt-Titel gefunden.\n\n"
                        "- Prüfe, dass mindestens ein Stremio-Add-on aktiv ist.\n"
                        "- Wenn magnet/.torrent zurückgegeben wird: Torrent-Client in Kraken - Torrent einrichten.\n"
                        "- Bei Debrid Token und Anbieter prüfen.",
                    ),
                )
                xbmcplugin.setResolvedUrl(plugin_handle, False, xbmcgui.ListItem())
                return
            if _is_unrouted_torrent_url(stream_url):
                xbmcgui.Dialog().ok(
                    "Kraken",
                    _t(
                        "La fuente seleccionada es torrent/magnet y no hay cliente torrent activo ni Debrid resolviendo.\n\nConfigura tu cliente torrent en Kraken - Torrent o conecta Debrid.",
                        "Selected source is torrent/magnet and no active torrent client or Debrid resolving is available.\n\nSet up your torrent client in Kraken - Torrent or connect Debrid.",
                        "La source sélectionnée est torrent/magnet et aucun client torrent actif ni résolution Debrid n'est disponible.\n\nConfigure ton client torrent (Kraken - Torrent) ou connecte Debrid.",
                        "La fonte selezionata è torrent/magnet e non c'è un client torrent attivo né risoluzione Debrid.\n\nConfigura il client torrent (Kraken - Torrent) o collega Debrid.",
                        "Die gewählte Quelle ist Torrent/Magnet und es gibt keinen aktiven Torrent-Client bzw. keine Debrid-Auflösung.\n\nRichte einen Torrent-Client unter Kraken - Torrent ein oder verbinde Debrid.",
                    ),
                )
                xbmcplugin.setResolvedUrl(plugin_handle, False, xbmcgui.ListItem())
                return
            _arm_auto_repick_watchdog()
            try:
                w = xbmcgui.Window(10000)
                w.setProperty("Kraken.LastPlaybackAttemptUrl", str(stream_url))
                w.clearProperty("Kraken.FallbackTriedUrls")
                w.clearProperty("Kraken.FallbackAutoAttempts")
                _set_playback_context_for_trakt_result(rid)
            except Exception:
                pass
            li = _playable_listitem(stream_url)
            xbmcplugin.setResolvedUrl(plugin_handle, True, li)
            return

        if rid.startswith("fallback::movie::") and resolve_fallback_candidates:
            parts = rid.split("::", 3)
            if len(parts) == 4:
                try:
                    year = int(parts[2]) if str(parts[2]).isdigit() else None
                except (TypeError, ValueError):
                    year = None
                title = unquote(parts[3] or "").strip()
                dialog_fb = _create_source_progress(
                    get_setting,
                    _t(
                        "Kraken - Resolver",
                        "Kraken - Resolver",
                        "Kraken - Resolution",
                        "Kraken - Risolutore",
                        "Kraken - Auflösung",
                    ),
                    _t(
                        "Resolviendo fuentes",
                        "Resolving sources",
                        "Resolution des sources",
                        "Risoluzione delle fonti",
                        "Quellen werden aufgelöst",
                    ),
                )
                fb_started_at = time.time()

                def _fb_progress_cb(percent, phase, detail):
                    kraken_progress(dialog_fb, percent, phase, detail)

                try:
                    kraken_progress(
                        dialog_fb,
                        5,
                        resolver_progress_phase,
                        resolver_progress_detail(
                            _t("Inicio (respaldo)", "Start (fallback)", "Début (secours)", "Avvio (fallback)", "Start (Fallback)"),
                            [],
                            [],
                            fb_started_at,
                        ),
                    )
                    candidates = (
                        resolve_fallback_candidates(
                            title,
                            year,
                            "movie",
                            progress_cb=_fb_progress_cb,
                            progress_started_at=fb_started_at,
                        )
                        or []
                    )
                    kraken_progress(
                        dialog_fb,
                        100,
                        resolver_progress_phase,
                        resolver_progress_detail(
                            _t(
                                "Listo (respaldo)",
                                "Done (fallback)",
                                "Terminé (secours)",
                                "Fatto (fallback)",
                                "Fertig (Fallback)",
                            ),
                            candidates,
                            None,
                            fb_started_at,
                        ),
                    )
                finally:
                    dialog_fb.close()
                stash_source_candidates(
                    candidates,
                    _t("Película (respaldo)", "Movie (fallback)", "Film (secours)", "Film (fallback)", "Film (Fallback)"),
                )
                try:
                    w = xbmcgui.Window(10000)
                    w.setProperty("Kraken.LastPlaybackKind", "movie")
                    w.clearProperty("Kraken.PlaybackSeason")
                    w.clearProperty("Kraken.PlaybackEpisode")
                    w.clearProperty("Kraken.PlaybackEpisodeTitle")
                except Exception:
                    pass
                stream_url = pick_stream_dialog(
                    _t(
                        "Kraken - Selecciona fuente",
                        "Kraken - Select source",
                        "Kraken - Sélectionner une source",
                        "Kraken - Seleziona fonte",
                        "Kraken - Quelle wählen",
                    ),
                    candidates,
                    playback_kind="movie",
                    rotation=_build_source_rotation(
                        rid, get_setting, set_setting, get_bool_setting
                    ),
                )
                if stream_url is None:
                    xbmcplugin.setResolvedUrl(plugin_handle, False, xbmcgui.ListItem())
                    return
                if stream_url:
                    if trakt_public_get:
                        _bind_fallback_movie_to_trakt_playing(
                            title, year, trakt_public_get
                        )
                    stream_url = finalize_playback_stream_url(
                        stream_url,
                        playback_context={"kind": "movie"},
                    )
                    if _is_unrouted_torrent_url(stream_url):
                        xbmcgui.Dialog().ok(
                            "Kraken",
                            _t(
                                "La fuente seleccionada es torrent/magnet y no hay cliente torrent activo ni Debrid resolviendo.\n\nConfigura tu cliente torrent en Kraken - Torrent o conecta Debrid.",
                                "Selected source is torrent/magnet and no active torrent client or Debrid resolving is available.\n\nSet up your torrent client in Kraken - Torrent or connect Debrid.",
                                "La source sélectionnée est torrent/magnet et aucun client torrent actif ni résolution Debrid n'est disponible.\n\nConfigure ton client torrent (Kraken - Torrent) ou connecte Debrid.",
                                "La fonte selezionata è torrent/magnet e non c'è un client torrent attivo né risoluzione Debrid.\n\nConfigura il client torrent (Kraken - Torrent) o collega Debrid.",
                                "Die gewählte Quelle ist Torrent/Magnet und es gibt keinen aktiven Torrent-Client bzw. keine Debrid-Auflösung.\n\nRichte einen Torrent-Client unter Kraken - Torrent ein oder verbinde Debrid.",
                            ),
                        )
                        xbmcplugin.setResolvedUrl(
                            plugin_handle, False, xbmcgui.ListItem()
                        )
                        return
                    _arm_auto_repick_watchdog()
                    try:
                        w = xbmcgui.Window(10000)
                        w.setProperty("Kraken.LastPlaybackAttemptUrl", str(stream_url))
                        w.clearProperty("Kraken.FallbackTriedUrls")
                        w.clearProperty("Kraken.FallbackAutoAttempts")
                    except Exception:
                        pass
                    li = _playable_listitem(stream_url)
                    xbmcplugin.setResolvedUrl(plugin_handle, True, li)
                    return
                xbmcgui.Dialog().ok(
                    "Kraken",
                    _t(
                        "No se encontró stream para este resultado fallback (TMDb/OMDb).",
                        "No stream found for this fallback result (TMDb/OMDb).",
                        "Aucun stream trouvé pour ce résultat de secours (TMDb/OMDb).",
                        "Nessuno stream trovato per questo risultato fallback (TMDb/OMDb).",
                        "Kein Stream für dieses Fallback-Ergebnis (TMDb/OMDb) gefunden.",
                    ),
                )
                xbmcplugin.setResolvedUrl(plugin_handle, False, xbmcgui.ListItem())
                return

        if rid.startswith("fallback::show::") and resolve_fallback_candidates:
            parts = rid.split("::", 3)
            if len(parts) == 4:
                try:
                    year = int(parts[2]) if str(parts[2]).isdigit() else None
                except (TypeError, ValueError):
                    year = None
                title = unquote(parts[3] or "").strip()
                dialog_fb = xbmcgui.DialogProgress()
                dialog_fb.create(
                    _t(
                        "Kraken - Resolver",
                        "Kraken - Resolver",
                        "Kraken - Resolution",
                        "Kraken - Risolutore",
                        "Kraken - Auflösung",
                    ),
                    _t(
                        "Resolviendo fuentes",
                        "Resolving sources",
                        "Resolution des sources",
                        "Risoluzione delle fonti",
                        "Quellen werden aufgelöst",
                    ),
                )
                fb_started_at = time.time()

                def _fb_progress_cb(percent, phase, detail):
                    kraken_progress(dialog_fb, percent, phase, detail)

                try:
                    kraken_progress(
                        dialog_fb,
                        5,
                        resolver_progress_phase,
                        resolver_progress_detail(
                            _t("Inicio (respaldo)", "Start (fallback)", "Début (secours)", "Avvio (fallback)", "Start (Fallback)"),
                            [],
                            [],
                            fb_started_at,
                        ),
                    )
                    candidates = (
                        resolve_fallback_candidates(
                            title,
                            year,
                            "series",
                            progress_cb=_fb_progress_cb,
                            progress_started_at=fb_started_at,
                        )
                        or []
                    )
                    kraken_progress(
                        dialog_fb,
                        100,
                        resolver_progress_phase,
                        resolver_progress_detail(
                            _t(
                                "Listo (respaldo)",
                                "Done (fallback)",
                                "Terminé (secours)",
                                "Fatto (fallback)",
                                "Fertig (Fallback)",
                            ),
                            candidates,
                            None,
                            fb_started_at,
                        ),
                    )
                finally:
                    dialog_fb.close()
                stash_source_candidates(
                    candidates,
                    _t("Serie (respaldo)", "TV show (fallback)", "Serie (secours)", "Serie TV (fallback)", "Serie (Fallback)"),
                )
                try:
                    w = xbmcgui.Window(10000)
                    w.setProperty("Kraken.LastPlaybackKind", "episode")
                    w.clearProperty("Kraken.PlaybackSeason")
                    w.clearProperty("Kraken.PlaybackEpisode")
                    w.clearProperty("Kraken.PlaybackEpisodeTitle")
                except Exception:
                    pass
                stream_url = pick_stream_dialog(
                    _t(
                        "Kraken - Selecciona fuente",
                        "Kraken - Select source",
                        "Kraken - Sélectionner une source",
                        "Kraken - Seleziona fonte",
                        "Kraken - Quelle wählen",
                    ),
                    candidates,
                    playback_kind="episode",
                    rotation=_build_source_rotation(
                        rid, get_setting, set_setting, get_bool_setting
                    ),
                )
                if stream_url is None:
                    xbmcplugin.setResolvedUrl(plugin_handle, False, xbmcgui.ListItem())
                    return
                if stream_url:
                    stream_url = finalize_playback_stream_url(stream_url)
                    if _is_unrouted_torrent_url(stream_url):
                        xbmcgui.Dialog().ok(
                            "Kraken",
                            _t(
                                "La fuente seleccionada es torrent/magnet y no hay cliente torrent activo ni Debrid resolviendo.\n\nConfigura tu cliente torrent en Kraken - Torrent o conecta Debrid.",
                                "Selected source is torrent/magnet and no active torrent client or Debrid resolving is available.\n\nSet up your torrent client in Kraken - Torrent or connect Debrid.",
                                "La source sélectionnée est torrent/magnet et aucun client torrent actif ni résolution Debrid n'est disponible.\n\nConfigure ton client torrent (Kraken - Torrent) ou connecte Debrid.",
                                "La fonte selezionata è torrent/magnet e non c'è un client torrent attivo né risoluzione Debrid.\n\nConfigura il client torrent (Kraken - Torrent) o collega Debrid.",
                                "Die gewählte Quelle ist Torrent/Magnet und es gibt keinen aktiven Torrent-Client bzw. keine Debrid-Auflösung.\n\nRichte einen Torrent-Client unter Kraken - Torrent ein oder verbinde Debrid.",
                            ),
                        )
                        xbmcplugin.setResolvedUrl(
                            plugin_handle, False, xbmcgui.ListItem()
                        )
                        return
                    _arm_auto_repick_watchdog()
                    try:
                        w = xbmcgui.Window(10000)
                        w.setProperty("Kraken.LastPlaybackAttemptUrl", str(stream_url))
                        w.clearProperty("Kraken.FallbackTriedUrls")
                        w.clearProperty("Kraken.FallbackAutoAttempts")
                    except Exception:
                        pass
                    li = _playable_listitem(stream_url)
                    xbmcplugin.setResolvedUrl(plugin_handle, True, li)
                    return
            xbmcgui.Dialog().ok(
                "Kraken",
                _t(
                    "No se encontró stream para este resultado fallback de serie.",
                    "No stream found for this fallback TV show result.",
                    "Aucun stream trouvé pour ce résultat de secours de série.",
                    "Nessuno stream trovato per questo risultato fallback serie TV.",
                    "Kein Stream für dieses Fallback-Serienergebnis gefunden.",
                ),
            )
            xbmcplugin.setResolvedUrl(plugin_handle, False, xbmcgui.ListItem())
            return

        providers = get_enabled_providers()
        for provider in providers:
            raw_res = provider.resolve(rid)
            stream_url, stremio_hdr = _unpack_resolve_stream(raw_res)
            if stream_url and is_playable_stream_url(stream_url):
                stream_url = finalize_playback_stream_url(stream_url)
                if _is_unrouted_torrent_url(stream_url):
                    xbmcgui.Dialog().ok(
                        "Kraken",
                        _t(
                            "La fuente seleccionada es torrent/magnet y no hay cliente torrent activo ni Debrid resolviendo.\n\nConfigura tu cliente torrent en Kraken - Torrent o conecta Debrid.",
                            "Selected source is torrent/magnet and no active torrent client or Debrid resolving is available.\n\nSet up your torrent client in Kraken - Torrent or connect Debrid.",
                            "La source sélectionnée est torrent/magnet et aucun client torrent actif ni résolution Debrid n'est disponible.\n\nConfigure ton client torrent (Kraken - Torrent) ou connecte Debrid.",
                            "La fonte selezionata è torrent/magnet e non c'è un client torrent attivo né risoluzione Debrid disponibile.\n\nConfigura il client torrent (Kraken - Torrent) o collega Debrid.",
                            "Die ausgewählte Quelle ist Torrent/Magnet und es ist kein aktiver Torrent-Client oder Debrid-Auflösung verfügbar.\n\nRichte einen Torrent-Client unter Kraken - Torrent ein oder verbinde Debrid.",
                        ),
                    )
                    xbmcplugin.setResolvedUrl(plugin_handle, False, xbmcgui.ListItem())
                    return
                _arm_auto_repick_watchdog()
                try:
                    w = xbmcgui.Window(10000)
                    w.setProperty("Kraken.LastPlaybackAttemptUrl", str(stream_url))
                    w.clearProperty("Kraken.FallbackTriedUrls")
                    w.clearProperty("Kraken.FallbackAutoAttempts")
                except Exception:
                    pass
                li = _playable_listitem(stream_url, http_headers_extra=stremio_hdr)
                xbmcplugin.setResolvedUrl(plugin_handle, True, li)
                return

        hint = _t(
            "No hay URL de reproducción para este resultado.\n\n"
            "- Resultados Stremio: el complemento debe devolver enlaces http(s), magnet o infoHash en /stream/.\n"
            "- En Kraken - Torrent puedes dirigir magnet y .torrent al cliente configurado.\n"
            "- Trakt solo lista títulos; activa Stremio y un catálogo con enlaces por título.",
            "No playback URL available for this result.\n\n"
            "- Stremio results: addon must return http(s), magnet or infoHash links in /stream/.\n"
            "- In Kraken - Torrent you can route magnet and .torrent to your configured client.\n"
            "- Trakt only lists titles; enable Stremio and a catalog with title links.",
            "Aucune URL de lecture disponible pour ce résultat.\n\n"
            "- Résultats Stremio : l'addon doit renvoyer des liens http(s), magnet ou infoHash dans /stream/.\n"
            "- Dans Kraken - Torrent : envoyer magnet/.torrent au client configuré.\n"
            "- Trakt ne liste que les titres ; active Stremio et un catalogue avec des liens par titre.",
            "Nessun URL di riproduzione disponibile per questo risultato.\n\n"
            "- Risultati Stremio: l'addon deve restituire link http(s), magnet o infoHash in /stream/.\n"
            "- Con Kraken - Torrent puoi indirizzare magnet e .torrent al client configurato.\n"
            "- Trakt elenca solo titoli; attiva Stremio e un catalogo con link per titolo.",
            "Keine Wiedergabe-URL für dieses Ergebnis verfügbar.\n\n"
            "- Stremio-Ergebnisse: Addon muss http(s)-, Magnet- oder infoHash-Links in /stream/ zurückgeben.\n"
            "- In Kraken - Torrent kannst du Magnet und .torrent an den eingestellten Client senden.\n"
            "- Trakt listet nur Titel; aktiviere Stremio und einen Katalog mit Titellinks.",
        )
        xbmcgui.Dialog().ok("Kraken", hint)
        xbmcplugin.setResolvedUrl(plugin_handle, False, xbmcgui.ListItem())
    except Exception as ex:
        xbmc.log(f"[Kraken] Exception in run_play: {ex}", xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(plugin_handle, False, xbmcgui.ListItem())
