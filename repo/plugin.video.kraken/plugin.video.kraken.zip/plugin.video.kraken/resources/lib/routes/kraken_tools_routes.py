import os

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib.maintenance.kraken_cache_maintenance import (
    addon_cache_root_bytes,
    clear_logo_disk_cache,
    clear_omdb_metadata_file,
    clear_search_ram_cache,
    clear_stremio_session_cache,
    clear_subtitle_disk_cache,
)

_PROFILE_LABEL_IDS = {
    "home": 30451,
    "movies": 30452,
    "tvshows": 30453,
    "mixed": 30454,
}

_SETTING_BY_PROFILE = {
    "home": "kraken_view_mode_home",
    "movies": "kraken_view_mode_movies",
    "tvshows": "kraken_view_mode_tvshows",
    "mixed": "kraken_view_mode_mixed",
}

_PROFILE_ORDER = ("home", "movies", "tvshows", "mixed")

_VIEW_MODE_LABEL_IDS = (
    (0, 30502),
    (50, 30503),
    (51, 30504),
    (500, 30505),
    (504, 30506),
    (503, 30507),
    (508, 30508),
    (513, 30509),
    (53, 30522),
    (54, 30523),
    (55, 30524),
    (520, 30525),
    (501, 30526),
    (502, 30527),
)


def run_kraken_tools_hub(
    *,
    plugin_handle,
    addon,
    url_for_views_menu,
    url_for_open_kodi_addon_settings,
    url_for_maintenance_menu,
    url_for_show_changelog,
    url_for_tail_log,
    default_list_art,
):
    title = "{} — {}".format(
        addon.getAddonInfo("name") or "Kraken", addon.getLocalizedString(30440)
    )
    xbmcplugin.setPluginCategory(plugin_handle, title)
    xbmcplugin.setContent(plugin_handle, "files")
    base_art = default_list_art()
    items = []

    def _mk(url, headline_id, blurb_id):
        li = xbmcgui.ListItem(
            addon.getLocalizedString(headline_id),
            addon.getLocalizedString(blurb_id),
        )
        li.setInfo(
            "video",
            {
                "title": li.getLabel(),
                "plot": addon.getLocalizedString(blurb_id),
                "mediatype": "video",
            },
        )
        li.setArt(dict(base_art or {}))
        items.append((url, li, True))

    _mk(url_for_views_menu(), 30443, 30444)
    _mk(url_for_open_kodi_addon_settings(), 30517, 30518)
    _mk(url_for_maintenance_menu(), 30460, 30461)
    _mk(url_for_show_changelog(), 30477, 30478)
    _mk(url_for_tail_log(), 30475, 30476)
    xbmcplugin.addDirectoryItems(plugin_handle, items, len(items))
    xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)


def run_kraken_open_kodi_addon_settings(*, addon_id, addon, icon_path_fn):
    name = addon.getAddonInfo("name") or "Kraken"
    aid = str(addon_id or "").strip()
    if not aid:
        xbmcgui.Dialog().ok(name, addon.getLocalizedString(30511))
        return
    try:
        xbmc.executebuiltin("Addon.OpenSettings({})".format(aid))
    except Exception:
        xbmcgui.Dialog().ok(name, addon.getLocalizedString(30511))


def run_kraken_views_menu(
    *,
    plugin_handle,
    addon,
    url_for_pick_profile_fn,
    default_list_art,
):
    title = "{} — {}".format(
        addon.getAddonInfo("name") or "Kraken", addon.getLocalizedString(30443)
    )
    xbmcplugin.setPluginCategory(plugin_handle, title)
    xbmcplugin.setContent(plugin_handle, "files")
    base_art = default_list_art()
    items = []
    note = addon.getLocalizedString(30496)
    for slug in _PROFILE_ORDER:
        li_head = addon.getLocalizedString(_PROFILE_LABEL_IDS[slug])
        li = xbmcgui.ListItem(li_head, note)
        blurb = "{}\n\n{}".format(
            addon.getLocalizedString(30445),
            addon.getLocalizedString(30496),
        )
        li.setInfo(
            "video",
            {
                "title": li_head,
                "plot": blurb,
                "mediatype": "video",
            },
        )
        li.setArt(dict(base_art or {}))
        items.append((url_for_pick_profile_fn(slug), li, True))
    xbmcplugin.addDirectoryItems(plugin_handle, items, len(items))
    xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)


def run_kraken_views_pick_profile(
    *,
    profile_slug,
    addon,
    get_setting,
    set_setting,
    icon_path_fn,
):
    slug = str(profile_slug or "").strip().lower()
    sid = _SETTING_BY_PROFILE.get(slug)
    if not sid:
        xbmcgui.Dialog().notification(addon.getAddonInfo("name") or "Kraken", "?", icon_path_fn())
        return
    labels = [addon.getLocalizedString(lbl) for _vid, lbl in _VIEW_MODE_LABEL_IDS]
    current_s = ""
    try:
        current_s = str(get_setting(sid) or "").strip()
    except Exception:
        current_s = ""
    preset_index = 0
    for idx, pair in enumerate(_VIEW_MODE_LABEL_IDS):
        if str(pair[0]) == current_s:
            preset_index = idx
            break
    pre = addon.getLocalizedString(30501)
    title = "{} — {}".format(addon.getLocalizedString(_PROFILE_LABEL_IDS[slug]), pre)
    try:
        pick = xbmcgui.Dialog().select(title, labels, preselect=preset_index)
    except TypeError:
        pick = xbmcgui.Dialog().select(title, labels)
    if pick < 0:
        return
    vid_s = str(_VIEW_MODE_LABEL_IDS[pick][0])
    try:
        set_setting(sid, vid_s)
        xbmcgui.Dialog().notification(
            addon.getAddonInfo("name") or "Kraken",
            "{}: {}".format(addon.getLocalizedString(30500), labels[pick]),
            icon_path_fn(),
            time=2800,
        )
    except Exception as ex:
        xbmcgui.Dialog().ok(addon.getAddonInfo("name") or "Kraken", str(ex))


def _profile_hint_bytes(profile_path_translate):
    try:
        base = xbmcvfs.translatePath(profile_path_translate or "")
        if base:
            b = addon_cache_root_bytes(base)
            return b / (1024.0 * 1024.0)
    except Exception:
        pass
    return 0.0


def run_kraken_maintenance_menu(
    *,
    plugin_handle,
    addon,
    url_library_clean,
    url_library_scan,
    url_clear_omdb,
    url_clear_ram,
    url_clear_stremio,
    url_clear_logos,
    url_clear_subtitles,
    url_clear_all,
    profile_path_translate,
    default_list_art,
):
    title = "{} — {}".format(
        addon.getAddonInfo("name") or "Kraken", addon.getLocalizedString(30460)
    )
    xbmcplugin.setPluginCategory(plugin_handle, title)
    xbmcplugin.setContent(plugin_handle, "files")
    mb = _profile_hint_bytes(profile_path_translate)
    label2_mb = "{} ~{:,.2f} MB".format(addon.getLocalizedString(30710), mb) if mb > 0 else ""
    pairs = (
        (url_clear_omdb(), 30801, 30802),
        (url_clear_ram(), 30803, 30804),
        (url_clear_stremio(), 30805, 30806),
        (url_clear_logos(), 30807, 30808),
        (url_clear_subtitles(), 30824, 30825),
        (url_library_clean(), 30820, 30821),
        (url_library_scan(), 30822, 30823),
        (url_clear_all(), 30809, 30810),
    )
    base_art = default_list_art()
    items = []
    for url, head_id, blurb_id in pairs:
        li = xbmcgui.ListItem(addon.getLocalizedString(head_id), label2_mb)
        li.setInfo(
            "video",
            {
                "title": addon.getLocalizedString(head_id),
                "plot": addon.getLocalizedString(blurb_id),
                "mediatype": "video",
            },
        )
        li.setArt(dict(base_art or {}))
        items.append((url, li, True))
    xbmcplugin.addDirectoryItems(plugin_handle, items, len(items))
    xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)


def run_kraken_maintenance_confirm_and_run(
    *,
    action,
    addon,
    omdb_clear_fn,
    logos_clear_fn,
    stremio_clear_fn,
    ram_clear_fn,
    subtitle_clear_fn,
    icon_path_fn,
):
    name = addon.getAddonInfo("name") or "Kraken"
    act = str(action or "").strip().lower()
    confirm_by_action = {
        "omdb": 30473,
        "ram": 30473,
        "stremio": 30473,
        "logos": 30473,
        "subtitles": 30473,
        "all": 30811,
    }
    yid = confirm_by_action.get(act)
    if yid is None:
        return
    if not xbmcgui.Dialog().yesno(name, addon.getLocalizedString(yid)):
        return
    try:
        if act == "omdb":
            ok, err = clear_omdb_metadata_file(addon, omdb_clear_fn)
            summary = addon.getLocalizedString(30512 if ok else 30511)
            tail = "\n{}".format(err.strip()) if (err or "").strip() else ""
        elif act == "ram":
            ok, err = clear_search_ram_cache(ram_clear_fn)
            summary = addon.getLocalizedString(30513 if ok else 30511)
            tail = "\n{}".format(err.strip()) if (err or "").strip() else ""
        elif act == "stremio":
            ok, err = clear_stremio_session_cache(stremio_clear_fn)
            summary = addon.getLocalizedString(30514 if ok else 30511)
            tail = "\n{}".format(err.strip()) if (err or "").strip() else ""
        elif act == "logos":
            ok, cnt = clear_logo_disk_cache(logos_clear_fn)
            summary = addon.getLocalizedString(30515 if ok else 30511)
            tail = "\n{}".format(cnt) if ok else ""
        elif act == "subtitles":
            ok, cnt = clear_subtitle_disk_cache(
                addon.getAddonInfo("profile"), subtitle_clear_fn
            )
            summary = addon.getLocalizedString(30519 if ok else 30511)
            tail = "\n{}".format(cnt) if ok else ""
        elif act == "all":
            lines = []
            ok_o, er_o = clear_omdb_metadata_file(addon, omdb_clear_fn)
            lines.append("{} OMDb {}".format(ok_o, er_o.strip() if er_o else ""))
            ok_r, er_r = clear_search_ram_cache(ram_clear_fn)
            lines.append("{} RAM {}".format(ok_r, er_r.strip() if er_r else ""))
            ok_s, er_s = clear_stremio_session_cache(stremio_clear_fn)
            lines.append("{} Stremio {}".format(ok_s, er_s.strip() if er_s else ""))
            ok_l, n_l = clear_logo_disk_cache(logos_clear_fn)
            lines.append("{} logos {}".format(ok_l, n_l))
            ok_sub, n_sub = clear_subtitle_disk_cache(
                addon.getAddonInfo("profile"), subtitle_clear_fn
            )
            lines.append("{} subtitles {}".format(ok_sub, n_sub))
            summary = addon.getLocalizedString(30516)
            tail = "\n" + "\n".join(lines)
        else:
            return
        xbmcgui.Dialog().ok(name, "{}{}".format(summary, tail))
        xbmcgui.Dialog().notification(
            name, summary.replace("\n", " "), icon_path_fn(), time=3200
        )
    except Exception as ex:
        msg = "{}: {}".format(addon.getLocalizedString(30511), ex)
        xbmcgui.Dialog().ok(name, msg)
        xbmcgui.Dialog().notification(
            name, msg, icon_path_fn(), xbmcgui.NOTIFICATION_ERROR
        )


def noop_end_directory(plugin_handle):
    xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)


def run_kraken_kodi_library_action(*, action, addon, icon_path_fn):
    act = str(action or "").strip().lower()
    name = addon.getAddonInfo("name") or "Kraken"
    if act == "clean":
        if not xbmcgui.Dialog().yesno(name, addon.getLocalizedString(30821)):
            return
        try:
            xbmc.executebuiltin("CleanLibrary(video)")
            xbmcgui.Dialog().notification(
                name, addon.getLocalizedString(30820), icon_path_fn(), time=3200
            )
        except Exception as ex:
            xbmcgui.Dialog().ok(
                name,
                "{}: {}".format(addon.getLocalizedString(30511), ex),
            )
    elif act == "scan":
        try:
            xbmc.executebuiltin("UpdateLibrary(video)")
            xbmcgui.Dialog().notification(
                name, addon.getLocalizedString(30822), icon_path_fn(), time=3200
            )
        except Exception as ex:
            xbmcgui.Dialog().ok(
                name,
                "{}: {}".format(addon.getLocalizedString(30511), ex),
            )


def run_kraken_tools_show_changelog(*, addon, icon_path_fn):
    root = addon.getAddonInfo("path") or ""
    path = os.path.join(root, "changelog.txt")
    txt = addon.getLocalizedString(30488)
    if path and os.path.isfile(path):
        try:
            with open(path, encoding="utf-8", errors="replace") as fh:
                txt = fh.read()
        except Exception:
            txt = addon.getLocalizedString(30488)
    if len(txt) > 98000:
        txt = "…\n\n" + txt[-95000:]
    xbmcgui.Dialog().textviewer(
        "{} — {}".format(addon.getAddonInfo("name") or "Kraken", addon.getLocalizedString(30477)),
        txt,
    )


def run_kraken_tools_tail_kodi_log(*, addon, icon_path_fn, max_chars=78000):
    log_path = ""
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
    except Exception:
        log_path = ""
    if not log_path or not os.path.isfile(log_path):
        xbmcgui.Dialog().ok(
            addon.getAddonInfo("name") or "Kraken",
            addon.getLocalizedString(30485),
        )
        return
    try:
        with open(log_path, encoding="utf-8", errors="replace") as fh:
            data = fh.read()
    except Exception:
        try:
            with open(log_path, encoding="latin-1", errors="replace") as fh:
                data = fh.read()
        except Exception as ex:
            xbmcgui.Dialog().ok(addon.getAddonInfo("name") or "Kraken", str(ex))
            return
    if len(data) > max_chars:
        data = "[…]\n\n" + data[-max_chars:]
    title = "{} — {}".format(
        addon.getAddonInfo("name") or "Kraken", addon.getLocalizedString(30486)
    )
    xbmcgui.Dialog().textviewer(title, data)
