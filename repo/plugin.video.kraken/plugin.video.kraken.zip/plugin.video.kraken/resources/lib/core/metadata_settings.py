def metadata_timeout(get_int_setting):
    return max(3, min(20, get_int_setting("metadata_timeout", 10)))


def metadata_priority(get_setting):
    value = (get_setting("metadata_priority") or "TMDB first").strip().lower()
    if "omdb" in value:
        return "omdb_first"
    return "tmdb_first"


def trakt_results_limit(get_int_setting):
    return max(5, min(100, get_int_setting("trakt_results_limit", 20)))


def trakt_title_with_year(get_bool_setting):
    return get_bool_setting("trakt_title_with_year")


def metadata_fallback_fanart(get_bool_setting):
    return get_bool_setting("metadata_fallback_fanart")


def tmdb_language(get_setting):
    value = str(get_setting("tmdb_language") or "").strip()
    low = value.lower()
    aliases = {
        "spanish": "es-ES",
        "español": "es-ES",
        "castellano": "es-ES",
        "english": "en-US",
        "inglés": "en-US",
        "ingles": "en-US",
        "french": "fr-FR",
        "francés": "fr-FR",
        "frances": "fr-FR",
        "italian": "it-IT",
        "italiano": "it-IT",
        "german": "de-DE",
        "alemán": "de-DE",
        "aleman": "de-DE",
    }
    return aliases.get(low, value or "Auto (Kodi)")


def tmdb_country(get_setting):
    value = str(get_setting("tmdb_country") or "").strip()
    low = value.lower()
    aliases = {
        "spain": "ES",
        "españa": "ES",
        "espana": "ES",
        "united states": "US",
        "estados unidos": "US",
        "usa": "US",
        "mexico": "MX",
        "méxico": "MX",
        "argentina": "AR",
        "chile": "CL",
        "colombia": "CO",
        "peru": "PE",
        "perú": "PE",
        "united kingdom": "GB",
        "reino unido": "GB",
        "france": "FR",
        "francia": "FR",
        "germany": "DE",
        "alemania": "DE",
        "italy": "IT",
        "italia": "IT",
        "portugal": "PT",
        "brazil": "BR",
        "brasil": "BR",
    }
    return aliases.get(low, value.upper() or "ES")


def tmdb_image_quality(get_setting):
    value = str(get_setting("tmdb_image_quality") or "High").strip().lower()
    if "original" in value:
        return "original"
    if "medium" in value or "media" in value:
        return "medium"
    return "high"


def omdb_image_quality(get_setting):
    value = str(get_setting("omdb_image_quality") or "High").strip().lower()
    if "original" in value:
        return "original"
    if "medium" in value or "media" in value:
        return "medium"
    return "high"


def fanart_tv_enabled(get_bool_setting, get_setting):
    return get_bool_setting("fanart_tv_enabled") and bool(
        str(get_setting("fanart_tv_api_key") or "").strip()
    )


def fanart_tv_api_key(get_setting):
    return str(get_setting("fanart_tv_api_key") or "").strip()


def external_scrapers_timeout(get_int_setting):
    return max(3, min(20, get_int_setting("external_scrapers_timeout", 8)))
