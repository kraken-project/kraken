"""PNG temporal + ventana XML KrakenQrDialog (rutas skin centralizadas)."""

from __future__ import annotations

import time
from urllib.parse import urlencode

import xbmc
import xbmcvfs

from resources.lib.core.kraken_local_qr import save_qr_png_for_text


def device_activation_qr_url(verification_url: str, user_code: str) -> str:
    """URL de activación por dispositivo (OAuth device flow): página + código en query."""
    vu = (verification_url or "").strip().split("#", 1)[0]
    uc = str(user_code or "").strip().upper().replace(" ", "")
    if not vu:
        return ""
    if not uc:
        return vu
    qs = urlencode({"user_code": uc})
    return f"{vu}&{qs}" if "?" in vu else f"{vu}?{qs}"


def oauth_device_flow_qr_url(device: dict) -> str:
    """
    URL a codificar en QR para JSON de /device/code de flujos tipo AllDebrid OAuth.
    Prioriza verification_*_complete; si no, verification_url / verification_uri + user_code.
    """
    for key in ("verification_uri_complete", "verification_url_complete"):
        u = str((device or {}).get(key) or "").strip().split("#", 1)[0]
        if u:
            return u
    base = (
        str((device or {}).get("verification_url") or "")
        .strip()
        or str((device or {}).get("verification_uri") or "").strip()
    ).split("#", 1)[0]
    uc = (device or {}).get("user_code", "")
    return device_activation_qr_url(base, uc) or base


def pin_challenge_qr_url(page_url: str, code: str, *, query_param: str = "pin") -> str:
    """Página de PIN (p. ej. AllDebrid) con código en query."""
    u = (page_url or "").strip().split("#", 1)[0]
    c = str(code or "").strip()
    if not u:
        return ""
    if not c:
        return u
    key = (query_param or "pin").strip() or "pin"
    qs = urlencode({key: c})
    return f"{u}&{qs}" if "?" in u else f"{u}?{qs}"

_QR_XML = "kraken_qr_dialog.xml"
_QR_THEME = "default"
_QR_RES = "1080i"


def qr_dialog_skin_tuple():
    """Argumentos posicionales WindowXMLDialog: xml, addon_path, theme, resolución."""
    return (_QR_XML, _QR_THEME, _QR_RES)


def write_qr_png_to_special_temp(
    filename: str,
    text: str,
    *,
    scale: int = 6,
    border: int = 4,
) -> str | None:
    """
    Escribe QR en special://temp/<filename>.
    Devuelve la ruta special:// si tuvo éxito; si no, None.
    """
    name = (filename or "").strip().lstrip("/")
    if not name:
        return None
    if name.lower().endswith(".png"):
        stem = name[:-4]
        name = f"{stem}_{int(time.time() * 1000)}.png"
    special = f"special://temp/{name}"
    try:
        save_qr_png_for_text(
            text,
            xbmcvfs.translatePath(special),
            scale=scale,
            border=border,
        )
        return special
    except Exception as ex:
        try:
            xbmc.log(f"[Kraken][QR] No se pudo escribir QR en {special}: {ex}", xbmc.LOGWARNING)
        except Exception:
            pass
        return None


def open_kraken_qr_modal(
    qr_dialog_cls,
    addon_path: str,
    *,
    dialog_title: str,
    body_text: str,
    qr_special_path: str,
    poll_interval_sec: float = 0,
    poll_deadline_epoch: float | None = None,
    poll_fn=None,
) -> dict:
    """Muestra KrakenQrDialog y libera la ventana al cerrar.

    Opcional poll_fn + interval: segundo plano mientras está abierta (OAuth/PIN);
    cuando poll_fn devuelve True la ventana se cierra desde el hilo.
    """
    xml, theme, res = qr_dialog_skin_tuple()
    dialog = qr_dialog_cls(
        xml,
        addon_path,
        theme,
        res,
        dialog_title=dialog_title,
        url=body_text,
        qr_url=qr_special_path or "",
        poll_interval_sec=poll_interval_sec,
        poll_deadline_epoch=poll_deadline_epoch,
        poll_fn=poll_fn,
    )
    try:
        dialog.doModal()
        return {
            "success": bool(getattr(dialog, "auth_success", False)),
            "timeout": bool(getattr(dialog, "timed_out", False)),
        }
    finally:
        del dialog
