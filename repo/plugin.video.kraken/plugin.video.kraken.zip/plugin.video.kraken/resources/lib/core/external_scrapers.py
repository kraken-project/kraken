import xbmc


def external_scraper_candidates(
    title,
    year,
    imdb_id,
    *,
    media_type="movie",
    season=None,
    episode=None,
    tvshowtitle=None,
    preferred_engine="",
    progress_cb=None,
    external_scrapers_timeout,
    get_bool_setting,
    addon_installed,
    load_scraper_module,
    is_playable_stream_url,
    normalize_language_label,
):
    """Resuelve fuentes desde cocoscrapers y elementum burst."""
    out = []
    seen = set()
    has_imdb_tt = bool(imdb_id and str(imdb_id).startswith("tt"))
    configs = [
        (
            "provider_coco_scrapers",
            "script.module.cocoscrapers",
            "cocoscrapers",
            "Coco",
        ),
        ("provider_elementum_burst", "script.elementum.burst", None, "Burst"),
    ]
    base_data = {
        "title": str(title or "").strip(),
        "year": str(year or ""),
        "imdb": str(imdb_id).strip(),
        "aliases": [],
        "timeout": external_scrapers_timeout(),
    }
    if media_type == "series":
        base_data.update(
            {
                "tvshowtitle": str(tvshowtitle or title or "").strip(),
                "title": "Episodio",
                "season": int(season or 1),
                "episode": int(episode or 1),
                "total_seasons": int(season or 1),
            }
        )
    wanted = str(preferred_engine or "").strip().lower()
    for setting_id, addon_id, package_name, label in configs:
        if wanted and wanted not in label.lower():
            continue
        if not get_bool_setting(setting_id):
            continue
        if not addon_installed(addon_id):
            xbmc.log(f"[Kraken] {addon_id} not installed", xbmc.LOGINFO)
            continue
        if package_name is None:
            elementum_id = "plugin.video.elementum"
            if not addon_installed(elementum_id):
                xbmc.log(
                    f"[Kraken] Torrent Burst requiere {elementum_id}",
                    xbmc.LOGINFO,
                )
                continue
            from resources.lib.core.elementum_burst_client import (
                elementum_burst_to_kraken_candidates,
                run_burst_search,
            )

            try:
                burst_raw = run_burst_search(
                    media_type=media_type,
                    title=base_data["title"],
                    year=base_data["year"],
                    imdb_id=base_data["imdb"],
                    season=base_data.get("season"),
                    episode=base_data.get("episode"),
                    tvshowtitle=base_data.get("tvshowtitle"),
                )
            except Exception as err:
                xbmc.log(f"[Kraken] Torrent Burst search: {err}", xbmc.LOGWARNING)
                burst_raw = []
            merged = elementum_burst_to_kraken_candidates(
                burst_raw,
                normalize_language_label=normalize_language_label,
                is_playable_stream_url=is_playable_stream_url,
                seen=seen,
            )
            for item in merged:
                if callable(progress_cb):
                    progress_cb(label, "multi", list(out))
                out.append(item)
                if callable(progress_cb):
                    progress_cb(label, "multi", list(out))
            continue
        if not has_imdb_tt:
            continue
        module = load_scraper_module(package_name, addon_id)
        if not module or not hasattr(module, "sources"):
            continue
        try:
            providers = module.sources(ret_all=False) or []
        except Exception as err:
            xbmc.log(
                f"[Kraken] {package_name} sources() fallo: {err}",
                xbmc.LOGWARNING,
            )
            providers = []
        for provider_name, provider_cls in providers:
            if callable(progress_cb):
                progress_cb(label, provider_name, list(out))
            try:
                scraper = provider_cls()
                raw_items = scraper.sources(dict(base_data), {}) or []
            except Exception:
                raw_items = []
            for raw in raw_items:
                url = str((raw or {}).get("url") or "").strip()
                if not url or url in seen or not is_playable_stream_url(url):
                    continue
                seen.add(url)
                out.append(
                    {
                        "url": url,
                        "label": str(
                            (raw or {}).get("name") or provider_name or "Fuente"
                        ).strip(),
                        "title": str((raw or {}).get("name") or "").strip(),
                        "quality": str((raw or {}).get("quality") or "Auto").strip(),
                        "language": normalize_language_label(
                            (raw or {}).get("language"),
                            provider_name=provider_name,
                            label=(raw or {}).get("name"),
                            title=(raw or {}).get("name"),
                            info=(raw or {}).get("info"),
                            stream_url=url,
                        ),
                        "origin": f"{label} {provider_name}",
                    }
                )
                if callable(progress_cb):
                    progress_cb(label, provider_name, list(out))
    return out
