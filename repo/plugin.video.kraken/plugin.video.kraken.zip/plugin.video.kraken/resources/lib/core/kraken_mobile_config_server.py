# Servidor HTTP local para editar ajustes largos / JSON desde el movil (misma red WiFi).
import json
import os
import secrets
import socket
import socketserver
import threading
from http.server import BaseHTTPRequestHandler
from urllib.parse import parse_qs, quote, unquote, urlparse

import xbmc

from resources.lib.core.settings_helpers import get_setting, set_setting

# Campos editables (texto / JSON / labelenum como texto) — IDs de settings.xml
_MOBILE_CORE = (
    ("kraken_mobile_web_port", "Servidor web movil — puerto (1024–65535)"),
    ("sources_order_priority", "Orden de fuentes (igual que desplegable Kraken)"),
    ("stremio_manifest_catalog_pick", "Stremio — filtro catalogos manifest (JSON)"),
    ("stremio_catalog_named", "Stremio — catalogo nombrado (punto y coma)"),
    ("stremio_catalog_urls", "Stremio — URLs extra (comas)"),
    ("stremio_catalog_url", "Stremio — URL catalogo general"),
)

_MOBILE_STREMIO_URLS = (
    ("stremio_torrentio_enabled", "Stremio — Torrentio activado (true/false)"),
    ("stremio_torrentio_url", "Stremio — Torrentio URL catalogo JSON"),
    ("stremio_preeflix_enabled", "Stremio — Preeflix activado (true/false)"),
    ("stremio_preeflix_url", "Stremio — Preeflix URL catalogo JSON"),
    ("stremio_comet_enabled", "Stremio — Comet activado (true/false)"),
    ("stremio_comet_url", "Stremio — Comet URL catalogo JSON"),
    ("stremio_mediafusion_enabled", "Stremio — MediaFusion activado (true/false)"),
    ("stremio_mediafusion_url", "Stremio — MediaFusion URL catalogo JSON"),
    ("stremio_aiostreams_enabled", "Stremio — AIOStreams activado (true/false)"),
    ("stremio_aiostreams_url", "Stremio — AIOStreams URL catalogo JSON"),
)

_MOBILE_LITE_URLS = (
    ("lite_link_url_2ddl", "KrakenLite — URL 2ddl"),
    ("lite_link_url_300mbfilms", "KrakenLite — URL 300mbfilms"),
    ("lite_link_url_allmoviesforyou", "KrakenLite — URL allmoviesforyou"),
    ("lite_link_url_anymovies", "KrakenLite — URL anymovies"),
    ("lite_link_url_cmovieshd", "KrakenLite — URL cmovieshd"),
    ("lite_link_url_databasegdriveplayer", "KrakenLite — URL databasegdriveplayer"),
    ("lite_link_url_dbgo", "KrakenLite — URL dbgo"),
    ("lite_link_url_easynews", "KrakenLite — URL easynews"),
    ("lite_link_url_filmxy", "KrakenLite — URL filmxy"),
    ("lite_link_url_furk", "KrakenLite — URL furk"),
    ("lite_link_url_gowatchseries", "KrakenLite — URL gowatchseries"),
    ("lite_link_url_maxrls", "KrakenLite — URL maxrls"),
    ("lite_link_url_myvideolinks", "KrakenLite — URL myvideolinks"),
    ("lite_link_url_onlineseries", "KrakenLite — URL onlineseries"),
    ("lite_link_url_ororo", "KrakenLite — URL ororo"),
    ("lite_link_url_rapidmoviez", "KrakenLite — URL rapidmoviez"),
    ("lite_link_url_rlsbb", "KrakenLite — URL rlsbb"),
    ("lite_link_url_scenerls", "KrakenLite — URL scenerls"),
)

_MOBILE_SCRAPERS_META = (
    (
        "external_scrapers_timeout",
        "Timeout scrapers externos (valor labelenum: 5|8|10|12|15)",
    ),
    ("stremio_http_timeout", "Stremio — timeout HTTP (15|20|25|30|45|60)"),
    ("stremio_search_threads", "Stremio — hilos de busqueda (1|2|4|6|8|12|16|24)"),
    ("tmdb_api_key", "TMDB — API key v3"),
    ("tmdb_language", "TMDB — idioma (Auto (Kodi)|es-ES|en-US|...)"),
    ("tmdb_country", "TMDB — pais/region (ES|US|MX|...)"),
    ("tmdb_image_quality", "TMDB — calidad imagen (Medium|High|Original)"),
    ("omdb_api_key", "OMDb — API key"),
    ("omdb_image_quality", "OMDb — calidad imagen (Medium|High|Original)"),
    ("fanart_tv_enabled", "Fanart.tv — activado (true/false)"),
    ("fanart_tv_api_key", "Fanart.tv — API key"),
    ("metadata_priority", "Prioridad metadatos (TMDB primero|OMDb primero)"),
    ("metadata_timeout", "Timeout metadatos seg (5|8|10|15)"),
    ("trakt_plot_language", "Trakt — idioma titulo/sinopsis (Auto (Kodi)|es|en|…)"),
    ("trakt_results_limit", "Trakt — max resultados (10|20|30|50|75|100)"),
)

_MOBILE_TRAKT_OAUTH = (
    ("trakt_access_token", "Trakt — access token"),
    ("trakt_refresh_token", "Trakt — refresh token"),
    ("trakt_token_expires", "Trakt — token expires (epoch o texto)"),
    ("trakt_account_info", "Trakt — info cuenta (solo lectura / respaldo)"),
)

_MOBILE_DEBRID = (
    ("debrid_ad_token", "AllDebrid — token"),
    ("debrid_provider", "Debrid legacy — proveedor"),
    ("debrid_api_key", "Debrid legacy — API key / token"),
    ("debrid_refresh_token", "Debrid legacy — refresh"),
    ("debrid_account_info", "Debrid legacy — info cuenta"),
    ("debrid_ad_info", "AllDebrid — texto estado cuenta (respaldo)"),
    ("debrid_rg_info", "Rapidgator — texto estado / notas"),
)

_MOBILE_TORRENT_UI = (
    (
        "provider_elementum_burst",
        "Torrent Burst (script.elementum.burst, torrent al resolver Trakt/Stremio) true/false",
    ),
    (
        "torrent_player",
        "Torrent — igual que enum Kraken Torrent en Kodi (mismo texto)",
    ),
    ("download_movies_path", "Descargas — carpeta peliculas (ruta)"),
    ("download_series_path", "Descargas — carpeta series (ruta)"),
    ("download_last_mode", "Descargas — ultimo modo (interno)"),
    (
        "source_selector_style",
        "Selector fuentes (Compact|Detailed|Compact alternate|Detailed alternate)",
    ),
    ("source_search_style", "Busqueda fuentes (Foreground|Background)"),
    (
        "kraken_rotate_sources_enabled",
        "Alternar servidor entre reproducciones del mismo titulo si hay varias fuentes (true/false)",
    ),
    ("kraken_quality_filter_enabled", "Calidad vídeo — filtro por resolución activo"),
    ("kraken_quality_allow_4k", "Calidad — incluir 4K"),
    ("kraken_quality_allow_1080p", "Calidad — incluir 1080p"),
    ("kraken_quality_allow_720p", "Calidad — incluir 720p"),
    ("kraken_quality_allow_sd", "Calidad — incluir SD"),
    ("kraken_quality_filter_allow_auto", "Calidad — incluir fuentes Auto/sin calibre"),
    ("kraken_size_filter_enabled", "Tamaño — filtro activo"),
    ("kraken_size_min_gb", "Tamaño — minimo GB (0 desactiva)"),
    ("kraken_size_max_gb", "Tamaño — maximo GB (0 desactiva)"),
    ("kraken_size_filter_allow_unknown", "Tamaño — permitir fuentes sin tamaño"),
    ("kraken_codec_filter_enabled", "Codec — filtro activo"),
    ("kraken_codec_allow_h264", "Codec — permitir H.264"),
    ("kraken_codec_allow_h265", "Codec — permitir H.265/HEVC"),
    ("kraken_codec_allow_av1", "Codec — permitir AV1"),
    ("kraken_codec_allow_other", "Codec — permitir desconocido/otro"),
    ("kraken_hdr_filter_enabled", "HDR — filtro activo"),
    ("kraken_hdr_allow_hdr10", "HDR — permitir HDR/HDR10"),
    ("kraken_hdr_allow_dolby_vision", "HDR — permitir Dolby Vision"),
    ("kraken_hdr_allow_sdr", "HDR — permitir SDR"),
    ("kraken_hdr_allow_unknown", "HDR — permitir desconocido"),
    ("autoplay_movies_enabled", "Autoplay — peliculas (true/false)"),
    ("autoplay_series_enabled", "Autoplay — series/episodios (true/false)"),
    ("autoplay_lang_primary", "Autoplay — idioma preferido"),
    ("autoplay_lang_secondary", "Autoplay — idioma alternativo"),
    ("next_episode_warn_seconds", "Siguiente cap — aviso segundos (labelenum)"),
    ("opensubtitles_preferred_lang", "OpenSubtitles — idioma preferido"),
    ("opensubtitles_fallback_lang", "OpenSubtitles — idioma fallback"),
    ("subtitle_translate_enabled", "Subtitulos — traducir fallback con Lingva (true/false)"),
    ("subtitle_translate_endpoint", "Subtitulos — endpoint Lingva"),
    ("subtitle_translate_max_chars", "Subtitulos — tamaño bloque Lingva"),
    ("debrid_expiration_notify_days", "Debrid — aviso caducidad dias (labelenum)"),
)

MOBILE_EDITABLE_FIELDS = (
    _MOBILE_CORE
    + _MOBILE_STREMIO_URLS
    + _MOBILE_LITE_URLS
    + _MOBILE_SCRAPERS_META
    + _MOBILE_TRAKT_OAUTH
    + _MOBILE_DEBRID
    + _MOBILE_TORRENT_UI
)

# Claves estables para la web móvil (deben coincidir con SECTION_ORDER en mobile_config.html)
_MOBILE_SEC_CORE = "core"
_MOBILE_SEC_STREMIO = "stremio_urls"
_MOBILE_SEC_LITE = "lite_links"
_MOBILE_SEC_SCRAPERS = "scrapers_meta"
_MOBILE_SEC_TRAKT = "trakt"
_MOBILE_SEC_DEBRID = "debrid"
_MOBILE_SEC_TORRENT = "torrent_ui"

_MOBILE_FIELD_SECTIONS = (
    (_MOBILE_SEC_CORE, _MOBILE_CORE),
    (_MOBILE_SEC_STREMIO, _MOBILE_STREMIO_URLS),
    (_MOBILE_SEC_LITE, _MOBILE_LITE_URLS),
    (_MOBILE_SEC_SCRAPERS, _MOBILE_SCRAPERS_META),
    (_MOBILE_SEC_TRAKT, _MOBILE_TRAKT_OAUTH),
    (_MOBILE_SEC_DEBRID, _MOBILE_DEBRID),
    (_MOBILE_SEC_TORRENT, _MOBILE_TORRENT_UI),
)


def section_for_mobile_field_id(sid):
    for sec_key, group in _MOBILE_FIELD_SECTIONS:
        for row in group:
            if row[0] == sid:
                return sec_key
    return "other"


# Rutas /config/<slug> en la web movil (un slug = un modulo).
_MOBILE_CONFIG_SLUGS = frozenset(
    {"all", "nucleo", "stremio", "lite", "scrapers", "trakt", "debrid", "ui"}
)

# Alias cortos tipo /stremio-config -> /config/stremio
_LEGACY_CONFIG_PATH_TO_SLUG = {
    "/stremio-config": "stremio",
    "/lite-config": "lite",
    "/nucleo-config": "nucleo",
    "/scrapers-config": "scrapers",
    "/trakt-config": "trakt",
    "/debrid-config": "debrid",
    "/ui-config": "ui",
}


def _is_mobile_config_app_path(path):
    if path in ("/", "/index.html"):
        return True
    parts = [p for p in path.split("/") if p]
    if len(parts) == 2 and parts[0] == "config" and parts[1] in _MOBILE_CONFIG_SLUGS:
        return True
    return False


_HTML_CACHE = None
_LOCK = threading.Lock()
_SERVER = None
_SERVER_THREAD = None
_TOKEN = ""
_PORT = 0


def _addon_path(addon):
    return addon.getAddonInfo("path")


def _html_path(addon):
    return os.path.join(_addon_path(addon), "resources", "web", "mobile_config.html")


def load_mobile_html(addon):
    global _HTML_CACHE
    path = _html_path(addon)
    try:
        with open(path, encoding="utf-8") as f:
            _HTML_CACHE = f.read()
    except Exception as ex:
        xbmc.log(
            f"[Kraken][WebCfg] No se pudo leer mobile_config.html: {ex}",
            xbmc.LOGWARNING,
        )
        _HTML_CACHE = "<!DOCTYPE html><html><body><p>Falta resources/web/mobile_config.html</p></body></html>"
    return _HTML_CACHE


def guess_lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.5)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "127.0.0.1"


def mobile_web_port_from_addon(addon):
    raw = (get_setting(addon, "kraken_mobile_web_port") or "").strip()
    if not raw:
        raw = "53931"
    try:
        p = int(raw)
    except (TypeError, ValueError):
        p = 53931
    return max(1024, min(65535, p))


def is_mobile_server_running():
    return _SERVER is not None


def mobile_server_token():
    return _TOKEN


def mobile_server_port():
    return _PORT


class _KrakenHTTPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True


class KrakenMobileHandler(BaseHTTPRequestHandler):
    server_version = "KrakenMobile/1.0"

    def log_message(self, fmt, *args):
        xbmc.log("[Kraken][WebCfg] " + (fmt % args), xbmc.LOGDEBUG)

    def _redirect(self, location):
        self.send_response(302)
        self.send_header("Location", location)
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def _serve_addon_icon_png(self):
        try:
            addon = self.server.kraken_addon
            icon_path = os.path.join(_addon_path(addon), "icon.png")
            if not os.path.isfile(icon_path):
                self.send_error(404)
                return
            with open(icon_path, "rb") as handle:
                data = handle.read()
            self.send_response(200)
            self.send_header("Content-Type", "image/png")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "public, max-age=86400")
            self.end_headers()
            self.wfile.write(data)
        except Exception as ex:
            xbmc.log(f"[Kraken][WebCfg] icon.png: {ex}", xbmc.LOGWARNING)
            self.send_error(500)

    def _reply(self, code, body, content_type="text/html; charset=utf-8"):
        bs = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(bs)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(bs)

    def _reply_json(self, code, obj):
        self._reply(
            code, json.dumps(obj, ensure_ascii=False), "application/json; charset=utf-8"
        )

    def _token_from_query(self):
        parsed = urlparse(self.path)
        q = parse_qs(parsed.query)
        return (q.get("token") or [""])[0]

    def _auth_ok(self, tok):
        return tok and tok == self.server.kraken_token

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path).rstrip("/") or "/"

        # Entrada sin query (?token=): muchas apps de QR cortan en "?" al abrir el enlace.
        # /k/<token>/ redirige a /?token=... (misma pagina y API que ya existen).
        segs = [p for p in path.split("/") if p]
        if len(segs) >= 2 and segs[0] == "k":
            tok_path = segs[1]
            if self._auth_ok(tok_path):
                loc = "/config/all?token=" + quote(tok_path, safe="")
                self._redirect(loc)
                return
            self._reply(
                401,
                "<!DOCTYPE html><html><body><p>Token invalido en la ruta /k/....</p></body></html>",
            )
            return

        if path == "/icon.png":
            self._serve_addon_icon_png()
            return

        slug_alias = _LEGACY_CONFIG_PATH_TO_SLUG.get(path)
        if slug_alias:
            q = parsed.query
            loc = "/config/" + slug_alias + (("?" + q) if q else "")
            self._redirect(loc)
            return

        if path == "/config":
            tok = self._token_from_query()
            if not self._auth_ok(tok):
                self._reply(
                    401,
                    "<!DOCTYPE html><html><body><p>Token invalido o falta en la URL.</p></body></html>",
                )
                return
            q = parsed.query
            loc = "/config/all" + (("?" + q) if q else "")
            self._redirect(loc)
            return

        if path == "/api/json-bundle":
            from resources.lib.core.mobile_config_labels import (
                mobile_field_label,
                normalize_request_lang,
            )

            tok = self._token_from_query()
            if not self._auth_ok(tok):
                self._reply_json(403, {"ok": False, "error": "token"})
                return
            addon = self.server.kraken_addon
            lang = normalize_request_lang(
                parsed.query or "",
                self.headers.get("Accept-Language"),
            )
            items = []
            for sid, _label_es in MOBILE_EDITABLE_FIELDS:
                items.append(
                    {
                        "id": sid,
                        "label": mobile_field_label(sid, lang),
                        "value": get_setting(addon, sid) or "",
                        "section": section_for_mobile_field_id(sid),
                    }
                )
            self._reply_json(200, {"ok": True, "settings": items, "lang": lang})
            return

        if path == "/api/ping":
            tok = self._token_from_query()
            if not self._auth_ok(tok):
                self._reply_json(403, {"ok": False})
                return
            self._reply_json(200, {"ok": True})
            return

        if path == "/api/stop":
            tok = self._token_from_query()
            if not self._auth_ok(tok):
                self._reply_json(403, {"ok": False})
                return
            self._reply_json(200, {"ok": True, "stopping": True})
            threading.Thread(target=_delayed_stop, daemon=True).start()
            return

        if _is_mobile_config_app_path(path):
            tok = self._token_from_query()
            if not self._auth_ok(tok):
                self._reply(
                    401,
                    "<!DOCTYPE html><html><body><p>Token invalido o falta ?token= en la URL.</p></body></html>",
                )
                return
            html = load_mobile_html(self.server.kraken_addon)
            # Fallback: algunos navegadores/QR alteran la query; inyectamos token en la página.
            marker = "</body>"
            inj = f"<script>window.__KRAKEN_TOKEN__={json.dumps(str(tok))};</script>"
            if marker in html:
                html = html.replace(marker, inj + marker, 1)
            else:
                html += inj
            self._reply(200, html)
            return

        self.send_error(404)

    def do_POST(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path).rstrip("/") or "/"

        if path != "/api/json-bundle":
            self.send_error(404)
            return

        try:
            ln = int(self.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            ln = 0
        if ln <= 0 or ln > 4 * 1024 * 1024:
            self._reply_json(400, {"ok": False, "error": "body"})
            return

        raw = self.rfile.read(ln).decode("utf-8", errors="replace")
        try:
            data = json.loads(raw)
        except (TypeError, ValueError) as err:
            self._reply_json(400, {"ok": False, "error": "json", "detail": str(err)})
            return

        tok = str(data.get("token") or "").strip()
        if not self._auth_ok(tok):
            self._reply_json(403, {"ok": False, "error": "token"})
            return

        addon = self.server.kraken_addon
        settings_in = data.get("settings")
        if not isinstance(settings_in, list):
            self._reply_json(400, {"ok": False, "error": "settings"})
            return

        allowed_ids = {sid for sid, _ in MOBILE_EDITABLE_FIELDS}
        errors = []
        for block in settings_in:
            if not isinstance(block, dict):
                continue
            sid = str(block.get("id") or "").strip()
            if sid not in allowed_ids:
                errors.append(f"id no permitido: {sid}")
                continue
            val = block.get("value")
            if val is None:
                val = ""
            text = str(val)
            if sid == "stremio_manifest_catalog_pick" and text.strip():
                try:
                    json.loads(text)
                except (TypeError, ValueError) as err:
                    errors.append(
                        f"stremio_manifest_catalog_pick no es JSON valido: {err}"
                    )
                    continue
            if sid == "kraken_mobile_web_port" and text.strip():
                try:
                    p = int(text.strip())
                    if p < 1024 or p > 65535:
                        errors.append(
                            "kraken_mobile_web_port: usa un puerto entre 1024 y 65535"
                        )
                        continue
                except (TypeError, ValueError):
                    errors.append("kraken_mobile_web_port debe ser numerico")
                    continue
            try:
                set_setting(addon, sid, text)
            except Exception as ex:
                errors.append(f"{sid}: {ex}")

        if errors:
            self._reply_json(400, {"ok": False, "errors": errors})
            return
        self._reply_json(200, {"ok": True})
        return


def _delayed_stop():
    import time

    time.sleep(0.3)
    stop_mobile_config_server()


def stop_mobile_config_server():
    global _SERVER, _SERVER_THREAD, _TOKEN, _PORT
    with _LOCK:
        srv = _SERVER
        _SERVER = None
        _SERVER_THREAD = None
        _TOKEN = ""
        _PORT = 0
    if srv:
        try:
            srv.shutdown()
        except Exception:
            pass
        try:
            srv.server_close()
        except Exception:
            pass


def start_mobile_config_server(addon):
    """
    Arranca el servidor en 0.0.0.0:puerto con token aleatorio.
    Retorna (ok, mensaje_error).
    """
    global _SERVER, _SERVER_THREAD, _TOKEN, _PORT

    with _LOCK:
        if _SERVER is not None:
            return True, ""

        port = mobile_web_port_from_addon(addon)
        token = secrets.token_urlsafe(24)
        try:
            httpd = _KrakenHTTPServer(("0.0.0.0", port), KrakenMobileHandler)
        except OSError as err:
            return False, str(err)

        httpd.kraken_addon = addon
        httpd.kraken_token = token

        def _serve():
            try:
                httpd.serve_forever()
            except Exception as ex:
                xbmc.log(f"[Kraken][WebCfg] serve_forever: {ex}", xbmc.LOGINFO)

        th = threading.Thread(target=_serve, daemon=True)
        th.start()

        _SERVER = httpd
        _SERVER_THREAD = th
        _TOKEN = token
        _PORT = port

    load_mobile_html(addon)
    return True, ""
