import json
import os
import time
from urllib.parse import urlencode

from resources.lib.core.metadata_cache import addon_data_dir


def fanart_cache_path(addon):
    base = addon_data_dir(addon)
    return os.path.join(base, "fanart_tv_cache.json") if base else ""


def _cache_load(addon):
    path = fanart_cache_path(addon)
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _cache_save(addon, cache):
    path = fanart_cache_path(addon)
    if not path:
        return
    try:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(cache, fh, ensure_ascii=True)
    except Exception:
        pass


def _best_image(rows, lang):
    if not isinstance(rows, list):
        return ""
    lang = str(lang or "").strip().lower()

    def score(row):
        if not isinstance(row, dict):
            return -1
        rlang = str(row.get("lang") or "").strip().lower()
        likes = row.get("likes")
        try:
            likes_n = int(likes)
        except Exception:
            likes_n = 0
        lang_score = 0
        if lang and rlang == lang:
            lang_score = 10000
        elif rlang in ("00", "en", ""):
            lang_score = 5000
        return lang_score + likes_n

    ordered = sorted(rows, key=score, reverse=True)
    for row in ordered:
        url = str((row or {}).get("url") or "").strip()
        if url:
            return url
    return ""


def fanart_tv_search_art(
    *,
    addon,
    media_type,
    tmdb_id="",
    imdb_id="",
    tvdb_id="",
    enabled,
    api_key,
    json_get,
    metadata_timeout,
    language="en",
    ttl_seconds=7 * 24 * 60 * 60,
    max_items=500,
):
    if not enabled():
        return {"poster": "", "fanart": ""}
    key = str(api_key() or "").strip()
    if not key:
        return {"poster": "", "fanart": ""}
    kind = "tv" if media_type == "series" else "movies"
    fid = str(tvdb_id or "").strip() if kind == "tv" else str(tmdb_id or "").strip()
    if kind == "movies" and not fid:
        fid = str(imdb_id or "").strip()
    if not fid:
        return {"poster": "", "fanart": ""}
    cache_key = "{}|{}".format(kind, fid)
    cache = _cache_load(addon)
    node = cache.get(cache_key) if isinstance(cache, dict) else None
    now = int(time.time())
    if isinstance(node, dict) and now - int(node.get("saved_at") or 0) <= ttl_seconds:
        art = node.get("art") or {}
        return {
            "poster": str(art.get("poster") or ""),
            "fanart": str(art.get("fanart") or ""),
        }
    url = "https://webservice.fanart.tv/v3/{}/{}?{}".format(
        kind, fid, urlencode({"api_key": key})
    )
    try:
        payload = json_get(url, timeout=metadata_timeout())
    except Exception:
        return {"poster": "", "fanart": ""}
    if not isinstance(payload, dict):
        return {"poster": "", "fanart": ""}
    lang = str(language or "en").strip().lower()
    if kind == "tv":
        poster = _best_image(payload.get("tvposter"), lang)
        fanart = _best_image(payload.get("showbackground"), lang)
    else:
        poster = _best_image(payload.get("movieposter"), lang)
        fanart = _best_image(payload.get("moviebackground"), lang)
    art = {"poster": poster, "fanart": fanart}
    cache[cache_key] = {"saved_at": now, "art": art}
    valid = []
    for k, v in cache.items():
        if isinstance(v, dict) and now - int(v.get("saved_at") or 0) <= ttl_seconds:
            valid.append((k, v, int(v.get("saved_at") or 0)))
    valid.sort(key=lambda row: row[2], reverse=True)
    _cache_save(addon, {k: v for k, v, _ in valid[:max_items]})
    return art
