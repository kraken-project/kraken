import hashlib
import json
import os
import re
import time
from urllib.parse import quote
from urllib.request import Request, urlopen

try:
    import xbmc
except Exception:  # pragma: no cover - Kodi runtime only
    xbmc = None

try:
    import xbmcvfs
except Exception:  # pragma: no cover - Kodi runtime only
    xbmcvfs = None


_SRT_TIME_RE = re.compile(r"\d{1,2}:\d{2}:\d{2}[,.]\d{1,3}\s+-->\s+\d{1,2}:\d{2}:\d{2}[,.]\d{1,3}")
_SEP_PREFIX = "KRAKEN_SUB_BLOCK_"


def _log(message, level=None):
    if xbmc is None:
        return
    try:
        xbmc.log(str(message), level if level is not None else xbmc.LOGINFO)
    except Exception:
        pass


def _translate_path(path):
    raw = str(path or "").strip()
    if not raw:
        return ""
    if xbmcvfs is not None and raw.startswith("special://"):
        try:
            return xbmcvfs.translatePath(raw)
        except Exception:
            return raw
    return raw


def _ensure_dir(path):
    if not path:
        return
    if os.path.isdir(path):
        return
    os.makedirs(path, exist_ok=True)


def _safe_int(value, default, minv, maxv):
    try:
        out = int(str(value or "").strip())
    except (TypeError, ValueError):
        out = int(default)
    return max(int(minv), min(int(maxv), out))


def normalize_language_code(value, default=""):
    text = str(value or "").strip().lower()
    if not text:
        return default
    text = text.replace("_", "-")
    aliases = {
        "auto": "",
        "auto (kodi)": "",
        "spanish": "es",
        "castellano": "es",
        "espanol": "es",
        "español": "es",
        "english": "en",
        "ingles": "en",
        "inglés": "en",
        "french": "fr",
        "francais": "fr",
        "français": "fr",
        "italian": "it",
        "italiano": "it",
        "german": "de",
        "aleman": "de",
        "alemán": "de",
        "deutsch": "de",
        "none": "",
        "ninguno": "",
        "n/a": "",
    }
    if text in aliases:
        return aliases[text] or default
    if "-" in text:
        text = text.split("-", 1)[0]
    if len(text) == 2 and text.isalpha():
        return text
    return default


def _candidate_roots(profile_dir):
    roots = []
    for raw in (
        profile_dir,
        "special://temp",
        "special://home/userdata/addon_data/service.subtitles.opensubtitles",
        "special://home/userdata/addon_data/service.subtitles.opensubtitles_by_opensubtitles",
    ):
        p = _translate_path(raw)
        if p and p not in roots and os.path.isdir(p):
            roots.append(p)
    return roots


def _find_recent_srt_by_name(name, profile_dir, max_age_sec=900):
    needle = os.path.basename(str(name or "").strip()).lower()
    if not needle:
        return ""
    now = time.time()
    best = ("", 0.0)
    for root in _candidate_roots(profile_dir):
        for dirpath, dirnames, filenames in os.walk(root):
            if len(dirpath) - len(root) > 260:
                dirnames[:] = []
                continue
            for fn in filenames:
                if not fn.lower().endswith(".srt"):
                    continue
                if needle and needle not in fn.lower() and fn.lower() not in needle:
                    continue
                full = os.path.join(dirpath, fn)
                try:
                    mtime = os.path.getmtime(full)
                except OSError:
                    continue
                if now - mtime > max_age_sec:
                    continue
                if mtime > best[1]:
                    best = (full, mtime)
    return best[0]


def active_subtitle_srt_path(player, profile_dir):
    try:
        current = str(player.getSubtitles() or "").strip()
    except Exception:
        current = ""
    if not current:
        return ""
    direct = _translate_path(current)
    if direct.lower().endswith(".srt") and os.path.isfile(direct):
        return direct
    return _find_recent_srt_by_name(current, profile_dir)


def _read_text(path):
    raw = open(path, "rb").read()
    for enc in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def _parse_srt(text):
    blocks = re.split(r"\r?\n\s*\r?\n", str(text or "").strip())
    parsed = []
    for block in blocks:
        lines = [ln.rstrip("\r") for ln in block.splitlines()]
        if not lines:
            continue
        time_idx = -1
        for idx, line in enumerate(lines[:3]):
            if _SRT_TIME_RE.search(line):
                time_idx = idx
                break
        if time_idx < 0:
            parsed.append({"raw": block})
            continue
        parsed.append(
            {
                "index": lines[:time_idx],
                "time": lines[time_idx],
                "text": lines[time_idx + 1 :],
            }
        )
    return parsed


def _render_srt(blocks, translated):
    out = []
    tpos = 0
    for block in blocks:
        if "raw" in block:
            out.append(block["raw"])
            continue
        lines = []
        lines.extend(block.get("index") or [])
        lines.append(block.get("time") or "")
        text_lines = translated[tpos].splitlines() if tpos < len(translated) else block.get("text") or []
        lines.extend(text_lines)
        out.append("\n".join(lines).strip())
        tpos += 1
    return "\n\n".join(out).strip() + "\n"


def _lingva_base(endpoint):
    raw = str(endpoint or "").strip() or "https://lingva.ml"
    raw = raw.rstrip("/")
    if raw.endswith("/api/v1"):
        raw = raw[: -len("/api/v1")]
    return raw


def _lingva_translate(endpoint, source_lang, target_lang, text, timeout=18):
    src = normalize_language_code(source_lang, "auto") or "auto"
    dst = normalize_language_code(target_lang, "")
    if not dst:
        return ""
    url = "{}/api/v1/{}/{}/{}".format(_lingva_base(endpoint), src, dst, quote(str(text or ""), safe=""))
    req = Request(url, headers={"User-Agent": "Kraken-SubtitleTranslate/1.0"})
    with urlopen(req, timeout=timeout) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    if isinstance(data, dict):
        for key in ("translation", "translatedText", "text"):
            val = data.get(key)
            if isinstance(val, str) and val.strip():
                return val
    return ""


def _translate_cues(cues, source_lang, target_lang, endpoint, max_chars):
    translated = []
    i = 0
    max_chars = _safe_int(max_chars, 1200, 200, 2400)
    while i < len(cues):
        batch = []
        size = 0
        while i + len(batch) < len(cues):
            candidate = cues[i + len(batch)]
            add_size = len(candidate) + 32
            if batch and size + add_size > max_chars:
                break
            batch.append(candidate)
            size += add_size
        seps = [f"{_SEP_PREFIX}{n:04d}" for n in range(len(batch))]
        joined_parts = []
        for n, cue in enumerate(batch):
            if n:
                joined_parts.append(seps[n])
            joined_parts.append(cue)
        joined = "\n\n".join(joined_parts)
        raw = _lingva_translate(endpoint, source_lang, target_lang, joined)
        pieces = [raw]
        if len(batch) > 1:
            pattern = "|".join(re.escape(sep) for sep in seps[1:])
            pieces = re.split(pattern, raw) if pattern else [raw]
        if len(pieces) != len(batch):
            pieces = [
                _lingva_translate(endpoint, source_lang, target_lang, cue)
                for cue in batch
            ]
        translated.extend([p.strip() or orig for p, orig in zip(pieces, batch)])
        i += len(batch)
        time.sleep(0.15)
    return translated


def translate_srt_file(path, profile_dir, source_lang, target_lang, endpoint, max_chars=1200):
    src_path = _translate_path(path)
    if not src_path.lower().endswith(".srt") or not os.path.isfile(src_path):
        return ""
    src = normalize_language_code(source_lang, "auto") or "auto"
    dst = normalize_language_code(target_lang, "")
    if not dst or src == dst:
        return ""
    text = _read_text(src_path)
    blocks = _parse_srt(text)
    cues = ["\n".join(block.get("text") or []).strip() for block in blocks if "text" in block]
    if not cues:
        return ""
    cache_root = os.path.join(_translate_path(profile_dir), "translated_subtitles")
    _ensure_dir(cache_root)
    digest = hashlib.sha256()
    digest.update(text.encode("utf-8", errors="replace"))
    digest.update(src.encode("ascii", errors="ignore"))
    digest.update(dst.encode("ascii", errors="ignore"))
    out_path = os.path.join(cache_root, f"{digest.hexdigest()[:24]}_{src}_{dst}.srt")
    if os.path.isfile(out_path) and os.path.getsize(out_path) > 0:
        return out_path
    translated = _translate_cues(cues, src, dst, endpoint, max_chars)
    rendered = _render_srt(blocks, translated)
    with open(out_path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(rendered)
    _log(f"[Kraken][Subtitles] Subtitulo traducido con Lingva: {out_path}")
    return out_path


def clear_translated_subtitles(profile_dir):
    cache_root = os.path.join(_translate_path(profile_dir), "translated_subtitles")
    removed = 0
    if not os.path.isdir(cache_root):
        return 0
    for root, _dirs, files in os.walk(cache_root):
        for name in files:
            if not name.lower().endswith((".srt", ".sub", ".vtt", ".ass", ".ssa")):
                continue
            path = os.path.join(root, name)
            try:
                os.remove(path)
                removed += 1
            except OSError:
                continue
    return removed
