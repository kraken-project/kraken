from urllib.request import Request, urlopen

from resources.lib.sources.source_language import autoplay_resolve_bucket_ids
from resources.lib.sources.source_ranking import filter_candidates_by_source_prefs
from resources.lib.sources.source_rotation import (
    remember_pick,
    rotate_candidates_order,
    rotation_enabled,
    last_fingerprint_for,
)


def _looks_non_media_url(url):
    low = str(url or "").strip().lower()
    if not low:
        return True
    blocked_parts = ("/configure", "/config", "/settings", "/setup", "/manifest.json")
    if any(part in low for part in blocked_parts):
        return True
    blocked_ext = (".css", ".js", ".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg")
    if any(low.endswith(ext) for ext in blocked_ext):
        return True
    return False


def is_stream_url_viable_quick(url, timeout_sec=4):
    raw = str(url or "").strip()
    if not raw:
        return False
    if raw.startswith(("plugin://", "magnet:")):
        return True
    if not raw.startswith(("http://", "https://")):
        return False
    if _looks_non_media_url(raw):
        return False
    try:
        req = Request(
            raw,
            headers={
                "User-Agent": "Kraken-SourceProbe/1.0",
                "Range": "bytes=0-0",
            },
        )
        with urlopen(req, timeout=max(2, int(timeout_sec))) as resp:
            final_url = str(resp.geturl() or raw).strip()
            ctype = str(resp.headers.get("Content-Type") or "").strip().lower()
    except Exception:
        return False
    if _looks_non_media_url(final_url):
        return False
    if "text/html" in ctype and not any(
        x in final_url.lower() for x in (".m3u8", ".mpd", ".mp4", ".mkv", ".avi")
    ):
        return False
    return True


def candidates_deduped_for_picker(candidates):
    clean = []
    seen = set()
    for c in candidates or []:
        url = str((c or {}).get("url") or "").strip()
        origin = str((c or {}).get("origin") or "").strip()
        dedup_key = f"{origin.lower()}||{url}"
        if not url or dedup_key in seen:
            continue
        seen.add(dedup_key)
        clean.append(
            {
                "url": url,
                "label": str((c or {}).get("label") or "Fuente").strip(),
                "title": str((c or {}).get("title") or "").strip(),
                "quality": str((c or {}).get("quality") or "Auto").strip(),
                "language": str((c or {}).get("language") or "N/D").strip(),
                "origin": origin,
                "_raw_text": str((c or {}).get("_raw_text") or "").strip(),
            }
        )
    return clean


def _rotation_apply(clean, rotation):
    if not rotation or not rotation.get("content_key"):
        return clean
    if not rotation_enabled(rotation["get_bool_setting"]):
        return clean
    last = last_fingerprint_for(
        rotation["get_setting"], rotation["content_key"]
    )
    if last:
        return rotate_candidates_order(clean, last)
    return clean


def _rotation_note(rotation, url, clean_list):
    if not url or not rotation or not rotation.get("content_key"):
        return
    u = str(url).strip()
    for it in clean_list or []:
        if str((it or {}).get("url") or "").strip() == u:
            remember_pick(
                rotation["set_setting"],
                rotation["get_setting"],
                rotation["content_key"],
                it,
            )
            return
    remember_pick(
        rotation["set_setting"],
        rotation["get_setting"],
        rotation["content_key"],
        {"url": u, "origin": ""},
    )


def pick_stream_url_silent(
    candidates,
    *,
    playback_kind=None,
    source_sort_key_with_language_fn,
    get_bool_setting_fn,
    get_setting_fn,
    autoplay_url_by_language_priority_fn,
    rotation=None,
):
    """
    Misma puntuación de fuentes que el selector, sin abrir diálogo.
    """
    clean = candidates_deduped_for_picker(candidates)
    clean = filter_candidates_by_source_prefs(clean, get_setting_fn)
    if not clean:
        return ""
    if len(clean) == 1:
        only_url = str(clean[0].get("url") or "").strip()
        out = only_url if is_stream_url_viable_quick(only_url) else ""
        if out:
            _rotation_note(rotation, out, clean)
        return out
    clean.sort(key=source_sort_key_with_language_fn)
    clean = _rotation_apply(clean, rotation)
    autoplay_on = get_bool_setting_fn("autoplay_source_by_language")
    if autoplay_on:
        pk = str(playback_kind or "").strip().lower()
        if pk == "movie":
            autoplay_on = get_bool_setting_fn("autoplay_movies_enabled")
        elif pk == "episode":
            autoplay_on = get_bool_setting_fn("autoplay_series_enabled")

    if autoplay_on:
        primary_bid, secondary_bid = autoplay_resolve_bucket_ids(get_setting_fn)
        auto_url = autoplay_url_by_language_priority_fn(
            clean, primary_bid, secondary_bid
        )
        if auto_url and is_stream_url_viable_quick(auto_url):
            _rotation_note(rotation, auto_url, clean)
            return auto_url
    for item in clean[:6]:
        u = str(item.get("url") or "").strip()
        if u and is_stream_url_viable_quick(u):
            _rotation_note(rotation, u, clean)
            return u
    fallback_u = str(clean[0].get("url") or "").strip()
    _rotation_note(rotation, fallback_u, clean)
    return fallback_u
