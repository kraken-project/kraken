from collections import Counter

import xbmc

from resources.lib.sources.source_ranking import filter_candidates_by_source_prefs
from resources.lib.sources.source_picker import is_stream_url_viable_quick
from resources.lib.sources.source_language import autoplay_resolve_bucket_ids
from resources.lib.sources.source_rotation import (
    remember_pick,
    rotate_candidates_order,
    rotation_enabled,
    last_fingerprint_for,
)
from resources.lib.ui.ui_helpers import _t


def pick_stream_dialog(
    title,
    candidates,
    *,
    playback_kind=None,
    rotation=None,
    candidates_deduped_for_picker,
    source_sort_key_with_language,
    get_bool_setting,
    get_setting,
    autoplay_url_by_language_priority,
    language_bucket_for_item,
    language_section_title,
    compact_origin,
    normalize_language_label,
    language_flag,
    pretty_source_line,
    quality_counts_colored,
    kraken_sources_dialog_cls,
    addon_path,
):
    clean = candidates_deduped_for_picker(candidates)
    clean = filter_candidates_by_source_prefs(clean, get_setting)
    if not clean:
        xbmc.log(
            f"[Kraken] {_t('Selector sin fuentes', 'Picker with no sources', 'Sélecteur sans sources', 'Selettore senza fonti', 'Auswahl ohne Quellen')}",
            xbmc.LOGWARNING,
        )
        return ""
    if len(clean) == 1:
        one = str(clean[0].get("url") or "").strip()
        if is_stream_url_viable_quick(one):
            if rotation and rotation.get("content_key") and rotation_enabled(
                rotation["get_bool_setting"]
            ):
                remember_pick(
                    rotation["set_setting"],
                    rotation["get_setting"],
                    rotation["content_key"],
                    clean[0],
                )
            _log_single = _t(
                "Selector autoelige unica fuente",
                "Picker auto-selects single source",
                "Le sélecteur choisit automatiquement la source unique",
                "Il selettore sceglie automaticamente l'unica fonte",
                "Auswahl wählt automatisch die einzige Quelle",
            )
            xbmc.log(f"[Kraken] {_log_single}: {one}", xbmc.LOGINFO)
            return one
        xbmc.log(
            f"[Kraken] {_t('Unica fuente descartada por precheck', 'Single source discarded by precheck', 'Source unique rejetée par le pré-contrôle', 'Fonte unica scartata dal precheck', 'Einzelquelle vom Vorab-Check verworfen')}: {one}",
            xbmc.LOGWARNING,
        )
        return ""

    clean.sort(key=source_sort_key_with_language)
    if rotation and rotation.get("content_key") and rotation_enabled(
        rotation["get_bool_setting"]
    ):
        last = last_fingerprint_for(
            rotation["get_setting"], rotation["content_key"]
        )
        if last:
            clean = rotate_candidates_order(clean, last)
    autoplay_on = get_bool_setting("autoplay_source_by_language")
    if autoplay_on:
        pk = str(playback_kind or "").strip().lower()
        if pk == "movie":
            autoplay_on = get_bool_setting("autoplay_movies_enabled")
        elif pk == "episode":
            autoplay_on = get_bool_setting("autoplay_series_enabled")

    if autoplay_on:
        primary_bid, secondary_bid = autoplay_resolve_bucket_ids(get_setting)
        auto_url = autoplay_url_by_language_priority(clean, primary_bid, secondary_bid)
        if auto_url and is_stream_url_viable_quick(auto_url):
            if rotation and rotation.get("content_key"):
                for it in clean:
                    if str((it or {}).get("url") or "").strip() == str(
                        auto_url
                    ).strip():
                        remember_pick(
                            rotation["set_setting"],
                            rotation["get_setting"],
                            rotation["content_key"],
                            it,
                        )
                        break
            xbmc.log(
                f"[Kraken] {_t('Autoplay idioma', 'Language autoplay', 'Lecture auto par langue', 'Autoplay per lingua', 'Sprach-Autoplay')}: primary={primary_bid} secondary={secondary_bid} -> ok",
                xbmc.LOGINFO,
            )
            return auto_url
        if auto_url:
            xbmc.log(
                f"[Kraken] {_t('Autoplay idioma descartado por precheck', 'Language autoplay discarded by precheck', 'Lecture auto par langue rejetée par le pré-contrôle', 'Autoplay per lingua scartato dal precheck', 'Sprach-Autoplay vom Vorab-Check verworfen')}: {auto_url}",
                xbmc.LOGWARNING,
            )
        xbmc.log(
            f"[Kraken] {_t('Autoplay idioma: sin match', 'Language autoplay: no match', 'Lecture auto langue : aucune correspondance', 'Autoplay lingua: nessuna corrispondenza', 'Sprach-Autoplay: kein Treffer')} (first={primary_bid}, second={secondary_bid}) -> dialog",
            xbmc.LOGINFO,
        )

    xbmc.sleep(200)
    xbmc.log(
        f"[Kraken] {_t('Selector mostrando', 'Picker showing', 'Sélecteur affichant', 'Selettore mostra', 'Auswahl zeigt')} {len(clean)} {_t('fuentes', 'sources', 'sources', 'fonti', 'Quellen')}",
        xbmc.LOGINFO,
    )
    bucket_counts = Counter(
        bid for _o, bid in (language_bucket_for_item(x) for x in clean)
    )
    rows = []
    prev_bucket = None
    for source_index, item in enumerate(clean):
        _b_order, bid = language_bucket_for_item(item)
        if bid != prev_bucket:
            nsec = bucket_counts.get(bid, 0)
            sec_title = language_section_title(bid)
            rows.append(
                {
                    "line1": f"[B][COLOR FFCC8800]-- {sec_title} --[/COLOR][/B]",
                    "line2": f"[COLOR gray]{nsec} {_t('fuente(s)', 'source(s)', 'source(s)', 'fonte/i', 'Quelle(n)')}[/COLOR]",
                    "bottom": "",
                    "selectable": False,
                }
            )
            prev_bucket = bid
        origin = compact_origin(item.get("origin"))
        q = str(item.get("quality") or "Auto")
        lng = normalize_language_label(
            item.get("language"),
            label=item.get("label"),
            title=item.get("title"),
            stream_url=item.get("url"),
        )
        lng_flag = language_flag(lng)
        line1 = pretty_source_line(item)
        line2 = f"[COLOR FF00BFFF]{origin}[/COLOR]   [COLOR FF00D1FF]{q}[/COLOR]   [COLOR FFFFF36B]{lng_flag}[/COLOR]"
        bottom = "{}: {}\n{}: {}\nURL: {}".format(
            _t("Proveedor", "Provider", "Fournisseur", "Provider", "Anbieter"),
            str(item.get("origin") or "—"),
            _t("Fuente", "Source", "Source", "Fonte", "Quelle"),
            str(item.get("label") or _t("Fuente", "Source", "Source", "Fonte", "Quelle")),
            str(item.get("url") or ""),
        )
        rows.append(
            {
                "line1": line1,
                "line2": line2,
                "bottom": bottom,
                "selectable": True,
                "source_index": source_index,
            }
        )
    dialog = kraken_sources_dialog_cls(
        "kraken_sources_dialog.xml",
        addon_path,
        "default",
        "1080i",
        dialog_title=title,
        dialog_subtitle=_t(
            "{n} fuentes  |  por idioma  |  {q}",
            "{n} sources  |  by language  |  {q}",
            "{n} sources  |  par langue  |  {q}",
            "{n} fonti  |  per lingua  |  {q}",
            "{n} Quellen  |  nach Sprache  |  {q}",
        ).format(n=len(clean), q=quality_counts_colored(clean)),
        rows=rows,
    )
    dialog.doModal()
    index = dialog.selected_index
    del dialog
    if index < 0:
        xbmc.log("[Kraken] Selector cancelado por usuario", xbmc.LOGINFO)
        return None
    xbmc.log(
        "[Kraken] Selector elige indice {} -> {}".format(index, clean[index]["url"]),
        xbmc.LOGINFO,
    )
    picked_url = clean[index]["url"]
    if rotation and rotation.get("content_key"):
        remember_pick(
            rotation["set_setting"],
            rotation["get_setting"],
            rotation["content_key"],
            clean[index],
        )
    return picked_url
