import re
from urllib.parse import parse_qs, unquote as _unquote_lang, urlparse

from resources.lib.core.language_prefs import preferred_text_lang_code

# Orden de secciones / sort: interfaz en inglés → English primero; resto (ES, FR, …)
# → Castellano → Latino → … (como antes).
_RANK_ES = {
    "castellano": 0,
    "latino": 1,
    "english": 2,
    "sub": 3,
    "multi": 4,
    "other_lang": 5,
    "unknown": 6,
}
_RANK_EN_FIRST = {
    "english": 0,
    "castellano": 1,
    "latino": 2,
    "sub": 3,
    "multi": 4,
    "other_lang": 5,
    "unknown": 6,
}


def _wbrx(token):
    """Token rodeado de no-letras (evita 'cast' en 'broadcast', 'lat' en 'relate')."""
    return re.compile(r"(?<![a-z])" + re.escape(token) + r"(?![a-z])", re.I)


def latino_hint_in_text(text):
    """Patrones habituales en labels Stremio/torrent (latino, no subcadenas sueltas)."""
    low = (text or "").strip().lower()
    if not low:
        return False
    if any(
        token in low
        for token in (
            "latino",
            "latin ",
            "latinos",
            "latam",
            "audio latino",
            "es-la",
            "es_la",
            "es-mx",
            "es_mx",
            "es-419",
            "[lat]",
            " lat ",
            " latin ",
            " latino ",
            "(lat)",
            "amzn dubs",
        )
    ):
        return True
    if re.search(r"(?<![a-z0-9])lat(?![a-z0-9])", low):
        return True
    return False


def castellano_hint_in_text(text):
    """Castellano / ESP / SPA en tags de release (Torrentio, indexers, Peerflix)."""
    low = (text or "").strip().lower()
    if not low:
        return False
    if foreign_audio_hint_in_text(low) and not strong_spanish_audio_hint_in_text(low):
        return False
    if _language_from_magnet_region_flags(text):
        return True
    if any(
        token in low
        for token in (
            "castellano",
            " español",
            "español",
            "espanol",
            "spanish",
            " spanish",
            "spaniard",
            "es-es",
            "es_es",
            "spain",
            "doblaje",
            "audiocastellano",
            "audio castellano",
            "multi español",
            "multiesp",
            "multi esp",
            "multi-spa",
            "multi.spa",
            "vod es",
            "webdl es",
            "nf esp",
            "nf.es",
            "nf es",
            "amzn esp",
            "amzn.es",
            "dsnp esp",
            "hmax esp",
            "hbo esp",
            "movistar",
            ".es.",
            "[es]",
            "(es)",
            "[spa]",
            "[esp]",
            ".spa.",
            ".esp.",
            "-es.",
            ".es-",
            "-es-",
            "dual es ",
            "es dual",
            "ac3 es",
            "dd5.1 es",
            "aac2.0 es",
            "5.1.es",
            "2.0.es",
            "atmos.es",
            "truehd.es",
            "audio-es",
            "audio_es",
            "es-audio",
            " es ",
            "spa.m",
            "-spa.",
            ".spa-",
            "-spa-",
            " esp.",
            " esp ",
            " esp-",
            " spa.",
            " spa ",
            "sub espa",
            "subs esp",
            "es.subs",
            " españ ",
        )
    ):
        return True
    if re.search(r"[\[\(](?:es|esp|spa|spain)[\]\)]", low, re.I):
        return True
    if _wbrx("cast").search(low):
        return True
    # SPA / ESP como código (evita "especially": la e tras "esp" rompe el límite).
    if re.search(r"(?<![a-z0-9])(?:spa|esp)(?![a-z])", low):
        return True
    return False


def strong_spanish_audio_hint_in_text(text):
    """Señales fuertes de audio ES; evita aceptar solo "Spanish subtitles"."""
    low = (text or "").strip().lower()
    if not low:
        return False
    if _language_from_magnet_region_flags(text):
        return True
    strong_tokens = (
        "castellano",
        "audio castellano",
        "audio español",
        "audio espanol",
        "audio spanish",
        "spanish audio",
        "español audio",
        "espanol audio",
        "spaniard",
        "es-es",
        "es_es",
        "spa.m",
        "multi-spa",
        "multi.spa",
        "multi esp",
        "multiesp",
        "vod es",
        "webdl es",
        "nf esp",
        "amzn esp",
        "dsnp esp",
        "hmax esp",
        "hbo esp",
        "ac3 es",
        "dd5.1 es",
        "aac2.0 es",
        "5.1.es",
        "2.0.es",
        "atmos.es",
        "truehd.es",
        "audio-es",
        "audio_es",
        "es-audio",
    )
    if any(token in low for token in strong_tokens):
        return True
    if re.search(r"[\[\(](?:es|esp|spa|spain)[\]\)]", low, re.I):
        return True
    if re.search(r"(?<![a-z0-9])(?:spa|esp)(?![a-z])", low):
        return True
    return False


def foreign_audio_hint_in_text(text):
    """Detecta fuentes claramente etiquetadas como audio extranjero."""
    low = (text or "").strip().lower()
    if not low:
        return False
    if any(flag in text for flag in ("\U0001f1f7\U0001f1fa", "\U0001f1fa\U0001f1e6", "\U0001f1ec\U0001f1e7", "\U0001f1fa\U0001f1f8")):
        return True
    foreign_tokens = (
        "russian",
        "ruso",
        "russo",
        "рус",
        "ukrainian",
        "ukrain",
        "ucraniano",
        "ucranian",
        "укра",
        "audio ru",
        "ru audio",
        "audio ua",
        "ua audio",
        "audio en",
        "en audio",
    )
    if any(token in low for token in foreign_tokens):
        return True
    if re.search(r"(?<![a-z0-9])(?:ru|rus|ua|ukr)(?![a-z0-9])", low):
        return True
    return False


def extra_text_from_stream_url(stream_url):
    """Query/path de URLs (debrid, directos) suele incluir el nombre del release."""
    u = str(stream_url or "").strip()
    if not u.startswith(("http://", "https://")):
        return ""
    out = []
    try:
        tail = urlparse(u).path.rsplit("/", 1)[-1]
        if len(tail) > 8 and "." in tail:
            out.append(_unquote_lang(tail))
    except Exception:
        pass
    try:
        qs = parse_qs(urlparse(u).query)
        for key in qs:
            kl = key.lower()
            if not any(
                x in kl for x in ("lang", "audio", "alang", "dl", "file", "title", "name")
            ):
                continue
            for val in qs[key]:
                vs = _unquote_lang(str(val).strip())
                if len(vs) > 2:
                    out.append(vs.lower())
    except Exception:
        pass
    return " ".join(out)


def finalize_stream_language(src_dict, stream_url=None):
    """Unifica idioma del addon + nombre de torrent + dn= del magnet para UI y buckets."""
    sd = src_dict if isinstance(src_dict, dict) else {}
    url = stream_url if stream_url is not None else sd.get("url")
    info = str(sd.get("info") or "").strip()
    raw = str(sd.get("_raw_text") or "").strip()
    if raw:
        info = (info + " " + raw).strip()
    ex = extra_text_from_stream_url(url)
    if ex:
        info = (info + " " + ex).strip()
    out = normalize_language_label(
        sd.get("language"),
        label=sd.get("label"),
        title=sd.get("title"),
        info=info,
        stream_url=url,
    )
    return str(out or "").strip() or "N/D"


def _text_hints_english(text):
    """
    Inglés sin falsos positivos tipo "torrent/rent" (-> "en") o "string" (-> "ing").
    """
    low = (text or "").lower()
    if not low.strip():
        return False
    if "english" in low:
        return True
    if re.search(r"\beng\b", low):
        return True
    if re.search(r"\[(?:en|eng)\]", low):
        return True
    if re.search(r"\((?:en|eng)\)", low):
        return True
    if re.search(r"\.(?:en|eng)\.", low):
        return True
    if re.search(r"(?<![a-z0-9])(?:en-us|en-gb)(?![a-z0-9])", low):
        return True
    if re.search(r"(?<![a-z0-9])en(?![a-z0-9])", low):
        return True
    if "ingl" in low or "ingles" in low:
        return True
    return False

_FLAG_LANG_ES = "\U0001f1ea\U0001f1f8"
_FLAG_LANG_MX = "\U0001f1f2\U0001f1fd"
_FLAG_LANG_AR = "\U0001f1e6\U0001f1f7"
_FLAG_LANG_CO = "\U0001f1e8\U0001f1f4"
_FLAG_LANG_VE = "\U0001f1fb\U0001f1ea"


def language_flag(language):
    lang = str(language or "").strip().lower()
    if lang in ("english",):
        return "EN"
    if lang in ("castellano",):
        return "CAST"
    if lang in ("latino",):
        return "LAT"
    if "lat" in lang:
        return "LAT"
    if "cast" in lang:
        return "CAST"
    if "spa" in lang or "span" in lang or "espa" in lang:
        return "ES"
    if "engl" in lang or lang == "en":
        return "EN"
    if "it" in lang:
        return "IT"
    if "fr" in lang:
        return "FR"
    if "pt" in lang:
        return "PT"
    if "de" in lang:
        return "DE"
    if "multi" in lang:
        return "MULTI"
    if "sub" in lang:
        return "SUB"
    return "N/D"


def _magnet_dn_plain(stream_url):
    u = str(stream_url or "").strip()
    if not u.startswith("magnet:"):
        return ""
    try:
        q = u.split("?", 1)[1]
    except IndexError:
        return ""
    for part in q.split("&"):
        if part.startswith("dn="):
            return _unquote_lang(part[3:].replace("+", " "))
    return ""


def _language_from_magnet_region_flags(blob):
    if not blob:
        return None
    if _FLAG_LANG_ES in blob:
        return "Castellano"
    if any(
        f in blob for f in (_FLAG_LANG_MX, _FLAG_LANG_AR, _FLAG_LANG_CO, _FLAG_LANG_VE)
    ):
        return "Latino"
    return None


def normalize_language_label(
    language, provider_name="", label="", title="", info="", stream_url=""
):
    """
    Nota: `provider_name` no se usa para inferir idioma. Incluir "Torrentio" / URLs de
    addons solía activar la regla vieja "en" in texto por subcadenas ("rent", "torrent").
    """
    _ = provider_name  # API estable; no usar (véase docstring).
    bits = [
        str(language or ""),
        str(label or ""),
        str(title or ""),
        str(info or ""),
    ]
    dn = _magnet_dn_plain(stream_url)
    if dn:
        bits.append(dn)
    exu = extra_text_from_stream_url(stream_url)
    if exu:
        bits.append(exu)
    banner = " ".join(bits).strip()
    flagged = _language_from_magnet_region_flags(banner)
    if flagged:
        return flagged
    text = banner.lower()
    if foreign_audio_hint_in_text(banner) and not strong_spanish_audio_hint_in_text(banner):
        if _text_hints_english(text):
            return "English"
        return "Other"
    if "vose" in text or "vos " in text:
        return "Sub"
    if latino_hint_in_text(text):
        return "Latino"
    if castellano_hint_in_text(text):
        return "Castellano"
    if (
        "_es" in text
        or "español" in text
        or "espanol" in text
        or "spanish" in text
    ):
        return "Castellano"
    if "sub" in text:
        return "Sub"
    if "multi" in text:
        return "Multi"
    if _text_hints_english(text):
        return "English"
    if "fr" in text:
        return "French"
    if "it" in text:
        return "Italian"
    if "pt" in text:
        return "Portuguese"
    if "de" in text:
        return "German"
    return "N/D"


def language_bucket_from_normalized(lng):
    """
    Asigna bucket_id y una clave de orden según el idioma de la interfaz de Kodi:
    interfaz en inglés → English primero; interfaz en castellano (u otras) → Castellano primero,
    luego el resto en el mismo orden relativo (Sub, Multi, otros, desconocido).
    """
    n = str(lng or "").strip()
    if n == "Castellano":
        bid = "castellano"
    elif n == "Latino":
        bid = "latino"
    elif n == "English":
        bid = "english"
    elif n == "Sub":
        bid = "sub"
    elif n == "Multi":
        bid = "multi"
    elif n and n not in ("N/D",):
        bid = "other_lang"
    else:
        bid = "unknown"
    ui = preferred_text_lang_code()
    rank_map = _RANK_EN_FIRST if ui == "en" else _RANK_ES
    return rank_map.get(bid, 99), bid


def language_bucket_for_item(item, normalize_language_label_fn):
    info = " ".join(
        str(item.get(k) or "")
        for k in ("info", "_raw_text", "raw_text")
    ).strip()
    language = item.get("language")
    if info and foreign_audio_hint_in_text(info) and not strong_spanish_audio_hint_in_text(info):
        language = ""
    lng = normalize_language_label_fn(
        language,
        provider_name=item.get("origin"),
        label=item.get("label"),
        title=item.get("title"),
        info=info,
        stream_url=item.get("url"),
    )
    return language_bucket_from_normalized(lng)


def language_section_title(bucket_id):
    return {
        "castellano": "Castellano",
        "latino": "Latino",
        "english": "Inglés",
        "sub": "Sub / VOSE",
        "multi": "Multi",
        "other_lang": "Otros idiomas",
        "unknown": "Desconocido",
    }.get(bucket_id, "Desconocido")


def source_sort_key_with_language(
    item, language_bucket_for_item_fn, source_order_rank_fn, preferred_bucket_ids=None
):
    b_order, _bid = language_bucket_for_item_fn(item)
    if preferred_bucket_ids:
        preferred = {}
        for pos, bid in enumerate(preferred_bucket_ids):
            if bid and bid not in preferred:
                preferred[bid] = pos
        if _bid in preferred:
            b_order = preferred[_bid]
        else:
            b_order = len(preferred) + b_order
    return (b_order, source_order_rank_fn(item))


def setting_lang_to_bucket_id(label):
    t = (label or "").strip().lower()
    t = t.replace("í", "i").replace("é", "e")
    if not t:
        return None
    # Valor guardado = texto traducido del labelenum (#30186 "Any", etc.)
    if "cual" in t:
        return None
    if t in ("any", "qualsiasi") or "beliebig" in t:
        return None
    if "importe" in t and "quel" in t:
        return None
    if "cast" in t or t == "es":
        return "castellano"
    if t.startswith("ingl") or t in ("ingles", "english", "en"):
        return "english"
    if t.startswith("lat"):
        return "latino"
    if t.startswith("sub"):
        return "sub"
    return None


def autoplay_resolve_bucket_ids(get_setting):
    """
    Resuelve idiomas de autoplay: «Cualquiera» usa el idioma de interfaz de Kodi
    (en → inglés + castellano de respaldo; es → castellano + latino).
    """
    p_bid = setting_lang_to_bucket_id(get_setting("autoplay_lang_primary") or "")
    s_bid = setting_lang_to_bucket_id(get_setting("autoplay_lang_secondary") or "")
    ui = preferred_text_lang_code()
    if p_bid is None:
        if ui == "en":
            p_bid = "english"
        elif ui == "es":
            p_bid = "castellano"
        else:
            p_bid = "castellano"
    if s_bid is None:
        if ui == "en":
            s_bid = "castellano"
        elif ui == "es":
            s_bid = "latino"
        else:
            s_bid = "latino"
    return p_bid, s_bid
