import xbmc


def run_noop():
    xbmc.log("[Kraken] noop: non-interactive item", xbmc.LOGDEBUG)


def run_providers_view_route(
    *, run_providers_view, plugin_handle, get_enabled_providers, url_for_noop
):
    run_providers_view(
        plugin_handle=plugin_handle,
        get_enabled_providers=get_enabled_providers,
        url_for_noop=url_for_noop,
    )


def run_providers_check_route(
    *,
    run_providers_check,
    plugin_handle,
    get_enabled_providers,
    get_bool_setting,
    get_setting,
    set_setting,
    addon_installed,
    load_scraper_module,
    json_get,
):
    run_providers_check(
        plugin_handle=plugin_handle,
        get_enabled_providers=get_enabled_providers,
        get_bool_setting=get_bool_setting,
        get_setting=get_setting,
        set_setting=set_setting,
        addon_installed=addon_installed,
        load_scraper_module=load_scraper_module,
        json_get=json_get,
    )


def run_settings_route(
    *,
    run_settings,
    plugin_handle,
    addon,
    default_list_art,
    url_for_views_menu,
    url_for_maintenance_menu,
    url_for_open_kodi_addon_settings,
    url_for_experience_menu=None,
):
    run_settings(
        plugin_handle=plugin_handle,
        addon=addon,
        default_list_art=default_list_art,
        url_for_views_menu=url_for_views_menu,
        url_for_maintenance_menu=url_for_maintenance_menu,
        url_for_open_kodi_addon_settings=url_for_open_kodi_addon_settings,
        url_for_experience_menu=url_for_experience_menu,
    )


def run_stremio_open_config_route(
    *,
    run_stremio_open_config,
    addon_key,
    peerflix_web_url,
    get_setting,
    addon_path,
    qr_dialog_cls,
):
    run_stremio_open_config(
        addon_key=addon_key,
        peerflix_web_url=peerflix_web_url,
        get_setting=get_setting,
        addon_path=addon_path,
        qr_dialog_cls=qr_dialog_cls,
    )


def run_stremio_open_all_configs_route(
    *,
    run_stremio_open_all_configs,
    stremio_addons_config,
    stremio_open_all_peerflix,
    peerflix_web_url,
    get_setting,
    addon_path,
    qr_dialog_cls,
):
    run_stremio_open_all_configs(
        stremio_addons_config=stremio_addons_config,
        stremio_open_all_peerflix=stremio_open_all_peerflix,
        peerflix_web_url=peerflix_web_url,
        get_setting=get_setting,
        addon_path=addon_path,
        qr_dialog_cls=qr_dialog_cls,
    )


def run_accounts_status_route(
    *,
    run_accounts_status,
    get_bool_setting,
    get_setting,
    get_stremio_toggle_names,
    tmdb_enabled,
    omdb_enabled,
    addon_path,
    qr_dialog_cls,
):
    run_accounts_status(
        get_bool_setting=get_bool_setting,
        get_setting=get_setting,
        get_stremio_toggle_names=get_stremio_toggle_names,
        tmdb_enabled=tmdb_enabled,
        omdb_enabled=omdb_enabled,
        addon_path=addon_path,
        qr_dialog_cls=qr_dialog_cls,
    )
