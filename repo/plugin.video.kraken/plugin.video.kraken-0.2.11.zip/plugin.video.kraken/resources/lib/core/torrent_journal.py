"""Registro local de torrents/magnets reproducidos o elegidos para descarga."""

import json
import os
import time
from urllib.parse import parse_qs, unquote, urlparse

import xbmc
import xbmcaddon
import xbmcvfs

_JOURNAL_NAME = "torrent_journal.json"
_MAX_ITEMS = 300


def _profile_journal_path():
    try:
        add = xbmcaddon.Addon()
        prof = add.getAddonInfo("profile")
        base = xbmcvfs.translatePath(prof) if prof else ""
    except Exception:
        base = ""
    if not base:
        return ""
    if not os.path.isdir(base):
        try:
            os.makedirs(base, exist_ok=True)
        except OSError:
            return ""
    return os.path.join(base, _JOURNAL_NAME)


def _torrent_like(url):
    raw = str(url or "").strip()
    low = raw.lower()
    return raw.startswith("magnet:") or low.endswith(".torrent") or ".torrent?" in low


def title_from_torrent_url(url, fallback="Torrent"):
    raw = str(url or "").strip()
    if raw.startswith("magnet:"):
        try:
            qs = parse_qs(raw.split("?", 1)[1])
            dn = str((qs.get("dn") or [""])[0] or "").strip()
            if dn:
                return unquote(dn.replace("+", " "))[:180]
        except Exception:
            pass
        return fallback
    try:
        tail = os.path.basename(urlparse(raw).path or "").strip()
        if tail:
            return unquote(tail)[:180]
    except Exception:
        pass
    return fallback


def load_journal():
    path = _profile_journal_path()
    if not path or not os.path.isfile(path):
        return {"version": 1, "items": []}
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict) and isinstance(data.get("items"), list):
            return data
    except Exception as err:
        xbmc.log(f"[Kraken][torrent-journal] read: {err}", xbmc.LOGDEBUG)
    return {"version": 1, "items": []}


def save_journal(data):
    path = _profile_journal_path()
    if not path:
        return False
    try:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=True, indent=0)
        try:
            if os.path.isfile(path):
                os.remove(path)
        except OSError:
            pass
        os.replace(tmp, path)
        return True
    except Exception as err:
        xbmc.log(f"[Kraken][torrent-journal] save: {err}", xbmc.LOGWARNING)
        return False


def append_entry(*, url, title="", kind="", action="played"):
    raw = str(url or "").strip()
    if not raw or not _torrent_like(raw):
        return False
    act = str(action or "").strip().lower()
    if act not in ("played", "download"):
        act = "played"
    entry = {
        "url": raw,
        "title": str(title or "").strip() or title_from_torrent_url(raw),
        "kind": str(kind or "").strip().lower(),
        "action": act,
        "added": time.time(),
    }
    data = load_journal()
    items = list(data.get("items") or [])
    # Evita crecer con duplicados seguidos del mismo magnet/torrent.
    items = [
        x
        for x in items
        if str((x or {}).get("url") or "").strip() != raw
        or str((x or {}).get("action") or "").strip().lower() != act
    ]
    items.insert(0, entry)
    data["items"] = items[:_MAX_ITEMS]
    return save_journal(data)


def items():
    return list((load_journal().get("items") or []))


def get_item(index):
    try:
        idx = int(index)
    except (TypeError, ValueError):
        return None
    rows = items()
    if idx < 0 or idx >= len(rows):
        return None
    row = rows[idx]
    return row if isinstance(row, dict) else None
