"""Rutas plugin://…/descargas y /download/… — guardar HTTP directo en disco."""

import io
import os
import ssl
import time
from urllib.parse import quote, unquote
from urllib.request import Request, urlopen

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib.core.download_journal import append_entry, filter_items, journal_resolved_isfile
from resources.lib.core.playback_source_stash import stash_source_candidates
from resources.lib.core.torrent_journal import append_entry as append_torrent_entry
from resources.lib.core.torrent_journal import items as torrent_journal_items
from resources.lib.core.torrent_journal import title_from_torrent_url
from resources.lib.sources.resolver_progress import (
    RESOLVER_PROGRESS_PHASE,
    resolver_progress_detail,
)
from resources.lib.ui.ui_helpers import _t
from resources.lib.ui.ui_helpers import kraken_progress

_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)
_BAD_FS = '<>:"/\\|?*'


def _translate_path(fs):
    p = str(fs or "").strip()
    if not p:
        return ""
    try:
        return xbmcvfs.translatePath(p)
    except Exception:
        return p


def _safe_filename(label, maxlen=155):
    s = "".join("_" if c in _BAD_FS else c for c in str(label or "").strip()).strip()
    s = "_".join(s.split()) or "Kraken_download"
    if len(s) > maxlen:
        s = s[:maxlen].rstrip("_.")
    return s


def _unique_path(dest_abs):
    if not os.path.isfile(dest_abs):
        return dest_abs
    root, ext = os.path.splitext(dest_abs)
    n = 2
    cand = f"{root}_{n}{ext}"
    while os.path.isfile(cand):
        n += 1
        cand = f"{root}_{n}{ext}"
    return cand


def _torrent_like(url):
    raw = str(url or "").strip()
    if not raw:
        return False
    low = raw.lower()
    if raw.startswith("magnet:"):
        return True
    return low.endswith(".torrent") or ".torrent?" in low


def _journal_kind_show(show_dict):
    try:
        for g in (show_dict or {}).get("genres") or []:
            if str(g.get("slug") or g.get("name") or "").lower().find("anime") >= 0:
                return "anime"
    except Exception:
        pass
    return "series"


def _guess_ext(resp, fallback_base):
    try:
        cd = resp.headers.get("Content-Disposition") or ""
        if "filename=" in cd:
            fn = cd.split("filename=", 1)[1].strip().strip('"').split(";")[0]
            _, ext = os.path.splitext(fn)
            if ext and len(ext) <= 8:
                return ext.lower()
    except Exception:
        pass
    low = fallback_base.lower()
    for suf in (
        ".mp4",
        ".mkv",
        ".avi",
        ".mov",
        ".webm",
        ".mpeg",
        ".mpg",
        ".m4v",
    ):
        if low.endswith(suf):
            return suf
    try:
        ct = str(resp.headers.get("Content-Type") or "").split(";")[0].lower().strip()
        mapping = (
            ("video/mp4", ".mp4"),
            ("video/x-matroska", ".mkv"),
            ("video/x-msvideo", ".avi"),
            ("video/quicktime", ".mov"),
            ("video/webm", ".webm"),
        )
        for k, suf in mapping:
            if ct == k:
                return suf
    except Exception:
        pass
    return ".mp4"


def _headers_for_pick(candidates, picked_url):
    want = str(picked_url or "").strip()
    for ent in candidates or []:
        if not isinstance(ent, dict):
            continue
        if str(ent.get("url") or "").strip() == want:
            h = ent.get("http_headers")
            return h if isinstance(h, dict) and h else None
    return None


def _stream_is_non_file_http(url):
    low = str(url or "").strip().lower()
    if not low.startswith(("http://", "https://")):
        return True
    if any(x in low for x in (".m3u8", ".mpd", "playlist.m3u8", "/manifest", "manifest.mpd")):
        return True
    return False


def _save_stream_url_to_local(
    url,
    target_fs,
    *,
    heading="Kraken",
    message="",
    http_headers=None,
    notify=True,
):
    """
    Descarga HTTP(S) binaria completa en target_fs.

    Recovery y descargas usan esta firma: (bool ok, path_fs traducido, bytes).
    """
    base_raw = str(url or "").strip().split("|", 1)[0].strip()
    if not base_raw.startswith(("http://", "https://")):
        xbmcgui.Dialog().notification(
            "Kraken",
            _t(
                "La URL guardada debe ser HTTP/HTTPS.",
                "Saved URL must be HTTP/HTTPS.",
                "URL HTTP/HTTPS requise.",
                "Serve un URL HTTP/HTTPS.",
                "URL muss HTTP/HTTPS sein.",
            ),
            xbmcgui.NOTIFICATION_WARNING,
            4800,
        )
        return False, "", 0

    tgt = _translate_path(target_fs).strip()
    if not tgt:
        return False, "", 0
    dirname = os.path.dirname(tgt) or tgt
    try:
        if dirname and not os.path.isdir(dirname):
            os.makedirs(dirname, exist_ok=True)
    except OSError:
        pass

    from resources.lib.core.download_active import begin as _dabegin
    from resources.lib.core.download_active import finish as _dafinish
    from resources.lib.core.download_active import update as _daupdate

    did = None
    try:
        did = _dabegin(str(heading or "Kraken")[:110], str(message or base_raw)[:180])
    except Exception:
        did = None

    req_headers = dict(http_headers or {}) if isinstance(http_headers, dict) else {}
    if not any(str(k).lower() == "user-agent" for k in req_headers):
        req_headers["User-Agent"] = _AGENT
    rq = Request(base_raw, headers=req_headers)

    nbytes = 0
    fh = None
    try:
        ctx = ssl.create_default_context()
        resp = urlopen(rq, timeout=90, context=ctx)
        ext = _guess_ext(resp, base_raw)
        root, tail_ext = os.path.splitext(tgt)
        if not tail_ext or len(tail_ext) > 6:
            tgt = root + ext
            tgt = _unique_path(_translate_path(tgt))
            dirname = os.path.dirname(tgt) or dirname
            if dirname and not os.path.isdir(dirname):
                os.makedirs(dirname, exist_ok=True)
        elif not os.path.splitext(os.path.basename(tgt))[1]:
            tgt = tgt + ext
        tgt = _unique_path(_translate_path(tgt))

        total_hdr = ""
        try:
            total_hdr = resp.headers.get("Content-Length") or ""
            total_expect = int(str(total_hdr).strip()) if str(total_hdr).isdigit() else 0
        except (TypeError, ValueError):
            total_expect = 0

        fh = io.open(tgt, "wb", buffering=0)
        blk = 256 * 1024
        while True:
            chunk = resp.read(blk)
            if not chunk:
                break
            nbytes += len(chunk)
            fh.write(chunk)
            if did and total_expect > 0:
                try:
                    pct = max(1, min(99, int(nbytes * 100 / total_expect)))
                except ZeroDivisionError:
                    pct = 1
                _daupdate(did, pct)

        fh.flush()
        try:
            os.fsync(fh.fileno())
        except (OSError, AttributeError):
            pass
        fh.close()
        fh = None
        resp.close()

        fs_out = tgt
        if nbytes < 1024:
            try:
                if os.path.isfile(fs_out):
                    os.remove(fs_out)
            except OSError:
                pass
            raise RuntimeError("archivo muy pequeño")

        if did:
            _dafinish(did)
        if notify:
            try:
                xbmcgui.Dialog().notification(
                    "Kraken",
                    _t(
                        "Descarga finalizada.",
                        "Download finished.",
                        "Telechargement termine.",
                        "Download completato.",
                        "Download abgeschlossen.",
                    ),
                    xbmcgui.NOTIFICATION_INFO,
                    4300,
                )
            except Exception:
                pass
        return True, fs_out, nbytes
    except Exception as err:
        xbmc.log(f"[Kraken] download save: {err}", xbmc.LOGWARNING)
        try:
            if fh:
                fh.close()
        except Exception:
            pass
        try:
            if tgt and os.path.isfile(tgt) and nbytes == 0:
                os.remove(tgt)
        except OSError:
            pass
        if did:
            try:
                _dafinish(did)
            except Exception:
                pass
        return False, "", 0


def _movie_title_for_journal(rid, trakt_public_get):
    rs = str(rid or "").strip()
    try:
        if rs.startswith("trakt::movie::"):
            tid = rs.split("::")[-1]
            md = trakt_public_get(
                f"https://api.trakt.tv/movies/{quote(str(tid), safe='')}?extended=full"
            )
            return str((md or {}).get("title") or f"movie-{tid}").strip() or f"movie-{tid}"
        if rs.startswith("fallback::movie::"):
            parts = rs.split("::", 3)
            return _safe_filename(unquote(parts[3]) if len(parts) > 3 else "movie") or "movie"
    except Exception:
        pass
    return _safe_filename("movie")


def run_downloads_hub(
    *,
    plugin_handle,
    default_list_art,
    url_for_downloads_category,
    url_for_downloads_active,
    url_for_downloads_torrents,
    url_for_downloads_subtitles=None,
    url_for_downloads_failures=None,
    url_for_downloads_continue=None,
):
    art = dict(default_list_art() or {})

    rows = []

    rows.append(
        (
            (
                url_for_downloads_category("all"),
                xbmcgui.ListItem(
                    label=_t("Todas", "All", "Toutes", "Tutti", "Alle"),
                    label2=_t(
                        "Películas, series y anime",
                        "Movies, TV and anime",
                        "Films, series et anime",
                        "Film, serie e anime",
                        "Filme, Serien und Anime",
                    ),
                ),
                True,
            )
        ),
    )

    rows.append(
        (
            (
                url_for_downloads_category("movie"),
                xbmcgui.ListItem(
                    label=_t("Películas", "Movies", "Films", "Film", "Filme"),
                    label2=_t(
                        "Solo películas",
                        "Movies only",
                        "Films seulement",
                        "Solo film",
                        "Nur Filme",
                    ),
                ),
                True,
            )
        ),
    )

    rows.append(
        (
            (
                url_for_downloads_category("series"),
                xbmcgui.ListItem(
                    label=_t("Series", "TV shows", "Séries", "Serie TV", "Serien"),
                    label2=_t(
                        "Series (no anime)",
                        "TV shows (non-anime)",
                        "Series (sans anime)",
                        "Serie (no anime)",
                        "Serien (ohne Anime)",
                    ),
                ),
                True,
            )
        ),
    )

    rows.append(
        (
            (
                url_for_downloads_category("anime"),
                xbmcgui.ListItem(label="Anime"),
                True,
            )
        ),
    )

    rows.append(
        (
            (
                url_for_downloads_active(),
                xbmcgui.ListItem(
                    label=_t("En curso", "Active", "En cours", "In corso", "Aktiv"),
                    label2=_t(
                        "Descargas HTTP en progreso",
                        "HTTP downloads in progress",
                        "Telechargements HTTP en cours",
                        "Download HTTP in corso",
                        "HTTP-Downloads laufen",
                    ),
                ),
                True,
            )
        ),
    )

    rows.append(
        (
            (
                url_for_downloads_torrents(),
                xbmcgui.ListItem(
                    label=_t(
                        "Torrents reproducidos/descargados",
                        "Played/downloaded torrents",
                        "Torrents lus/telecharges",
                        "Torrent riprodotti/scaricati",
                        "Abgespielte/heruntergeladene Torrents",
                    ),
                    label2=_t(
                        "Historial de magnets y .torrent usados por Kraken",
                        "History of magnets and .torrent files used by Kraken",
                        "Historique magnets et .torrent utilises par Kraken",
                        "Storico magnet e .torrent usati da Kraken",
                        "Historie der von Kraken genutzten Magnet- und .torrent-Quellen",
                    ),
                ),
                True,
            )
        ),
    )

    if callable(url_for_downloads_subtitles):
        rows.append(
            (
                url_for_downloads_subtitles(),
                xbmcgui.ListItem(
                    label=_t("Subtítulos locales", "Local subtitles", "Sous-titres locaux", "Sottotitoli locali", "Lokale Untertitel"),
                    label2=_t("Subtítulos descargados o traducidos por Kraken", "Subtitles downloaded or translated by Kraken", "Sous-titres téléchargés ou traduits par Kraken", "Sottotitoli scaricati o tradotti da Kraken", "Von Kraken geladene oder übersetzte Untertitel"),
                ),
                True,
            )
        )

    if callable(url_for_downloads_failures):
        rows.append(
            (
                url_for_downloads_failures(),
                xbmcgui.ListItem(
                    label=_t("Fallos recientes", "Recent failures", "Échecs récents", "Errori recenti", "Letzte Fehler"),
                    label2=_t("Últimos errores Kraken detectados en kodi.log", "Latest Kraken errors detected in kodi.log", "Dernières erreurs Kraken détectées dans kodi.log", "Ultimi errori Kraken rilevati in kodi.log", "Letzte Kraken-Fehler aus kodi.log"),
                ),
                True,
            )
        )

    if callable(url_for_downloads_continue):
        rows.append(
            (
                url_for_downloads_continue(),
                xbmcgui.ListItem(
                    label=_t("Continuar viendo", "Continue watching", "Continuer à regarder", "Continua a guardare", "Weiterschauen"),
                    label2=_t("Accesos a películas, series y anime sin finalizar", "Shortcuts to unfinished movies, TV shows and anime", "Accès aux films, séries et anime non terminés", "Scorciatoie a film, serie e anime non terminati", "Zugriffe auf nicht abgeschlossene Filme, Serien und Anime"),
                ),
                True,
            )
        )

    flat = []
    for pack in rows:
        if not isinstance(pack, tuple):
            continue
        if len(pack) == 1 and isinstance(pack[0], tuple):
            pack = pack[0]
        try:
            u, li, fld = pack
        except ValueError:
            continue
        try:
            li.setArt(art)
        except Exception:
            pass
        flat.append((u, li, fld))
    try:
        xbmcplugin.addDirectoryItems(plugin_handle, flat, len(flat))
        xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)
    except Exception:
        try:
            xbmcplugin.endOfDirectory(plugin_handle, succeeded=False)
        except Exception:
            pass


def run_downloads_active(
    *,
    plugin_handle,
    default_list_art,
    url_for_noop,
):
    from resources.lib.core.download_active import snapshot

    art = dict(default_list_art() or {})
    snap = snapshot() or []

    rows = []

    rows.append(
        (
            (
                url_for_noop(),
                xbmcgui.ListItem(
                    label=_t("(Vacio)", "(Empty)", "(Vide)", "(Vuoto)", "(Leer)"),
                    label2=_t(
                        "Nada registrado en segundo plano",
                        "Nothing in background tracker",
                        "Rien dans le suivi",
                        "Nulla nella coda locale",
                        "Nicht vorgemerkt",
                    ),
                ),
                False,
            )
        )
        if not snap else []
    )

    for row in snap:
        title = str((row or {}).get("title") or "…").strip()
        pct = int((row or {}).get("pct") or 0)
        det = str((row or {}).get("detail") or "").strip()
        rows.append(
            (
                (
                    url_for_noop(),
                    xbmcgui.ListItem(
                        label=f"{title}  [{pct}%]",
                        label2=det[:255],
                    ),
                    False,
                )
            ),
        )

    flat = []
    for pack in rows:
        if not isinstance(pack, tuple):
            continue
        try:
            u, li, fld = pack
        except ValueError:
            continue
        try:
            li.setArt(art)
        except Exception:
            pass
        flat.append((u, li, fld))

    xbmcplugin.addDirectoryItems(plugin_handle, flat, len(flat))
    xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)


def run_downloads_torrents(
    *,
    plugin_handle,
    default_list_art,
    url_for_torrent_play,
    url_for_noop,
):
    art = dict(default_list_art() or {})
    rows = []
    entries = torrent_journal_items()
    if not entries:
        rows.append(
            (
                url_for_noop(),
                xbmcgui.ListItem(
                    label=_t(
                        "(Vacío)",
                        "(Empty)",
                        "(Vide)",
                        "(Vuoto)",
                        "(Leer)",
                    ),
                    label2=_t(
                        "Aún no hay torrents reproducidos o seleccionados para descarga.",
                        "No torrents played or selected for download yet.",
                        "Aucun torrent lu ou selectionne pour telechargement.",
                        "Nessun torrent riprodotto o selezionato per il download.",
                        "Noch keine abgespielten oder zum Download gewaehlten Torrents.",
                    ),
                ),
                False,
            )
        )
    else:
        for idx, ent in enumerate(entries):
            raw_url = str((ent or {}).get("url") or "").strip()
            title = str((ent or {}).get("title") or "").strip()
            if not title:
                title = title_from_torrent_url(raw_url, "Torrent")
            action = str((ent or {}).get("action") or "").strip().lower()
            action_label = (
                _t("Descarga", "Download", "Telechargement", "Download", "Download")
                if action == "download"
                else _t("Reproducido", "Played", "Lu", "Riprodotto", "Abgespielt")
            )
            li = xbmcgui.ListItem(
                label=title[:255],
                label2=f"{action_label} · {raw_url[:220]}",
            )
            li.setProperty("IsPlayable", "true")
            try:
                li.setContentLookup(False)
                li.setArt(art)
            except Exception:
                pass
            rows.append((url_for_torrent_play(str(idx)), li, False))

    xbmcplugin.addDirectoryItems(plugin_handle, rows, len(rows))
    xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)


def _profile_dir():
    try:
        import xbmcaddon

        prof = xbmcaddon.Addon().getAddonInfo("profile")
        return _translate_path(prof)
    except Exception:
        return ""


def run_downloads_subtitles(*, plugin_handle, default_list_art, url_for_noop):
    art = dict(default_list_art() or {})
    base = _profile_dir()
    root = os.path.join(base, "translated_subtitles") if base else ""
    rows = []
    files = []
    if root and os.path.isdir(root):
        try:
            for name in sorted(os.listdir(root), reverse=True):
                if name.lower().endswith((".srt", ".sub", ".vtt", ".ass", ".ssa")):
                    full = os.path.join(root, name)
                    files.append((name, full, os.path.getmtime(full)))
        except Exception:
            files = []
    if not files:
        rows.append(
            (
                url_for_noop(),
                xbmcgui.ListItem(
                    label=_t("(Vacío)", "(Empty)", "(Vide)", "(Vuoto)", "(Leer)"),
                    label2=_t("No hay subtítulos traducidos en caché.", "No translated subtitles in cache.", "Aucun sous-titre traduit en cache.", "Nessun sottotitolo tradotto in cache.", "Keine übersetzten Untertitel im Cache."),
                ),
                False,
            )
        )
    for name, full, mtime in files[:200]:
        label2 = time.strftime("%Y-%m-%d %H:%M", time.localtime(mtime))
        li = xbmcgui.ListItem(label=name[:255], label2=label2)
        li.setProperty("IsPlayable", "false")
        li.setArt(art)
        rows.append((url_for_noop(), li, False))
    xbmcplugin.addDirectoryItems(plugin_handle, rows, len(rows))
    xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)


def _recent_kraken_errors(limit=30):
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
    except Exception:
        log_path = ""
    if not log_path:
        return []
    try:
        with open(log_path, encoding="utf-8", errors="ignore") as fh:
            lines = fh.readlines()[-1500:]
    except Exception:
        return []
    out = []
    for line in reversed(lines):
        low = line.lower()
        if "kraken" in low and ("error" in low or "exception" in low or "traceback" in low):
            out.append(line.strip())
            if len(out) >= limit:
                break
    return out


def run_downloads_failures(*, plugin_handle, default_list_art, url_for_noop):
    art = dict(default_list_art() or {})
    rows = []
    errors = _recent_kraken_errors()
    if not errors:
        errors = [_t("Sin fallos recientes Kraken.", "No recent Kraken failures.", "Aucun échec Kraken récent.", "Nessun errore Kraken recente.", "Keine aktuellen Kraken-Fehler.")]
    for line in errors:
        li = xbmcgui.ListItem(label=str(line)[:255], label2=str(line)[255:510])
        li.setProperty("IsPlayable", "false")
        li.setArt(art)
        rows.append((url_for_noop(), li, False))
    xbmcplugin.addDirectoryItems(plugin_handle, rows, len(rows))
    xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)


def run_downloads_continue(*, plugin_handle, default_list_art, url_for_movies, url_for_series, url_for_anime):
    art = dict(default_list_art() or {})
    rows = []
    for url, label in (
        (url_for_movies(), _t("Películas sin finalizar", "Unfinished movies", "Films non terminés", "Film non finiti", "Nicht beendete Filme")),
        (url_for_series(), _t("Series en seguimiento", "Shows in progress", "Séries en cours", "Serie in corso", "Serien in Bearbeitung")),
        (url_for_anime(), _t("Anime en seguimiento", "Anime in progress", "Anime en cours", "Anime in corso", "Anime in Bearbeitung")),
    ):
        li = xbmcgui.ListItem(label=label)
        li.setProperty("IsPlayable", "false")
        li.setArt(art)
        rows.append((url, li, True))
    xbmcplugin.addDirectoryItems(plugin_handle, rows, len(rows))
    xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)


def run_downloads_list(
    *,
    plugin_handle,
    default_list_art,
    kind_slug,
    url_for_noop,
):
    art = dict(default_list_art() or {})
    ks = str(kind_slug or "all").strip().lower()

    filt = ks
    if ks in ("all", "todas", "*"):
        filt = "all"
    elif ks in ("movie", "peliculas", "película", "peliculas", "movies", "film", "pelis"):
        filt = "movie"
    elif ks in ("serie", "series", "shows", "tv"):
        filt = "series"
    elif ks == "anime":
        filt = "anime"
    elif ks not in ("movie", "series", "anime", "all"):
        filt = "all"

    items = filter_items(filt)
    rows = []
    rows.append(
        (
            (
                url_for_noop(),
                xbmcgui.ListItem(
                    label=_t(
                        "Registro Kraken…",
                        "Kraken registry…",
                        "Journal Kraken…",
                        "Registro Kraken…",
                        "Kraken Journal…",
                    ),
                    label2=(
                        _t(
                            "{} fichero(s) listado(s)",
                            "{} listed file(s)",
                            "{} fichier(s)",
                            "{} file in elenco",
                            "{} Eintraege",
                        ).format(len(items))
                    ),
                ),
                False,
            ),
        ),
    )

    for ent in items:
        if not isinstance(ent, dict):
            continue
        p = str((ent.get("path") or "")).strip()
        ttl = str((ent.get("title") or "").strip()) or os.path.basename(p)

        playable = journal_resolved_isfile(p)

        rows.append(
            (
                (
                    p if playable else url_for_noop(),
                    xbmcgui.ListItem(
                        label=ttl[:255],
                        label2=p[-255:] if p else "",
                    ),
                    False,
                )
            ),
        )

    flat = []
    for pack in rows:
        u, li, fld = pack[0], pack[1], pack[2]
        try:
            li.setArt(art)
        except Exception:
            pass
        try:
            if str(u).strip().startswith("http"):
                pass
            if os.path.sep in str(u) or str(u).lower().startswith("smb:"):
                li.setProperty("IsPlayable", "true")
                li.setContentLookup(False)
        except Exception:
            pass
        flat.append((u, li, fld))

    xbmcplugin.addDirectoryItems(plugin_handle, flat, len(flat))
    xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)


def _resolve_candidates_movie(
    rid,
    *,
    resolve_trakt_result,
    resolve_fallback_candidates,
    trakt_public_get,
):
    dialog = xbmcgui.DialogProgress()
    dialog.create(
        "Kraken",
        _t(
            "Resolviendo fuentes…",
            "Resolving sources…",
            "Resolution des sources…",
            "Risoluzione fonti…",
            "Quellen werden geladen…",
        ),
    )
    started = time.time()

    def _pcb(percent, phase, detail):
        kraken_progress(dialog, percent, phase, detail)

    cands = []
    try:
        rs = str(rid or "").strip()
        kraken_progress(dialog, 5, RESOLVER_PROGRESS_PHASE, resolver_progress_detail("inicio", [], None, started))
        if rs.startswith("trakt::"):
            cands = (
                resolve_trakt_result(
                    rs,
                    collect_sources=True,
                    progress_cb=_pcb,
                    progress_started_at=started,
                )
                or []
            )
        elif rs.startswith("fallback::movie::"):
            parts = rs.split("::", 3)
            year = None
            if len(parts) > 2 and str(parts[2]).isdigit():
                year = int(parts[2])
            title_fb = unquote(parts[3]).strip() if len(parts) > 3 else "movie"
            if not title_fb:
                title_fb = "movie"
            cands = (
                resolve_fallback_candidates(
                    title_fb,
                    year,
                    "movie",
                    progress_cb=_pcb,
                    progress_started_at=started,
                )
                or []
            )
        else:
            kraken_progress(dialog, 100, RESOLVER_PROGRESS_PHASE, resolver_progress_detail("no soportado", [], [], started))
            return []
        kraken_progress(
            dialog,
            100,
            RESOLVER_PROGRESS_PHASE,
            resolver_progress_detail("listo", cands or [], None, started),
        )
        return list(cands or [])
    finally:
        dialog.close()


def run_download_movie(
    *,
    result_id,
    get_bool_setting,
    get_setting,
    set_setting,
    resolve_trakt_result,
    pick_stream_dialog,
    torrent_player_route,
    resolve_fallback_candidates,
    trakt_public_get,
    debrid_resolve_torrent_for_download,
):
    _ = set_setting
    rs = unquote(str(result_id or "").strip())
    folder = str(get_setting("download_movies_path") or "").strip()
    folder_fs = _translate_path(folder)

    if not folder_fs:
        xbmcgui.Dialog().ok(
            "Kraken",
            _t(
                "Define la carpeta de descarga de películas en Kraken ▸ Descargas.",
                "Set the movies download folder under Kraken ▸ Downloads.",
                "Definis le dossier films dans Kraken ▸ Telechargements.",
                "Imposta la cartella film in Kraken ▸ Download.",
                "Filme Download-Ordner unter Kraken ▸ Downloads festlegen.",
            ),
        )
        return

    if get_bool_setting("download_ask_always"):
        ok = xbmcgui.Dialog().yesno(
            "Kraken",
            _t(
                "¿Descargar ahora?",
                "Download now?",
                "Telecharger maintenant ?",
                "Scaricare ora?",
                "Jetzt herunterladen?",
            ),
        )
        if not ok:
            return

    candidates = _resolve_candidates_movie(
        rs,
        resolve_trakt_result=resolve_trakt_result,
        resolve_fallback_candidates=resolve_fallback_candidates,
        trakt_public_get=trakt_public_get,
    )
    if not candidates:
        xbmcgui.Dialog().notification(
            "Kraken",
            _t("Sin fuentes.", "No sources.", "Sans sources.", "Nessuna fonte.", "Keine Quellen."),
            xbmcgui.NOTIFICATION_WARNING,
            5600,
        )
        return

    stash_source_candidates(candidates, _t("Descarga película", "Movie download", "Film", "Film", "Film"))

    picked = pick_stream_dialog(
        _t(
            "Kraken — descarga",
            "Kraken — download",
            "Kraken — téléchargement",
            "Kraken — download",
            "Kraken — Download",
        ),
        candidates,
        playback_kind="movie",
    )

    if picked is None:
        return
    if not picked:
        xbmcgui.Dialog().notification(
            "Kraken",
            _t("Sin URL elegida.", "No URL picked.", "Aucune URL.", "URL mancante.", "Keine URL."),
            xbmcgui.NOTIFICATION_INFO,
            3200,
        )
        return

    original_pick = str(picked or "").strip()
    if _torrent_like(original_pick):
        try:
            append_torrent_entry(
                url=original_pick,
                title=title_from_torrent_url(original_pick, "Torrent descarga"),
                kind="movie",
                action="download",
            )
        except Exception:
            pass

    try:
        picked = str(debrid_resolve_torrent_for_download(str(picked)) or "").strip() or picked
    except Exception:
        pass

    picked = torrent_player_route(picked)

    hdrs = _headers_for_pick(candidates, picked)

    if str(picked or "").startswith("plugin://"):
        xbmcgui.Dialog().ok(
            "Kraken",
            _t(
                "Este origen delega la reproducción al cliente torrent. "
                "No se puede copiar aquí como fichero único.",
                "This origin delegates playback to your torrent client. "
                "It can't be copied as a single file from here.",
                "Origine Torrent client — fichier unique impossible.",
                "Origine cliente torrent.",
                "Torrent-Client — kein Einzel-File-Download hier.",
            ),
        )
        return

    if _torrent_like(picked) or _stream_is_non_file_http(picked):
        xbmcgui.Dialog().ok(
            "Kraken",
            _t(
                "Solo se guardan enlaces HTTP/MPEG/VOD directos tras Debrid.",
                "Only direct HTTP video links after Debrid can be saved.",
                "Seuls liens HTTP directs apres Debrid.",
                "Solo HTTP dopo Debrid.",
                "Speichern nur mit direktem HTTP nach Debrid.",
            ),
        )
        return

    jtitle = str(_movie_title_for_journal(rs, trakt_public_get))
    tgt_name = _safe_filename(jtitle) + ".mkv"

    tgt = os.path.join(folder_fs.rstrip(os.path.sep), tgt_name)
    ok_save, fs_out, _n = _save_stream_url_to_local(
        picked,
        tgt,
        heading=_t(
            "Descarga película",
            "Movie download",
            "Film",
            "Film",
            "Film-Download",
        ),
        message=jtitle[:200],
        http_headers=hdrs,
    )
    if ok_save:
        append_entry(path_fs=fs_out, title=jtitle, kind="movie", bytes_size=os.path.getsize(fs_out))


def run_download_episode(
    *,
    show_trakt_id,
    season_number,
    episode_number,
    get_bool_setting,
    get_setting,
    set_setting,
    resolve_trakt_episode_stream,
    pick_stream_dialog,
    torrent_player_route,
    trakt_public_get,
    debrid_resolve_torrent_for_download,
):
    _ = set_setting
    sid = str(show_trakt_id or "").strip()
    season_num = int(str(season_number or "0"))
    episode_num = int(str(episode_number or "0"))
    folder = _translate_path(str(get_setting("download_series_path") or "").strip())
    if not sid or season_num < 0 or episode_num < 1 or not folder:
        xbmcgui.Dialog().ok(
            "Kraken",
            _t(
                "Define la carpeta de series en Kraken ▸ Descargas e inténtalo de nuevo.",
                "Set TV download folder under Kraken ▸ Downloads and retry.",
                "Dossier series dans Kraken ▸ Telechargements.",
                "Cartella serie in Kraken ▸ Download.",
                "Serien-Ordner in Kraken ▸ Downloads einstellen.",
            ),
        )
        return

    if get_bool_setting("download_ask_always"):
        if not xbmcgui.Dialog().yesno(
            "Kraken",
            _t(
                "¿Descargar este episodio?",
                "Download this episode?",
                "Telecharger cet episode?",
                "Scaricare questo episodio?",
                "Diese Folge laden?",
            ),
        ):
            return

    dialog = xbmcgui.DialogProgress()
    dialog.create("Kraken", _t("Resolviendo episodio…", "Resolving episode…", "…", "…", "…"))
    started = time.time()
    ep_ctx = f"{season_num:02d}x{episode_num:02d}"

    def _pcb(percent, phase, detail):
        kraken_progress(dialog, percent, phase, detail)

    try:
        kraken_progress(
            dialog,
            5,
            RESOLVER_PROGRESS_PHASE,
            resolver_progress_detail(f"{ep_ctx} · …", [], None, started),
        )
        candidates = (
            resolve_trakt_episode_stream(
                sid,
                season_num,
                episode_num,
                collect_sources=True,
                progress_cb=_pcb,
                progress_started_at=started,
                context_label=ep_ctx,
            )
            or []
        )
        kraken_progress(
            dialog,
            100,
            RESOLVER_PROGRESS_PHASE,
            resolver_progress_detail(f"{ep_ctx} · OK", candidates, None, started),
        )
    finally:
        dialog.close()

    stash_source_candidates(
        candidates,
        _t("Descarga episodio", "Episode dl", "Ep.", "Ep.", "Episode") + f" {ep_ctx}",
    )

    picked = pick_stream_dialog(
        _t("Kraken — descarga episodio", "Kraken — download ep", "", "", ""),
        candidates,
        playback_kind="episode",
    )

    if picked is None:
        return
    if not picked:
        return

    original_pick = str(picked or "").strip()
    if _torrent_like(original_pick):
        try:
            append_torrent_entry(
                url=original_pick,
                title=title_from_torrent_url(original_pick, "Torrent descarga"),
                kind="episode",
                action="download",
            )
        except Exception:
            pass

    picked = torrent_player_route(debrid_resolve_torrent_for_download(picked) or picked)

    hdrs = _headers_for_pick(candidates, picked)

    if picked.startswith("plugin://") or _torrent_like(picked) or _stream_is_non_file_http(picked):
        xbmcgui.Dialog().notification(
            "Kraken",
            _t(
                "Origen incompatible con archivo local.",
                "Source incompatible with local file.",
                "",
                "",
                "",
            ),
            xbmcgui.NOTIFICATION_WARNING,
            6000,
        )
        return

    show_data = {}
    try:
        show_data = (
            trakt_public_get(f"https://api.trakt.tv/shows/{quote(sid)}?extended=full")
            or {}
        )
    except Exception:
        pass
    jkind = _journal_kind_show(show_data)
    ep_title = f"Episode {episode_num}"
    try:
        ep_d = trakt_public_get(
            f"https://api.trakt.tv/shows/{quote(sid)}/seasons/{season_num}/episodes/{episode_num}?extended=full"
        )
        ep_title = str((ep_d or {}).get("title") or ep_title).strip()
    except Exception:
        pass
    show_ttl = _safe_filename(str(show_data.get("title") or "show"))

    tgt_dir = os.path.join(folder.rstrip(os.path.sep), show_ttl)
    fname = (
        _safe_filename(
            "{} S{:02d}E{:02d} - {}".format(
                show_ttl,
                season_num,
                episode_num,
                ep_title,
            )
        )
        + ".mp4",
    )

    tgt = os.path.join(tgt_dir, fname)
    heading = "{} · {}".format(ep_ctx, ep_title[:80])
    ok_save, fs_out, _n = _save_stream_url_to_local(
        picked,
        tgt,
        heading=heading,
        message="{}{}".format(show_ttl[:60], ""),
        http_headers=hdrs,
    )
    if ok_save:
        append_entry(
            path_fs=fs_out,
            title="{} {}".format(show_ttl, heading),
            kind=jkind,
            bytes_size=os.path.getsize(fs_out),
        )


def _download_episode_bulk(
    label_season,
    pairs,
    *,
    show_id,
    show_title,
    jkind,
    folder_series,
    resolve_trakt_episode_stream,
    pick_stream_url_silent,
    torrent_player_route,
    debrid_resolve_torrent_for_download,
    trakt_public_get,
    get_bool_setting,
    get_setting,
    set_setting,
):
    dlg = xbmcgui.DialogProgress()
    dlg.create(
        "Kraken — {}".format(label_season),
        _t(
            "Preparando…",
            "Preparing…",
            "Preparation…",
            "Preparazione…",
            "Vorbereitung…",
        ),
    )
    total = max(1, len(pairs))
    for i, (sn, en) in enumerate(pairs):
        if dlg.iscanceled():
            break
        dlg.update(int(i * 100 / total), f"S{sn:02d}E{en:02d}")
        started = time.time()

        def _pcb(percent, phase, detail):
            try:
                dlg.update(
                    int(i * 100 / total + max(1, int(percent * (100 / total) / 100))),
                    detail[:90] if detail else f"S{sn:02d}E{en:02d}",
                )
            except Exception:
                pass

        try:
            cands = (
                resolve_trakt_episode_stream(
                    show_id,
                    int(sn),
                    int(en),
                    collect_sources=True,
                    progress_cb=_pcb,
                    progress_started_at=started,
                    context_label=f"{sn:02d}x{en:02d}",
                )
                or []
            )
        except Exception:
            cands = []

        rot_dl = None
        if get_setting and set_setting:
            rot_dl = {
                "content_key": f"e:{show_id}:{int(sn)}:{int(en)}",
                "get_setting": get_setting,
                "set_setting": set_setting,
                "get_bool_setting": get_bool_setting,
            }
        pick = pick_stream_url_silent(
            cands, playback_kind="episode", rotation=rot_dl
        )
        if not pick:
            continue
        original_pick = str(pick or "").strip()
        if _torrent_like(original_pick):
            try:
                append_torrent_entry(
                    url=original_pick,
                    title=title_from_torrent_url(original_pick, "Torrent descarga"),
                    kind=jkind,
                    action="download",
                )
            except Exception:
                pass
        pick = torrent_player_route(debrid_resolve_torrent_for_download(pick) or pick)
        hdrs = _headers_for_pick(cands, pick)
        if pick.startswith("plugin://") or _torrent_like(pick) or _stream_is_non_file_http(pick):
            continue

        ep_title = f"Episode {en}"
        try:
            ep_d = trakt_public_get(
                f"https://api.trakt.tv/shows/{quote(show_id)}/seasons/{int(sn)}/episodes/{int(en)}?extended=full"
            )
            ep_title = str((ep_d or {}).get("title") or ep_title).strip()
        except Exception:
            pass

        show_ttl = _safe_filename(show_title)
        tgt_dir = os.path.join(folder_series.rstrip(os.path.sep), show_ttl)
        fname = _safe_filename(
            "{} S{:02d}E{:02d} - {}".format(show_ttl, sn, en, ep_title),
        )
        tgt = os.path.join(tgt_dir, fname + ".mp4")

        heading = "S{:02d}E{:02d}".format(sn, en)
        ok_save, fs_out, _n = _save_stream_url_to_local(
            pick,
            tgt,
            heading=heading,
            message="{}{}".format(show_ttl[:40], ""),
            http_headers=hdrs,
        )
        if ok_save:
            sz = os.path.getsize(fs_out)
            append_entry(path_fs=fs_out, title="{} {}".format(show_ttl, heading), kind=jkind, bytes_size=sz)

    dlg.close()


def run_download_season(
    *,
    show_trakt_id,
    season_number,
    get_bool_setting,
    get_setting,
    set_setting,
    resolve_trakt_episode_stream,
    pick_stream_url_silent,
    torrent_player_route,
    trakt_public_get,
    debrid_resolve_torrent_for_download,
):
    sid = str(show_trakt_id or "").strip()
    folder = _translate_path(str(get_setting("download_series_path") or "").strip())
    season_num = int(str(season_number or "0"))
    if not sid or season_num < 0 or not folder:
        xbmcgui.Dialog().ok("Kraken", _t("Carpeta de series no configurada.", "TV folder not set.", "", "", ""))
        return

    if get_bool_setting("download_ask_always"):
        if not xbmcgui.Dialog().yesno(
            "Kraken",
            _t(
                "¿Descargar toda esta temporada?",
                "Download entire season?",
                "",
                "",
                "",
            ),
        ):
            return

    episodes = []
    try:
        episodes = (
            trakt_public_get(f"https://api.trakt.tv/shows/{quote(sid)}/seasons/{season_num}/episodes?extended=full")
            or []
        )
    except Exception:
        pass

    nums = []
    for x in episodes or []:
        if not isinstance(x, dict):
            continue
        num = x.get("number")
        try:
            n = int(num)
        except (TypeError, ValueError):
            continue
        if n > 0:
            nums.append(n)
    nums = sorted(nums)

    if not nums:
        xbmcgui.Dialog().notification(
            "Kraken",
            _t("Sin episodios en la temporada.", "No episodes.", "", "", ""),
            xbmcgui.NOTIFICATION_INFO,
            5400,
        )
        return

    show_data = trakt_public_get(f"https://api.trakt.tv/shows/{quote(sid)}?extended=full") or {}
    jkind = _journal_kind_show(show_data)
    ttl = str(show_data.get("title") or "show")

    pairs = [(season_num, n) for n in nums]
    _download_episode_bulk(
        label_season="S{:02d}".format(season_num),
        pairs=pairs,
        show_id=sid,
        show_title=ttl,
        jkind=jkind,
        folder_series=folder,
        resolve_trakt_episode_stream=resolve_trakt_episode_stream,
        pick_stream_url_silent=pick_stream_url_silent,
        torrent_player_route=torrent_player_route,
        debrid_resolve_torrent_for_download=debrid_resolve_torrent_for_download,
        trakt_public_get=trakt_public_get,
        get_bool_setting=get_bool_setting,
        get_setting=get_setting,
        set_setting=set_setting,
    )


def run_download_show(
    *,
    show_trakt_id,
    get_bool_setting,
    get_setting,
    set_setting,
    resolve_trakt_episode_stream,
    pick_stream_url_silent,
    torrent_player_route,
    trakt_public_get,
    debrid_resolve_torrent_for_download,
):
    sid = str(show_trakt_id or "").strip()
    folder = _translate_path(str(get_setting("download_series_path") or "").strip())
    if not sid or not folder:
        xbmcgui.Dialog().ok("Kraken", _t("Carpeta de series no configurada.", "TV folder not set.", "", "", ""))
        return

    if get_bool_setting("download_ask_always"):
        if not xbmcgui.Dialog().yesno(
            "Kraken",
            _t("¿Descargar toda la serie?", "Download whole show?", "", "", ""),
            nolabel=_t("No", "No", "Non", "No", "Nein"),
            yeslabel=_t("Sí", "Yes", "Oui", "Sì", "Ja"),
        ):
            return

    seasons = []
    try:
        seasons = trakt_public_get(f"https://api.trakt.tv/shows/{quote(sid)}/seasons") or []
    except Exception:
        seasons = []

    season_nums = []
    for s in seasons or []:
        if not isinstance(s, dict):
            continue
        try:
            n = int(s.get("number"))
        except (TypeError, ValueError):
            continue
        season_nums.append(n)
    season_nums = sorted(set(season_nums))

    pairs = []
    for sn in season_nums:
        eps = []
        try:
            eps = (
                trakt_public_get(
                    f"https://api.trakt.tv/shows/{quote(sid)}/seasons/{sn}/episodes?extended=full"
                )
                or []
            )
        except Exception:
            eps = []
        for ep in eps or []:
            if not isinstance(ep, dict):
                continue
            try:
                en = int(ep.get("number"))
            except (TypeError, ValueError):
                continue
            if en > 0:
                pairs.append((sn, en))

    if not pairs:
        xbmcgui.Dialog().notification(
            "Kraken",
            _t("Sin episodios.", "No episodes.", "Sans episodes.", "Nessun episodio.", "Keine Episoden."),
            xbmcgui.NOTIFICATION_INFO,
            5600,
        )
        return

    show_data = trakt_public_get(f"https://api.trakt.tv/shows/{quote(sid)}?extended=full") or {}
    jkind = _journal_kind_show(show_data)
    ttl = str(show_data.get("title") or "show")

    _download_episode_bulk(
        label_season=_t(
            "Serie completa",
            "Full show",
            "Serie entiere",
            "Serie completa",
            "Komplette Serie",
        ),
        pairs=pairs,
        show_id=sid,
        show_title=ttl,
        jkind=jkind,
        folder_series=folder,
        resolve_trakt_episode_stream=resolve_trakt_episode_stream,
        pick_stream_url_silent=pick_stream_url_silent,
        torrent_player_route=torrent_player_route,
        debrid_resolve_torrent_for_download=debrid_resolve_torrent_for_download,
        trakt_public_get=trakt_public_get,
        get_bool_setting=get_bool_setting,
        get_setting=get_setting,
        set_setting=set_setting,
    )
