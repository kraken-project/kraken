import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.ui.video_info import apply_video_info
from resources.lib.ui.ui_helpers import _t


def run_settings(
    *,
    plugin_handle,
    addon,
    default_list_art,
    url_for_views_menu,
    url_for_maintenance_menu,
    url_for_open_kodi_addon_settings,
    url_for_experience_menu=None,
):
    """Menú reducido: vistas de lista, mantenimiento de cachés y ajustes nativos de Kodi."""
    xbmcplugin.setPluginCategory(
        plugin_handle,
        _t("Ajustes", "Settings", "Parametres", "Impostazioni", "Einstellungen"),
    )
    xbmcplugin.setContent(plugin_handle, "files")
    xbmcplugin.addSortMethod(plugin_handle, xbmcplugin.SORT_METHOD_NONE)
    base_art = default_list_art()
    directory = []

    def _add(url, title_id: int, plot_id: int):
        title = addon.getLocalizedString(title_id)
        plot = addon.getLocalizedString(plot_id)
        li = xbmcgui.ListItem(title, plot)
        apply_video_info(li, {"title": title, "plot": plot, "mediatype": "video"})
        li.setArt(dict(base_art or {}))
        li.setProperty("IsPlayable", "false")
        directory.append((url, li, True))

    def _add_text(url, title, plot):
        li = xbmcgui.ListItem(title, plot)
        apply_video_info(li, {"title": title, "plot": plot, "mediatype": "video"})
        li.setArt(dict(base_art or {}))
        li.setProperty("IsPlayable", "false")
        directory.append((url, li, True))

    if callable(url_for_experience_menu):
        _add_text(
            url_for_experience_menu(),
            _t("Asistente y diagnóstico", "Wizard and diagnostics", "Assistant et diagnostic", "Guida e diagnostica", "Assistent und Diagnose"),
            _t("Perfiles rápidos, salud de Kraken y estado Stremio.", "Quick profiles, Kraken health and Stremio status.", "Profils rapides, santé Kraken et état Stremio.", "Profili rapidi, salute Kraken e stato Stremio.", "Schnellprofile, Kraken-Status und Stremio-Zustand."),
        )
    _add(url_for_views_menu(), 30443, 30444)
    _add(url_for_maintenance_menu(), 30460, 30461)
    _add(url_for_open_kodi_addon_settings(), 30517, 30518)

    xbmcplugin.addDirectoryItems(plugin_handle, directory, len(directory))
    xbmcplugin.endOfDirectory(plugin_handle)
