"""Rutas de experiencia de producto: perfiles, diagnóstico y estado de fuentes."""

import json
from urllib.request import Request, urlopen

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib.sources.stremio_sources_config import (
    STREMIO_CATALOG_NAMED_ADDONS,
    STREMIO_DEFAULT_MANIFEST_BY_PREFIX,
)
from resources.lib.ui.ui_helpers import _t


_PROFILE_ROWS = (
    (
        "castellano",
        "Castellano estricto",
        {
            "autoplay_source_by_language": "true",
            "autoplay_movies_enabled": "true",
            "autoplay_series_enabled": "true",
            "autoplay_lang_primary": "Castellano",
            "autoplay_lang_secondary": "Latino",
            "stremio_autoplay_language_manifest": "true",
            "kraken_quality_filter_enabled": "false",
        },
    ),
    (
        "latino",
        "Latino preferido",
        {
            "autoplay_source_by_language": "true",
            "autoplay_movies_enabled": "true",
            "autoplay_series_enabled": "true",
            "autoplay_lang_primary": "Latino",
            "autoplay_lang_secondary": "Castellano",
            "stremio_autoplay_language_manifest": "true",
            "kraken_quality_filter_enabled": "false",
        },
    ),
    (
        "quality",
        "Máxima calidad",
        {
            "kraken_quality_filter_enabled": "true",
            "kraken_quality_allow_4k": "true",
            "kraken_quality_allow_1080p": "true",
            "kraken_quality_allow_720p": "false",
            "kraken_quality_allow_sd": "false",
            "kraken_quality_filter_allow_auto": "true",
            "source_search_style": "Background",
            "stremio_search_threads": "12",
        },
    ),
    (
        "low",
        "Bajo consumo",
        {
            "kraken_quality_filter_enabled": "true",
            "kraken_quality_allow_4k": "false",
            "kraken_quality_allow_1080p": "false",
            "kraken_quality_allow_720p": "true",
            "kraken_quality_allow_sd": "true",
            "kraken_size_filter_enabled": "true",
            "kraken_size_max_gb": "4",
            "stremio_search_threads": "4",
            "source_search_style": "Foreground",
        },
    ),
    (
        "debrid",
        "Solo Debrid",
        {
            "torrent_debrid_first": "true",
            "stremio_alldebrid_auto_torrentio": "true",
        },
    ),
    (
        "torrent",
        "Torrent local",
        {
            "torrent_debrid_first": "false",
            "torrent_player": "Elementum",
        },
    ),
)


def _bool_text(ok):
    return _t("sí", "yes", "oui", "sì", "ja") if ok else _t("no", "no", "non", "no", "nein")


def run_setup_wizard(*, get_setting, set_setting):
    labels = [name for _slug, name, _settings in _PROFILE_ROWS]
    pick = xbmcgui.Dialog().select(
        _t(
            "Kraken - Perfil rápido",
            "Kraken - Quick profile",
            "Kraken - Profil rapide",
            "Kraken - Profilo rapido",
            "Kraken - Schnellprofil",
        ),
        labels,
    )
    if pick < 0:
        return
    _slug, label, settings = _PROFILE_ROWS[pick]
    for key, value in settings.items():
        try:
            set_setting(key, value)
        except Exception:
            pass
    try:
        set_setting("kraken_setup_wizard_done", "true")
        set_setting("kraken_setup_wizard_profile", _slug)
    except Exception:
        pass
    xbmcgui.Dialog().notification(
        "Kraken",
        _t("Perfil aplicado: ", "Profile applied: ", "Profil appliqué : ", "Profilo applicato: ", "Profil angewendet: ") + label,
        xbmcgui.NOTIFICATION_INFO,
        4500,
    )


def _last_kraken_error():
    try:
        log_path = xbmcvfs.translatePath("special://logpath/kodi.log")
    except Exception:
        log_path = ""
    if not log_path:
        return ""
    try:
        with open(log_path, encoding="utf-8", errors="ignore") as fh:
            lines = fh.readlines()[-700:]
    except Exception:
        return ""
    for line in reversed(lines):
        low = line.lower()
        if "kraken" in low and ("error" in low or "exception" in low or "traceback" in low):
            return line.strip()[:420]
    return ""


def _stremio_state_count(get_setting):
    try:
        raw = str(get_setting("stremio_addons_state") or "").strip()
        data = json.loads(raw) if raw else {}
        known = data.get("known") if isinstance(data, dict) else {}
        if isinstance(known, dict):
            enabled = sum(1 for row in known.values() if isinstance(row, dict) and bool(row.get("enabled", True)))
            return enabled, len(known)
    except Exception:
        pass
    return 0, 0


def run_health_panel(*, addon, get_bool_setting, get_setting, addon_installed):
    st_enabled, st_total = _stremio_state_count(get_setting)
    lines = [
        "Kraken {}".format(addon.getAddonInfo("version") or "?"),
        "",
        "Trakt: {}".format(_bool_text(bool(get_bool_setting("trakt_enabled") and get_setting("trakt_access_token")))),
        "AllDebrid: {}".format(_bool_text(bool(get_bool_setting("debrid_ad_enabled") and get_setting("debrid_ad_token")))),
        "Elementum: {}".format(_bool_text(bool(addon_installed("plugin.video.elementum")))),
        "Stremio: {} ({}/{})".format(
            _bool_text(bool(get_bool_setting("provider_stremio_catalog"))),
            st_enabled,
            st_total,
        ),
        "OpenSubtitles: {}".format(str(get_setting("opensubtitles_preferred_lang") or "Auto")),
        "Idioma Autoplay: {} / {}".format(
            str(get_setting("autoplay_lang_primary") or "Auto"),
            str(get_setting("autoplay_lang_secondary") or "Auto"),
        ),
        "Último estado Debrid: {}".format(xbmcgui.Window(10000).getProperty("Kraken.LastDebridStatus") or "-"),
        "",
        "Último error Kraken:",
        _last_kraken_error() or "-",
    ]
    xbmcgui.Dialog().textviewer("Kraken - Diagnóstico", "\n".join(lines))


def _probe_manifest(url):
    raw = str(url or "").strip()
    if not raw:
        return "sin URL"
    try:
        req = Request(raw, headers={"User-Agent": "Kraken-Diagnostics/1.0"})
        with urlopen(req, timeout=8) as resp:
            final = str(resp.geturl() or raw).strip()
            if any(x in final.lower() for x in ("/configure", "/setup", "/config")):
                return "redirige a configuración"
            return "OK HTTP {}".format(getattr(resp, "status", 200))
    except Exception as ex:
        return "ERROR {}".format(str(ex)[:90])


def run_stremio_status_panel(*, get_bool_setting, get_setting):
    lines = [
        "Stremio - Estado de complementos",
        "",
        "Catálogo global: {}".format(_bool_text(bool(get_bool_setting("provider_stremio_catalog")))),
        "Filtro por complementos: {}".format(_bool_text(bool(get_bool_setting("stremio_use_per_addon_toggle")))),
        "Idioma Autoplay en manifest: {}".format(_bool_text(str(get_setting("stremio_autoplay_language_manifest") or "true").lower() != "false")),
        "",
    ]
    for name, prefix in STREMIO_CATALOG_NAMED_ADDONS:
        enabled = bool(get_bool_setting(f"{prefix}_enabled"))
        url = str(get_setting(f"{prefix}_url") or "").strip() or STREMIO_DEFAULT_MANIFEST_BY_PREFIX.get(prefix, "")
        status = _probe_manifest(url) if enabled else "desactivado"
        lines.append("{}: {} - {}".format(name, _bool_text(enabled), status))
        lines.append("  {}".format(url or "-"))
    xbmcgui.Dialog().textviewer("Kraken - Stremio", "\n".join(lines))


def run_experience_menu(
    *,
    plugin_handle,
    default_list_art,
    url_for_setup,
    url_for_health,
    url_for_stremio_status,
):
    xbmcplugin.setPluginCategory(plugin_handle, "Kraken - Experiencia")
    xbmcplugin.setContent(plugin_handle, "files")
    art = dict(default_list_art() or {})
    rows = []
    for url, label, desc in (
        (url_for_setup(), "Asistente / perfiles rápidos", "Configura Kraken en un toque."),
        (url_for_health(), "Diagnóstico Kraken", "Estado de cuentas, fuentes y último error."),
        (url_for_stremio_status(), "Estado Stremio", "Comprueba complementos y manifests."),
    ):
        li = xbmcgui.ListItem(label=label, label2=desc)
        li.setProperty("IsPlayable", "false")
        li.setArt(dict(art))
        rows.append((url, li, True))
    xbmcplugin.addDirectoryItems(plugin_handle, rows, len(rows))
    xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)
