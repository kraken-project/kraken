import os
import threading

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib.ui.ui_helpers import _t


def _play_ui_sfx(kind):
    # Sonido UI sutil con rutas de fallback (si no existe, Kodi lo ignora).
    focus_candidates = (
        "special://skin/sounds/focus.wav",
        "special://skin/sounds/click.wav",
        "special://xbmc/media/focus.wav",
        "focus.wav",
    )
    click_candidates = (
        "special://skin/sounds/click.wav",
        "special://skin/sounds/select.wav",
        "special://xbmc/media/click.wav",
        "click.wav",
    )
    candidates = click_candidates if str(kind) == "click" else focus_candidates
    for sfx in candidates:
        try:
            if sfx.startswith("special://") and not xbmcvfs.exists(sfx):
                continue
            xbmc.executebuiltin(f"PlaySFX({sfx})")
            return
        except Exception:
            pass


def _kodi_apply_local_image(control, value, log_prefix="[Kraken][Img]"):
    """
    Asigna una textura local a un control imagen.
    Prefiere ruta absoluta (special:// -> disco) y desactiva caché para PNG regenerados.
    """
    src = (value or "").strip()
    if not src:
        return False
    if "\\" in src:
        src = src.replace("\\", "/")
    abs_path = None
    try:
        if src.startswith("special://"):
            t = xbmcvfs.translatePath(src)
            if t:
                abs_path = t.replace("\\", "/")
    except Exception:
        abs_path = None

    candidates = []
    if abs_path:
        candidates.append(abs_path)
    if src not in candidates:
        candidates.append(src)

    for path_try in candidates:
        if not path_try:
            continue
        try:
            if path_try.startswith("special://"):
                if not xbmcvfs.exists(path_try):
                    continue
            elif not os.path.isfile(path_try):
                continue
        except Exception:
            continue
        try:
            try:
                control.setImage("")
            except Exception:
                pass
            try:
                control.setImage(path_try, False)
            except TypeError:
                control.setImage(path_try)
            try:
                control.setVisible(True)
            except Exception:
                pass
            return True
        except Exception as ex:
            xbmc.log(
                f"{log_prefix} No se pudo cargar imagen: {path_try} — {ex}",
                xbmc.LOGWARNING,
            )
    return False


class KrakenQrDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self._addon_path = str(args[1]) if len(args) >= 2 else ""
        self._title = kwargs.pop("dialog_title", "Kraken")
        self._url = kwargs.pop("url", "")
        self._qr_url = kwargs.pop("qr_url", "")
        self._poll_interval_sec = float(kwargs.pop("poll_interval_sec", 0) or 0)
        self._poll_deadline_epoch = kwargs.pop("poll_deadline_epoch", None)
        self._poll_fn = kwargs.pop("poll_fn", None)
        self._countdown_control_id = int(kwargs.pop("countdown_control_id", 103) or 103)
        self._progress_control_id = int(kwargs.pop("progress_control_id", 104) or 104)
        self._poll_stop = threading.Event()
        self._poll_thread = None
        self._countdown_thread = None
        self._closing = False
        self.auth_success = False
        self.timed_out = False
        super().__init__(*args, **kwargs)

    def onInit(self):
        self._set_fanart_background()
        self._set_label(100, self._title)
        # Texto principal: label multilinea (id 101) — mas fiable que textbox en WindowXML.
        self._set_label(101, self._url)
        self._set_image(102, self._qr_url)
        dead = float(self._poll_deadline_epoch or 0)
        if dead > 0:
            self._tick_countdown_now()
            self._countdown_thread = threading.Thread(
                target=self._countdown_runner, daemon=True
            )
            self._countdown_thread.start()
        else:
            try:
                self._set_label(self._countdown_control_id, "")
            except Exception:
                pass
        self.setFocusId(201)
        if callable(self._poll_fn) and self._poll_interval_sec > 0:
            self._poll_thread = threading.Thread(target=self._poll_worker_loop, daemon=True)
            self._poll_thread.start()

    def _request_dialog_close_async(self):
        """Cierre idempotente desde hilos secundarios (polling / cuenta atrás)."""
        if self._closing:
            return
        self._closing = True
        try:
            self._poll_stop.set()
        except Exception:
            pass
        xbmc.sleep(80)
        try:
            super().close()
        except Exception:
            pass

    def close(self):
        if self._closing:
            return
        self._closing = True
        try:
            self._poll_stop.set()
        except Exception:
            pass
        try:
            super().close()
        except Exception:
            pass

    def _countdown_line(self, remaining_secs: int) -> str:
        r = max(0, int(remaining_secs))
        mm, ss = divmod(r, 60)
        return _t(
            "Caduca en %02d:%02d",
            "Expires in %02d:%02d",
            "Expire dans %02d:%02d",
            "Scade tra %02d:%02d",
            "Läuft ab in %02d:%02d",
        ) % (mm, ss)

    def _tick_countdown_now(self):
        try:
            import time as _time

            dead = float(self._poll_deadline_epoch or 0)
            if dead <= 0:
                self._set_label(self._countdown_control_id, "")
                return
            rem = max(0, int(dead - _time.time()))
            self._set_label(self._countdown_control_id, self._countdown_line(rem))
            total = max(1, int(dead - float(getattr(self, "_countdown_started_epoch", 0) or 0)))
            if not getattr(self, "_countdown_started_epoch", 0):
                self._countdown_started_epoch = _time.time()
                total = max(1, int(dead - self._countdown_started_epoch))
            pct = int(max(0, min(100, (float(rem) / float(total)) * 100.0)))
            self._set_progress(self._progress_control_id, pct)
        except Exception:
            pass

    def _countdown_runner(self):
        import time as _time

        dead = float(self._poll_deadline_epoch or 0)
        if dead <= 0:
            return
        while not self._poll_stop.is_set():
            now = _time.time()
            if now >= dead:
                self.timed_out = True
                self._request_dialog_close_async()
                return
            self._tick_countdown_now()
            target = now + 1.0
            while _time.time() < target:
                if self._poll_stop.is_set():
                    return
                if _time.time() >= dead:
                    self.timed_out = True
                    self._request_dialog_close_async()
                    return
                xbmc.sleep(20)

    def _poll_worker_loop(self):
        import time as _time

        slip = max(0.08, float(self._poll_interval_sec))
        slip_ms = max(80, int(min(900, slip * 1000)))
        while not self._poll_stop.is_set():
            if (
                self._poll_deadline_epoch is not None
                and float(self._poll_deadline_epoch) > 0
                and _time.time() >= float(self._poll_deadline_epoch)
            ):
                self.timed_out = True
                self._request_dialog_close_async()
                return
            try:
                ok = bool(self._poll_fn())
            except Exception:
                ok = False
            if ok:
                self.auth_success = True
                self._request_dialog_close_async()
                return
            for _ in range(max(4, slip_ms // 20)):
                if self._poll_stop.is_set():
                    return
                if (
                    float(self._poll_deadline_epoch or 0) > 0
                    and _time.time() >= float(self._poll_deadline_epoch)
                ):
                    self.timed_out = True
                    self._request_dialog_close_async()
                    return
                xbmc.sleep(20)

    def _set_fanart_background(self):
        """Rellena id 99 con fanart.jpg / fanart.png del addon si existen."""
        base = (self._addon_path or "").strip()
        if not base:
            return
        try:
            base = xbmcvfs.translatePath(base)
        except Exception:
            return
        for name in ("fanart.jpg", "fanart.png"):
            path_abs = os.path.join(base, name)
            if not os.path.isfile(path_abs):
                continue
            p = path_abs.replace("\\", "/")
            try:
                self._set_image(99, p)
                return
            except Exception:
                pass

    def onClick(self, control_id):
        if control_id == 201:
            self.close()

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (10, 13, 92):
            self.close()

    def _set_label(self, control_id, value):
        try:
            control = self.getControl(control_id)
            control.setLabel(value or "")
        except Exception as ex:
            xbmc.log(
                f"[Kraken][QrDialog] setLabel {control_id}: {ex}",
                xbmc.LOGWARNING,
            )

    def _set_image(self, control_id, value):
        try:
            control = self.getControl(control_id)
        except Exception as ex:
            xbmc.log(
                f"[Kraken][QrDialog] getControl {control_id}: {ex}",
                xbmc.LOGWARNING,
            )
            return
        if not _kodi_apply_local_image(control, value, "[Kraken][QrDialog]"):
            if (value or "").strip():
                xbmc.log(
                    f"[Kraken][QrDialog] QR no cargado (sin archivo o ruta invalida): {value}",
                    xbmc.LOGWARNING,
                )

    def _set_progress(self, control_id, value):
        try:
            control = self.getControl(control_id)
            try:
                control.setPercent(float(value))
            except AttributeError:
                control.setValue(int(value))
        except Exception:
            pass


class KrakenSourcesDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self._addon_path = str(args[1]) if len(args) >= 2 else ""
        self._title = kwargs.pop("dialog_title", None)
        if not (self._title or "").strip():
            self._title = _t(
                "Kraken - Fuentes",
                "Kraken - Sources",
                "Kraken - Sources",
                "Kraken - Fonti",
                "Kraken - Quellen",
            )
        self._subtitle = kwargs.pop("dialog_subtitle", "")
        self._rows = kwargs.pop("rows", [])
        self._selected_index = -1
        super().__init__(*args, **kwargs)

    def onInit(self):
        self._set_fanart_background()
        self._set_label(100, self._title)
        self._set_label(101, self._subtitle)
        control = self.getControl(400)
        control.reset()
        items = []
        sel_num = 0
        for _idx, row in enumerate(self._rows, start=1):
            if not row.get("selectable", True):
                label = row.get("line1", "")
                label2 = row.get("line2", "")
            else:
                sel_num += 1
                label = "[COLOR FFFFFFFF]#{}[/COLOR] {}".format(
                    sel_num, row.get("line1", "")
                )
                label2 = row.get("line2", "")
            li = xbmcgui.ListItem(label=label, label2=label2)
            icon = str(row.get("icon") or "").strip()
            if icon:
                try:
                    li.setArt({"icon": icon, "thumb": icon})
                except Exception:
                    pass
                try:
                    li.setIconImage(icon)
                except Exception:
                    pass
                try:
                    li.setThumbnailImage(icon)
                except Exception:
                    pass
            items.append(li)
        control.addItems(items)
        if items:
            start_idx = self._first_selectable_index()
            control.selectItem(start_idx)
            self._sync_bottom(start_idx)
        try:
            self.setFocus(control)
        except Exception:
            try:
                self.setFocusId(400)
            except Exception:
                self.setFocusId(201)

    def onFocus(self, control_id):
        if int(control_id) == 400:
            self._sync_bottom()

    def onClick(self, control_id):
        if control_id == 400:
            self._pick_current()
        elif control_id == 201:
            self.close()

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (7,):  # ACTION_SELECT_ITEM
            self._pick_current()
            return
        if action_id in (10, 13, 92):
            self.close()
            return
        if action_id in (3, 4, 5, 6):  # navigation
            self._sync_bottom()

    def _pick_current(self):
        try:
            pos = int(self.getControl(400).getSelectedPosition())
        except Exception:
            pos = -1
        if pos < 0 or pos >= len(self._rows):
            return
        self._selected_index = pos
        row = self._rows[pos]
        if not row.get("selectable", True):
            return
        source_index = int(row.get("source_index", -1))
        if source_index < 0:
            return
        self._selected_index = source_index
        self.close()

    def _sync_bottom(self, forced_pos=None):
        pos = forced_pos
        if pos is None:
            try:
                pos = int(self.getControl(400).getSelectedPosition())
            except Exception:
                pos = -1
        if pos < 0 or pos >= len(self._rows):
            return
        row = self._rows[pos]
        self._set_textbox(102, row.get("bottom", ""))

    def _first_selectable_index(self):
        for idx, row in enumerate(self._rows):
            if row.get("selectable", True):
                return idx
        return 0

    def _set_label(self, control_id, value):
        try:
            self.getControl(control_id).setLabel(value)
        except Exception:
            pass

    def _set_fanart_background(self):
        base = (self._addon_path or "").strip()
        if not base:
            return
        try:
            base = xbmcvfs.translatePath(base)
        except Exception:
            return
        for name in (
            os.path.join("resources", "art", "wallpaper.png"),
            "wallpaper.png",
            "fanart.jpg",
            "fanart.png",
        ):
            path_abs = os.path.join(base, name)
            if not os.path.isfile(path_abs):
                continue
            p = path_abs.replace("\\", "/")
            try:
                control = self.getControl(99)
                if hasattr(control, "setTexture"):
                    control.setTexture(p)
                else:
                    control.setImage(p)
                return
            except Exception:
                pass

    def _set_textbox(self, control_id, value):
        try:
            self.getControl(control_id).setText(value)
        except Exception:
            pass

    @property
    def selected_index(self):
        return self._selected_index
