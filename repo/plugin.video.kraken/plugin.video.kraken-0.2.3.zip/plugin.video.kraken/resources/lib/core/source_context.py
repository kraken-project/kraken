def build_source_context(
    *,
    normalize_quality_impl,
    quality_counts_colored_impl,
    quality_rank_impl,
    compact_origin_impl,
    language_flag_impl,
    normalize_language_label_bridge,
    normalize_language_label_impl,
    language_bucket_for_item_bridge,
    language_bucket_for_item_impl,
    language_section_title_impl,
    source_sort_key_with_language_impl,
    autoplay_url_by_language_priority_impl,
    source_selector_style_impl,
    sources_order_priority_impl,
    source_order_rank_impl,
    parse_trakt_compound_id_impl,
    get_setting,
):
    normalize_quality = lambda value: normalize_quality_impl(value)
    quality_counts_colored = lambda candidates: quality_counts_colored_impl(
        candidates
    )
    quality_rank = lambda value: quality_rank_impl(value, normalize_quality)
    compact_origin = lambda value: compact_origin_impl(value)
    language_flag = lambda language: language_flag_impl(language)

    def normalize_language_label(
        language, provider_name="", label="", title="", info="", stream_url=""
    ):
        return normalize_language_label_bridge(
            language=language,
            provider_name=provider_name,
            label=label,
            title=title,
            info=info,
            stream_url=stream_url or "",
            normalize_language_label_impl=normalize_language_label_impl,
        )

    def language_bucket_for_item(item):
        return language_bucket_for_item_bridge(
            item=item,
            language_normalizer=normalize_language_label,
            language_bucket_for_item_impl=language_bucket_for_item_impl,
        )

    language_section_title = lambda bucket_id: language_section_title_impl(bucket_id)
    source_selector_style = lambda: source_selector_style_impl(get_setting)
    sources_order_priority = lambda: sources_order_priority_impl(get_setting)
    source_order_rank = lambda item: source_order_rank_impl(
        item, sources_order_priority, quality_rank, compact_origin
    )
    source_sort_key_with_language = lambda item: source_sort_key_with_language_impl(
        item, language_bucket_for_item, source_order_rank
    )
    autoplay_url_by_language_priority = lambda clean, primary_bid, secondary_bid: (
        autoplay_url_by_language_priority_impl(
            clean, primary_bid, secondary_bid, language_bucket_for_item
        )
    )
    parse_trakt_compound_id = lambda result_id: parse_trakt_compound_id_impl(result_id)

    return {
        "normalize_quality": normalize_quality,
        "quality_counts_colored": quality_counts_colored,
        "quality_rank": quality_rank,
        "compact_origin": compact_origin,
        "language_flag": language_flag,
        "normalize_language_label": normalize_language_label,
        "language_bucket_for_item": language_bucket_for_item,
        "language_section_title": language_section_title,
        "source_sort_key_with_language": source_sort_key_with_language,
        "autoplay_url_by_language_priority": autoplay_url_by_language_priority,
        "source_selector_style": source_selector_style,
        "sources_order_priority": sources_order_priority,
        "source_order_rank": source_order_rank,
        "parse_trakt_compound_id": parse_trakt_compound_id,
    }
